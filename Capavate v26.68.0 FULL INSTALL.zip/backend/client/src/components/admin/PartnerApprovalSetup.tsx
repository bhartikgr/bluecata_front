import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import type { AnnualArrangement, ApprovalSetup, AnnualPreview } from "@shared/partnerApprovalSetup";

export type ApprovalSetupState = { enabled: boolean; setup: ApprovalSetup | null };
type Options = { tiers: string[]; currencies: { code: string; minorUnitExponent: number }[] };

export function PartnerApprovalSetup({ applicationId, disabled, onChange }: {
  applicationId: string; disabled?: boolean; onChange: (state: ApprovalSetupState) => void;
}) {
  const [enabled, setEnabled] = useState(false);
  const [options, setOptions] = useState<Options | null>(null);
  const [tier, setTier] = useState("");
  const [mode, setMode] = useState<AnnualArrangement["mode"]>("tier_price");
  const [currency, setCurrency] = useState("");
  const [minor, setMinor] = useState("");
  const [reason, setReason] = useState("");
  const [preview, setPreview] = useState<{ key: string; value: AnnualPreview } | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const key = JSON.stringify([applicationId, tier, mode, currency, minor]);
  const currentPreview = preview?.key === key ? preview.value : null;
  const base = `/api/admin/consortium/applications/${encodeURIComponent(applicationId)}/approval-preview`;
  const values: AnnualArrangement = {
    tier, mode, reason: reason.trim(),
    ...(mode !== "tier_price" ? { currency, amountMinor: mode === "free_exemption" ? 0 : Number(minor) } : {}),
  };
  const validAmount = mode !== "custom_annual" || (/^\d+$/.test(minor) && Number.isSafeInteger(Number(minor)) && Number(minor) > 0);

  useEffect(() => {
    onChange({ enabled, setup: enabled && currentPreview && reason.trim() && validAmount
      ? { ...values, expectedCharge: currentPreview.charge } : null });
  }, [enabled, key, reason, preview, onChange]);

  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    setError("");
    fetch(base, { credentials: "include" }).then(async r => {
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || "Membership options could not be loaded.");
      if (alive) setOptions(data);
    }).catch(e => { if (alive) setError(e.message); });
    return () => { alive = false; };
  }, [enabled, base]);

  async function refreshPreview() {
    setLoading(true); setError(""); setPreview(null);
    const requestedKey = key;
    try {
      if (!validAmount) throw new Error("Enter a positive whole number of minor units.");
      const qs = new URLSearchParams({ tier, mode });
      if (mode !== "tier_price") {
        qs.set("currency", currency);
        qs.set("amountMinor", String(mode === "free_exemption" ? 0 : Number(minor)));
      }
      const r = await fetch(`${base}?${qs}`, { credentials: "include" });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || "The annual charge could not be resolved.");
      setPreview({ key: requestedKey, value: data });
    } catch (e) { setError((e as Error).message); }
    finally { setLoading(false); }
  }

  const control = "w-full border border-border rounded p-2 text-sm bg-background";
  const exponent = options?.currencies.find(c => c.code === currency)?.minorUnitExponent;
  return <fieldset className="border border-border rounded p-3 mb-4 space-y-3" disabled={disabled}>
    <legend className="text-sm font-semibold px-1">Membership setup at approval</legend>
    <label className="flex items-start gap-2 text-sm">
      <input type="checkbox" checked={enabled} onChange={e => { setEnabled(e.target.checked); setPreview(null); }} />
      Choose a membership tier and annual arrangement
    </label>
    {!enabled ? <p className="text-xs text-muted-foreground">
      Existing approval behavior is unchanged. A new partner otherwise starts on Catalyst; its annual price must resolve.
    </p> : <>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-sm">Membership tier
          <select className={control} value={tier} onChange={e => setTier(e.target.value)}>
            <option value="">Select a tier</option>
            {options?.tiers.map(t => <option key={t} value={t}>{t.replaceAll("_", " ")}</option>)}
          </select>
        </label>
        <label className="text-sm">Annual arrangement
          <select className={control} value={mode} onChange={e => setMode(e.target.value as AnnualArrangement["mode"])}>
            <option value="tier_price">Use current price (retain any existing annual override)</option>
            <option value="free_exemption">Individual free exemption</option>
            <option value="custom_annual">Custom paid annual price</option>
          </select>
        </label>
        {mode !== "tier_price" && <label className="text-sm">Annual price currency
          <select className={control} value={currency} onChange={e => setCurrency(e.target.value)}>
            <option value="">Select an active currency</option>
            {options?.currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
          </select>
        </label>}
        {mode === "custom_annual" && <label className="text-sm">Annual amount (integer minor units)
          <input className={control} inputMode="numeric" value={minor} onChange={e => setMinor(e.target.value)} />
          {exponent !== undefined && <span className="text-xs text-muted-foreground">{10 ** exponent} minor units = 1 {currency}.</span>}
        </label>}
      </div>
      <label className="block text-sm">Membership setup reason (required)
        <textarea className={control} maxLength={1000} value={reason} onChange={e => setReason(e.target.value)} />
      </label>
      <p className="text-xs text-muted-foreground">
        Founding member is a membership tier, not an automatic billing exemption. Select Individual free exemption to approve without an annual invoice.
        This sets only the partner's own membership price, not company referral discounts or partner referral fees.
      </p>
      <Button type="button" variant="outline" size="sm" disabled={loading || !tier || !options || !validAmount ||
        (mode !== "tier_price" && !currency)} onClick={() => void refreshPreview()}>
        {loading ? "Checking annual charge…" : "Preview annual charge"}
      </Button>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      {currentPreview && <div role="status" className="rounded border p-3 text-sm space-y-1">
        <p>{currentPreview.outcome === "exempt" ? "Explicit free exemption: no annual invoice will be raised." :
          `Approval will raise one annual invoice for ${currentPreview.charge.amountMinor} ${currentPreview.charge.currency} minor units.`}</p>
        <p>Source: {currentPreview.charge.source === "partner_override" ? "individual partner arrangement" : "tier catalogue"}.
          This preview is advisory; approval rechecks the price and all existing agreement and compliance requirements.</p>
      </div>}
      {!currentPreview && <p className="text-xs text-muted-foreground">Preview the current charge before approving. Changing a pricing field invalidates the preview.</p>}
    </>}
  </fieldset>;
}
