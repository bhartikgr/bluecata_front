/**
 * PP2667 referral registration dates: admin dates, server-derived availability.
 * The browser never derives "open/closed" from its own clock: every availability
 * assertion below uses a server-supplied `state` that deliberately disagrees
 * with what the local clock would say.
 */
import React, { useState } from "react";
import { render, screen, waitFor, cleanup, fireEvent, act } from "@testing-library/react";
import { describe, it, expect, vi, afterEach } from "vitest";
import {
  AdminCompanyReferralPanel,
  PartnerCompanyReferralPanel,
  ReferralCodeInput,
  referralAvailabilityText,
  referralRegistrationWindowText,
} from "../CompanyReferralPanels";
import { apiRequest } from "@/lib/queryClient";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

vi.mock("@/lib/queryClient", () => ({ apiRequest: vi.fn() }));

afterEach(() => { cleanup(); vi.clearAllMocks(); });

function renderWithClient(ui: React.ReactElement) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(<QueryClientProvider client={queryClient}>{ui}</QueryClientProvider>);
}

const ENDPOINT = "/api/admin/partners/partner_win/company-referral-program";
const catalogue = {
  currencies: [{ code: "USD", minor_unit_exponent: 2 }],
  tiers: [{ id: "tier_pro", name: "Pro Tier", currency: "USD", annualPriceCents: 120000 }],
};
const baseTerms = {
  discountKind: "percent", discountBps: 1000, discountMinor: null, currency: "USD",
  feeMinor: 50000, feeCurrency: "USD", eligibleTierIds: ["tier_pro"],
  responseHours: 48, requestExpiryDays: 14, agreementRef: "AGR-WIN",
};
function code(over: Record<string, unknown> = {}, terms: Record<string, unknown> = {}) {
  return {
    id: "code_win", partnerId: "partner_win", code: "WINDOW10", status: "active", version: 3,
    maxReferrals: 10, acceptedCount: 2, bindingCount: 1, remaining: 7,
    createdAt: "2026-09-28T00:00:00Z", updatedAt: "2026-09-28T00:00:00Z",
    terms: { ...baseTerms, ...terms }, ...over,
  };
}
const json = (value: unknown) => ({ json: async () => value }) as any;
const lastPostTerms = () => {
  const call = vi.mocked(apiRequest).mock.calls.find(c => c[0] === "POST");
  return call ? (call[2] as any).terms : undefined;
};

describe("PP2667 admin registration dates", () => {
  it("prefills both UTC dates, labels them as inclusive UTC dates, and shows the server's availability", async () => {
    // The dates are far in the past/future, so the SERVER state is what must be shown even if a local clock disagrees.
    vi.mocked(apiRequest).mockResolvedValueOnce(json({
      codes: [code({ registrationWindow: { startsOn: "2999-01-01", endsOn: "2999-12-31", state: "closed", evaluatedOn: "2026-10-16" } },
        { registrationStartsOn: "2999-01-01", registrationEndsOn: "2999-12-31" })],
      catalogue,
    }));
    renderWithClient(<AdminCompanyReferralPanel partnerId="partner_win" />);
    await screen.findByDisplayValue("WINDOW10");
    const opens = await screen.findByLabelText("Registration opens (UTC date, optional)") as HTMLInputElement;
    const closes = screen.getByLabelText("Registration closes (UTC date, inclusive, optional)") as HTMLInputElement;
    expect(opens.type).toBe("date");
    expect(opens.value).toBe("2999-01-01");
    expect(closes.value).toBe("2999-12-31");
    const line = screen.getByTestId("referral-window").textContent!;
    expect(line).toContain("from 2999-01-01 through 2999-12-31 (UTC calendar dates, inclusive)");
    expect(line).toContain("Closed: stopped accepting new registrations after 2999-12-31 (UTC)");
    expect(line).toContain("already accepted keep their one-year benefit");
    // Capacity is reported separately and is unaffected by the window.
    expect(screen.getByTestId("referral-capacity").textContent).toContain("Accepted 2 · Pending 1 · Remaining 7 / 10");
    const help = screen.getByTestId("referral-window-help").textContent!;
    expect(help).toContain("UTC calendar dates");
    expect(help).toContain("new offer version");
  });

  it("an old code without dates shows no limit and sends no date keys when left blank", async () => {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ codes: [code()], catalogue }));
    renderWithClient(<AdminCompanyReferralPanel partnerId="partner_win" />);
    await screen.findByDisplayValue("WINDOW10");
    await screen.findByLabelText("Registration opens (UTC date, optional)");
    expect(screen.getByTestId("referral-window").textContent).toContain("No registration date limit.");
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ code: code({ version: 4 }) }));
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Save referral offer/i })); });
    await waitFor(() => expect(lastPostTerms()).toBeDefined());
    const terms = lastPostTerms();
    expect(terms).not.toHaveProperty("registrationStartsOn");
    expect(terms).not.toHaveProperty("registrationEndsOn");
    expect(vi.mocked(apiRequest).mock.calls.find(c => c[0] === "POST")![2]).toMatchObject({ id: "code_win", expectedVersion: 3 });
  });

  it("sends entered dates; clearing a stored date sends an explicit null while an untouched bound is resent", async () => {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({
      codes: [code({}, { registrationStartsOn: "2026-10-01", registrationEndsOn: "2026-12-31" })], catalogue,
    }));
    renderWithClient(<AdminCompanyReferralPanel partnerId="partner_win" />);
    await screen.findByDisplayValue("WINDOW10");
    const closes = await screen.findByLabelText("Registration closes (UTC date, inclusive, optional)") as HTMLInputElement;
    await waitFor(() => expect(closes.value).toBe("2026-12-31"));
    act(() => { fireEvent.change(closes, { target: { value: "" } }); });
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ code: code({ version: 4 }, { registrationStartsOn: "2026-10-01" }) }));
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Save referral offer/i })); });
    await waitFor(() => expect(lastPostTerms()).toBeDefined());
    expect(lastPostTerms()).toMatchObject({ registrationStartsOn: "2026-10-01", registrationEndsOn: null });
  });

  it("a brand-new code with blank dates sends no date keys; filled dates are sent as plain strings", async () => {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ codes: [], catalogue }));
    renderWithClient(<AdminCompanyReferralPanel partnerId="partner_win" />);
    const create = await screen.findByRole("button", { name: /Create new code/i });
    act(() => { fireEvent.click(create); });
    await screen.findByLabelText("Registration opens (UTC date, optional)");
    const fill = (label: RegExp | string, value: string) => act(() => { fireEvent.change(screen.getByLabelText(label), { target: { value } }); });
    const inputs = await screen.findAllByLabelText(/Referral code/i);
    act(() => { fireEvent.change(inputs.find(n => n.tagName === "INPUT")!, { target: { value: "NEWWIN1" } }); });
    act(() => { fireEvent.change(screen.getByRole("combobox", { name: /Referral code status/i }), { target: { value: "active" } }); });
    fill(/Company discount \(%\)/i, "10");
    fill(/Eligible subscription currency/i, "USD");
    fill(/Fixed partner referral fee/i, "500.00");
    fill(/Partner fee currency/i, "USD");
    fill(/Total referrals allowed/i, "5");
    act(() => { fireEvent.click(screen.getByRole("checkbox", { name: /Pro Tier/i })); });
    fill(/Partner response interval/i, "48");
    fill(/Introduction request expiry/i, "14");
    fill(/Referral agreement reference/i, "AGR-NEW");
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ code: code() }));
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Save referral offer/i })); });
    await waitFor(() => expect(lastPostTerms()).toBeDefined());
    expect(lastPostTerms()).not.toHaveProperty("registrationStartsOn");
    expect(lastPostTerms()).not.toHaveProperty("registrationEndsOn");
    expect(vi.mocked(apiRequest).mock.calls.find(c => c[0] === "POST")![2]).not.toHaveProperty("id");

    // Wait for the success notice (the follow-up refetch has been dispatched by then), then save again with dates.
    await screen.findByRole("status");
    vi.mocked(apiRequest).mockClear();
    fill("Registration opens (UTC date, optional)", "2026-10-16");
    fill("Registration closes (UTC date, inclusive, optional)", "2026-10-16");
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ code: code({ version: 4 }) }));
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Save referral offer/i })); });
    await waitFor(() => expect(lastPostTerms()).toBeDefined());
    expect(lastPostTerms()).toMatchObject({ registrationStartsOn: "2026-10-16", registrationEndsOn: "2026-10-16" });
  });

  it("refuses an end before the start locally and sends nothing", async () => {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ codes: [code()], catalogue }));
    renderWithClient(<AdminCompanyReferralPanel partnerId="partner_win" />);
    await screen.findByDisplayValue("WINDOW10");
    const opens = await screen.findByLabelText("Registration opens (UTC date, optional)");
    const closes = screen.getByLabelText("Registration closes (UTC date, inclusive, optional)");
    act(() => { fireEvent.change(opens, { target: { value: "2026-10-17" } }); });
    act(() => { fireEvent.change(closes, { target: { value: "2026-10-16" } }); });
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Save referral offer/i })); });
    expect((await screen.findByRole("alert")).textContent).toContain("Registration closes cannot be before registration opens.");
    expect(vi.mocked(apiRequest).mock.calls.some(c => c[0] === "POST")).toBe(false);
  });

  it("shows the server's typed refusal text when a save is rejected", async () => {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ codes: [code()], catalogue }));
    renderWithClient(<AdminCompanyReferralPanel partnerId="partner_win" />);
    await screen.findByDisplayValue("WINDOW10");
    const opens = await screen.findByLabelText("Registration opens (UTC date, optional)");
    act(() => { fireEvent.change(opens, { target: { value: "2026-10-16" } }); });
    vi.mocked(apiRequest).mockRejectedValueOnce(new Error("registrationEndsOn cannot be before registrationStartsOn"));
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Save referral offer/i })); });
    expect((await screen.findByRole("alert")).textContent).toContain("registrationEndsOn cannot be before registrationStartsOn");
  });
});

describe("PP2667 founder offer display", () => {
  function Harness() {
    const [value, setValue] = useState("WINDOW10");
    return <ReferralCodeInput value={value} onChange={setValue} />;
  }
  const offer = (extra: Record<string, unknown> = {}) => ({
    code: "WINDOW10", partnerName: "Partner Win", version: 3, remaining: 4,
    terms: { discountKind: "percent", discountBps: 1000, discountMinor: null, currency: "USD", eligibleTierIds: ["tier_pro"] },
    ...extra,
  });

  it("shows the server-supplied UTC window with the offer", async () => {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ offer: offer({ registrationWindow: { startsOn: "2026-10-01", endsOn: "2026-12-31", state: "open" } }) }));
    renderWithClient(<Harness />);
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Check code/i })); });
    const line = await screen.findByTestId("referral-offer-window");
    expect(line.textContent).toBe("New registrations accepted from 2026-10-01 through 2026-12-31 (UTC calendar dates, inclusive).");
    expect(screen.getByTestId("referral-offer-preview").textContent).toContain("4 registrations remaining.");
  });

  it("an unbounded offer says there is no limit", async () => {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({ offer: offer() }));
    renderWithClient(<Harness />);
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Check code/i })); });
    expect((await screen.findByTestId("referral-offer-window")).textContent).toBe("No registration date limit.");
  });

  it("a code outside its window shows the server message and still allows clearing the code", async () => {
    vi.mocked(apiRequest).mockRejectedValueOnce(new Error("This referral code stopped accepting new registrations after 2026-10-18 (UTC date). Register without the code to continue."));
    renderWithClient(<Harness />);
    act(() => { fireEvent.click(screen.getByRole("button", { name: /Check code/i })); });
    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toContain("stopped accepting new registrations after 2026-10-18 (UTC date)");
    expect(alert.textContent).toContain("You may clear the code to continue without its benefit.");
    expect(screen.queryByTestId("referral-offer-preview")).toBeNull();
  });
});

describe("PP2667 partner display and pure wording", () => {
  async function partnerPanel(window: unknown, terms: Record<string, unknown> = {}) {
    vi.mocked(apiRequest).mockResolvedValueOnce(json({
      codes: [code({ registrationWindow: window }, terms)],
      summary: { accepted: 2, pending: 1 }, referrals: [],
    }));
    renderWithClient(<PartnerCompanyReferralPanel />);
    return (await screen.findByTestId("partner-referral-window")).textContent!;
  }

  it("renders each server state verbatim, even when it disagrees with the local clock", async () => {
    // Dates in the far future but state 'open' from the server: the page must say open.
    expect(await partnerPanel({ startsOn: null, endsOn: "2999-12-31", state: "open", evaluatedOn: "2026-10-16" }, { registrationEndsOn: "2999-12-31" }))
      .toContain("Open for new registrations today (UTC).");
    cleanup(); vi.clearAllMocks();
    expect(await partnerPanel({ startsOn: "2000-01-01", endsOn: null, state: "not_yet_open", evaluatedOn: "1999-12-31" }, { registrationStartsOn: "2000-01-01" }))
      .toContain("Not yet open: registrations begin on 2000-01-01 (UTC).");
    cleanup(); vi.clearAllMocks();
    const closed = await partnerPanel({ startsOn: null, endsOn: "2999-12-31", state: "closed", evaluatedOn: "3000-01-01" }, { registrationEndsOn: "2999-12-31" });
    expect(closed).toContain("through 2999-12-31 (UTC calendar date, inclusive), with no start date.");
    expect(closed).toContain("Closed: stopped accepting new registrations after 2999-12-31 (UTC).");
  });

  it("keeps capacity separate from availability and still shows the registration link while closed", async () => {
    await partnerPanel({ startsOn: null, endsOn: "2000-01-01", state: "closed", evaluatedOn: "2026-10-16" }, { registrationEndsOn: "2000-01-01" });
    expect(screen.getByTestId("partner-referral-capacity").textContent).toContain("Accepted 2 · Pending 1 · Remaining 7 of 10");
    expect((screen.getByLabelText("Your shareable company registration link") as HTMLInputElement).value).toContain("referralCode=WINDOW10");
  });

  it("an old payload without a window object falls back to the stored dates with no availability claim", async () => {
    const text = await partnerPanel(undefined, { registrationStartsOn: "2026-10-01", registrationEndsOn: "2026-10-31" });
    expect(text).toContain("from 2026-10-01 through 2026-10-31");
    expect(text).not.toMatch(/Open for new|Not yet open|Closed:/);
  });

  it("pure wording helpers cover every bound combination and are UTC-labelled", () => {
    expect(referralRegistrationWindowText(null)).toBe("No registration date limit.");
    expect(referralRegistrationWindowText({ startsOn: null, endsOn: null })).toBe("No registration date limit.");
    expect(referralRegistrationWindowText({ startsOn: "2026-10-01", endsOn: null })).toContain("from 2026-10-01 (UTC calendar date, inclusive), with no end date");
    expect(referralRegistrationWindowText({ startsOn: null, endsOn: "2026-10-31" })).toContain("through 2026-10-31 (UTC calendar date, inclusive), with no start date");
    expect(referralAvailabilityText({ startsOn: null, endsOn: null })).toBe("");
    expect(referralAvailabilityText({ startsOn: null, endsOn: null, state: "open" })).toContain("Open for new registrations today (UTC)");
  });
});
