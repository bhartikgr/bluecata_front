# Capavate v26.69.0 — engineering and verification

Release: **v26.69.0** (Pricing & Payments, Wave A + Wave B). Source commit: `5da26bce63ef9845f2d287e438bc8bd8c282f983` (= `backend/INSTALL_RECEIPT.json → sourceCommit`, branch `pp2669-wave-ab`). Baseline: v26.68.0 (`7edffa75…`, the live release at build time). 37 commits; 159 paths changed (92 source, 58 test files, 9 build/metadata).

## 1. What was built (by contract item)

**Wave A** (owner rulings applied to existing surfaces): A1 pricing readiness census + console *Start here* panel; A2 approval options from advertisable tiers; A4 positioning display policy (`shared/pricingDisplay.ts`, `GET /api/price-display-policy`, admin switch); A5/A10 legacy founder charge and payments-charge endpoints retired (410, write nothing); A6 payment-gateway diagnostics (10,000-row retention); A8 computed current-state lines; A9 monthly refusal without a canonical monthly row; A11 `/consortium/pricing` signed-in, by approval only (R9).

**Wave B** (new money paths and data operations): B0 partner activation sync (listener + sweep); B1-a Collective member categories registry (R3) and B1-b application fee charged at approval with idempotent hosted checkout (R4); B2 canonical company standing + repointed readers (R5); B3 founding member free, exemption grants open-ended (R2/R8); B4-a invoice disposition data op with the $3,360.00 guard and manifest-drift failure (R6); B4-b record-only refunds with reason + Airwallex reference, atomic (R7); B6 promotions pending clarification (R12); B7 discount codes with reservations, no stacking, provider-confirmed release (R10/R11); B8 referral enrolment/approval delivery as a resumable idempotent record, earnings closures; B9 no ÷12 derivation in the store; B10 display policy across silos; B11 readiness endpoint. Data ops `pp2669-01/02/03` run once at boot and are recorded in `data_ops_applied`.

## 2. Changed source paths (92)

- `client/src/App.tsx`
- `client/src/components/admin/PartnerApprovalSetup.tsx`
- `client/src/lib/priceDisplayPolicy.ts`
- `client/src/lib/usePublicPricing.ts`
- `client/src/pages/admin/AdminFeesConsolidated.tsx`
- `client/src/pages/admin/AdminPartnerBillingOps.tsx`
- `client/src/pages/admin/CollectiveApplications.tsx`
- `client/src/pages/admin/CollectiveSubscriptions.tsx`
- `client/src/pages/admin/Companies.tsx`
- `client/src/pages/admin/FeeHub.tsx`
- `client/src/pages/admin/PartnerDetail.tsx`
- `client/src/pages/admin/PartnerFeeSchedules.tsx`
- `client/src/pages/admin/PartnerPL.tsx`
- `client/src/pages/admin/Pricing.tsx`
- `client/src/pages/collective/CollectiveMembership.tsx`
- `client/src/pages/collective/MembershipPage.tsx`
- `client/src/pages/consortium/ConsortiumPricing.tsx`
- `client/src/pages/founder/Company.tsx`
- `client/src/pages/founder/Settings.tsx`
- `client/src/pages/founder/Subscribe.tsx`
- `client/src/pages/investor/ApplyToCollective.tsx`
- `client/src/pages/partner/PartnerBilling.tsx`
- `client/src/pages/partner/PartnerDashboard.tsx`
- `client/src/pages/partner/PartnerSubscribe.tsx`
- `migrations/0242_pp2669_platform_ledgers.sql`
- `migrations/0243_pp2669_collective_categories_and_fee.sql`
- `migrations/0244_pp2669_discount_redemptions_and_referral_closure.sql`
- `package-lock.json`
- `package.json`
- `scripts/verify-install.mjs`
- `server/adminCollectiveRoutes.ts`
- `server/adminContactsStore.ts`
- `server/adminFeeTierRoutes.ts`
- `server/adminPlatformStore.ts`
- `server/adminPricingStore.ts`
- `server/collectiveAppStore.ts`
- `server/collectiveBillingStore.ts`
- `server/collectiveMembershipStore.ts`
- `server/collectiveRoutes.ts`
- `server/collectiveSubscriptionConfigStore.ts`
- `server/collectiveWaitlistRoutes.ts`
- `server/companyReferralEarningsRoutes.ts`
- `server/companyReferralRoutes.ts`
- `server/consortiumApplyStore.ts`
- `server/db/migrations/0242_pp2669_platform_ledgers.sql`
- `server/db/migrations/0243_pp2669_collective_categories_and_fee.sql`
- `server/db/migrations/0244_pp2669_discount_redemptions_and_referral_closure.sql`
- `server/index.ts`
- `server/invoiceStore.ts`
- `server/lib/airwallexCollective.ts`
- `server/lib/airwallexGateway.ts`
- `server/lib/capavateCompanyStanding.ts`
- `server/lib/collectiveApplicationFee.ts`
- `server/lib/collectiveSchemaSelfHeal.ts`
- `server/lib/companyReferralCheckout.ts`
- `server/lib/companyReferralEarnings.ts`
- `server/lib/dataOps/index.ts`
- `server/lib/dataOps/op01CatalystToNexus.ts`
- `server/lib/dataOps/op02ExemptionGrants.ts`
- `server/lib/dataOps/op03InvoiceDisposition.ts`
- `server/lib/dataOps/runner.ts`
- `server/lib/discountCodeCheckoutRegistry.ts`
- `server/lib/discountCodeRedemptionStore.ts`
- `server/lib/founderBillingExtensions.ts`
- `server/lib/partnerActivationSync.ts`
- `server/lib/partnerApprovalInvoice.ts`
- `server/lib/partnerApprovalSetup.ts`
- `server/lib/partnerBillingStore.ts`
- `server/lib/partnerEffectivePlan.ts`
- `server/lib/partnerExemptionSync.ts`
- `server/lib/partnerFeeAdminDisplayPolicy.ts`
- `server/lib/partnerFeeAdminRoutes.ts`
- `server/lib/partnerSelfServiceRoutes.ts`
- `server/lib/partnerSubscriptionStore.ts`
- `server/lib/paymentGatewayDiagnostics.ts`
- `server/lib/priceDisplayPolicyRoutes.ts`
- `server/lib/pricingReadiness.ts`
- `server/lib/requireCollectiveMember.ts`
- `server/lib/wave14MoneyRoutes.ts`
- `server/membershipStore.ts`
- `server/multiCompanyStore.ts`
- `server/partnerRoutes.ts`
- `server/paymentStore.ts`
- `server/pricingModelStore.ts`
- `server/pricingTiersStore.ts`
- `server/publicPricingRoutes.ts`
- `server/routes.ts`
- `server/spvEngineRoutes.ts`
- `server/subscriptionTierStore.ts`
- `shared/partnerApprovalSetup.ts`
- `shared/pricingDisplay.ts`
- `shared/schema.ts`

## 3. Test files added or changed (58)

- `client/src/pages/admin/__tests__/pp2666_w1_admin_fees_navigation_dom.test.tsx`
- `client/src/pages/admin/__tests__/pp2667_partner_setup_dom.test.tsx`
- `client/src/pages/admin/__tests__/pp2669_a1_a11_console_mirror_and_codes_dom.test.tsx`
- `client/src/pages/admin/__tests__/pp2669_a6_gateway_diagnostics_card_dom.test.tsx`
- `client/src/pages/admin/__tests__/pp2669_b11_readiness_panel_dom.test.tsx`
- `client/src/pages/admin/__tests__/pp2669_b1a_member_categories_card_dom.test.tsx`
- `client/src/pages/admin/__tests__/pp2669_b2_b4_admin_pricing_dom.test.tsx`
- `client/src/pages/admin/__tests__/pp2669_b6_partner_pl_total_label_dom.test.tsx`
- `client/src/pages/admin/__tests__/w61b_refund_unknown_amount_blocks.test.tsx`
- `client/src/pages/collective/__tests__/pp2669_a4_membership_subscribe_gate_dom.test.tsx`
- `client/src/pages/collective/__tests__/pp2669_b1b_membership_pending_payment_dom.test.tsx`
- `client/src/pages/consortium/__tests__/pp2669_b10_consortium_pricing_invitation_dom.test.tsx`
- `server/__tests__/_pp2669WpmFixtures.ts`
- `server/__tests__/adminPricing.test.ts`
- `server/__tests__/founderSinglePlan.test.ts`
- `server/__tests__/pp2666_compliant_approval_contract_SOL.test.ts`
- `server/__tests__/pp2669_a10_payments_charge_retired.test.ts`
- `server/__tests__/pp2669_a11_discount_code_patch_and_registry.test.ts`
- `server/__tests__/pp2669_a1_atomic_tier_price_write.test.ts`
- `server/__tests__/pp2669_a1_route_audit_in_tx.test.ts`
- `server/__tests__/pp2669_a2_approval_catalogue.test.ts`
- `server/__tests__/pp2669_a5_legacy_founder_charge_retired.test.ts`
- `server/__tests__/pp2669_a6_payment_gateway_diagnostics.test.ts`
- `server/__tests__/pp2669_a8_current_state.test.ts`
- `server/__tests__/pp2669_a9_cycle_not_offered_and_x12_refusal.test.ts`
- `server/__tests__/pp2669_admin_guard_probe.test.ts`
- `server/__tests__/pp2669_b0_partner_activation_sync.test.ts`
- `server/__tests__/pp2669_b10_public_pricing_no_consortium_amounts.test.ts`
- `server/__tests__/pp2669_b11_pricing_readiness.test.ts`
- `server/__tests__/pp2669_b1a_member_category.test.ts`
- `server/__tests__/pp2669_b1a_schema_self_heal.test.ts`
- `server/__tests__/pp2669_b1b_application_fee_flow.test.ts`
- `server/__tests__/pp2669_b2_company_standing.test.ts`
- `server/__tests__/pp2669_b2_r5_admin_companies_standing_http.test.ts`
- `server/__tests__/pp2669_b3a_catalyst_to_nexus.test.ts`
- `server/__tests__/pp2669_b3b_founding_member_free.test.ts`
- `server/__tests__/pp2669_b3c_exemption_grant_sync.test.ts`
- `server/__tests__/pp2669_b4a_invoice_disposition.test.ts`
- `server/__tests__/pp2669_b4b_record_refund.test.ts`
- `server/__tests__/pp2669_b7_discount_code_checkout.test.ts`
- `server/__tests__/pp2669_b8_referral_enrol_validation_closure.test.ts`
- `server/__tests__/pp2669_b9_no_div12_guard.test.ts`
- `server/__tests__/pp2669_b9_public_pricing_monthly_equivalent.test.ts`
- `server/__tests__/pp2669_r12_promotions_not_applied.test.ts`
- `server/__tests__/pp2669_r2_attempt_failure_not_terminal.test.ts`
- `server/__tests__/referral_r2_checkout_http.test.ts`
- `server/__tests__/referral_r2_payments.test.ts`
- `server/__tests__/v23411_phase2_subscribe_persist.test.ts`
- `server/__tests__/v2343_bug001_paid_plan_fresh_founder.test.ts`
- `server/__tests__/v23_8_fixes.test.ts`
- `server/__tests__/v25_47_apd020_consortium_pricing.test.ts`
- `server/__tests__/v25_47_high2_reapprove_idempotency.test.ts`
- `server/__tests__/w56_tier_write_path.test.ts`
- `server/__tests__/w61b_r42_refund_amount_fence.test.ts`
- `server/__tests__/wave44_zero_counters.test.ts`
- `server/__tests__/wave5_money_billing.test.ts`
- `server/__tests__/waveW13_partner_subscription_shape.test.ts`
- `shared/__tests__/pp2669_b9_pricing_display.test.ts`

## 4. Commits (newest first)

- `5da26bc` release: v26.69.0 production build outputs (client rebuilt after the member-category card)
- `1ebd7d0` PP2669 B1-a (R3): member-category registry editable in the console (label/description, retire/reinstate, per-category live-package line)
- `af70e88` release: v26.69.0 — version literal (package.json, package-lock.json, scripts/verify-install.mjs with 0242–0244 mirror checks) and production build outputs
- `93058c9` PP2669 R2 L3: refund ledger announcement failure after commit is logged, not thrown
- `4e5bf5f` PP2669 fix re-review R2: NEW-1 discount slot released on subscription.failed only after the provider confirms the intent terminal (sacred adapter untouched); NEW-2 referral effects stamped
- `440503b` PP2669 fix re-review N4: referral approval delivery is a strict durable workflow record with per-effect idempotency (attribution upsert, notification link, bridge aggregate, invite outbox 
- `7efc56b` PP2669 fix re-review N3: strict tx-aware refund ledger write (recordLedgerEntryStrictInTx) — insert failure rolls the refund back; chain/sync/cache announced only after commit
- `824af49` PP2669 fix re-review N1+N2: discount capacity released only after provider-confirmed cancel (gateway cancelPaymentIntent; attach failure cancels first); application fee: attempt failures a
- `9eb4d83` PP2669 regression fixes: PartnerApprovalSetup DOM test under QueryClientProvider; membership-standing panel reports malformed response; B9 null-monthly assertions in adminPricing/founderSi
- `96aa524` PP2669 B4-b review fix (Grok 5): refund API requires the Airwallex reference (REFUND_REFERENCE_REQUIRED); dialog relabelled Record refund
- `8aa063e` PP2669 R12 review fix: partner checkout never applies a promotion (acknowledged, list price charged); approving a promotion refused 409; Promotions tab computed banner + Approve disabled; 
- `563bd3f` PP2669 B8-a review fix: durable approval-completion marker; a live promotion with no completion is retried, not refused
- `d44c39d` PP2669 B4-a review fix: op03 fails on manifest drift (nothing written, data_op_failed on healthz) instead of silently skipping
- `c0bef1d` PP2669 B4-b (R7): Ledger & Invoices quick refund is record-only with reason + Airwallex reference; console nav test fixtures for readiness + member categories
- `b80cf0b` PP2669 B4-b review fixes: refund ledger line, status and refund invoice in ONE transaction (rollback test); API requires a reason (REFUND_REASON_REQUIRED)
- `0fd183d` PP2669 B1-b review fix: ambiguous gateway create keeps the charge pending on the same idempotency key (no duplicate intents); webhook binds unbound charges via order/metadata; quote refuse
- `c401434` PP2669 B7 review fixes: discount checkout not consumed by a non-applying referral; bound reservations never released on persist failure; sweep keeps capacity until the gateway confirms, re
- `5d3881e` PP2669 B2/R5 review fix: /api/me hasPaidPlan, admin companies list and /api/subscriptions/mine answer from company standing; legacy row only as legacyRecord; Companies.tsx filters on stand
- `1f9769f` PP2669 B9/PP-15: admin pricing tiers no longer derive a monthly figure from annual (null when monthly not offered)
- `95d0559` PP2669 B2+B4: canonical company standing (R5) with admin history + founder overlay; invoice dispositions data op (R6), restore/unmark, record-only refunds (R7) with referral hold and earni
- `15e24ec` PP2669 B1: Collective member categories + DB-authored packages (R3), application fee charged at approval with pending_payment, webhook/verify/waive, applicant endpoints, schema self-heal; 
- `2c86b45` PP2669 B8-c: earnings report shows closures, closed bucket, admin close action
- `28c4bd8` PP2669 integrator: boot sweeps (partner activation, discount reservations), readiness route + console panel, tier-change exemption sync hook, test updates for R2/B8-c/B9
- `b771151` PP2669 B7: routes.ts — POST /api/billing/plan reserve-before-intent, POST /api/billing/plan/quote, GET /api/billing/tiers display fields, checkout registry connection
- `c4cbb6b` PP2669 B7+B8: discount-code redemption ledger connected to Capavate Annual checkout (quote, reserve-before-intent, finaliser, sweep, admin release); referral approve/enrol hardening, save-
- `c4da14a` PP2669 B9+B10+B6+B11: monthly-equivalent display on public pricing, /12 guard, consortium pricing invitation-only (R9), P&L label (R14), pricing readiness library
- `95cb981` PP2669 B0+B3: partner activation sync (listener+sweep), tier_free end-to-end (R2), exemption grant sync (R8), data ops 01/02 (R1 catalyst→nexus, grant backfill), default tier from policy
- `881a885` PP2669 integrator: data-ops boot wiring + healthz data_op_failed; console display-flag switch, Used/Reserved/Remaining, R12 promotions notice, comped ledger link
- `41ea4df` PP2669 A1 re-review fixes: publish committed audit to activity log, IMMEDIATE tx, onAudit after commit, audit billingPeriod actual, lifecycle key; A6 error text
- `07486ea` PP2669 Wave B foundation: migrations 0242-0244 (+mirrors), data-ops runner, shared pricingDisplay helper, show_monthly_equivalent display flag + admin PUT
- `86bc60c` PP2669 Wave A review fixes: A1 audit in tx + post-commit publish + route tests; A5 path-variant pre-empt; A6 camelCase rows + error state + DOM test; A8 policy type; A9 monthly refusal + r
- `9b71dc0` PP2669 A4+A9: Collective Subscribe gate; no default/derived cadence on Capavate checkout and tiers; partner forbid_x12 honoured; referral quote refuses un-offered cadence
- `f11eb49` PP2669 A8 console lines + A6 gateway diagnostics card
- `fcb2083` PP2669 A5+A10+A6: retire legacy founder charge and demo payments charge (410); gateway diagnostics observer
- `9140141` PP2669 A2+A8: approval options from advertisable tiers (archived not assignable), computed current-state lines
- `ddbda45` PP2669 A11: discount-code PATCH validation, server-owned usesCount, checkout-connection registry, honest tab status; A1 mirror DOM test
- `e5878d3` PP2669 A1: atomic legacy→canonical tier price write; read-only mirror card; stale copy fixed

## 5. Verification actually run (all on the final tree unless stated)

| Gate | Result |
|---|---|
| Sacred protected check (`SPEC_ROOT=$PWD/spec npm run sacred`) | **SACRED OK: 48/48** at `5da26bc` (re-run on the shipped files by the archive reviewer) and at every intermediate commit that was reviewed. `server/paymentGatewayAdapter.ts` (WAIVER-8 hash) deliberately untouched. |
| Typecheck harness over the 82 touched source files | **0 new diagnostics**; 30 pre-existing diagnostics in 6 files (`routes.ts` ×12, `adminContactsStore.ts` ×8, `consortiumApplyStore.ts` ×3, `multiCompanyStore.ts` ×2, `adminPricingStore.ts` ×2, `client/src/pages/founder/Company.tsx` ×3) at lines not changed by this release. |
| Focused PP2669 suite (every test file mentioning PP2669) | **55 files / 538 tests passed** at `93058c9` (`records/focused_pp2669_suite_55_files.txt`, `--maxWorkers=2`); the one later source change (`1ebd7d0`, below) adds a 56th file, run green with its neighbour (`pp2669_b1a_member_categories_card_dom` 3/3, `w137_collective_subscriptions_minor_render` 6/6). |
| Broad regression: 594 affected test files on HEAD; 212 candidates re-run file-for-file on HEAD **and** on the untouched baseline | 165 pre-existing (fail identically on v26.68.0), 39 green on both, 2 fixed by this release, 6 new → all resolved (`REGRESSION_CLASSIFICATION.md`, `records/regression_head/`, `records/regression_baseline/`). |
| Migrations on a fresh database (`DATABASE_URL=file:… NODE_ENV=production tsx server/db/migrate.ts`) | 216 files, 215 applied, `0040_perf_indexes` PENDING exactly as on v26.68.0 (`records/fresh_db_migrate.log`). |
| Compiled-server boot on a fresh database (`node dist/index.cjs`, production env with test gateway credentials) | Run twice: at `af70e88` (same `dist/index.cjs` as shipped — the later commit changed only the client bundle; `records/fresh_db_boot_*`) and from the **extracted final installer** at `5da26bc` (`records/extracted_install_rehearsal/`): `/api/healthz` ok, version 26.69.0, buildSha 5da26bce…, migration ledger 244/244, no `data_op_failed`; data ops `pp2669-01/02/03` applied with benign skips on an empty database; served assets `index-DcE2qXR4.js` / `index-B2HY1bnY.css`; anonymous admin routes 401; `/api/pricing-public` shows "$70.00 per month, billed annually ($840.00/yr)" and partners "By approval". |
| Admin-guard probe for the 12 new admin routes | `server/__tests__/pp2669_admin_guard_probe.test.ts` 12/12 (anonymous → 401/403). |
| Independent reviews | Wave A: Sol, Grok, Opus (HOLD → fixed → Opus re-review APPROVE). Wave B: Sol, Grok, Opus (HOLD, 17 findings → fixed); fix re-review round 1 Sol (HOLD, N1–N4 by fault injection → fixed); round 2 Opus (N1–N3 closed, NEW-1/2/3 → fixed); round 3 Sol **APPROVE** at `93058c9` (78/78 focused tests, sacred 48/48). **One source commit landed after that approval:** `1ebd7d0` — the member-category editor card on the Collective Subscriptions tab (client only; it calls the already-reviewed `PUT /api/admin/collective/member-categories/:slug`), with its DOM test; it was covered by the archive review (`ARCHIVE_REVIEW_v26_69_0.md`, which found the documentation gap this paragraph closes) and by a focused re-review (`ARCHIVE_REVIEW_R2_v26_69_0.md`). All reports in the reviews archive; every finding's disposition in `WAVE_B_REVIEW_DISPOSITION.md`. |
| Extracted-install rehearsal | See `FINAL_RELEASE_RECEIPT.md` (performed on the packaged installer after assembly). |

## 6. Retained named failures (not caused by this release)

The 165 test files that fail identically on the untouched v26.68.0 baseline are listed by name with per-file failing counts in `REGRESSION_CLASSIFICATION.md`. Notable families: `wave47_*`, `slide13c_b1_*` (fixture lacks `company_referral_program_claim`), `wave28_item1` test 13 (stale pinned route set — the 11 new PP2669 admin routes are protected by the blanket `requireAdmin` mount at `routes.ts:1128`, proven by the guard probe), `sprint28_billing` ×5, `w2_consortium` ×4, `v23_9_fixes` ×6, `wave44_approval_invoice` ×3, `frontendBackendContract` ×2, `wave202_itemA/B`, and the pre-existing restyle-drop detector (stale `baseline.json`). None was weakened, skipped or re-baselined.

## 7. Known limitations carried into this release

- Promotions (R12) are intentionally inert until the owner's clarification (one constant: `PARTNER_PROMOTIONS_APPLY_AT_CHECKOUT`).
- Member Subscribe for Collective categories stays disabled until the owner answers whether the application fee is the first-year dues.
- The sacred gateway adapter still marks a canonical subscription `failed` on an Airwallex attempt-level failure; the discount-code capacity invariant is enforced independently in the discount store (provider confirmation before release).
- The partner referral approval queue (`/api/admin/partner-referrals`) has no dedicated admin page (pre-existing); its `enrolment_failed` / `delivery_incomplete` states are visible through the API and the admin audit.
- No browser (end-to-end UI) run was made for v26.69.0; DOM behaviour is covered by the jsdom suites listed above. Live acceptance on the host remains Avinay's gate.
