# VERDICT: APPROVE

Round 2 verification passes. The clobbered client terminal guards are now present in the real current source file.

## Gate results
- TypeScript gate: `npx tsc --noEmit | grep -c "error TS"` = **598** (expected 598). Full log: `gate_c1_round2_gpt55_tsc_full.txt`.
- Sacred checksum gate: **40/40 OK**. Full log: `gate_c1_round2_gpt55_sacred_full.txt`.
- Money checksum: `server/captableCommitStore.ts` sha16 = **01cd36130ee1c0cb**.
- Silent-drop guard: **exit 0**, counts **926 routes / 194 pages / 92 nav**. Full log: `gate_c1_round2_gpt55_guard_full.txt`.
- Targeted tests: **3 files passed / 20 tests passed**; `waveC1_invitation_terminal_guards.test.ts` specifically **4/4 passed**. Full log: `gate_c1_round2_gpt55_vitest_full.txt`.

## Code confirmations
- `client/src/pages/founder/RoundDetail.tsx:532-534` now disables resend for `accepted || revoked`, extend for `revoked || accepted`, and revoke for `revoked`.
- `server/roundInvitationsStore.ts:834-840` throws `ALREADY_REVOKED` before any revoke DB write/cache mutation; `server/roundInvitationsStore.ts:891-898` throws `INVITATION_REVOKED` / `INVITATION_ACCEPTED` before extend mutation; `server/roundInvitationsStore.ts:989-995` throws `INVITATION_REVOKED` before token generation, DB update, or email.
- Persist-first / zero-row guard logic remains below the new store guards for revoke and extend, and resend still updates DB before cache/email for live invitations.
- `server/routes.ts:2832-2868`, `server/routes.ts:2885-2902`, and `server/routes.ts:2924-2941` return typed 409s for terminal states; revoke already-revoked returns before `roundInvitationsNotifyRevoked`, so there is no re-notification.
- `client/src/pages/founder/Rounds.tsx:21` includes `createdAt`; `client/src/pages/founder/Rounds.tsx:159-165` sorts a copied array newest-first by `createdAt`, falls back safely to `0` when missing, and uses deterministic id tiebreak.
- `/api/rounds` returns the merged round object via spread at `server/routes.ts:1602-1608`; round objects include `createdAt` from `server/roundsStore.ts:70` and DB mapping at `server/roundsStore.ts:119`.
- Wave C1 source diff is scoped to the expected five files; no C1 migration, payment/Airwallex touch, or new `require()` was found.

No C1 defects found.
