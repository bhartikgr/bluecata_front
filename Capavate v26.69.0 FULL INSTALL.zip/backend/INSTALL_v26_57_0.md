# Avinay deployment runbook: Capavate v26.57.0

Install the cumulative full package, not a partial source overlay that leaves an old frontend served. Production installation and live acceptance have not been performed by this task.

This is the **complete application**, including the updated marketing landing page, its mission statement/photo/LinkedIn link, and the previously delivered v26.55/v26.56 application fixes. No separate marketing patch or earlier release archive is needed. Read `RELEASE_NOTES_v26_57_0.md` in this same bundle.

## Before installation

Use this package instead of the superseded v26.55.0 archive. The older package was found to contain 27 SQLite sidecar files; v26.57.0 excludes them and verifies that no database or sidecar is present. Delete superseded installation/archive copies where appropriate, but **do not delete production database WAL/SHM files** as a cleanup shortcut. Live SQLite sidecars are part of the database's normal operation.

1. Verify the supplied SHA-256 checksum of `capavate_v26.57.0_FULL_BUNDLE.zip`. Stop on any mismatch.
2. Record current application version, backend process command/working directory, frontend asset reference, database location and service-manager configuration. Do not print secrets, cookies or invitation URLs into deployment logs.
3. Make a consistent database backup using the established SQLite backup procedure, plus rollback copies of the current application and environment. Preserve uploads and external object storage. An application rollback after new invitation writes does not justify blindly restoring an old database.
4. Use a separate staging application directory and isolated staging database for rehearsal. Disable real outbound mail and any live payment/bridge credentials there. Do not point staging at the production database or start the sandbox's `.env`.
5. Confirm production's supported SQLite runtime. This release does not certify PostgreSQL execution.

## Package and build

The archive contains source, both migration directories, package manifests, protected baseline/check scripts and refreshed `server/public` assets. It intentionally excludes real `.env` files, databases, uploads, `node_modules`, the local `dist` build directory, internal build logs and backup directories. Supply the deployment's own environment and dependencies.

From the chosen new application root:

```sh
node -p "require('./package.json').version"
# Must print 26.57.0
npm ci
npm run sacred
bash scripts/verify_release_version.sh 26.57.0
npm run build
node --check dist/index.cjs
```

`npm run build` produces `dist/index.cjs` and `dist/public`, and mirrors the fresh frontend into `server/public`. Ensure both references resolve to the same build; do not retain the old `index-CB8z8AHA.js` as the active UI or mix old HTML with new assets. The sandbox asset filename/hash in the verification report proves the supplied build, but a different build environment can legitimately produce a different fingerprint; verify the deployed HTML and corresponding served bytes together.

Do not use `npm run typecheck` as evidence of clean CI: the inherited baseline is 578 diagnostics. Do not generate new guard/sacred baselines or add exemptions to make installation look green.

## Taxonomy migration and startup

Migration `0236_company_taxonomy.sql` must exist in both `migrations/` and `server/db/migrations/`, byte-identically, in the deployed source layout. The verified bootstrap reads this migration artifact and performs schema/seed validation atomically. Do not copy only the compiled backend and omit those runtime files.

Use the actual application root as the backend working directory. Follow the established migration/bootstrap path; do not blindly rerun every historical SQL file to clear the chain checker, which still reports the pinned historical 0040 and 0000 issues. If taxonomy validation fails, stop and investigate rather than accepting a partially seeded catalogue or adding a hardcoded fallback.

Retain the deployment's genuine session/JWT configuration, app origin, mail configuration and existing integrations. `APP_URL` or `INVITATION_BASE_URL` must be the trusted external HTTPS origin, without credentials, path, query or fragment. Never put secret values into the handover.

After a successful staging rehearsal, install through the normal production maintenance procedure and restart the actual backend process. Confirm any `APP_VERSION` environment override is also `26.57.0`, not an older version.

## Read-only acceptance before any invitation send

- **Marketing landing page:** keep the original “The Equity Social Network” tagline and “Your investors are more connected than you think.” headline. Confirm the Consortium Partner benefits, full mission immediately below the hero, Ozan portrait and exact LinkedIn destination. “Trusted infrastructure for modern fundraising” must sit directly above Pricing. At 375px, the portrait must load and the page must not overflow horizontally.
- **Health and version:** inspect the deployed `/api/healthz` and version surface; verify 26.57.0, database health and the actual process/build. A version override alone is insufficient.
- **Frontend:** inspect the script referenced by the served HTML, fetch it, and confirm it matches the deployed build. Avoid stale browser/service-worker/CDN cache.
- **Taxonomy:** admin can read the company-sector screen with the natural-language heading “Company sectors”; the catalogue initially has the intended 45 values. Existing custom/retired values survive. Exercise write/retire/reactivate only with separately authorized staging data or a specifically approved live change.
- **Tracking and eligibility:** unclaimed companies remain labelled in CRM tracking but cannot create Managed Founders engagements, graduate, or start SPV-on-behalf actions until genuinely registered.
- **Privacy:** a weak CRM relationship has no founder invitation identity or registered-founder identifiers and no invitation-status/reissue access. A legitimate creator with active originating attribution can view the permitted status; admin remains complete.
- **Recipient review:** Add Portfolio Company presents the actual entered name/email for confirmation before creation. Do not press final confirmation with a real recipient merely as a read-only check.
- **Claims:** existing accounts use normal login, including its existing MFA flow. Invitation acceptance must not mint a new session for an unauthenticated existing account. Use authorized staging identities for destructive or one-time claim tests.
- **Operational logs:** real staging responses retain their claim URLs for the authorized caller, but request logs must not contain bodies, email addresses, tokens, raw paths/queries or response headers. Use synthetic sentinels; never paste a real token into the acceptance record.
- **Cumulative notification regression:** confirm partner notification destinations and workspace/account scope still behave correctly.

## NOVA correction, only after explicit approval

NOVA's intended recipient is `novaisinak@gmail.com`; the original live creation audit and pending invitation recorded a different address. Do not rewrite that audit or silently repair the production database.

After installation is verified and the owner explicitly authorizes the send, the authorized originating partner should:

1. Open NOVA's permitted founder-invitation recovery control.
2. Verify company identity, existing recipient and the new intended recipient/name.
3. Review and confirm exactly one reissue. Do not create a duplicate company.
4. Record the new invitation ID and handoff outcome without storing the raw bearer token in operational logs or a support message.
5. Verify that the old invitation/token cannot be used, and separately confirm actual recipient receipt and authenticated registration.

“Accepted by SMTP” is not “delivered.” A failed/unknown handoff requires diagnosis; repeated blind clicks are not a recovery plan, especially given the retained transport-cache limitations and lack of a dedicated per-company throttle.

## Stop and rollback conditions

Stop if protected hashes fail, schema/bootstrap validation fails, new resource-authority tests fail, founder PII appears for a weak CRM relationship, logs contain a claim token, or a loading transition crashes the UI. Preserve the evidence without retaining secrets.

Rollback application files through the established deployment process and restart the previous backend only after assessing compatibility with writes already made. Preserve new invitation/audit history and avoid restoring a stale database over valid user actions. Never restore an old vulnerable route merely to bypass a denied authority check.

## Return evidence

Send the installed version, build/asset identifiers, health result, migration/bootstrap outcome, protected-check results and a concise acceptance checklist. Report unresolved warnings and whether NOVA correction and real inbox receipt were actually authorized and completed; do not label them complete based on staging.

The local full-build frontend is `assets/index-Bry1VbKh.js`; its SHA-256 is `7551efd024281fcb1b9e2ccb85076ee30db30e443b1e913fd3abf645f0bd42f7`. The portrait is `assets/ozan-isinak-CGr6jpNz.webp`. If rebuilding in another environment changes hashes, record the actual built asset and prove the live HTML/browser serves that same build.
