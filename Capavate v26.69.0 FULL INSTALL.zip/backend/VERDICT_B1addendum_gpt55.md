# VERDICT — Wave B1 Addendum (GPT-5.5 deciding verifier)

VERDICT: **REVISE**

## Blocking defect

### 1) IDOR / over-exposure of partner attribution for private B1 companies

**File/line:** `server/companyAttributionRoutes.ts:26` mounts `GET /api/companies/:id/attribution` with only `requireAuth`.

**Why this is a real defect:** any authenticated user can query any known `companyId` and receive the partner attribution. The new B1 creation path creates companies with `collective: { status: "none" }` in `server/partnerPortfolioCompanyRoutes.ts:126`, so these are not necessarily published to the Collective. For such private/unlisted companies, the association “this company is led by partner X” is not already public on the Collective profile. The endpoint therefore exposes a private business relationship to unrelated authenticated users.

**Observed proof:** saved in `idor_probe_b1addendum_gpt55.txt`. The probe created a B1 company with `collectiveStatus: 'none'`, then queried `/api/companies/{companyId}/attribution` as unrelated user `u_aisha_patel`; the endpoint returned HTTP 200 with `{ attributedPartner: { partnerId, name } }`.

**Concrete fix:** scope the endpoint before returning attribution. Options:
- Prefer a founder-scoped endpoint such as `GET /api/founder/companies/:id/attribution` using `requireFounder` if the only intended consumers are founder surfaces.
- If partner/admin access is also required, add explicit authorization after `requireAuth`: allow only admins, founders who own `:id`, and the linked partner's own active team members resolved from session-derived partner membership; return `403` otherwise. Do not rely on caller-supplied partner IDs.
- Keep the public Collective badge on the existing Collective/public profile path only for companies actually published/listed there.

## Non-blocking checks passed

- Sacred files: **40/40 OK**, exit 0 (`sacred_b1addendum_gpt55.txt`). `WAVE_B1_ADDENDUM.diff` touches only the three founder pages, `server/routes.ts`, the new route, and the new test; no sacred file appears in the diff.
- Sacred profile endpoint: `server/profileStore.ts` was byte-identical to baseline and its `/api/companies/:id/profile` response logic remains unchanged; attribution is not added to that payload.
- Money core: `server/captableCommitStore.ts` sha16 is **01cd36130ee1c0cb**.
- TypeScript: `npx tsc --noEmit` reports exactly **598** errors (`tsc_b1addendum_gpt55.txt`), same count as the prior baseline. The new route/test and `RoundDetail.tsx` add no TS errors. `CapTable.tsx` BigInt errors and `Dashboard.tsx` unknown/object errors are pre-existing baseline errors shifted by inserted lines.
- Silent-drop guard: **exit 0**, **926 routes / 194 pages / 92 nav** (`guard_b1addendum_gpt55.txt`).
- B1 tests: the three B1 test files passed (**3 files, 7 tests**, exit 0) in `tests_b1addendum_gpt55.txt`.
- Build: `npm run build` completed exit 0 in `build_b1addendum_gpt55.txt`; build artifacts were restored/cleaned afterward per instruction.
- New server file uses ESM imports only: no `require()` found in `server/companyAttributionRoutes.ts`.
- Robustness/client gating: the route catches resolver errors and returns `{ attributedPartner: null }`; all three client queries use `enabled: Boolean(companyId)` and encode the company id.
- Auth-guard test is legitimate for the narrow 401 assertion: `DISABLE_DEV_BYPASS=1` disables both the sandbox anonymous fallback and Vitest `x-user-id` bypass in `server/lib/userContext.ts`, so the observed 401 proves `requireAuth` is mounted. It does not prove company-level authorization, which is the blocker above.
- No addendum migration or payment/Airwallex changes were present in the addendum diff.
