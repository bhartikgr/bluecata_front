# Wave B — Consortium Partner Pipeline: design analysis for greenlight

Covers QA slides 7–9 (3a "Add Portfolio Company", 3b SPV process-box row,
3c Following-from-Collective). **Nothing here is built yet** — this is the
"analyse before you build, I'll greenlight" deliverable you asked for. Questions
are inline; please answer each so I can build to spec without assuming.

---

## Current state (what already exists in the code)

The Pipeline page (`/collective/partner/pipeline`) today already has **three
sections**, which is more than the screenshots suggested:

1. **Private Portfolio** — a 6-column Kanban (invited · viewed · soft_circle ·
   signed · funded · committed) of the partner's deals. An "Add company" bar
   posts `{ dealName }` to `POST /api/partner/me/pipeline` — this is the
   "too lightweight" create you flagged (it makes a **pipeline deal row**, not a
   real, independent company entity).
2. **SPVs** — a flat 3-column grid of SPV cards linking to the SPV Engine (NOT a
   stage-column process-box layout).
3. **Following from Collective** — pills linking to each followed company's
   Collective profile in a new tab. **3c already works this way.**

Also relevant:
- A **real company builder** exists: the founder `ProfileWizard` +
  `POST /api/founder/companies/new` creates a genuinely independent company
  (its own account, its own cap table).
- **Partner attribution already exists**: `linkConsortiumPartner(companyId,
  partnerId)` / `getConsortiumPartnerId(companyId)` — the tagging mechanism 3a
  wants ("tagged to the originating Consortium Partner").
- A partner-scoped **`PartnerPortfolioProfileDialog`** (compact company profile
  editor) already exists for portfolio companies.

So Wave B is mostly **wiring existing engines together + a layout change**, not
building new engines (matching your "we are NOT building new engines" note).

---

## 3a — "Add Portfolio Company" (net-new, independent company, tagged to partner)

**Your spec:** a nav link directly below **Pipeline** called **"Add Portfolio
Company"** that opens the **same company-profile builder** used in Capavate,
rendered inside the partner template (iframe if that's cleanest). Each created
company is a **separate, independent Capavate entity** with its own account, and
is **tagged to the originating Consortium Partner** so everyone sees the partner
is leading the raise.

**Proposed build:**
- Add nav item **"Add Portfolio Company"** under Pipeline in `CollectiveShell`
  (guard will report it as an informational add).
- New route `/collective/partner/add-portfolio-company` rendering the company
  builder **inside the partner shell** (not an iframe — reuse the real
  `ProfileWizard` component directly so it's styled + on-brand; an iframe would
  fight the reskin and session).
- On completion: create a genuinely independent company via the existing
  `POST /api/founder/companies/new` engine, then immediately
  `linkConsortiumPartner(newCompanyId, partnerId)` so attribution is set at
  birth. The company also appears in the partner's Private Portfolio (invited
  stage) automatically.

**Q3a-1 — Company ownership / login.** Slide 8 says founders get their own
username/password and can only access their own company workspace (not the
partner section). When the partner creates the company, who is the initial
owner/login?
  (a) The partner creates it and later invites the founder by email (founder
      sets their own password on redeem), OR
  (b) The partner enters the founder's email at creation and the platform sends
      the founder an invite to claim the company, OR
  (c) The company is initially owned by the partner and transferred to the
      founder later.
  → My recommendation: **(b)** — closest to your "get their client properly
  established" intent, and the founder never touches the partner section.

**Q3a-2 — Builder depth.** Reuse the **full founder ProfileWizard** (4 steps:
public profile, jurisdiction, preferences, financials), or a **trimmed
partner-facing version** (just enough to establish the entity, founder finishes
the rest later)?
  → Recommendation: **full wizard** (it IS "the same engine already used in
  Capavate," exactly as you asked), pre-tagged to the partner.

**Q3a-3 — Subscription/billing.** Slide 8 says standard annual Capavate fees
apply to these companies, and a referral payment may be payable to the partner.
For THIS wave, should I:
  (a) just create + tag the company (attribution recorded; billing/referral
      handled by existing flows later), OR
  (b) also wire the referral-payment marker now?
  → Recommendation: **(a)** — attribution only this wave; referral payout stays
  under rule #14 (payments) until you give a separate greenlight. (This matches
  the deferred "auto-trigger rev-share payout" carry-forward.)

**Q3a-4 — iframe vs native.** You said "potentially via an iframe if that is the
best implementation approach." I recommend **native component reuse** (no
iframe) for styling/session/reskin consistency. OK to go native?

---

## 3b — Two parallel process-box rows (companies row + SPVs row)

**Your spec:** the SPVs section should **mirror the company process-box (stage
column) layout**, and there should be **two parallel rows**: one row of stage
boxes for **Consortium-Partner-led companies**, and a second identical row
beneath it for **Consortium-Partner SPVs**. Each company card gets **"Make
Private"** and **"Publish to Collective"** toggles at the bottom.

**Proposed build:**
- **Row 1 (companies):** keep/refine the existing 6-stage Kanban (invited →
  committed) for Partner-led companies. Add **"Make Private" / "Publish to
  Collective"** toggle controls at the bottom of each company card. (A
  publish-to-collective concept already exists via the "Promote to Collective"
  action — see Q3b-2.)
- **Row 2 (SPVs):** re-render the SPVs section as a **matching stage-column
  row**, so SPVs sit in columns by their lifecycle, visually parallel to Row 1.
  Each SPV card also gets the Make-Private / Publish-to-Collective toggle (the
  SPV Engine already has a distributionScope private/network toggle — I'd reuse
  that exact logic).

**Q3b-1 — SPV stage columns.** SPVs have a different lifecycle than companies
(SPV status = draft · open · closed · wound_down; distribution = private ·
network). For the SPV row's columns, do you want:
  (a) the **SPV lifecycle** (Draft → Open → Closed → Wound-down), OR
  (b) the **SAME 6 company stages** (invited…committed) applied to SPVs for
      visual symmetry, OR
  (c) a **capital-raise** framing (Draft → Raising → Deploying → Distributing)?
  → Recommendation: **(a)** — it's the SPV's real lifecycle and won't mislead;
  the row still visually mirrors Row 1 (same box styling), just with SPV-true
  column labels.

**Q3b-2 — "Publish to Collective" semantics on a company card.** For a Partner-
led COMPANY (not an SPV), "Publish to Collective" most naturally maps to the
existing **Promote-to-Collective** flow (admin-reviewed) rather than an instant
public flip. Should the company toggle:
  (a) trigger the existing **Promote-to-Collective review** (admin approves
      before it's visible), OR
  (b) be an **instant** private↔collective visibility flip (no review)?
  → Recommendation: **(a)** — it reuses the audited path and avoids an
  unreviewed company appearing in the Collective. (SPVs keep their instant
  private/network toggle since that's already how the SPV Engine works.)

**Q3b-3 — "Make Private".** Confirm "Make Private" = remove from Collective
visibility / withdraw the promotion (returns the card to private-portfolio-only).
Yes?

---

## 3c — Following from Collective

**Your spec:** companies the partner has expressed interest in via Collective
appear here; selecting one links to its full Collective profile.

**Current state:** **already implemented** — the "Following from Collective"
section renders pills linking to `/collective/companies/:id` (opens the full
Collective profile in a new tab).

**Q3c-1 —** Is the existing behavior acceptable as-is, or do you want it
restyled into the same **box/card layout** as the two process rows for visual
consistency (rather than the current pill chips)?
  → Recommendation: light **restyle to cards** for consistency with 3b, keeping
  the same click-through to the Collective profile.

---

## Cross-cutting questions

**Q-B1 — Attribution visibility.** Slide 8: "all users engaging with that
company can clearly see that a registered Consortium Partner is associated with
and leading the capital raise." Where should this partner badge/label appear?
  (a) On the company's Collective profile, (b) on the founder's own dashboard,
  (c) on the cap-table/round surfaces, (d) all of the above.
  → Recommendation: **(a) + (c)** this wave (most visible to investors);
  founder-dashboard badge optional.

**Q-B2 — Founder isolation.** Confirm: a founder whose company was created by a
partner must have **zero access** to the partner section (only their own company
workspace). This is already the platform's model (partner routes are gated by
`requirePartnerAuth`), so I'll just verify it holds for partner-created
companies. OK?

**Q-B3 — Wave sizing / sequencing.** 3a (create+tag+nav+builder reuse) is the
big one; 3b (layout + toggles) is medium; 3c (already done, maybe restyle) is
small. Do you want them as **one Wave B**, or split (e.g. B1 = 3a, B2 = 3b/3c)
so you can review the create-company flow before the layout work?
  → Recommendation: **split** — B1 = 3a first (the risky, net-new-entity part),
  you verify it against the live/staging, then B2 = 3b/3c layout.

**Q-B4 — Migration.** 3a/3b likely need **no new migration** (companies reuse
`founder/companies/new`; attribution reuses `consortiumLinkStore`; SPV toggle
reuses distributionScope). If a partner↔company portfolio link needs its own
row I'd use the **next free id 0109**, additive/mirrored. OK to add one only if
unavoidable?

---

## What I will NOT do without your explicit go-ahead
- Touch payments/Airwallex or wire the referral payout (rule #14).
- Fork the money core / commitment path (SPV deployment still flows through the
  one sacred `commitFunded`).
- Ship any of Wave B before you greenlight this design.
