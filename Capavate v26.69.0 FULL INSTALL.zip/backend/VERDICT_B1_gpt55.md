# VERDICT: REVISE

I am not approving Wave B1. The required gates pass, but there are real data-integrity defects in the Add Portfolio Company route.

## Gate results run

| Gate | Actual result |
|---|---:|
| `npx tsc --noEmit 2>&1 \| grep -c "error TS"` | `598` |
| `sha256sum -c sacred_baseline/SACRED_SHA256.txt 2>&1 \| grep -c ": OK"` | `40` |
| `sha256sum server/captableCommitStore.ts \| cut -c1-16` | `01cd36130ee1c0cb` |
| `npm run guard 2>&1 \| tail -3` | exit `0`; `OK: 925 routes, 194 pages, 92 nav — no silent drops` |
| `npx vitest run server/__tests__/waveB1_add_portfolio_company.test.ts server/__tests__/waveA_consortium_qa.test.ts server/__tests__/spvUnifiedCanonical.test.ts` | `3` files passed, `16` tests passed |
| `grep -nE "\brequire\(" server/partnerPortfolioCompanyRoutes.ts` | no matches; grep exit `1` |
| `grep -nE "companyProfileStore|subscriptionStore\b" server/partnerPortfolioCompanyRoutes.ts` | no matches; grep exit `1` |

Additional checks:
- New server route imports `subscriptionsStore` plural, not sacred `subscriptionStore.ts` singular, and does not import `companyProfileStore.ts`.
- B1 source diff contains no migration file diff. The working tree has Wave A migration files, but `WAVE_B1_SOURCE.diff` adds no migration.
- B1 source diff does not touch Airwallex/payment/referral payout code. The only payment-adjacent text is the free subscription status check in the new route.
- I did not run `npm run build`, so no build artifact restore was needed.

## Defects requiring revision

### 1) Attribution failure returns 500 but leaves an orphan company without attribution

**File/lines:** `server/partnerPortfolioCompanyRoutes.ts:129-156`

The route calls `addCompanyForFounder(ownerUserId, company)` at lines 129-130, then calls `linkConsortiumPartner(companyId, ctx.partnerId)` at lines 152-153. If attribution fails, the catch at lines 154-156 returns `500 ATTRIBUTION_LINK_FAILED`, but it does not roll back the already-committed company, company_members row, tenant row, or in-memory membership cache. This violates the brief's data-integrity requirement that attribution fail closed with no orphan company without attribution.

I confirmed this with an adversarial test saved as `server/__tests__/waveB1_adversarial_attribution_orphan.test.ts`: after forcing `linkConsortiumPartner` to fail by dropping `consortium_links`, the route returned `500`, but the company still persisted and had a `company_members` owner row for `u_pending_founder_...`:

```json
{"status":500,"error":"ATTRIBUTION_LINK_FAILED","companyPersisted":true,"membershipUserId":"u_pending_founder_2ee427c3c3781341"}
```

**Fix:** Make company creation + attribution atomic, or add a guaranteed rollback path before returning the 500. The fix must remove/undo the company row, company_members row, tenant/user_prefs side effects, and any cache state if attribution cannot be durably written. Do not report either 201 or a durable created company unless attribution is present.

### 2) Defensive invitation-table ensure does not match the real schema

**File/lines:** `server/partnerPortfolioCompanyRoutes.ts:63-81`

The route's `ensureFounderTeamInvitationsTable()` creates `founder_team_invitations` without the `sent_at` column. The real schema in `server/lib/founderTeamStore.ts:45-63` creates the same table and then idempotently adds `sent_at TEXT` via `ALTER TABLE`. The brief explicitly requires the defensive ensure to be idempotent and match the real schema.

**Fix:** Mirror the real ensure logic: include `sent_at TEXT` for fresh creates and/or run the same idempotent `ALTER TABLE founder_team_invitations ADD COLUMN sent_at TEXT` guarded by catch-if-exists.

### 3) Founder owner-invite failure is silently downgraded to a successful create

**File/lines:** `server/partnerPortfolioCompanyRoutes.ts:176-205`; client consequence at `client/src/pages/partner/PartnerAddPortfolioCompany.tsx:60-65`

The founder OWNER invitation insert is required for the founder to claim the pending-owned company. But the route catches any invite failure at lines 192-196, logs a warning, then still returns `201` with `founderInvite: null` at lines 198-205. That can leave a pending-founder-owned company with no claim token. The client also unconditionally shows the success toast "The founder has been invited" on success at lines 60-65, even when `founderInvite` is null.

**Fix:** Treat owner-invite persistence as part of the atomic create operation, or return a non-201 failure and roll back the company/attribution when the owner invite cannot be durably issued. If the product intentionally allows a nonfatal invite failure, the API and client must not state that the founder was invited, and there must be a partner-accessible recovery path that does not require founder workspace access.

## Per-check confirmations

- **Founder-owner isolation:** The company owner is derived with `pendingFounderUserId(founderEmail)` at `server/partnerPortfolioCompanyRoutes.ts:110` and passed to `addCompanyForFounder(ownerUserId, company)` at line 130. The acting partner user id is not used as company owner; it is only used for pipeline ownership and inviter attribution.
- **Partner/founder section isolation:** The write route is guarded by `requirePartnerAuth`, `assertSubRole`, and `requireSignedAgreement` at `server/partnerPortfolioCompanyRoutes.ts:90-92`; a normal founder without a partner-team row cannot call it. The created company membership uses the pending-founder id, not the partner user id.
- **Company persist fail-closed:** `addCompanyForFounder` errors are caught at `server/partnerPortfolioCompanyRoutes.ts:129-134` and return `500 COMPANY_PERSIST_FAILED`; `server/multiCompanyStore.ts:579-664` rethrows DB persist failure before cache mirroring.
- **Attribution fail-closed status:** The route does return `500 ATTRIBUTION_LINK_FAILED` when `linkConsortiumPartner` throws, and `server/consortiumLinkStore.ts:35-60` throws on durable write failure. However, defect #1 means this is not data-atomic and leaves an orphan company.
- **Founder invite role/status/token:** The insert hard-codes `role='owner'`, `status='pending'` at `server/partnerPortfolioCompanyRoutes.ts:185-190`; the token is 32 random bytes at line 179, stored only as SHA-256 at line 180, and returned as `/auth/redeem?token=...` at lines 203-205. The inviter is `ctx.userId` at line 190, not client input.
- **Token predictability:** The returned token is generated with `randomBytes(32).toString("hex")`, so it is not practically predictable.
- **Existing-user privilege confusion:** `pendingFounderUserId()` namespaces pending owners as `u_pending_founder_<sha256-email-prefix>` at `server/partnerPortfolioCompanyRoutes.ts:51-53`. It cannot be made equal to the normal `u_founder_...` ids generated by `registerFounderUser` at `server/lib/userContext.ts:529`. An existing user can only receive access by redeeming the real invite token for their email through `/auth/redeem`.
- **Attribution badge:** Server returns `profile.attributedPartner` read-only and null-on-miss at `server/collectiveRoutes.ts:946-955`; the client badge renders only when `profile.attributedPartner?.name` exists at `client/src/pages/collective/CollectiveDealRoomDetail.tsx:172-176`.
- **No sacred singular-store import in the new route:** Confirmed by grep; the new route imports `subscriptionsStore` plural at `server/partnerPortfolioCompanyRoutes.ts:31`.
