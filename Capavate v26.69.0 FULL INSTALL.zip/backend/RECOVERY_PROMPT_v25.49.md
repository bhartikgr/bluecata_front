# Capavate v25.49 — SANDBOX RECOVERY / CONTINUATION PROMPT

> UPDATE 2026-07-03: v25.49.2 = v25.49.1 + Investor left-nav reorg (client-only, AppShell.tsx useInvestorNav → OVERVIEW/DEALS/NETWORK/ACCOUNT, 3 orphaned pages recovered, badge intact, nothing dropped). Audit: review/investor_audit_findings.md. Avi bugs 2 & 3 still OPEN.
### (Copy this ENTIRE document as the first message into a new task if this sandbox fails or is lost.)

> You are resuming a production build wave for Capavate (founder/CEO: Ozan Isinak): the **Consortium
> Partner module rebuild + the canonical SPV Engine**. Read this whole doc first. Do not guess; ask
> Ozan logic/business questions rather than assume (his explicit instruction).

## 0. WHERE THINGS STAND (as of FINAL v25.49.0 — WAVE COMPLETE)
All phases DONE, gate-green, triple-verified SHIP (GPT-5.5 overriding; 3 SPV review rounds cleared 9
blockers), and packaged as final v25.49.0. Phases 1-3 (partner rebuild) + Phase 4/4B/4C/4D (canonical
SPV engine) are all shipped. Migrations 0083-0087. 104/104 partner+SPV tests pass; sacred 39/39; tsc 601;
build 0. If resuming, the wave is complete — only future-cleanup items remain (see CHANGELOG 'Known /
future cleanup'). The rest of this doc is the historical build record + how to rebuild/re-gate.
- Phase 1 (DONE): fixed the React #310 crash that took down the entire partner workspace. Root cause:
  `client/src/components/CollectiveShell.tsx` called `useCollectiveMembershipActive()` conditionally
  (`partner.isPartner && ...`) → hook-count changed between loading/loaded renders. Fixed: hook is now
  unconditional. Regression test: `client/src/components/__tests__/CollectiveShell.partnerHooks.test.ts`.
- Phase 2 (DONE): re-skinned partner module to capavate.com brand (red #cc0001, navy #041e41, cream,
  Montserrat + Instrument Serif) reusing existing `--cv-*` tokens + `[data-product="partner"]` in
  `client/src/index.css`; grouped left-nav (OVERVIEW / DEALS & SPVs / WORKSPACE / NETWORK / ACCOUNT).
- Phase 3 (DONE): enhanced the SEPARATE Partner Clients CRM (migration 0083 → `partner_client_crm` +
  `partner_client_activity`; new `server/partnerClientCrmStore.ts` + `partnerClientCrmRoutes.ts`;
  stages/timeline/search; honest cap-table card). Inserted Messaging + Posts via the SHARED comms engine
  (`PartnerMessages.tsx`, `PartnerPosts.tsx`, dashboard cards, NETWORK nav group). Test:
  `server/__tests__/partnerClientCrm.test.ts` + `client/src/components/__tests__/PostsFeed.partnerBasePath.test.ts`.
- Phase 4 (TODO — the big one): the canonical SPV Engine. FULL brief already written:
  `/home/user/workspace/review/PARTNER_PHASE4_SPV_BRIEF.md`. Spec: `/tmp/spv_prompt.md` (source docx at
  `/home/user/workspace/uploaded_attachments/62d3641de38a4d25be9be01b381918b2/capavate_spv_build_prompt.docx`).

## 1. OZAN'S DECISIONS (locked — `/home/user/workspace/review/PARTNER_WAVE_DECISIONS.md`)
- SPV carry basis: GP must explicitly choose per-deployment vs whole-SPV (NO default) — but the wizard
  step must be DEAD SIMPLE with one-line plain-language help. Not complicated for the partner.
- CRM: KEEP the separate Consortium Partner (Clients) engine; ENHANCE it (done in Phase 3). Do NOT fold
  into the canonical crmStore.
- Left-nav: grouped with section headers (done).
- SPV vs Funds: ONE unified canonical SPV engine + a single 'SPVs' surface; migrate existing SPV+Fund
  records in (Fund = an SPV type). Nothing dropped.

## 2. NON-NEGOTIABLE RULES (violating any = DO-NOT-SHIP)
1. 39 sacred files BYTE-IDENTICAL — never edit; verify before+after vs `sacred_baseline/SACRED_SHA256.txt`.
2. No new `require()` in server TS (static/await import only).
3. tsc budget ≤611, **zero net-new vs baseline 601**. Current = 601. If your additive types raise it,
   drive it back to 601.
4. Migrations additive + idempotent (IF NOT EXISTS); test vs a copy of live data.db.
5. Fail-closed on money/auth/cap-table/durability; ZERO in-memory canonical state (write-through +
   rehydrate); ZERO mock/demo on any customer path (DEMO_SEED_ENABLED seed is the only allowed seed).
6. Tests hit REAL Express routes via supertest; if a pre-existing test encodes old behavior we changed,
   FIX THE TEST not prod.
7. Sacred cap-table LEDGER stays byte-safe — SPV deployment is a SINGLE write through the EXISTING
   ledger path; do confirm/wire/attest at the route/parallel layer, never inside a sacred file.
8. Triple-verify Opus 4.8 + Gemini 3.1 Pro + GPT-5.5; **GPT-5.5 overrides**; do NOT ship on its REVISE.
9. Sacred Rule #78: never silently drop/delete/FORGET a widget or functionality.
10. Every release package MUST include: FULL+PATCH zips, SHA256SUMS, CHANGELOG, README for Avi,
    **CAPAVATE_SACRED_FILES.md**, and **this RECOVERY_PROMPT**. Deliver via share_file.

## 3. FILE MAP (exact paths)
- Build tree (edit in place; NOT git): `/home/user/workspace/capavate_build/capavateAIzip`
  (deps installed; tsc/tsx/vitest at `node_modules/.bin/*`; version currently 25.49.0-rc1).
- Original v25.48.2 diff baseline (FLAT layout): `/tmp/orig/` (files at `/tmp/orig/server/...`).
- Live data.db copy for migration tests: `/home/user/workspace/q2_diag/live_copy.db`. Real live tree:
  `/home/user/workspace/live_server_july3/capavateAIzip`.
- Briefs/decisions/audit: `/home/user/workspace/review/PARTNER_WAVE_DECISIONS.md`,
  `partner_audit_findings.md`, `PARTNER_PHASE1_BRIEF.md`..`PARTNER_PHASE4_SPV_BRIEF.md`,
  `V25_49_RC1_REVIEW_BRIEF.md`, verdicts `verify_rc1_*.md`.
- rc1 package: `/home/user/workspace/dist_pkg_v25_49_rc1/`.
- If the build tree is gone: rebuild from
  `/home/user/workspace/uploaded_attachments/bc2a9c9023e24a31aa68f43597ed353b/capavate_v25.48.2_FULL_INSTALL.zip`
  (base v25.48.2), then re-apply v25.48.3 PATCH (`/home/user/workspace/dist_pkg/capavate_v25.48.3_PATCH.zip`)
  then the rc1 PATCH (`/home/user/workspace/dist_pkg_v25_49_rc1/capavate_v25.49.0-rc1_PATCH.zip`), then
  `npm ci`. Also unzip the v25.48.2 FULL to `/tmp/orig` for the diff baseline.

## 4. THE FOUR GATES (run from the build tree)
```bash
cd /home/user/workspace/capavate_build/capavateAIzip
# sacred
MISMATCH=0; while read h p; do [ -z "$p" ] && continue; if [ -f "$p" ]; then a=$(sha256sum "$p"|awk '{print $1}'); [ "$a" != "$h" ] && { echo "MISMATCH $p"; MISMATCH=1; }; else echo "MISSING $p"; MISMATCH=1; fi; done < sacred_baseline/SACRED_SHA256.txt; [ "$MISMATCH" = "0" ] && echo "SACRED CLEAN 39/39"
./node_modules/.bin/tsc --noEmit 2>&1 | grep -c 'error TS'          # MUST be 601
./node_modules/.bin/tsx script/build.ts ; echo "BUILD_EXIT=$?"       # 0
ENABLE_DEMO_SEED=1 NODE_ENV=test ./node_modules/.bin/vitest run <partner + spv + new tests>
```
Known/expected: 3 PRE-EXISTING failures in `server/__tests__/partner_workspace.test.ts` (SPV creation
→ 500) are the OLD SPV/Fund contract drift that Phase 4 REPLACES. Not a regression.

## 5. NEXT ACTION (if resuming for Phase 4)
Launch a coding subagent (subagent_type=codebase, existing-workspace mode, preload skill "coding")
with objective = follow `/home/user/workspace/review/PARTNER_PHASE4_SPV_BRIEF.md` exactly. Build the ONE
canonical SPV engine (8 additive tables 0084+, one store + 3 contexts, GP 5-step wizard, 3 compliance
gates, 2-layer fee model + Airwallex, distribution scopes incl. collective_only, single cap-table
ledger line, admin tabs, full lifecycle, real-Express tests incl. cross-partner isolation). Migrate the
existing partner SPV+Fund records in (nothing dropped). Then gates + triple-verify (GPT-5.5 overrides) →
live re-verify on capavate.com (partner login: ozan@blueprintcatalyst.com / placeholder_removed_use_approved_recovery) →
package final v25.49.0 for Avi with all required docs.

## 6. LIVE LOGINS (secrets)
- Partner: https://capavate.com/partner/login — ozan@blueprintcatalyst.com / placeholder_removed_use_approved_recovery
- Admin: https://capavate.com/admin/login — ozan@capavate.io / placeholder_removed_use_approved_recovery
- Founder: https://capavate.com/user/login — Ozan.isinak@gmail.com / placeholder_removed_use_approved_recovery
- Investor: https://capavate.com/investor/login — ozan@capavate.com / placeholder_removed_use_approved_recovery

*Generated 2026-07-03 as part of the v25.49.0-rc1 checkpoint, per Ozan's directive that a recovery
prompt always be included in the package.*
