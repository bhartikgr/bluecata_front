import re

files = [
    "server/__tests__/w227_accreditation_jurisdiction_scope.test.ts",
    "server/__tests__/w221_benchmarking_opt_out.test.ts",
    "client/src/pages/founder/__tests__/w228_collective_false_claims.test.tsx",
    "server/__tests__/w216_esignature_intent_and_hash.test.ts",
    "client/src/lib/__tests__/w226_attestation_rendered.test.tsx",
    "client/src/pages/investor/__tests__/w221_benchmarking_sharing_dom.test.tsx",
    "server/__tests__/wave207_fee_basis_fence.test.ts"
]

for f in files:
    with open(f, 'r') as file:
        lines = file.readlines()
        for i, line in enumerate(lines):
            if ".toLowerCase()" in line and ("expect" in line or "===" in line):
                print(f"=== {f} LINE {i} (toLowerCase) ===")
                print("".join(lines[max(0, i-5):min(len(lines), i+6)]))
            if "filter(" in line:
                print(f"=== {f} LINE {i} (filter) ===")
                print("".join(lines[max(0, i-3):min(len(lines), i+3)]))
            if "trim(" in line and "expect" in line:
                print(f"=== {f} LINE {i} (trim) ===")
                print("".join(lines[max(0, i-3):min(len(lines), i+3)]))
            if "toEqual([])" in line:
                print(f"=== {f} LINE {i} (empty array) ===")
                print("".join(lines[max(0, i-3):min(len(lines), i+3)]))
            if "document.querySelector" in line:
                print(f"=== {f} LINE {i} (unscoped DOM) ===")
                print("".join(lines[max(0, i-3):min(len(lines), i+3)]))
