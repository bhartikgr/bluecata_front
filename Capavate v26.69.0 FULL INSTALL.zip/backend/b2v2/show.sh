#!/bin/bash
f="$1"; shift
python3 /home/user/workspace/b2/strip.py "/home/user/workspace/work/$f" | grep -n "" > /tmp/s.$$
for r in "$@"; do
  if [[ "$r" == *-* ]]; then a=${r%-*}; b=${r#*-}; else a=$r; b=$r; fi
  sed -n "${a},${b}p" /tmp/s.$$
done
rm -f /tmp/s.$$
