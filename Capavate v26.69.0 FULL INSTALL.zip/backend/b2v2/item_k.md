## ITEM K — R112: SPV-LAUNCH ELIGIBILITY GATE AND LAPSE FREEZE (BUILD NOW)

R112 (`spec/OWNER_RULINGS_2026_08_13.md:3905-3971`) **supersedes §0.6's statement
that R110.4's gate is not to be built, and supersedes the earlier instruction to
put it behind an off switch.** There is no master off switch in this item. The
owner's four answers are binding: (a) the gate applies to an SPV with **no**
target company; (b) **every** associated portfolio company must be paid up, not
just the lead; (c) a lapse **freezes** existing SPVs; (d) it applies **across the
board, retroactively**.

### §K.1 The real source of membership state — verified, and it is not the obvious one

There are **two** subscription tables. Only one is canonical.

| | canonical | decoy |
|---|---|---|
| table | `capavate_subscriptions` | drizzle `subscriptions` |
| reader | `server/subscriptionStore.ts` — `listForCompany` at **`:372-384`** | `server/multiCompanyStore.ts:1400-1406` |
| rows in `data.db` | **0** | **364**, every one `pending_payment` / `founder_pro` |
| status vocabulary | `pending \| active \| failed` (`subscriptionStore.ts:41`) | `pending_payment` |
| rendered at | — | `client/src/pages/founder/Company.tsx:616` |

`server/founderCollectiveApplyStore.ts:39` names `capavate_subscriptions` the
**"canonical subscriber status (Sacred Rule 76)"**. That is the source. The
drizzle `subscriptions` table is **not** to be read by this item; its 364
`pending_payment` rows are the reason a builder who guesses will produce a gate
that blocks every launch on the platform *for the wrong reason*.

`server/subscriptionStore.ts` is **SACRED** (`sacred_baseline/SACRED_SHA256.txt`,
manifest row 4) — **call it, never edit it**. This is fortunate rather than
limiting: `listForCompany` **throws** when the driver is unavailable and lets SQL
errors propagate (`:372-384`). That propagation *is* the third state. Supporting
facts: `ensureTable` `:99-152` (adds `current_period_end` at `:128`), `rowToSub`
`:154-171`.

**Two existing readers must NOT be reused, and the reason is the ruling itself:**

* `server/spvEngineStore.ts:303-323` `resolveCompanyFacts` — `:310-311` is
  `try { …some(s => s.status === "active") } catch { paidSubscriber = false; }`.
  An unreadable database becomes *unpaid*. That is unknown-treated-as-lapsed,
  which R112.3(3) forbids by name.
* `server/lib/canonicalPlanResolver.ts` `resolveCanonicalPlan` `:57-92` returns
  `null` both when there is no plan and when the read **fails** (`:62-65`). It
  cannot express three states, and it is **SACRED** (manifest row 19), so it
  cannot be corrected. Do not route the gate through it.

Therefore the gate gets its own **new, non-sacred** reader.

### §K.2 The three-state reader — `server/lib/spvMembershipGate.ts` (NEW FILE)

```
export type MembershipState =
  | { state: "paid";       companyId: string; companyName: string; cycle: "annual"; periodEnd: string | null }
  | { state: "not_paid";   companyId: string; companyName: string;
      kind: "no_membership" | "lapsed" | "non_annual_cycle" | "payment_failed" | "pending_payment";
      periodEnd: string | null }
  | { state: "unreadable"; companyId: string; companyName: string | null;
      kind: "read_failed" | "company_not_found" }
```

Detection, in this exact order. Every step is a live read; **no cached flag, no
hardcoded company list, no denormalised column** (R95).

1. **Name and existence.** Narrow drizzle select of `id, name, legalName,
   deletedAt` from `companiesTable` via `getDb()` (the DB-backed pattern already
   used at `server/multiCompanyStore.ts:467-500`). If the select **throws** →
   `unreadable / read_failed`. If no row, or `deletedAt` is set → `unreadable /
   company_not_found`. Display name = `legalName ?? name`; if both are blank →
   `unreadable / company_not_found`, because a refusal that cannot name the
   company is a refusal that cannot be acted on.
   **Trap:** do **not** use `server/companyProfileStore.ts:289`
   `getCompanyProfile` — it is an in-memory map that *invents* an empty profile
   for an unknown id (`:290-293`) and never throws, so a missing company would
   silently render as a company with a blank name. Do not use
   `multiCompanyStore.ts:397` `getCompanyNameById` either — it reads only the
   hydrated `USER_COMPANIES` map and returns `undefined` for a real company that
   is not hydrated.
2. **Membership rows.** `listForCompany(companyId)` (`subscriptionStore.ts:372`).
   If it **throws** → `unreadable / read_failed`. Never catch-and-default.
3. `rows.length === 0` → `not_paid / no_membership`.
4. Take rows with `status === "active"`. If none: `not_paid / payment_failed` when
   the newest row is `failed`, otherwise `not_paid / pending_payment`.
5. Of the active rows, keep those with `billingCycle === "annual"` (R112.1 says
   *annual* membership). If active rows exist but none is annual →
   `not_paid / non_annual_cycle`.
6. For the newest active annual row, `periodEnd = currentPeriodEnd ?? expiresAt`.
   If `periodEnd` is present **and** in the past → `not_paid / lapsed`.
   If `periodEnd` is **absent** → `paid`, `periodEnd: null`. **Status is the
   authority; a missing period end is displayed as "Not on record" and is never
   treated as evidence of lapse.** (R111 Q13.)
7. Otherwise → `paid`.

`unreadable` is never coerced. There is no code path in this file that assigns
`false` inside a `catch`.

### §K.3 Which companies an SPV is associated with

`companiesForSpv(spvId)` — union of, each read live:

* `spv.target_company_id` (single, nullable) — the engine SPV's target.
* `SELECT DISTINCT company_id FROM spv_deployment WHERE spv_id = ?` — the
  multi-company case; already indexed (`idx_spv_deployment_company`).
* legacy `spvs.lead_company_id` for a vehicle that exists only in the legacy
  table.

**Deliberately excluded, with reasons stated in-file:**

* `spv_mandate.company_ids_json` — mandate **candidates**, not holdings. A
  candidate company's lapse must never freeze a vehicle that has not invested in
  it. The *deployment* action into a candidate is still gated, because at that
  moment the candidate becomes an associated company (§K.5).
* `spv_positions` — carries `security_id`, not `company_id`; it cannot answer the
  question. (Note also that `spv_deployments`, plural, is the deployment-**fee**
  table, not holdings; `spv_deployment`, singular, is the association.)

At **launch** time there are no deployments yet, so the launch set is
`{ targetCompanyId }` or **∅** — and ∅ is governed by its own named setting.

### §K.4 Settings — reuse `platform_config`, invent nothing

The mechanism already exists and is audited: the STRICT `platform_config` table
plus `platform_config_history` (migration `0123_wave0_platform_config.sql`), 6
live rows, with triggers that **forbid an unaudited insert, update or delete**.
The precedent for a *gate* key is `kyc.capital_call.gate_mode = "warn"`.

Writer: `server/lib/platformConfigWriter.ts` — `readConfigRow` `:90-110`,
`updatePlatformConfigValue` `:121`, `ensurePlatformConfigKey` `:234-329` (inserts
the history genesis row and the config row in one transaction),
`computeRevisionHash` `:59-77`. Boot-seed precedents to copy:
`server/lib/esignatureStore.ts:259-263`, `server/lib/roundMathDisclosureStore.ts:167-205`.

**TRAP — do not use the drizzle path.** `shared/schema.ts:743` `platformConfig`
still declares the **old** shape (`value`, `hash`, `prev_hash`) while the live
table is the STRICT shape. That is why `adminPlatformStore.ts`
`setLifecyclePolicies` `:2035-2080` has a silently broken write-through (the
failure is swallowed at `:2076`; routes at `:3236-3255`). Write only through
`platformConfigWriter`. **Never** `INSERT` into `platform_config` from a
migration — the triggers will reject it and the history chain would be broken.

Two keys, both seeded at boot via `ensurePlatformConfigKey` (idempotent):

| key | values | default | meaning |
|---|---|---|---|
| `spv.launch_gate.membership_mode` | `enforced` \| `warn` | **`enforced`** | whether an unpaid associated company blocks a launch and freezes money actions |
| `spv.launch_gate.no_company_mode` | `enforced` \| `exempt` | **`enforced`** | R112.2(1)'s explicitly named no-company case: whether an SPV with **no** associated portfolio company may launch |

`warn` records the refusal reason and shows the banner but does not block; it
exists because R112.2(1) orders the gate to be admin-configurable and DB-driven,
and because §K.11's census may show the platform cannot be switched to
`enforced` on day one. It is **not** an off switch for the item: the default is
`enforced`, and the wizard states the requirement up front in both modes.

**Config read failure ≠ membership read failure.** If the config row cannot be
read, the resolver returns the **default** (`enforced`) — the W52 precedent — and
that is fail-closed for launching. It does **not** make a freeze decision; freeze
fails open only on an unreadable **membership** (§K.6).

### §K.5 Every endpoint that must consult the gate

**Launch (fail CLOSED).** `POST /api/partner/me/spv` —
`server/spvEngineRoutes.ts:319-451`; `WRITE_ROLES` at `:77` =
`managing_partner | associate | bd`. The gate runs **after** the payload and
signoff validation at `:373-380` and **before** `recordSignoff` at `:402-415`, so
a refused launch never leaves a recorded signoff behind. `createSpv` is
`spvEngineStore.ts:377-469` and is not modified.

**Money actions on an existing vehicle (freeze — fail OPEN):**

| action | route |
|---|---|
| new commitment | `spvEngineRoutes.ts:679` (POST), `:685` (PATCH), `:1176` lp-commit; `spvFundStore.ts:1551` (POST), `:1582` (PATCH) |
| new deployment | `spvEngineRoutes.ts:734`, `:740`, `:755` (commit); `spvFundStore.ts:1742` db-positions |
| new capital call | `spvFundStore.ts:1628` |

**Deliberately NOT blocked** — distributions (`spvEngineRoutes.ts:810`,
`spvFundStore.ts:1669`) and transfers (`spvFundStore.ts:973`). These move money
**back to LPs** or record an LP's exit; blocking them would punish investors for
a portfolio company's unpaid invoice, and R112.2(2) lists only "launching, new
commitments, new deployments, new capital calls". **This is flagged to the owner
for confirmation** (§K.12) rather than decided silently.

Each guarded handler calls one helper, `assertSpvMoneyActionAllowed(spvId,
action)`, which throws a typed refusal carrying both a code and a sentence.

**Refusal shape — R77.** `err()` at `spvEngineRoutes.ts:175-264` returns
`{ error: CODE }` **only**; a bare code is exactly what R77 forbids reaching a
user's eye. The gate must therefore respond with `{ error, message }` explicitly
and not via `err()`. This works end-to-end: `client/src/lib/queryClient.ts:44-67`
`throwIfResNotOk` prefers `message` when it `looksHuman` (`:60-64`), so the
server-authored sentence is what reaches the toast at
`PartnerSpvEngine.tsx:618`. Sentences are authored server-side, once:

* not paid — *"Northwind Robotics does not have a paid-up annual Capavate
  membership, so this SPV cannot be launched. Ask the company to complete its
  annual membership payment, then launch again."*
* multi-company — the same sentence naming **every** failing company, comma
  separated, never "one or more companies".
* no company — *"This SPV has no portfolio company attached. A launch requires at
  least one portfolio company with a paid-up annual Capavate membership. Attach
  the company, or ask an administrator to allow blind-pool launches."*
* unreadable, launch — HTTP **503** — *"We could not check Northwind Robotics'
  membership just now, so the launch was not attempted. Nothing was changed. Try
  again in a few minutes; if it keeps happening, contact Capavate support."*
* frozen — *"New commitments are paused for this SPV because Northwind Robotics'
  annual Capavate membership has lapsed. Existing positions, documents and
  history are unchanged. The pause lifts as soon as the membership is paid."*

Status codes: **409** for not-paid / no-company (a state conflict, retryable
after payment), **503** for unreadable on launch. Never 500, never a raw code.

### §K.6 Fail closed one way, fail open the other — the decision table

| associated set | LAUNCH (fail closed) | EXISTING VEHICLE (fail open) |
|---|---|---|
| all `paid` | allow | not frozen |
| any `not_paid` | **refuse 409**, name every failing company | **frozen**, banner names every lapsed company |
| any `unreadable`, none `not_paid` | **refuse 503** "could not check" | **NOT frozen**; the company's state renders "Not on record" and the panel says the check could not be completed |
| ∅ (no company) | `no_company_mode = enforced` → **refuse 409**; `exempt` → allow | **not frozen** — there is no company that can lapse; the no-company setting governs launching only |
| any state, active admin override | allow, and record that an override was used | not frozen; banner states an override is in place, by whom, and when |

Every response and every surface says **which** of the two happened —
"not paid up" and "could not be checked" are different sentences and are never
merged into one.

### §K.7 Freeze is derived, never stored

There is **no** `frozen` column and no scheduled job. Frozen-ness is computed
live from membership state on each read of a gated surface, so **payment lifts
the freeze on the next request** — which is what "reversible instantly on
payment" (R112.2(2)) requires. A persisted flag would need a reconciliation job
and would strand a paid-up company in a frozen state.

**Admin override** is the only persisted artefact — migration **0203**, additive,
never destructive:

`migrations/0203_wave146_spv_membership_gate_override.sql`, byte-identical mirror
in `server/db/migrations/`:

```sql
CREATE TABLE IF NOT EXISTS spv_membership_gate_override (
  id            TEXT PRIMARY KEY,
  scope         TEXT NOT NULL CHECK (scope IN ('spv','company')),
  scope_id      TEXT NOT NULL,
  action        TEXT NOT NULL CHECK (action IN ('launch','freeze','both')),
  reason        TEXT NOT NULL,
  created_by    TEXT NOT NULL,
  created_at    TEXT NOT NULL,
  revoked_at    TEXT,
  revoked_by    TEXT
);
CREATE INDEX IF NOT EXISTS idx_spv_gate_override_scope
  ON spv_membership_gate_override(scope, scope_id, revoked_at);
```

No `DROP`, no `ALTER` of an existing table, no data backfill, no `INSERT` into
`platform_config`. A revoke sets `revoked_at`; rows are never deleted. Highest
existing migration is `0199_wave143_partner_team_peers_enable.sql` in **both**
directories; this batch takes 0200 (C), 0201 (G), 0202 (H), **0203 (K)**. Apply
with `npm run db:migrate` only; never set `MIGRATIONS_DIR`; `cmp` the two copies.

### §K.8 Surfaces — what each one shows, and nothing disappears

Read model: **two new additive GET endpoints** in a new
`server/spvMembershipGateRoutes.ts` (registered with one line in
`server/routes.ts`, admin endpoints behind `requireAdmin` from
`./lib/authMiddleware`, the pattern at `server/adminFeeTierRoutes.ts:43/:144`):

* `GET /api/partner/me/spv-gate/preview?companyId=…` — the wizard's up-front
  check; returns per-company state and the sentence.
* `GET /api/spv-gate/state?spvIds=a,b,c` — per-SPV `{ spvId, moneyActionsPaused,
  viewerMessage, companies? }`. `companies` (names + states) is returned **only**
  to the sponsoring partner and to admins. Ids the caller cannot already see are
  **omitted from the response, not 403'd**, so the endpoint is not an enumeration
  oracle (the same discipline as `wave35_spv_detail_enumeration.test.ts`).

Existing payload shapes are **not** modified. This is deliberate: adding keys to
`/api/partner/me/spv/:id` or the collective/capavate list payloads would collide
with the key-set fences those routes carry (including item H's H-T1).

| surface | file | what it shows |
|---|---|---|
| wizard, up front | `PartnerSpvEngine.tsx` step 0 at `:877` | a permanent requirement statement: every attached portfolio company needs a paid-up annual Capavate membership; blind-pool launches need an administrator's allowance. **Stated here, not at the end** (R112.2(1)) |
| wizard, company step | `:1011` mandate select, `:1068` target-company input | live state beside the chosen company: paid (with period end, or "Not on record"), not paid up, or "could not be checked" |
| wizard, review | `:1242-1421`, target-company row `:1271` | the same state repeated with the exact sentence that would refuse the launch |
| wizard, launch button | `:1432`; mutation `:504`, `:569-618` | button stays **rendered**; `disabled` is set and the reason sentence is shown next to it. The server still re-checks — the client check is a courtesy, never the enforcement |
| SPV detail | `PartnerSpvDetail.tsx`, banner inserted after the header card at `:450` | always-rendered `<SpvMembershipGateBanner>`; content conditional. Names each lapsed company and the next step |
| SPV detail money actions | capital-call form `:456-504` (submit `:495`), `commitMut` `:263/:289`, `callMut` `:310/:315`, `inviteMut` `:242/:244` | buttons stay rendered and visible; `disabled` plus a stated reason. `distMut` `:371/:373` is untouched |
| partner SPV list | `PartnerSpvs.tsx` (395 lines) | a "Money actions paused" chip; no row, column or figure removed |
| collective portfolio | `MyPortfolioPage.tsx:101-102` (consumes `/api/collective/spvs` `spvEngineRoutes.ts:1410`, `/api/capavate/spvs` `:1417`) | neutral note: new commitments and capital calls are paused; existing records unchanged |
| investor / LP | `components/investor/LpPositions.tsx:72`, `SpvInvitations.tsx:48`, `lib/investor/lpVehicleInterests.ts:40/:96`; roster `/api/spv/:spvId/lp-roster` `:985` | the same neutral note. Positions, documents and history render exactly as before |
| admin | `/api/admin/consortium-spv` `:1424`; settings panel mounted in `pages/admin/LifecyclePolicies.tsx` (already routed at `App.tsx:1144`) | the two settings, the frozen-SPV list, and the override create/revoke form with mandatory reason |

**Confidentiality decision, stated not silent:** the lapsed company's **name** is
shown to the sponsoring partner and to admins, who are the parties who can act
on it. LP, investor and Collective surfaces get the neutral sentence **without**
the company name, because which portfolio company owes Capavate a fee is the
partner's and the company's commercial information, not the LP's. R112.2(2)
requires the freeze to be visible and explained on the SPV — it is, on every
surface — and requires LPs to keep full read access to their records, which they
do. **This asymmetry is recorded for the owner to overrule if he wants LPs to see
the name.**

**Drop-gate discipline.** `scripts/silent-drop-guard/guard.ts` reports
*disappeared* ids only (`computeDisappeared` `:420`, allowlist keys `:105-127`),
so additions are safe — but a conditional that replaces a sibling is not. Rules
for this item: the banner is an **always-rendered sibling** whose *content* is
conditional; every existing button stays rendered with only `disabled` and a
reason added; all gate logic is hoisted into `useMemo`; no existing
`data-testid` is renamed or removed; `npm run drop:restyle` after each step. No
allowlist entry is added by this item (R111 Q15).

### §K.9 Notification path — no new kind, no sacred edit

`server/notificationsStore.ts` is **SACRED** (manifest row 9). It does not need
editing: the kind list at `:83-125` already contains **`membership.renewal_due`
(`:113`)** and **`membership.lapsed` (`:114`)**. Emit via `emitNotification`
`:155-187`.

* **Before** the freeze — `membership.renewal_due` to the partner's team when a
  paid annual membership's period end is within 14 days, and to the founder
  company's owners. Once per company per period; the idempotency key is
  `companyId + periodEnd`, so re-emission on every read is impossible.
* **On** the freeze — `membership.lapsed` on the first request that observes a
  transition to `not_paid` for a company with at least one associated SPV, keyed
  `companyId + periodEnd + spvId`.
* **On** payment — `membership.renewal_due` is not re-sent; the banner simply
  disappears on the next read, which is the point of §K.7.

Recipients: `partnerTeamStore.listByPartner` (`server/partnerWorkspaceStore.ts:997`;
store object `:909`; `findByUserId` `:1096-1130`; `SubRole` `:121`). An
`unreadable` state **never** emits a notification — a database hiccup must not
tell a partner his company lapsed.

### §K.10 Tests — each demonstrated failing before the change

New file `server/__tests__/wave146_spv_membership_gate.test.ts` (in-memory DB
only; never touch `data.db` / `test.db`):

* **K-T1 — no company, enforced.** Launch with no `targetCompanyId` → 409, body
  `message` contains "no portfolio company attached"; no `spv` row created; no
  signoff recorded (asserts `recordSignoff` did not run — the ordering fence for
  §K.5). Fails before: today the launch succeeds.
* **K-T2 — no company, exempt.** Same request with
  `spv.launch_gate.no_company_mode = "exempt"` (written through
  `updatePlatformConfigValue`) → 201. Proves the setting is DB-driven, not a
  literal.
* **K-T3 — multi-company partial payment.** SPV with three `spv_deployment` rows;
  two companies paid, one lapsed. Deployment POST → 409 naming **only** the
  lapsed company; the two paid names must **not** appear. Fails before: no gate
  exists.
* **K-T4 — lapsed freezes, and freezes narrowly.** One associated company's
  active annual row has `current_period_end` in the past. Assert: commitment POST
  409, capital-call POST 409, deployment POST 409 — **and** that the detail
  payload, `lp-roster` (`:985`), positions and documents still return the *same
  row counts and the same figures* as before the lapse, and that distribution and
  transfer still succeed. This is the "never destructive" assertion.
* **K-T5 — UNREADABLE.** Stub the driver so `listForCompany` throws. Assert
  launch → **503** with "could not check", and **no** `spv` row; and the existing
  vehicle is **NOT** frozen — commitment POST still succeeds — while the surface
  payload reports `"Not on record"` for that company. Also assert no
  `membership.lapsed` notification was emitted. This is the single most important
  test in the item: it pins fail-closed-for-launch and fail-open-for-freeze in
  one place.
* **K-T6 — admin override.** With a lapsed company, an active `launch` override
  → 201; a `freeze` override → commitment succeeds and the payload reports the
  override with actor and timestamp; after revoke, both refuse again.
* **K-T7 — non-annual cycle.** An `active` monthly row → `not_paid /
  non_annual_cycle`, and the sentence says the membership is not an annual one
  (ruling-literal; see §K.12).
* **K-T8 — status is the authority.** An `active` annual row with a **null**
  `current_period_end` → `paid`, and the period end renders "Not on record".
  Guards against a builder inferring lapse from a missing date.
* **K-T9 — no raw code reaches a user.** Every gate response body's `message`
  matches `/^[A-Z][^_]*$/`-style prose: no `[A-Z]{2,}_[A-Z_]+` token anywhere in
  any `message` (R77 / R111 Q14), and `error` is present for machines.
* **K-T10 — canonical source only.** Static assertion over
  `server/lib/spvMembershipGate.ts`: it imports from `./subscriptionStore` and
  does **not** reference the drizzle `subscriptions` table,
  `resolveCompanyFacts`, or `resolveCanonicalPlan`; and it contains **no**
  `catch` that assigns a boolean literal. Guards §K.1's whole argument.
* **K-T11 — sacred untouched.** `SPEC_ROOT="$PWD/spec" npm run sacred` clean;
  waiver count is **NINE**; `subscriptionStore.ts`, `canonicalPlanResolver.ts`,
  `notificationsStore.ts` hashes unchanged.
* **K-T12 — client, `client/src/pages/partner/__tests__/wave146_gate_ui.test.tsx`.**
  With a lapsed company: the launch button is still **present** and `disabled`
  with a reason; the capital-call submit is still **present** and `disabled`; the
  banner names the company; every `data-testid` present before the change is
  still present. With `unreadable`: the banner says the check could not be
  completed and the buttons are **enabled**.

**Existing tests that pin today's behaviour — the honest count.** **32 test
files** exercise the launch path with a signoff (29 under `server/__tests__/`,
including `w82_spv_launch_atomicity`, `spvEngine`, `spvUnifiedCanonical`,
`w127_five_money_surfaces_agree`, `wave140_spv_cap_null_and_refusal_order`,
`wave3f_item1_atomicity`, `spvFeeObligations`; plus 3 client tests —
`w82_spv_launch_and_review`, `w138_partner_create_payloads`,
`wave140_spv_blank_cap`). With `capavate_subscriptions` empty in fixtures, an
enforced gate turns **all of them red at once**. That is the single largest
regression surface in this batch.

The fix is one shared helper, not 32 edits of judgement:
`server/__tests__/helpers/seedPaidMembership.ts` — records and activates an
`active` annual `capavate_subscriptions` row through `subscriptionStore`'s own
exported functions (call-only; the store is sacred) and is invoked in each
affected file's existing setup. **Per R98:** every touched test keeps its name,
keeps every assertion, and gains a one-line comment naming **R112** as the reason
its fixture grew. Record the before/after assertion count for each of the 32
files; a reduction anywhere is a stop. Do **not** "fix" a red test by loosening
the gate, and do not add a test-only bypass environment variable — the census in
§K.11 is the answer to the production version of the same problem.

### §K.11 Precondition — the membership census, before enforcement

`capavate_subscriptions` has **0 rows** in `data.db`, and `companies` has **364**.
Read literally, "apply across the board, retroactively" with a `0`-row canonical
table means **every** existing SPV freezes and **every** launch is refused on the
day this lands. That is very probably a data-migration gap, not the owner's
intent.

So `K_membership_census.tsv` is a **precondition of switching
`spv.launch_gate.membership_mode` to `enforced`**, produced from the read-only
copies and shown to the owner: one row per company (id, name, state, kind, period
end) and one row per SPV that would freeze (spv id, name, sponsor, each
associated company and its state). The code, the migration, the settings at
default, the surfaces and the tests all land first with the census produced in
the same step; the owner sees the census and then the mode is confirmed. If the
census shows 364 unpaid companies, the honest interim is `warn` — banners and
recorded reasons, no blocking — until membership data is loaded. **That decision
is the owner's, not the builder's.**

### §K.12 Open questions returned to the owner — not invented answers

1. **Distributions and transfers are not blocked** (§K.5). Confirm.
2. **Monthly and one-time cycles** are treated as *not* an annual membership
   (R112.1 says annual). A company paying monthly is therefore not paid up. This
   is ruling-literal and may not be intended; no setting was invented for it.
3. **Do LPs see the lapsed company's name?** §K.8 says no. Overrule if wanted.
4. **`warn` mode's existence** is justified by R112.2(1)'s configurability order
   and by the census; if the owner wants only `enforced`, the key becomes a
   single-valued setting and K-T2 changes accordingly.

### §K.13 Files and classification

| file | kind |
|---|---|
| `server/lib/spvMembershipGate.ts` | **new**, server |
| `server/spvMembershipGateRoutes.ts` | **new**, server |
| `server/spvEngineRoutes.ts` (`:319-451`, `:679`, `:685`, `:734`, `:740`, `:755`, `:1176`) | edit, server |
| `server/spvFundStore.ts` (`:1551`, `:1582`, `:1628`, `:1742`) | edit, server |
| `server/routes.ts` | edit, server — one registration line |
| `migrations/0203_wave146_spv_membership_gate_override.sql` + `server/db/migrations/` mirror | **migration**, byte-identical |
| `client/src/components/partner/SpvMembershipGateBanner.tsx` | **new**, client |
| `client/src/components/admin/SpvLaunchGateSettingsPanel.tsx` | **new**, client |
| `client/src/pages/partner/PartnerSpvEngine.tsx`, `PartnerSpvDetail.tsx`, `PartnerSpvs.tsx` | edit, client |
| `client/src/pages/admin/LifecyclePolicies.tsx` | edit, client — mounts the panel; **no new route**, no `App.tsx` change |
| `client/src/pages/collective/MyPortfolioPage.tsx`, `client/src/components/investor/LpPositions.tsx` | edit, client — neutral note only |
| boot seed of the two `platform_config` keys | edit, server — via `ensurePlatformConfigKey` |

### §K.14 Blast radius

* **Consortium Partner** — the largest. Launching, commitments, deployments and
  capital calls can all refuse where they previously succeeded, on **existing**
  vehicles. Nothing is hidden: every figure, roster, document and history entry
  still renders. Wizard copy changes on three steps.
* **Collective** — read-only impact: a neutral paused note on affected vehicles
  in `MyPortfolioPage`. `/api/collective/spvs` (`:1410`) payload shape unchanged.
* **Capavate founder** — a founder whose company's membership lapses can cause a
  partner's vehicle to pause. Founders receive `membership.renewal_due` /
  `membership.lapsed`; the founder-side subscription UI
  (`founder/Company.tsx:616`) is **not** changed by this item, and its
  `pending_payment` display continues to come from the decoy table — a known
  inconsistency, not widened here.
* **Investor / LP** — no capability removed. A commitment invitation may become
  unactionable with a stated reason. Positions, documents, history: unchanged.
* **Admin** — gains two settings, a frozen-SPV list and an override with a
  mandatory reason, all inside the already-routed lifecycle-policies page. Every
  setting change is audited by the `platform_config` triggers; every override is
  a durable row with actor, reason and timestamp.

### §K.15 Sacred status

**No sacred file is edited.** `server/subscriptionStore.ts` (row 4),
`server/lib/canonicalPlanResolver.ts` (row 19) and
`server/notificationsStore.ts` (row 9) are **called only** — which is precisely
why the three-state reader is a new file and why the notification kinds are
reused instead of added. `spvEngineRoutes.ts`, `spvFundStore.ts`,
`spvEngineStore.ts`, `partnerWorkspaceStore.ts`, `platformConfigWriter.ts`,
`PartnerSpvEngine.tsx` and `PartnerSpvDetail.tsx` are **not** sacred (verified
against `sacred_baseline/SACRED_SHA256.txt`). The batch's **one** authorised
sacred edit remains item B site 7, and the waiver count remains **NINE**.

---
