#!/bin/bash
# grep in stripped file: g.sh file pattern
python3 /home/user/workspace/b2/strip.py "/home/user/workspace/work/$1" | grep -n "$2"
