#!/usr/bin/env python3
"""BATCH 2 ITEM B class sweep — unknown money coerced to zero.

Re-runnable. Comment-stripped (uses b2/strip.py's algorithm, inlined so this
script has no external dependency). Emits TSV: file<TAB>line<TAB>class<TAB>text

Classes:
  COALESCE_NUM   money-named identifier ?? 0 / || 0
  COALESCE_STR   money-named identifier ?? "0" / || "0"
  NUMBER_OR_ZERO (Number(x) || 0) / Number(x) ?? 0
  DEFAULT_ZERO   `<moneyName>: 0` literal in an object projection

Usage: python3 b2v2/sweep_money_zero.py [root...]
"""
import os, re, sys

def strip(src):
    out = []; i = 0; n = len(src); state = 'code'; q = ''
    while i < n:
        c = src[i]
        if state == 'code':
            if c in '"\'`':
                state = 'str'; q = c; out.append(c); i += 1; continue
            if c == '/' and i + 1 < n and src[i+1] == '/':
                while i < n and src[i] != '\n': i += 1
                continue
            if c == '/' and i + 1 < n and src[i+1] == '*':
                i += 2
                while i + 1 < n and not (src[i] == '*' and src[i+1] == '/'):
                    if src[i] == '\n': out.append('\n')
                    i += 1
                i += 2; continue
            out.append(c); i += 1; continue
        else:
            out.append(c)
            if c == '\\':
                if i + 1 < n: out.append(src[i+1]); i += 2; continue
                i += 1; continue
            if c == q: state = 'code'
            i += 1; continue
    return ''.join(out)

MONEY = (r"(?:investmentAmount|amountMinor|amount|pricePerShare|pricePerShareMinor|accruedInterest|"
         r"principal|invested|investedMinor|commitmentMinor|committedMinor|preMoney|postMoney|"
         r"valuation|valuationMinor|purchase|purchaseAmount|purchaseMinor|proceeds|distribution|"
         r"feeMinor|priceMinor|totalMinor|capitalMinor|nav|navMinor|balanceMinor|paidMinor|"
         r"minor|cap|fee|price|total|subtotal|salary|comp|payout|carry|management|dividend)")
IDENT = r"[A-Za-z_$][\w$.?\[\]\"'()]*"

PATTERNS = [
    ("COALESCE_NUM",  re.compile(r"(" + IDENT + MONEY + IDENT + r"?)\s*(?:\?\?|\|\|)\s*0(?![\d.])", re.I)),
    ("COALESCE_STR",  re.compile(r"(" + IDENT + MONEY + IDENT + r"?)\s*(?:\?\?|\|\|)\s*[\"']0[\"']", re.I)),
    ("NUMBER_OR_ZERO", re.compile(r"Number\s*\([^)]*\)\s*(?:\|\||\?\?)\s*0(?![\d.])")),
    ("DEFAULT_ZERO",  re.compile(r"\b(" + MONEY + r"\w*)\s*:\s*0\s*[,}]", re.I)),
]

SKIP_DIR = {"node_modules", "dist", "release", ".git", "migrations", "migrations-pg", "handover"}

def is_test(p):
    return "__tests__" in p or ".test." in p or ".spec." in p or "/tests/" in p or "/e2e/" in p

def main(roots):
    rows = []
    for root in roots:
        for dp, dns, fns in os.walk(root):
            dns[:] = [d for d in dns if d not in SKIP_DIR]
            for fn in fns:
                if not fn.endswith((".ts", ".tsx")):
                    continue
                p = os.path.join(dp, fn)
                if is_test(p):
                    continue
                try:
                    src = strip(open(p, encoding="utf-8", errors="replace").read())
                except Exception:
                    continue
                for i, line in enumerate(src.split("\n"), 1):
                    for cls, rx in PATTERNS:
                        if rx.search(line):
                            rows.append((p, i, cls, line.strip()[:160]))
                            break
    for r in sorted(rows):
        print("\t".join(map(str, r)))
    print(f"# TOTAL {len(rows)} candidate sites in {len(set(r[0] for r in rows))} files", file=sys.stderr)

if __name__ == "__main__":
    main(sys.argv[1:] or ["client", "server", "shared"])
