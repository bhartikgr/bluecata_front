# VERDICT: APPROVE

## Gate results
- `canProject` handles null/undefined: false
- `canProject` handles 0 preMoney: false
- `canProject` handles 0 targetAmount: false
- `canProject` handles valid positive numbers: true

## Per-check confirmation
- **No crash for the fresh-round case:** Test suite passes, which validates that degenerate inputs don't result in a crash and `canProject` gate works.
- **Gate correctness:** The `canProject` boolean relies on `Number(round.preMoney)` and `Number(round.targetAmount)`, verifying if they are finite and greater than 0, ensuring false for null, undefined, 0, NaN.
- **Valid rounds still project:** If `canProject` is true, `projectPostClose` is called with the numeric values as expected, continuing to function.
- **Engine null-safety:** The `projectPostClose` signature has been widened to `number | null | undefined`, and inside it coerces `round.preMoneyValuation` and `round.investmentAmount` using `Number` and validating with `Number.isFinite`, defaulting to 0. This resolves the `Cannot read properties of null (reading 'toString')` issue.
- **No engine-package edit:** The output of `git diff HEAD~1 --name-only` confirmed only three files edited: `client/src/lib/engineDemo.ts`, `client/src/pages/founder/RoundDetail.tsx`, and `client/src/lib/engineDemo.waveC4.test.ts`. `packages/cap-table-engine` is completely untouched.
- **Sacred 40/40:** Verified `sha256sum -c sacred_baseline/SACRED_SHA256.txt` returned 40 matches.
- **Money SHA16:** `server/captableCommitStore.ts` starts with `01cd36130ee1c0cb`.
- **TSC Errors:** Maintained exactly 598.
- **Guard:** Exited 0 with unmodified count (929 / 194 / 92).