# W-SHADIE Build Spec (decider-approved SOUND) — execution

Tree: /home/user/workspace/capavate_avi65_build (live wavi64 + W-AVI65). Sacred 40/40. Build on top; ship as v26.2.0-wshadie.
Full analysis: _WSHADIE reference = /home/user/workspace/capavate_wshadie/WSHADIE_ANALYSIS_AND_STRATEGY.md (read it).

## OWNER DECISIONS (locked)
- 5a: **icon-then-label** (icon, then text).
- 3a: **7-day** consistent default across ALL surfaces; 7 is the FIRST option; KEEP "Never" on RoundDetail.
- Bulk CSV: **align to 7** (server 14→7) + fix the "30-day" copy to "7-day".
- Scope: stacked on W-AVI65 (one package).

## HARD RULES
- Additive + behavior-preserving. NON-sacred files only (all targets confirmed non-sacred). Sacred 40/40 must hold — do NOT edit any sacred file; if something seems to need it, STOP and report.
- Keep ALL existing data-testids. Keep all existing behavior except the specified default-value/label/column changes.
- DB-driven; no in-memory canonical state; no money/commit/captable/isolation changes.

## FIX 2a — Apply-to-Collective checkboxes visible before checking
File: client/src/pages/founder/ApplyToCollective.tsx (the two <Checkbox> at data-testid="checkbox-fee-ack" and "checkbox-open-to-refinement").
- Add className="h-5 w-5 border-2 border-slate-500 bg-white data-[state=checked]:border-primary" to BOTH.
- Do NOT edit the shared client/src/components/ui/checkbox.tsx (20 consumers).
- Result: clearly visible empty box on the pale amber/blue panels; checked state still flips to brand red (primitive's data-[state=checked]:bg-primary still applies).
- SCOPE NOTE (put in fix report): fixes only these two instances by design.

## FIX 3a — 7-day consistent invite expiry
1. NEW client/src/lib/inviteExpiry.ts:
   export const INVITE_EXPIRY_OPTIONS = [7,14,30,60,90] as const;
   export const DEFAULT_INVITE_EXPIRY_DAYS = 7;
2. RoundNew.tsx:
   - :307 manualDraft state default expiryDays "14" -> "7".
   - :1344 post-add reset expiryDays "14" -> "7".
   - :1343 push `Number(manualDraft.expiryDays) || 14` -> `|| DEFAULT_INVITE_EXPIRY_DAYS`.
   - :1297 option map -> map over INVITE_EXPIRY_OPTIONS (shadcn <SelectItem>).
   - :1305 hint fallback `|| 14` -> `|| DEFAULT_INVITE_EXPIRY_DAYS`.
   - :305 comment "default 14" -> "default 7".
3. RoundDetail.tsx:
   - :129 inviteExpiry useState("30") -> useState("7") (or String(DEFAULT_INVITE_EXPIRY_DAYS)).
   - :189 post-send reset setInviteExpiry("30") -> setInviteExpiry("7").
   - :945 native <option> list -> 7/14/30/60/90 + keep "never" (7 FIRST). MUST include 90 (do not drop it).
   - Do NOT change the Extend increment at :250 ({expiryDays:30} = extend-by, different feature).
   - "Never" is really 14 today via server ?? 14 — leave option, do NOT claim it works (known pre-existing).
4. Bulk CSV (align to 7):
   - server/lib/bulkInvitationsRoutes.ts: change the 14-day expiry calc (:107) AND the two email-copy strings (:231 "expires in 14 days", :236) from 14 -> 7.
   - RoundDetail.tsx:972 dialog copy "default 30-day expiry" -> "default 7-day expiry".
5. UPDATE existing test client/src/pages/founder/__tests__/v2413_groupA_fixes.test.ts (THREE stale assertions):
   - L63 `toContain('"30"')` -> assert the NEW default (e.g. inviteExpiry useState("7") present). Keep it meaningful (assert "7" wired to inviteExpiry), don't just delete.
   - L68 `toContain('onChange={e => setInviteExpiry(e.target.value)}')` -> this is ALREADY RED on baseline (source is multi-statement `onChange={e => { setInviteExpiry(e.target.value); setInvitePreviewHtml(null); }}` at :944). Update assertion to match the ACTUAL handler. Do NOT change the source to satisfy it.
   - L84 `toContain('setInviteExpiry("30")')` -> `setInviteExpiry("7")`.
   - (L77-78 assert value="14"/"30" OPTIONS still exist — they DO, keep green.)
   TESTS THAT MUST STAY GREEN (do NOT touch, they exercise the server ?? 14 fallback which we do NOT change): waveC3_invite_preview_and_round_name.test.ts:45 ("expires in 14 days" renderer default), v25_55_shadie_v6.test.ts, v15_invitation_flow.test.ts, sprint14_stores.test.ts:158 (staleness constant, unrelated). NOTE: bulk copy change is server-side; confirm no test asserts bulk "14 days" copy — if one does, that's a NEW break to reconcile; report it.

## FIX 4a — Resent column between Sent and Viewed (RoundDetail.tsx invitations table)
- Header: add <th className="text-left font-medium px-3 py-2.5">Resent</th> BETWEEN the Sent th (:531) and Viewed th (:532).
- Cell: add a <td> BETWEEN the Sent cell (ends ~:569) and Viewed cell (~:570), rendering resentAt with the SAME pattern as Sent: absolute fmtDate on top + muted timeAgo below; "—" when null. Give it data-testid={`inv-resent-${i.id}`}.
- ALSO add data-testid={`inv-viewed-${i.id}`} to the Viewed cell (:570) so the cell-order test can assert on it (it currently has none).
- Empty-state colSpan={6} (:540) -> colSpan={7}. Do NOT touch colSpan={5} (:647) or colSpan={3} (:694).
- resentAt is ALREADY returned by the API (roundInvitationsStore publicView) and typed on Invitation (:56) — NO server change.
- Keep the existing teal "resent" StateBadge chip in the State column (additive; Shadie liked it).

## FIX 5a — action labels (icon-then-label) (RoundDetail.tsx ~:581-583)
- Resend button: <Repeat className="h-3.5 w-3.5 mr-1" />Resend
- Extend button: <Calendar className="h-3.5 w-3.5 mr-1" />Extend
- Revoke button: <Ban className="h-3.5 w-3.5 mr-1" />Revoke  (keep className text-destructive)
- Keep all disabled logic and data-testids EXACTLY. Add aria-label too (belt-and-suspenders) but the visible text is the fix.

## TESTS (client/src/pages/founder/__tests__/wshadie_*.test.ts) — ANTI-VACUITY (mandatory)
- wshadie_2a: extract each of the two checkbox element substrings (by data-testid) and assert border-2 + a neutral border + bg-white are INSIDE each — not file-wide.
- wshadie_3a: assert ABSENCE of old literals (inviteExpiry useState("30"), setInviteExpiry("30"), the two expiryDays:"14" resets) AND presence of the new 7 default wired to state; assert INVITE_EXPIRY_OPTIONS/DEFAULT_INVITE_EXPIRY_DAYS exist AND are imported/used (not an orphan module); assert RoundDetail option list includes value="7" as first and still includes value="90" and "never".
- wshadie_4a: assert ORDINAL position in BOTH header (indexOf("Resent") between ">Sent<" and ">Viewed<") AND the cell row (inv-sent- before inv-resent- before inv-viewed-); assert colSpan={7}.
- wshadie_5a: extract each data-testid'd button substring and assert its label text ("Resend"/"Extend"/"Revoke") is INSIDE that button (not anywhere in file).
- wshadie_bulk (optional): assert bulkInvitationsRoutes uses 7 (no residual 14 in the expiry calc/copy) and RoundDetail copy says "7-day".

## OUTPUT
Write /home/user/workspace/capavate_avi65_build/_WSHADIE_RESULT.md: files changed (new+edited), per-item change + which live surface it targets, confirm sacred 40/40 (no sacred edits), the v2413 test reconciliation (3 assertions, incl. the L68 pre-existing red), any test that unexpectedly breaks, and the anti-vacuity test list. Return a concise summary + the result path.
