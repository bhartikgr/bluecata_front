# Capavate v25.49.1 — HOTFIX (Bug 1: investor invitation page crash)

Single-bug hotfix on top of v25.49.0. Client-only. Additive; no migrations; no dependency changes.
Triple-model not required for a one-line-class null guard, but full gates pass. Sacred 39/39 · tsc 601 · build 0.

## Bug 1 — Investor Invitation page crashed ("can't access property 'replace', ke.category is undefined")
Root cause: dataroom-file table cells rendered `f.category.replace("_"," ")` with no guard. A freshly
invited investor's file record (or a round use-of-proceeds entry) can have a null/undefined `category`,
so the call threw and the error boundary took down the whole invitation page. `category` is legitimately
optional, so the fix is a render-side null guard (backend unchanged).

Fixes:
- client/src/pages/investor/InvitationDetail.tsx:603 — `{f.category ? f.category.replace("_"," ") : "Uncategorized"}`
- client/src/pages/investor/InvitationDetail.tsx:544-546 — use-of-proceeds map now `(i.round.useOfProceeds ?? [])`,
  with a stable fallback React key `key={u.category ?? \`uof-${idx}\`}` and label `{u.category ?? "Uncategorized"}`
- client/src/pages/investor/InvitationDetail.tsx:600 — `(dr.data ?? []).slice(0, 8)` (loading/pre-load guard)
- client/src/pages/investor/CompanyDetail.tsx:379 — `{(f.category ?? "").replace("_"," ") || "Uncategorized"}`

Regression test: client/src/pages/investor/__tests__/dataroomCategory.regression.test.ts (8 tests) — asserts
null/undefined category renders "Uncategorized" (no throw), normal category still transforms, and pins the
source so a revert to the crashing form fails CI.

## Gates
Sacred 39/39 byte-identical · tsc 601 (zero net-new) · build BUILD_EXIT=0 · regression test 8/8 · no migrations.
