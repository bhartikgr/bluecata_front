# VERDICT: REVISE

I cannot approve Wave A as shipped. The required gates are mostly green, but there are real correctness/security defects in the 1c sign-off implementation and real 2a claim mismatches.

## Gate results

- `npx tsc --noEmit 2>&1 | grep -c "error TS"`: **598** (expected 598)
- `sha256sum -c sacred_baseline/SACRED_SHA256.txt 2>&1 | grep -c ": OK"`: **40** (expected 40)
- `sha256sum server/captableCommitStore.ts | cut -c1-16`: **01cd36130ee1c0cb** (expected 01cd36130ee1c0cb)
- `npm run guard`: **exit 0**, tail shows `OK: 924 routes, 193 pages, 91 nav — no silent drops`
- `diff migrations/0108_1c_spv_launch_signoffs.sql server/db/migrations/0108_1c_spv_launch_signoffs.sql`: **identical** (`diff_exit=0`)
- `grep -nE "\brequire\(" server/spvLaunchSignoffStore.ts shared/partnerTitles.ts`: **empty** (`grep_exit=1`)
- Extra targeted tests: `spvUnifiedCanonical.test.ts` **9/9 passed**; `partner_workspace.test.ts` + `groupF1_partner_crm_parity.test.ts` **34/34 passed**; sprint18 phase tests show the reported **2 outbox failures** (not independently re-run on pristine HEAD).

## Defects requiring revision

1. **1c durable sign-off can be bypassed when sign-off persistence fails.**
   - `server/spvEngineRoutes.ts:120-123` creates and persists the SPV before sign-off durability is guaranteed.
   - `server/spvLaunchSignoffStore.ts:88-104` catches insert failures, logs them, and still returns an in-memory record.
   - Why this violates the brief: the hard rule requires a verifiable, durable sign-off for launch. With the current code, a missing/broken `spv_launch_signoffs` table or DB write failure still returns `201` with an SPV created and no durable sign-off row.
   - Suggested fix: make sign-off persistence fail closed and atomic with SPV creation. Do not swallow `recordSignoff` DB errors. Create the SPV and sign-off in one transaction, or roll back/delete the SPV if sign-off insertion fails; never return success unless the sign-off row is durably written.

2. **1c records the signer sub-role incorrectly.**
   - `server/lib/requirePartnerAuth.ts:59-65` stores the session role as `partnerSubRole`.
   - `server/spvEngineRoutes.ts:128` reads `(ctx as { subRole?: string }).subRole`, so `signerSubRole` is always `null` for normal partner sessions.
   - Why this violates the report: the sign-off record is supposed to capture the signer’s partner sub-role at signing time.
   - Suggested fix: use `ctx.partnerSubRole` when calling `recordSignoff`.

3. **2a does not implement the claimed 20-title list.**
   - `shared/partnerTitles.ts:13-31` contains **18** entries, while the brief and fix report both claim **20** display titles.
   - Why this violates the requested change/report: the shipped enum does not match the specified 20-title QA list.
   - Suggested fix: reconcile `PARTNER_TITLES` with the approved 20-title list from the QA deck and add a unit test asserting the exact count/order.

4. **2a invitation titles are not carried onto active members after redemption.**
   - `server/partnerWorkspaceStore.ts:1176-1190` creates the redeemed team member from `durable.subRole` but ignores `durable.title`.
   - `server/partnerRoutes.ts:1174-1177` renders active member `title` from `partner_team_member_contact.positionNote`, but redemption never writes that field.
   - Why this violates the report: pending invitations can carry `title`, but after redemption the title disappears unless manually re-entered through the contact override path.
   - Suggested fix: on invite redemption, persist a validated `durable.title` into the member’s title/position-note override, or add an explicit member-title field and route; keep it separate from `subRole`.

## Correctness notes

- 1c missing legal name and unaccepted attestation do return 400 before `createSpv` is called (`server/spvEngineRoutes.ts:112-120`), and signer identity uses `ctx.userId` from the session (`server/spvEngineRoutes.ts:123-127`). The durability bypass above remains ship-blocking.
- 1d partner post labels implement screen-name/company/generic fallback and anonymous-without-screen-name maps to `Consortium Partner` (`server/commsStore.ts:1274-1303`); sacred privacy/profile files remain byte-identical via the sacred hash gate.
- 1e client derivation returns valid strict enum values and defaults unknown countries to `delaware` (`client/src/pages/partner/PartnerSpvEngine.tsx:113-124`), but the actual server store rejects non-enum jurisdictions rather than exposing a `canonicalJurisdiction` fallback (`server/spvEngineStore.ts:260-262`). The report’s “mirrors server fallback exactly” rationale is inaccurate and should be reconciled.
- 2a server invitation creation still rejects any `subRole` outside the five permission tiers (`server/partnerRoutes.ts:1218-1225`), so titles do not currently escalate permissions.
