# Independent verification brief — Capavate Wave C2 (Shadie QA 1a/1b)

You are an INDEPENDENT verifier. Return APPROVE or REVISE with concrete file:line
defects + fixes. Read the real files. Be adversarial; flag only REAL issues. The
work is committed at HEAD — use `git diff HEAD~1` for the C2 diff. Do NOT run
`git checkout -- .` / `git reset` / any broad checkout that discards the tree.

Build tree: `/home/user/workspace/capavate_work` (deps installed). Diff:
`WAVE_C2_SOURCE.diff`. Report: `FIX_REPORT_WAVE_C2.md`. Live repro:
`capavate_crm_round_bug_repro_2026-07-10.md`.

## What C2 does
Bug (reproduced on live): a CRM/manual investor picked in round-creation Step 4
was recorded only as an initial-shareholder, never issued a round invitation, so
it did NOT appear in the round's Investor-invitations tab and no email was sent.

Fix (non-sacred, no migration):
- `server/lib/roundInitialShareholdersStore.ts` — the PATCH
  `/api/founder/rounds/:roundId/initial-shareholders` handler (now `async`) issues
  a canonical `roundInvitationsStore.createInvitation` for each picked investor
  with a valid email (surfaces them in the Invitations table + sends the email).
  Idempotent (duplicate_invitation => benign skip); no-email => skip; per-invite
  failures collected in `inviteErrors` and returned, NOT silently swallowed, and
  do NOT roll back the shareholder save. Lazy `require` is try/catch-guarded.
  Response: `{ ok, roundId, count, invited, skippedNoEmail, skippedDuplicate, inviteErrors }`.
- `client/src/pages/founder/RoundNew.tsx` — round-create onSuccess reads the
  summary and shows an accurate toast instead of swallowing the result.

## HARD RULES (any violation = REVISE)
1. Sacred 40/40 byte-identical (roundsStore.ts is SACRED — confirm untouched; no
   sacred file in the diff).
2. Money `server/captableCommitStore.ts` sha16 `01cd36130ee1c0cb`.
3. tsc net-new = 0 → exactly **598**.
4. Guard exit 0, counts UNCHANGED (926 / 194 / 92).
5. No NEW `require()` idiom beyond this file's existing createRequire shim (the
   file already uses lazy require for the sacred roundsStore boundary; the new
   one follows the same pattern and is try/catch-guarded). No new migration.
   Payments/Airwallex untouched.

## Correctness to verify (adversarial)
- **The pick now LANDS + is emailed:** confirm `createInvitation` is the store
  that `GET /api/rounds/:id/invitations` reads (roundInvitationsListForRound), so
  issuing it makes the investor appear in the Invitations tab AND sends the email
  (same path the round-detail invite uses). RUN
  `server/__tests__/waveC2_crm_investor_lands_on_round.test.ts` (3 tests).
- **No double-send / idempotent:** a re-PATCH (or an already-active invite) must
  NOT send a second email — confirm `duplicate_invitation` is caught as a benign
  skip (skippedDuplicate++), not surfaced as an error and not re-sent.
- **No-email pick:** must be recorded as a shareholder but NOT invited (no
  spurious invite, counted in skippedNoEmail).
- **Fail-closed reporting, not roll back:** an invite failure must be reported in
  `inviteErrors` and must NOT fail the shareholder save (round already exists).
- **Ownership gate intact:** the handler's existing ownership check
  (callerOwnsRound / admin) still runs before issuance; a non-owner still 403s.
- **Guarded require:** if `require("../roundInvitationsStore")` throws (isolated
  harness), the endpoint must still succeed (skip issuance), not 500.
- **No regression:** RUN `server/__tests__/v2348_round_initial_shareholders.test.ts`
  (the existing endpoint test) — must still pass after the async change.
- **Client toast:** confirm onSuccess reads the summary safely (json parse
  guarded) and never throws if the PATCH is skipped (selectedShareholders empty).

## Known pre-existing (NOT a regression)
`server/__tests__/sprint21_invitations.test.ts` has 2 co-soft-circle failures on
pristine HEAD. Unrelated to C2.

Run:
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # exit 0, 926/194/92
npx vitest run server/__tests__/waveC2_crm_investor_lands_on_round.test.ts server/__tests__/v2348_round_initial_shareholders.test.ts   # all pass
```
If you run `npm run build`, restore ONLY: `git checkout -- server/public && git clean -fdq server/public/assets dist` (scoped; never a broad checkout). Do NOT commit.

## Output
Write to `/home/user/workspace/capavate_work/VERDICT_C2_<model>.md`:
1. VERDICT: APPROVE / REVISE
2. Gate results (actual numbers)
3. Per-check confirmation or defect (file:line + fix)
