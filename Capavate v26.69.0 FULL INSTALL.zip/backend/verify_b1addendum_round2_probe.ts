import express from "express";
import request from "supertest";
import { createHash } from "node:crypto";
import { registerPartnerRoutes } from "./server/partnerRoutes";
import { registerPartnerPortfolioCompanyRoutes } from "./server/partnerPortfolioCompanyRoutes";
import { registerCompanyAttributionRoutes } from "./server/companyAttributionRoutes";
import { seedTestPartnerSandbox } from "./server/partnerWorkspaceStore";
import { getListedCompanyIds, upsertDirectoryListing } from "./server/collectiveInterestStore";
import { addCompanyForFounder } from "./server/multiCompanyStore";
import { linkConsortiumPartner } from "./server/consortiumLinkStore";

process.env.VITEST = "true";
process.env.NODE_ENV = "test";
process.env.ENABLE_DEMO_SEED = "1";

const MANAGING = "u_avi_managing";
const PARTNER_A = "ac_consortium_partner_test_partner_inc";
const UNRELATED = "u_aisha_patel";
const ADMIN = "u_admin";

function pendingFounderUserId(email: string): string {
  const h = createHash("sha256").update(email.trim().toLowerCase()).digest("hex").slice(0, 16);
  return `u_pending_founder_${h}`;
}

async function main() {
  const app = express();
  app.use(express.json());
  registerPartnerRoutes(app);
  registerPartnerPortfolioCompanyRoutes(app);
  registerCompanyAttributionRoutes(app);
  seedTestPartnerSandbox({ force: true });

  const founderEmail = `round2-${Date.now()}@example.com`;
  const create = await request(app)
    .post("/api/partner/me/portfolio-companies")
    .set("x-user-id", MANAGING)
    .send({ companyName: "Round 2 Probe Private Co", founderEmail });
  if (create.status !== 201) throw new Error(`create failed ${create.status}: ${JSON.stringify(create.body)}`);
  const companyId = create.body.companyId as string;
  const pendingFounderUserIdValue = pendingFounderUserId(founderEmail);
  const freshListed = getListedCompanyIds().has(companyId);

  async function attr(targetCompanyId: string, userId: string) {
    const r = await request(app).get(`/api/companies/${targetCompanyId}/attribution`).set("x-user-id", userId);
    if (r.status !== 200) throw new Error(`attr ${targetCompanyId} ${userId} status ${r.status}: ${JSON.stringify(r.body)}`);
    return r.body.attributedPartner ?? null;
  }

  const unrelatedPrivate = await attr(companyId, UNRELATED);
  const partnerPrivate = await attr(companyId, MANAGING);
  const adminPrivate = await attr(companyId, ADMIN);

  upsertDirectoryListing(companyId, `app_probe_${Date.now()}`, { chapter: "chap_probe", stage: "Seed", sector: "Fintech" });
  const listedAfterUpsert = getListedCompanyIds().has(companyId);
  const unrelatedPublic = await attr(companyId, UNRELATED);

  const founderCompanyId = `co_founder_probe_${Date.now()}`;
  addCompanyForFounder("u_maya_chen", {
    companyId: founderCompanyId,
    companyName: "Round 2 Founder-Owned Probe Co",
    legalName: "Round 2 Founder-Owned Probe Co, Inc.",
    logoUrl: null,
    role: "founder",
    lastActiveAt: new Date().toISOString(),
    kpi: { capTableHolders: 0, activeRoundsCount: 0, raisedThisYearUsd: 0, dataroomFiles: 0, pendingSoftCircles: 0, ownershipPct: 0 },
    collective: { status: "none" },
    billing: { plan: "Founder Free", monthlyUsd: 0, nextBillingDate: "—", cardLast4: null, invoiceCount: 0 },
    sector: "Fintech",
    stage: "Seed",
    hq: "Toronto",
  } as any);
  linkConsortiumPartner(founderCompanyId, PARTNER_A);
  const founderPrivate = await attr(founderCompanyId, "u_maya_chen");

  const result = {
    companyId,
    pendingFounderUserId: pendingFounderUserIdValue,
    founderCompanyId,
    freshListed,
    listedAfterUpsert,
    unrelatedPrivate,
    partnerPrivate,
    founderPrivate,
    adminPrivate,
    unrelatedPublic,
  };
  console.log(JSON.stringify(result, null, 2));

  if (freshListed !== false) throw new Error("fresh B1 company was unexpectedly listed");
  if (unrelatedPrivate !== null) throw new Error("private attribution leaked to unrelated user");
  for (const [label, value] of Object.entries({ partnerPrivate, founderPrivate, adminPrivate, unrelatedPublic })) {
    if (!value || (value as any).partnerId !== PARTNER_A || !(value as any).name) {
      throw new Error(`${label} did not receive linked partner attribution: ${JSON.stringify(value)}`);
    }
  }
  if (listedAfterUpsert !== true) throw new Error("listing upsert did not make company public");
}

main().catch((err) => { console.error(err); process.exit(1); });
