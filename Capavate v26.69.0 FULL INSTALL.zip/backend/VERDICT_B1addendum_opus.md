# VERDICT — Wave B1 ADDENDUM (independent verification, Opus)

**Verdict: APPROVE**

Scope: surfacing a "Led by <Consortium Partner>" attribution badge on the founder
Dashboard, CapTable, and RoundDetail surfaces via a NEW read-only endpoint
`GET /api/companies/:id/attribution`. Diff: `WAVE_B1_ADDENDUM.diff`.
Report: `FIX_REPORT_WAVE_B1.md` (Addendum section).

## Gate results (all pass)

| Gate | Expected | Actual | Result |
|------|----------|--------|--------|
| `npx tsc --noEmit \| grep -c "error TS"` | 598 (0 net-new; baseline BigInt/Dashboard errors are pre-existing) | 598 | ✅ |
| `sha256sum -c sacred_baseline/SACRED_SHA256.txt \| grep -c ": OK"` | 40 | 40 | ✅ |
| `sha256sum server/captableCommitStore.ts \| cut -c1-16` (money) | 01cd36130ee1c0cb | 01cd36130ee1c0cb | ✅ |
| `npm run guard` | exit 0, no silent drops | exit 0 — "926 routes, 194 pages, 92 nav — no silent drops" | ✅ |
| vitest (company_attribution + add_portfolio_company + adversarial_orphan) | all pass | 3 files, 7 tests passed | ✅ |
| `grep -nE "\brequire\(" server/companyAttributionRoutes.ts` | none | none | ✅ |

## Sacred / boundary confirmation
- `server/profileStore.ts` is **NOT** in the addendum diff and matches its sacred
  baseline hash (part of the 40/40 OK). The addendum added a **separate**
  endpoint (`companyAttributionRoutes.ts`) rather than editing the sacred
  founder company-profile endpoint. The only "profileStore.ts" occurrence in the
  addendum is a code comment stating it is intentionally untouched. ✅
- Money file `captableCommitStore.ts` unchanged (hash intact). ✅
- Addendum touches exactly 6 files: `CapTable.tsx`, `Dashboard.tsx`,
  `RoundDetail.tsx`, `companyAttributionRoutes.ts` (new), `routes.ts`
  (registration), `waveB1_company_attribution.test.ts` (new). ✅
- No payments file touched; no new migration / `.sql` in the addendum. ✅
- No new `require()` in server TS (route uses ESM `import` only). ✅

## Correctness review
**Endpoint `server/companyAttributionRoutes.ts:26`**
- Read-only: calls `getConsortiumPartnerId` (SELECT-only, `consortiumLinkStore.ts:83`)
  and `getConsortiumPartnerDisplayName` (SELECT/cache read-only,
  `adminContactsStore.ts:605`). No writes anywhere in the handler. ✅
- Auth-guarded: mounted with `requireAuth` (`authMiddleware.ts:67`). Test asserts
  401 when dev bypass disabled. ✅
- Null-safe / never throws to client: input trimmed; unknown company → 400 only
  on empty id; unattributed → `{ attributedPartner: null }`; any thrown error is
  caught and downgraded to `{ attributedPartner: null }` with a warn log
  (`companyAttributionRoutes.ts:36-40`). Returns `null` when name unresolved. ✅

**Registration** — `server/routes.ts` imports and calls
`registerCompanyAttributionRoutes(app)` in `registerRoutes`. ✅

**Client badges** (all three surfaces):
- Query `enabled: Boolean(companyId)` / `Boolean(activeCompanyId)` — gated on
  companyId presence (CapTable.tsx:130, Dashboard.tsx, RoundDetail.tsx:107). ✅
- Badge renders only when `attributedPartner?.name` is truthy
  (CapTable.tsx:300, Dashboard.tsx:359, RoundDetail.tsx:397). ✅
- `companyId` derived from `useActiveCompanyId()` / `active.data?.activeCompanyId`;
  `RoundDetail.activeCompanyId` defined at line 97. ✅
- `Badge` imported in all three files. ✅
- All use `data-testid="badge-led-by-partner"` and render "Led by {name}". ✅

## Notes
- `npm run build` was NOT run; no restore needed. No commit made.
- Files on disk verified to match the diff exactly.

**Defects: none.**
