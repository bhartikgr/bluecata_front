# Independent verification brief — Capavate Wave A (v26.1.x Consortium Partner QA)

You are an INDEPENDENT verifier. Review the change set on disk against the
standing rules below and return a verdict: **APPROVE** or **REVISE**. If REVISE,
list each concrete defect with file:line and a suggested fix. Be adversarial and
specific — do not rubber-stamp. Only flag REAL issues (a wrong claim, a rule
violation, a security hole, a regression, a broken gate), not style nits.

## Build tree
`/home/user/workspace/capavate_work` (git HEAD 6f7a17f = v26.1.0 final).
The full source diff is at `WAVE_A_SOURCE.diff`. The fix report is
`FIX_REPORT_WAVE_A_CONSORTIUM_QA.md`. Read the actual files, not just the diff.

## What Wave A changed (7 items + reskin)
- **1f** nav rename "Contacts" -> "Contacts (CRM)" (label only; route/testid unchanged; guard allowlist entry added).
- **1e** removed the redundant "Engine legal-entity type" field in the SPV wizard; auto-derive the strict enum from country (hidden input keeps the `spv-w-jurisdiction` testid + submitted value).
- **1a** added `formatShares`/`formatCount` to `client/src/lib/currency.ts`; audit doc explains currency/shares are already grouped on partner surfaces.
- **1d** `server/commsStore.ts` + `server/adminContactsStore.ts`: partner post-author label precedence (screen name -> company name -> "Consortium Partner"), honoring privacy; must never leak a raw `u_...` id.
- **1c** migration 0108 (`spv_launch_signoffs`) + `server/spvLaunchSignoffStore.ts` + `server/spvEngineRoutes.ts` (require typed legal name + attestation before SPV create; record durably; new GET signoffs route) + client Review-step sign-off UI gating Launch.
- **2a** Option 1: `shared/partnerTitles.ts` (20 display titles) + invitation `title` (in invitation_json, no migration) + member title via existing `partner_team_member_contact.position_note`; client Team page shows Title + Access. The 5 permission tiers (subRole) are UNCHANGED and still enforced.
- **Reskin** bolder `client/src/styles/partner-theme.css` (non-sacred), scoped `[data-product="partner"]`, consumes only `--cv-*` tokens.

## HARD RULES (any violation = REVISE)
1. **Sacred 40/40 byte-identical** — `sacred_baseline/SACRED_SHA256.txt` must report 40 OK / 0 FAILED. In particular `server/captableCommitStore.ts`, `server/profileStore.ts`, `server/lib/userPrivacyResolver.ts`, `client/src/styles/capavate-tokens.css`, `client/src/pages/founder/Billing.tsx` must be UNTOUCHED. Verify none of the 40 were edited.
2. **Money core** `server/captableCommitStore.ts` sha16 must be `01cd36130ee1c0cb`. The commitment path must not be forked.
3. **tsc net-new = 0**: `npx tsc --noEmit` error count must be exactly **598**.
4. **Anti-silent-drop guard**: `npm run guard` must exit 0. New routes/nav are informational adds; the only allow-listed removal must be the intentional "Contacts" label rename (approvedBy Ozan).
5. **No new `require()` in server TS** — new server code must use ESM `import` (static or dynamic `import()`), never `require(`. (Pre-existing `require()` in untouched code is fine.)
6. **Payments/Airwallex untouched** — no payment/billing/Airwallex file modified.
7. **Migrations** additive + idempotent + **mirrored** (identical in `migrations/` AND `server/db/migrations/`) + inline self-heal in `server/db/connection.ts`. Next id was 0108. Confirm the two 0108 files are byte-identical and the connection.ts self-heal matches.
8. **Rule #13** — a person's last name / full name must never be dropped where a name renders (check the 1d partner label + 1c signer legal name).
9. **Security (1c/1d)** — 1c must key the signer identity to the SESSION user, never a client-supplied id; missing name or unaccepted attestation must 400 (no SPV created). 1d must not leak raw ids and must respect the privacy/anonymity setting.

## Correctness checks to actually run
Run these and confirm:
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # expect 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # expect 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # expect exit 0
diff migrations/0108_1c_spv_launch_signoffs.sql server/db/migrations/0108_1c_spv_launch_signoffs.sql  # expect identical
grep -nE "\brequire\(" server/spvLaunchSignoffStore.ts shared/partnerTitles.ts   # expect none
```
Also confirm: does the FIX_REPORT's claim that the 2 sprint18 test failures are PRE-EXISTING hold? (Optional: stash + rerun to confirm — the report says they fail identically on pristine HEAD.)

## Output format
Return:
1. **VERDICT: APPROVE** or **VERDICT: REVISE**
2. Gate results (the 6 commands above, actual numbers).
3. If REVISE: numbered defects, each with file:line + why it violates a rule + suggested fix.
4. Any correctness concern about 1c (sign-off durability/security), 1d (label precedence/privacy), 1e (enum derivation matches server fallback), 2a (permission tiers intact).
Write your verdict to a file: `/home/user/workspace/capavate_work/VERDICT_<yourmodel>.md`.
