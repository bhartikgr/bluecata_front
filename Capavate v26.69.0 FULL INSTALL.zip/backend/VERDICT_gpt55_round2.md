# Wave A Round 2 Verification — GPT-5.5

**VERDICT: REVISE**

I cannot approve because at least one real round-1 fix is still incomplete, and an additional SPV-creation bypass remains exposed.

## Per-defect verification

1. **Sign-off persistence fail-closed — PARTIAL / NOT GLOBAL**
   - The canonical `POST /api/partner/me/spv` path now validates missing name and missing attestation before create: `server/spvEngineRoutes.ts:112-119`.
   - It records the sign-off before creation and returns `500 SIGNOFF_PERSIST_FAILED` if `recordSignoff` throws: `server/spvEngineRoutes.ts:125-138`.
   - It creates the SPV only after that durable sign-off call and then links it: `server/spvEngineRoutes.ts:139-142`.
   - `recordSignoff` no longer swallows durable insert failure; it throws `SIGNOFF_PERSIST_FAILED`: `server/spvLaunchSignoffStore.ts:94-112`.
   - **Remaining defect:** the registered legacy GP route `POST /api/partner/me/spvs` still calls `spvEngineStore.createSpv(...)` directly with no sign-off capture at `server/partnerRoutes.ts:1400-1432`; `registerPartnerRoutes(app)` is mounted before the canonical SPV engine at `server/routes.ts:835-843`. This is a real path where a partner can create an SPV without a durably recorded sign-off.
   - **Fix:** either remove/disable/redirect the legacy create route, or apply the same `signoffLegalName` + `signoffAccepted` validation and record-first/link-after workflow used in `server/spvEngineRoutes.ts:112-142`.

2. **signerSubRole field — HOLDS**
   - `PartnerContext` exposes `partnerSubRole`: `server/lib/requirePartnerAuth.ts:23-31`.
   - `requirePartnerAuth` and `requirePartnerSelf` populate it from `teamMember.subRole`: `server/lib/requirePartnerAuth.ts:59-67` and `server/lib/requirePartnerAuth.ts:109-117`.
   - The SPV launch route now records `signerSubRole: ctx.partnerSubRole ?? null`: `server/spvEngineRoutes.ts:127-133`.

3. **18-title contract — PARTIAL**
   - The shared title list is exactly 18 titles in the expected order: `shared/partnerTitles.ts:14-33`.
   - The client imports and renders that shared list rather than a local divergent list: `client/src/pages/partner/PartnerTeam.tsx:17` and `client/src/pages/partner/PartnerTeam.tsx:198-199`.
   - The targeted test asserts the exact 18-title list and length: `server/__tests__/waveA_consortium_qa.test.ts:8-31`.
   - **Remaining defect:** `FIX_REPORT_WAVE_A_CONSORTIUM_QA.md` still says the invite form has a title dropdown “(20)” at `FIX_REPORT_WAVE_A_CONSORTIUM_QA.md:82-84`, contradicting the required corrected wording.
   - **Fix:** change that report line to “dropdown (18)”.

4. **Invitation title carried onto redeemed member — HOLDS**
   - The redeem path inserts the member using `durable.subRole` and does not overwrite subRole during title carry-over: `server/partnerWorkspaceStore.ts:1175-1192` and `server/partnerWorkspaceStore.ts:1219-1237`.
   - For a brand-new member with an invitation title, it best-effort upserts `durable.title` into `partner_team_member_contact.positionNote`: `server/partnerWorkspaceStore.ts:1219-1237`.
   - The team-list response maps `positionNote` to `title`: `server/partnerRoutes.ts:1171-1177`.

5. **1e correctness-note wording — HOLDS**
   - The analysis accurately says non-enum values fall back to `delaware`, and the implemented mapper's “anything else / Other” branch maps to `delaware`: `WAVE_A_1e_LEGAL_ENTITY_ANALYSIS.md:30-38` and `WAVE_A_1e_LEGAL_ENTITY_ANALYSIS.md:42-49`.

## Gate results

- `npx tsc --noEmit 2>&1 | grep -c "error TS"` → **598**
- `sha256sum -c sacred_baseline/SACRED_SHA256.txt 2>&1 | grep -c ": OK"` → **40**
- `sha256sum server/captableCommitStore.ts | cut -c1-16` → **01cd36130ee1c0cb**
- `npm run guard` → **exit 0**; tail output ended with `OK: 924 routes, 193 pages, 91 nav — no silent drops`
- `diff migrations/0108_1c_spv_launch_signoffs.sql server/db/migrations/0108_1c_spv_launch_signoffs.sql` → **identical**
- `npx vitest run server/__tests__/waveA_consortium_qa.test.ts` → **4 passed / 4**
- `grep -nE "\brequire\(" server/spvLaunchSignoffStore.ts server/spvEngineRoutes.ts shared/partnerTitles.ts` → **no matches**

## Required fixes before approval

1. Close or sign-off-gate the legacy partner SPV create route at `server/partnerRoutes.ts:1400-1432` so there is no partner-accessible SPV creation path without a durable sign-off.
2. Correct the stale “dropdown (20)” wording at `FIX_REPORT_WAVE_A_CONSORTIUM_QA.md:82-84` to “dropdown (18)”.
