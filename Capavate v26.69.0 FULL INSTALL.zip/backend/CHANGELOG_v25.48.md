# Capavate v25.48 — CHANGELOG

Release date: 2026-07-01
Base: v25.47.0 · Runtime: Node 20 + tsx (ESM) · DB: SQLite (better-sqlite3) / Postgres

All changes are additive and were implemented via **parallel modules / route-layer
guards** — the 39 Tier-1 Sacred files (cap-table ledger math, AVI in-memory stores,
home3compo, and the Rule-76 subscription path) are **byte-identical** to v25.47.

## Highlights

### Collective eligibility (NEW-1)
- **Company JOIN gate** — both founder apply routes (`/api/founder/collective/applications`
  and `/api/founder/collective/nominations`) now fail closed with
  `403 not_active_subscriber` unless the company is an **active paid Capavate
  subscriber**. Status is read READ-ONLY from the Sacred `subscriptionStore`.
- **Investor JOIN gate** — `POST /api/collective/waitlist/investor-membership` now
  requires ≥1 active cap-table position anywhere (`403 no_cap_table_position`).
- **Promote gate** — per-company `isOnCapTable` on `/api/investor/collective/promote`
  is unchanged.

### DSC
- **DSC-1a** — the compute/score gate (`POST /api/collective/dsc/compute/:companyId`)
  now also accepts a `dsc_roles`-granted DSC member (`isDscMember`), matching the vote
  route. Granted DSC members can BOTH vote and score. (Sacred `userContext.ts` untouched.)
- **DSC-1b** — new client review/vote modal on the DSC pipeline surface, wired to the
  existing vote + compute endpoints.
- **DSC-1c** — the founder's uploaded pitch deck now renders as a clickable **signed,
  short-lived (10-min) secure link** on the DSC review surface
  (`GET /api/collective/dsc/pitch-deck/:companyId`, gated by `isDscMember`).

### Consortium pricing (CP)
- **CP-2a** — `/consortium/pricing` is fully dynamic: `resolveConsortiumPricing()` now
  iterates the live DB tiers (`listTiers()`), so an admin soft-delete hides a tier and an
  admin-added tier appears.
- **CP-2b** — advertised price = charged price: `POST /api/partner/me/subscribe` now
  resolves the SAME tier row the pricing page advertises (single source of truth).
- **CP copy fixes** — PartnerSignup stale "Anchor/Architect" copy replaced with the
  canonical Catalyst / Builder / Amplifier / Nexus / Founding Member taxonomy; the dead
  "activation link" text is no longer a fake link.

### Data / no-mock
- **DATA-1** — email templates are now DB-backed (`email_templates` table) and
  admin-editable: `GET /api/admin/email/templates`, `GET /:slug`, `PUT /:slug`; the
  canonical starter set self-seeds on boot (INSERT OR IGNORE by slug), DB-first and
  restart-safe.
- **DATA-2** — live paths serve real DB rows, never mock. `/api/companies` reads the
  authoritative DB company set (empty DB → `[]`, never mock fixtures).

### Infra / platform hardening
- **HIGH-7** — the notifications feed returns a clean empty list (`200 {items:[]}`) and
  the client renders an empty state; the missing `/founder/notifications` client route
  is added.
- **HIGH-8** — the legacy outbound "bridge" (server-to-server Collective sync) is
  disabled in production via a `BRIDGE_ENABLED` flag (default OFF in prod), so it no
  longer returns 501 or dead-letters events. (Sacred `bridgeRuntime.ts` untouched.)
- **HIGH-9** — the mock-data migration commit (`POST /api/admin/migration/commit`) is
  blocked in production unless `MOCK_MIGRATION_ALLOWED=1`, guarded at the route layer.
  (Sacred `migrationRunner.ts` untouched.)

### Founder cap-table (PF)
- **PF-1** — the `/founder/captable` crash is fixed: a new READ-ONLY
  `GET /api/founder/captable` endpoint uses `captableCommitStore`'s exported read
  helpers, plus a client null-guard; an empty cap table renders a safe empty view.
- **PF-UX-1** — member-gated collective pages now render a friendly "membership not
  active / pending approval" state (with a link to `/collective/membership`) for
  `403 not_collective_member` / `COLLECTIVE_INACTIVE`, instead of "Failed to load."

### Investment flow (B1–B5, cap-table SACRED — parallel/wrapper only)
- **B1** — bi-directional CRM auto-seed: on invitation redeem, the investor's CRM is
  seeded for the founder/company, tagged `invitation-sourced` (parallel module; Sacred
  `investorCrmStore.ts` untouched).
- **B2** — batch commit accepts a per-entry FOUNDER-confirmed amount via a parallel
  wrapper (`POST /api/founder/captable/commit-funded-batch-v2`) that calls the existing
  exported `commitFunded()` per entry.
- **B3** — persisted per-investor "subscription docs sent" flag + founder-visible list
  (`subscription_docs_sent` table).
- **B4** — optional investor-initiated "I wired" advisory signal (`investor_wired_signals`
  table) — NON-mandatory, does NOT move the cap table.
- **B5** — REQUIRED founder attestation at commit; attestor id + timestamp stored in the
  new `commit_attestations` table (fail-closed).

## Migrations (additive-only; mirrored in ./migrations AND server/db/migrations, plus base CREATE in server/db/connection.ts)
- `0078_v25_48_subscription_docs_sent.sql`
- `0079_v25_48_investor_wired_signals.sql`
- `0080_v25_48_commit_attestations.sql`
- `0081_v25_48_email_templates.sql`

## Gates (all green)
TSC ≤ 611 (zero net-new) · verify_avi exit 0 · Airwallex 45/45 · v25_48 supertests 30/30 ·
vite build exit 0 · npm run build exit 0 · full e2e 862 passed / 0 failed · sacred 39/39
byte-identical · migration chain applies + idempotent on a copy of the live data.db.
Independently triple-verified (Opus 4.8 + Gemini 3.1 Pro + GPT-5.5).

## New env flags
- `BRIDGE_ENABLED` — legacy outbound bridge toggle (default OFF in production).
- `MOCK_MIGRATION_ALLOWED` — set to `1` to allow the mock migration commit in production
  (mock/test only; leave unset in production).
