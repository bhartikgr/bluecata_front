# Wave B2 Round 2 Independent Verification — GPT-5.5

VERDICT: APPROVE

## Gate results
- TypeScript: `npx tsc --noEmit` error count = 598 exactly; grep of edited B2 files found no TS errors. Output: `gate_b2_round2_tsc_gpt55.txt`, `gate_b2_round2_tsc_count_gpt55.txt`, `gate_b2_round2_tsc_edited_files_gpt55.txt`.
- Sacred files: 40/40 OK; B2 diff sacred overlap = NONE. Outputs: `gate_b2_round2_sacred_gpt55.txt`, `gate_b2_round2_meta_gpt55.txt`.
- Money core: `server/captableCommitStore.ts` sha16 = `01cd36130ee1c0cb`. Output: `gate_b2_round2_money_full_gpt55.txt`.
- Silent-drop guard: exit 0; counts `926 routes / 194 pages / 92 nav` unchanged. Output: `gate_b2_round2_guard_gpt55.txt`.
- Targeted B2 tests: `server/__tests__/waveB2_pipeline_dynamic.test.ts` passed 7/7. Output: `gate_b2_round2_vitest_gpt55.txt`.
- Extra SPV regression: `server/__tests__/spvUnifiedCanonical.test.ts` passed 9/9, confirming valid SPV create/status flows still work. Output: `gate_b2_round2_spv_canonical_gpt55.txt`.
- No new `require()` additions in the B2 diff. Output: `gate_b2_round2_meta_gpt55.txt`.
- Did not run `npm run build`; no build artifact restore was needed.

## Round-1 defect fix verification

1. **Make-Private UI gate matches server — fixed.**
   - `client/src/pages/partner/PartnerPipeline.tsx:98-103` defines `canWithdrawPromotion` as `role.identity?.subRole === "managing_partner"`.
   - `client/src/pages/partner/PartnerPipeline.tsx:398-421` renders the company `Make Private` button only under `canWithdrawPromotion`; non-managing users with an active/pending collective promotion receive a read-only `In review` / `In Collective` badge.
   - `server/partnerRoutes.ts:985-1008` keeps the withdraw endpoint gated by `assertSubRole("managing_partner")`.
   - Result: associates can no longer trigger a company-promotion withdraw that the server will reject.

2. **`pending_collective_review` recognized — fixed.**
   - `client/src/pages/partner/PartnerPipeline.tsx:62-70` includes `pending_collective_review` in the `Promotion.status` union.
   - `client/src/pages/partner/PartnerPipeline.tsx:398-401` treats `live`, `pending`, and `pending_collective_review` collective promotions as active for the Publish/Make-Private toggle.
   - `server/partnerWorkspaceStore.ts:2198-2208` also treats `pending_collective_review` as active for duplicate active-promotion detection, and `server/partnerWorkspaceStore.ts:2243-2252` creates collective deal-room promotions as `pending_collective_review`.
   - Result: a company under Collective review shows the active-promotion state instead of a new Publish control.

3. **SPV status PATCH server validation — fixed.**
   - `shared/spvEngine.ts:42-45` defines the canonical `SPV_STATUSES`, and `shared/spvEngine.ts:430-434` exports `isSpvStatus`.
   - `server/spvEngineStore.ts:269-283` validates create status and stores only an enum status; `server/spvEngineStore.ts:338-350` rejects invalid update status before mutation.
   - `server/spvEngineRoutes.ts:54-74` maps `INVALID_SPV_STATUS` to HTTP 400, and `server/spvEngineRoutes.ts:171-175` routes PATCH through `updateSpv`.
   - `server/__tests__/waveB2_pipeline_dynamic.test.ts:94-100` proves a bad status PATCH returns 400 and leaves the persisted status as `draft`.
   - Result: invalid lifecycle status cannot be persisted through the canonical SPV PATCH path.

4. **Draft-SPV discoverability copy/UI — fixed.**
   - `server/spvEngineStore.ts:321-335` excludes `status === "draft"` SPVs from Collective/Capavate/network discovery.
   - `client/src/pages/partner/PartnerPipeline.tsx:487-502` labels draft `collective_only` SPVs as `Collective (on launch)` and non-draft collective SPVs as `In Collective`.
   - `client/src/pages/partner/PartnerPipeline.tsx:533-544` disables `Publish to Collective` while draft and supplies the explanatory title.
   - `client/src/pages/partner/PartnerPipeline.tsx:224-229` toast copy says discoverability occurs once the SPV leaves Draft.
   - `server/__tests__/waveB2_pipeline_dynamic.test.ts:102-118` proves draft `collective_only` SPVs are not visible, open ones are visible, and private removes visibility again.
   - Result: Pipeline copy and controls now match discovery behavior.

## New on-Capavate invariant verification

- `server/partnerRoutes.ts:891-929` checks the partner-owned pipeline deal, then returns HTTP 409 `COMPANY_NOT_ON_CAPAVATE` when the deal has no linked `companyId` or the linked company record is missing, before creating any Collective promotion.
- `client/src/pages/partner/PartnerPipeline.tsx:423-441` shows `Publish to Collective` only for deals with `companyId`; bare name-only deals instead show an `Add to Capavate first` link to `/collective/partner/add-portfolio-company`.
- `server/__tests__/waveB2_pipeline_dynamic.test.ts:121-130` proves a bare name-only pipeline deal cannot be promoted and receives `COMPANY_NOT_ON_CAPAVATE`.
- `server/__tests__/waveB2_pipeline_dynamic.test.ts:132-159` proves a B1-created portfolio company with `companyId` can be promoted, creates `pending_collective_review`, and can then be withdrawn.
- The Add Portfolio Company route exists at `client/src/App.tsx:1071-1072`, matching the client link.

## Diff/sacred review

- B2 diff files: `client/src/pages/partner/PartnerPipeline.tsx`, `server/__tests__/waveB2_pipeline_dynamic.test.ts`, `server/partnerRoutes.ts`, `server/spvEngineRoutes.ts`, `server/spvEngineStore.ts`, `shared/spvEngine.ts`.
- Sacred overlap check returned NONE; these edited implementation files are non-sacred for this wave.
- No payments/Airwallex/money-core files were touched by the B2 diff.

## New-defect review

No new Wave B2 defect found. The known broader SPV fixture-drift failures were not used as B2 regressions; the targeted B2 suite and canonical SPV regression suite pass.
