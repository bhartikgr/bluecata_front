# W-AVI65 Fix Spec (LIVE-CONFIRMED root causes) — execution

Tree: /home/user/workspace/capavate_avi65_build (live ai65/v26.2.0/wavi64). Sacred baseline 40/40.
ALL root causes below were CONFIRMED on the live site (network captures), not guessed. wavi64 failed by fixing dead paths — every fix here targets the CONFIRMED live path.

## HARD RULES
- Additive + behavior-preserving. DB-driven, ZERO in-memory canonical state (write-through + hydrate; never "cache-non-empty = done").
- SACRED files BYTE-IDENTICAL. Do NOT edit: server/lib/userContext.ts, server/lib/capTableMembership.ts, server/messagingStore.ts, server/captableCommitStore.ts, server/paymentGatewayAdapter.ts, server/lib/userPrivacyResolver.ts, server/lib/bridgeRuntime.ts, and every other path in sacred_baseline/SACRED_SHA256.txt. If a fix seems to need a sacred edit, STOP and report.
- Fail-closed isolation. No cross-tenant leak. No identity leak. Money only via commitFunded (untouched).
- Every fix MUST target the endpoint the LIVE client actually calls (confirmed below). No dead-path fixes.

## FIX 1 — Round wizard PATCH returns 403 not_round_owner (investor never invited/sees round)
CONFIRMED LIVE: founder owns co_a2e5ca95c358; round rnd_... belongs to it; /api/auth/me shows it; yet
PATCH /api/founder/rounds/:id/initial-shareholders → 403 {"ok":false,"error":"not_round_owner"}, while
POST /api/rounds/:id/invitations → 200 (invitation created, emailDelivered:true). Same founder/round/company.
ROOT CAUSE: `callerOwnsRound` (roundInitialShareholdersStore.ts:122) resolves the round via a LAZY
`require("../roundsStore").getRoundById(roundId)` (createRequire shim, L29-36). In the PRODUCTION BUNDLE
(dist/index.cjs) this require fails to resolve → round=null → companyId undefined → returns false → 403.
The working POST path uses a STATIC import (routes.ts:220 roundsGetById) and succeeds.
FIX (editable file, self-contained, no sacred edit, no bundle-fragile require):
- In roundInitialShareholdersStore.ts, make ownership validation NOT depend on the failing lazy require.
  The handler already has `body.companyId` and computes `companyId = companyForRound(roundId) ?? body.companyId`.
  Validate ownership as: resolve the round's companyId robustly, then check it is in `ctx.founder.companies`.
  Robust companyId resolution order (all without the fragile require if possible):
    1) body.companyId (client sends it) — but DO NOT trust it alone for ownership.
    2) Cross-check: the resolved companyId MUST be present in ctx.founder.companies (the SAME check the
       auth context already trusts). If the round's true companyId is knowable, prefer it; otherwise use
       body.companyId ONLY IF it is in ctx.founder.companies (so a founder can only write to a round whose
       company they own — fail-closed, no cross-tenant).
  BEST FIX: replace the lazy `require("../roundsStore")` in callerOwnsRound + companyForRound with the SAME
  mechanism the working path uses. If a static top-level import risks the documented circular import,
  import roundsStore's getRoundById via the app's already-loaded module registry, OR resolve companyId from
  a non-circular source. If neither is safe, fall back to: ownership = (roundCompanyId ?? body.companyId) ∈
  ctx.founder.companies, where roundCompanyId is obtained from a working accessor. MUST verify the chosen
  accessor actually resolves in the bundle (mirror routes.ts:220's working static import pattern).
- After ownership passes, the existing invite loop (L313-363) already issues createInvitation correctly.
- SECONDARY (Issue-1 belt-and-suspenders, read path): the investor's round visibility is served by
  buildInvitedRounds in SACRED userContext.ts which hydrates RUNTIME_INVITATIONS only when empty (L342) —
  a stale-cache bug. DO NOT EDIT userContext.ts (sacred). Instead ensure the invitation is DB-persisted
  (createInvitation already does) so a fresh context/login hydrates it. Note the cache-union improvement as
  a FUTURE owner-authorized sacred edit in the fix report; do not edit sacred now.
ACCEPTANCE: PATCH initial-shareholders with an owned round returns 200 + inviteResults[status:invited];
a round the founder does NOT own still returns 403 (negative test). No cross-tenant write.

## FIX 3 — Admin/global header search returns nothing
CONFIRMED LIVE: header search fires GET /api/founder/search?q=... → {"results":[],"counts":{round:0,contact:0,file:0}}
even as admin. /api/admin/search has ZERO client callers (wavi64 fixed a dead endpoint).
ROOT CAUSE: founderSearchStore.ts:130-162 is founder-scoped (getCompaniesForFounder(admin)=[] → searchFounderWorkspace([],q) returns []) AND never searches companies (only round|contact|file).
FIX:
- Make the header search role-aware. Preferred: in client AppShell.tsx GlobalSearch (L426-489), when the
  session is admin (from /api/auth/me isAdmin), call GET /api/admin/search?q= (the wavi64 union already
  matches companies.name/legal_name + invited investors) instead of /api/founder/search. Render company +
  investor result kinds.
- Server: ensure /api/admin/search (adminV25Store.ts) is requireAdmin and returns a shape the client renders
  (results[] with kind/label/href). Add a `company` result kind if missing.
- ALSO fix the founder path additively so a real FOUNDER can find their own companies/rounds: add a company
  surface to founderSearchStore scoped STRICTLY to getCompaniesForFounder(userId) (NO cross-tenant; keep the
  companyIds scoping; do NOT drop the scope). Keep likeTerm() escaping + parameterized SQL.
ACCEPTANCE: as admin, searching a known company label (e.g. "BluePrint" / "Workspace") returns it; as founder,
searching own company returns it; a founder CANNOT match another tenant's company/round/contact (negative test).

## FIX 2 — Founder↔Investor DM shows "Private Investor" (no name)
CONFIRMED (code): live UI reads GET /api/comms/channels → displayTitle. commsStore.projectChannel/resolveIdentity
already call resolveDisplayName with isCoMember, but isCoMember comes from areCoMembersOnAnyCapTable
(SACRED capTableMembership.ts:45-73) which is INVESTOR↔INVESTOR only → a FOUNDER never qualifies → masked.
Compounded: COMMS_USERS is {} in prod (commsStore.ts:250) so legalName passed to the resolver is a raw u_… id.
FIX (all in editable commsStore.ts + a NEW caller-side helper; DO NOT edit sacred capTableMembership.ts or userPrivacyResolver.ts):
- Add a new caller-side co-membership predicate (e.g. server/lib/dmCoMembership.ts) that returns true when ANY:
  (1) viewer is an active company_members row (role founder/co_founder) for a company on whose captable_commits
      the counterparty holds a committed, non-deleted row;
  (2) the reverse (viewer is a committed holder on a company the counterparty founds);
  (3) areCoMembersOnAnyCapTable(a,b) (existing investor↔investor, call the sacred fn unchanged).
  isCoMember = (1)||(2)||(3). Parameterized SQL. Fail-closed FALSE on any error/missing row.
- In commsStore.resolveIdentity/projectChannel, use this new predicate to compute isCoMember for DM channels
  (replace the investor-only call for the DM case). Pass it to resolveDisplayName exactly as today.
- Real name source: when COMMS_USERS lacks the user, resolve legalName via displayNameResolver
  (server/lib/displayNameResolver.ts — users → credentials → userContext), NOT the raw u_… id. If unresolved,
  the resolver's existing fallback ("Invited contact") stands (never a raw id).
- LEAK GUARANTEES (must hold, add negative tests):
  * visibleToCoMembers opt-out still wins (resolver L222 runs before isCoMember) — do not bypass.
  * NON-co-members (e.g. founder↔founder cold DM, cold outreach with no shared cap table) MUST still get
    "Private Investor". Do NOT derive isCoMember from "a DM channel exists" or from canDM privacyMode.
  * Resolve per (viewer,counterparty) per request; never cache a resolved name on the thread/channel row.
ACCEPTANCE: founder on a cap table with investor sees the investor's screen/legal name in Messages; a founder
with NO cap-table relationship to a user still sees "Private Investor" (negative test); an opted-out investor
still shows "Private Investor" (negative test).

## FIX 4 (BRIDGE) — config + hydrate hoist (self-loop on capavate.com)
CONFIRMED LIVE: 568 queued / 0 delivered / chain broken. Collective = same app at capavate.com/collective.
ROOT CAUSES: (a) wrong URL (collective.capavate.com dead); (b) HMAC MISMATCH — outbound signs with
COLLECTIVE_WEBHOOK_SECRET (bridgeRuntime.ts:90), inbound verifies with BRIDGE_INBOUND_HMAC_SECRET/BRIDGE_HMAC_SECRET
(bridgeStore.ts:295-301) → every self-POST 401s; (c) hydrate nested in outbound gate (index.ts:431-452).
FIX (config + editable index.ts; do NOT edit sacred bridgeRuntime.ts):
- .env.example + DEPLOY doc + CAPAVATE_LIVE_ENVIRONMENT.md: the CORRECT block —
    BRIDGE_ENABLED=1
    COLLECTIVE_WEBHOOK_URL=https://capavate.com/api/bridge/inbound
    COLLECTIVE_WEBHOOK_SECRET=<secret>
    BRIDGE_INBOUND_HMAC_SECRET=<SAME secret as COLLECTIVE_WEBHOOK_SECRET>   # REQUIRED for self-loop
    COLLECTIVE_APP_URL=https://capavate.com/collective
  Explicitly document that the two secrets MUST be equal (self-loop) or all events 401/dead-letter.
- index.ts: HOIST hydrateBridgeStore() + hydrateDurableMaps() OUT of the `maySendOutboundBridge()` outbound gate
  (currently L431-452) so inbound durable maps rehydrate on boot regardless of outbound config. Additive/safe.
- Do NOT auto-rewrite the "chain broken @0" — add a note for an admin-gated non-destructive re-verify.

## TESTS (server/__tests__/wavi65_*.test.ts)
- wavi65_round_owner.test.ts — owned round PATCH succeeds; unowned round → 403 (no cross-tenant write); the
  ownership resolution does NOT depend on the fragile lazy require (simulate require failure → still resolves via companyId∈ctx.founder.companies).
- wavi65_admin_search.test.ts — admin search returns a known company + investor; founder search is tenant-scoped
  (founder A cannot match founder B's company).
- wavi65_dm_comember.test.ts — founder↔investor on a shared cap table → isCoMember true → name resolves; founder
  with no cap-table link → "Private Investor"; opted-out investor → "Private Investor".
- wavi65_bridge_env.test.ts — hasRealReceiver true with capavate.com URL; self-loop requires equal secrets
  (document/verify BRIDGE_INBOUND_HMAC_SECRET==COLLECTIVE_WEBHOOK_SECRET). Update the stale wavi64_bridge_env
  test that referenced collective.capavate.com.

## OUTPUT
Write /home/user/workspace/capavate_avi65_build/_WAVI65_RESULT.md: files changed (new+edited), per-fix
root-cause + change + WHICH LIVE ENDPOINT it targets (proof it's not a dead path), STOP list of any sacred
edit wanted, the exact .env block, new tests, and confirm sacred 40/40 (only non-sacred changed).
