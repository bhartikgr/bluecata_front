# FIX REPORT — Wave 2 (Gate + Accreditation) — v26.2.0-w2

**Baseline:** v26.2.0-w1 (W1 security, HEAD `355c09b`). **Scope:** Part A of
`ROADMAP_SPEC_GATE_MESSAGING.md` (A1–A7) + **Avi finding #2** (admin↔investor
profile/KYC reconciliation). Part B (Wave 2M messaging) is a SEPARATE later wave.
No payments/Airwallex code touched; no sacred file edited.

## Gates (final)
- Sacred: **40/40 OK** · Money sha16: **01cd36130ee1c0cb** (unchanged)
- tsc net-new: **0** (total **598**)
- Guard: **exit 0** — **931** routes / 194 pages / 92 nav (was 929 in W1; +2 = the two
  NEW endpoints gate-state + legal-copy; **no drops**)
- Build: **EXIT 0** · No-silent-drop test: **pass**
- New suite `waveW2_gate_accreditation.test.ts`: **13/13** (incl. round-1 Avi#2 404 fix
  regression); W1 suite still **16/16** (29 total)
- Pre-existing failing suites UNCHANGED (no regressions): `sprint21_invitations` 2,
  `spvEngine` 30.
- Migration **0110** mirrored byte-identical (renumbered from spec's 0109 — W1 H6 already
  used 0109; approved by Ozan as Option A).

## Server changes

### A2 — accreditation gate status  (`investorComplianceRoutes.ts`)
- New `getAccreditationGateStatus(userId)` → `none | self_certified | verified` + source.
  Reads the SAME store path as `hasAccreditedDeclaration` (compliance profile + latest
  declaration). Verified is never downgraded by a self-cert row. Preserves the legacy
  grace (unparseable signed_at + row present ⇒ self_certified) with a warning log.

### A3 — capTableExempt  (`collectiveMembershipStore.ts`, `adminCollectiveRoutes.ts`, `shared/schema.ts`)
- `CollectiveMembershipRow` + `activate(..., { capTableExempt })` carry a durable
  `capTableExempt` flag; all DB read/hydrate paths map `cap_table_exempt`. Re-activation
  without the flag PRESERVES an existing exemption.
- Bootstrap route defaults `capTableExempt = body.capTableExempt !== false` (bootstrap =
  explicit bypass) and audits `capTableExempt` + `capTableExemptReason`.

### A4 — migration 0110 + self-heal  (`migrations/`, `server/db/migrations/`, `connection.ts`)
- `0110_collective_membership_captable_exempt.sql` mirrored byte-identical; adds
  `cap_table_exempt INTEGER NOT NULL DEFAULT 0` + index. `applyW2CapTableExemptSchema`
  self-heals on boot (idempotent — duplicate-column error swallowed). Fresh CREATE TABLE
  includes the column.

### A1 — server gate 4-step tree  (`lib/requireCollectiveMember.ts`)
- Rewrote the member sub-checks into: (1) auth, (2) active membership [both above],
  (3) **cap-table sub-check now EXEMPT-AWARE** (capTableExempt bypasses ONLY this check),
  (4) **first-sign-on accreditation CAPTURE**: a genuine `none` member is blocked with
  `403 ACCREDITATION_DECLARATION_REQUIRED` (client-actionable) until they self-declare.
  Fails CLOSED with `403 ACCREDITATION_STATUS_UNAVAILABLE` on a read error. Replaces the
  old SOFT-log/strict-flag behavior. W1 H6 fail-closed block retained above, admin bypass
  retained. capTableExempt does NOT bypass accreditation capture.

### A5 — gate-state endpoint  (`collectiveAppStore.ts`)
- `GET /api/collective/gate-state` returns `{ isMember, isPartnerOnly, capTableExempt,
  accreditationStatus, requiresAccreditationDeclaration, declarationEndpoint, copy }` —
  the signals the client gate needs to block child pages without relying on child API
  failures. 401 when unauthenticated. Fails closed (accreditation read error ⇒ "none").
  NEVER consults KYC (KYC never gates).

### A7 — indemnity / legal-copy slot  (`shared/collectiveLegalCopy.ts`, `server/collectiveLegalCopyStore.ts`, `collectiveAppStore.ts`)
- Shared types + a loader that serves user-supplied copy from
  `COLLECTIVE_LEGAL_COPY_JSON` (Ozan's "you supply final copy" decision) else a
  placeholder flagged `NON_LEGAL_ADVICE`. Malformed supplied JSON degrades to placeholder
  with `degraded:true` (never crashes). `GET /api/collective/legal-copy?slots=…`.

### Avi #2 — admin↔investor profile/KYC reconciliation  (`adminPlatformStore.ts`)
- Root cause: admin investor record read `users`+`securities` (+ a synthetic
  `derived_inv_<invitationId>` snapshot elsewhere), NEVER the SACRED profileStore where
  investors save. New NON-SACRED `reconcileInvestorProfileForAdmin(id)` READS the real
  `profilestore_investor_profile` table (never imports/mutates the sacred store),
  resolves synthetic ids via the previously-UNUSED `redeemed_by_user_id` join key, reads
  the accreditation fast-flag from `investor_compliance_profile`, and surfaces the
  investor's KYC documents. `GET /api/admin/investors/:id` now returns the reconciled
  name/region/bio/taxId/accreditation + a `kyc` block. Fail-soft (never throws).
  SACRED `profileStore.ts` untouched; fix lives entirely in the admin layer.

  **ROUND-1 REVISE fix (deciding verifier GPT-5.5):** the endpoint 404'd a synthetic
  `derived_inv_<invitationId>` id BEFORE reconciliation ran (no `users` row for a synthetic
  id), defeating the fix for the exact case Avi hit. Now reconciliation runs FIRST
  (resolves `derived_inv_` → real redeemer userId via `redeemed_by_user_id`), then the
  users lookup uses the resolved id (with a minimal user shell when a profile exists but
  no users row), and 404 only when neither raw nor resolved id maps to a user AND no
  profile exists. New regression test proves the reconciled record is returned, not 404.

## Client changes (all client-only; no server/sacred edits)
- `CollectiveMemberGate.tsx` — rewritten to consume `/api/collective/gate-state` with the
  A5 decision order (loading → error/retry card → marketing → accreditation blocker →
  children); fail-closed default never mounts children on a bad response.
- `collective/CollectiveAccreditationBlocker.tsx` (NEW) — blocks entry until the
  self-declaration is signed; renders the `collective_gate_indemnity` copy with a
  NON-LEGAL-ADVICE badge; invalidates gate-state on success.
- `collective/OptionalKycUploadCard.tsx` (NEW) — optional KYC upload (never gates),
  mounted in `investor/Profile.tsx` near the accreditation card.
- `investor/AccreditationDeclaration.tsx` — accepts optional `copySlot`/`legalCopy` props
  to render the declaration indemnity slot + badge; existing behavior preserved.

## Rule assurances
- No edits to `captableCommitStore.ts`, `profileStore.ts`, or any sacred file (40/40).
- No Airwallex/payment code touched. Migration additive + idempotent + mirrored + self-
  healed. ESM only — reused the existing `createRequire` shim in `collectiveAppStore.ts`;
  the admin reconciliation avoids a circular import by reading the compliance table
  directly (no new shim). Last-name-everywhere respected (reconciled name uses
  firstName+lastName).
