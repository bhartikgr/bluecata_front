/**
 * Wave C-3 — Collective Shell
 *
 * Standalone shell with its own sidebar + topbar for the Collective experience.
 * Visual identity: v25.43 R3-2 re-skin — brand red #cc0001 accent, cream #F7F6F2 background, navy text.
 *   WAVE 96 · ITEM 2 SUPERSEDES THE CREAM: the rail, its rules and the top-bar
 *   title ink no longer carry literals at all. They read `--cv-color-surface-cream`,
 *   `--cv-color-divider`, `--cv-color-surface` and `--cv-color-navy`, which each
 *   product scope re-points — so this one shared component renders the Collective
 *   rail and the Consortium Partner rail from each area's own tokens. Full note at
 *   the `CollectiveSidebar` return below.
 * Light-mode only. No web storage.
 */

import { LegalFooterLinks } from "@/components/LegalFooterLinks";
import { NotificationBell } from "@/components/NotificationBell";
import { useState, useRef, type ReactNode, type Ref, type RefObject } from "react";
import { WishListProvider, WishListLauncher } from "@/components/wishlist/WishList";
import { WISH_SOURCE_ROUTE_KEYS } from "@shared/wishlist";
import { Link, useLocation } from "wouter";
import { workspaceDashboard } from "@/lib/workspaceDashboard";
import {
  LayoutDashboard, Briefcase, Users, Building2, Circle, BarChart3,
  TrendingUp, ClipboardList, UserCircle, Activity, Settings, Menu, X,
  ArrowLeftRight, LogOut, Scale, UserPlus, FileText,
  PiggyBank, CalendarDays, Trophy, Receipt,
  /* v25.42 (Bucket B) — icons for the 7 new Collective nav entries. */
  Network, Handshake, ClipboardCheck, Inbox,
  LayoutTemplate, /* WAVE 30 ENGINE 3 — SPV Templates nav icon */
  /* v25.33 Consortium Partner Payment Model — icons for the new partner
     self-service nav items (Subscribe / Agreement / Tax Forms). */
  FileSignature, FileCheck,
  /* v25.49 Phase-3B — icons for the new partner NETWORK group (Messages/Posts). */
  MessageSquare, Newspaper,
  /* GROUP F1 — icon for the person-level partner CRM Contacts nav item. */
  Contact,
  /* WAVE 7 W-8 (DEF-057) / W-5 (DEF-056) — icons for the restored Tasks and
     Files nav entries. */
  ListTodo, FolderOpen,
  /* WAVE 149 · ITEM 2 — icon for the new Notifications nav entry. */
  Bell,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useLegalDrawer } from "@/lib/legalDrawer";
import { useRole } from "@/lib/role";
import { usePartnerMembership } from "@/lib/partner/usePartnerMembership";
import { useQuery } from "@tanstack/react-query"; /* v16 Fix 6 — read COLLECTIVE_ENABLED */
import { apiRequest, queryClient } from "@/lib/queryClient"; /* v16 Fix 6 */
import { ChapterSelector } from "@/components/ChapterSelector"; /* v17 Phase A — chapter scope dropdown in topbar */
import { MarketTicker } from "@/components/feeds/MarketTicker"; /* v25.43 R3-4 — persistent live ticker strip */
import { CollectiveMemberGate } from "@/components/CollectiveMemberGate"; /* v25.48.2 MF7 (Q9) — member gate on the common shell */
import { CapavateLogo } from "@/components/CapavateLogo"; /* W-LOGO — real Capavate wordmark in the shell brand block */

/* ============================================================
 * v25.41 Bug-1 — Consortium Partner vs Collective separation
 *
 * A partner-only user (active partner membership but NO active Collective
 * chapter membership) must see ONLY the PARTNER WORKSPACE nav, branded
 * "CONSORTIUM". A dual-role user (partner AND active Collective member)
 * keeps the existing combined view on Collective pages. Owner instruction
 * 2026-09-29: an authenticated partner choosing a partner route gets partner
 * presentation even when also an active Collective member. Detection is chapter_id-free: the
 * existing GET /api/me/chapters endpoint already returns ONLY active
 * memberships (server/chaptersStore.ts filters status="active"), so a
 * non-empty list == active Collective member. No server change, no removal
 * of any NAV_GROUPS / PARTNER_WORKSPACE_GROUP array — assembly logic only.
 */
function useCollectiveMembershipActive(): boolean {
  const q = useQuery<{ ok?: boolean; chapters?: Array<{ id: string }> }>({
    queryKey: ["/api/me/chapters"],
    queryFn: async () => {
      try {
        return await (await apiRequest("GET", "/api/me/chapters")).json();
      } catch {
        // Fail closed: when COLLECTIVE_ENABLED=0 the endpoint 503s and
        // apiRequest throws; treat as "no active membership".
        return { ok: false, chapters: [] };
      }
    },
    retry: false,
    staleTime: 30_000,
  });
  return Array.isArray(q.data?.chapters) && (q.data!.chapters!.length > 0);
}

/**
 * v25.41 Bug-1 — resolves the shell "mode" for the current session.
 *   - "partner"    : partner-only (show partner nav only, CONSORTIUM brand)
 *   - "combined"   : partner + active Collective member (existing combined view)
 *   - "collective" : non-partner (existing Collective view)
 */
function usePartnerOnlyMode(): boolean {
  const partner = usePartnerMembership();
  const collectiveMember = useCollectiveMembershipActive();
  return partner.isPartner && !collectiveMember;
}

type NavItem = {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
  "data-testid"?: string;
};

type NavGroup = {
  title: string;
  items: NavItem[];
};

/* WAVE 149 · ITEM 2/3 — ONE literal for the in-shell inbox, named once. Both nav
   entries and the bell's `viewAllHref` read it, so the nav destination and the
   bell's "View all" cannot drift apart. The route itself is registered in
   `App.tsx` wrapped in this same shell. */
export const COLLECTIVE_NOTIFICATIONS_HREF = "/collective/notifications";
/* 2026-09-19 — the Consortium Partner inbox is a SEPARATE route in this same
   shell. Partner nav and the partner-mode bell's "View all" both read it, so
   the partner's inbox lists and counts partner notices only. */
export const PARTNER_NOTIFICATIONS_HREF = "/collective/partner/notifications";

const NAV_GROUPS: NavGroup[] = [
  {
    title: "HUB",
    items: [
      { href: "/collective/dashboard", label: "Dashboard", icon: LayoutDashboard, "data-testid": "nav-collective-dashboard" },
      { href: "/collective/dealroom", label: "Deal Room", icon: Briefcase, "data-testid": "nav-collective-dealroom" },
    ],
  },
  {
    title: "NETWORK",
    items: [
      { href: "/collective/members", label: "Member Directory", icon: Users, "data-testid": "nav-collective-members" },
      { href: "/collective/companies", label: "Companies", icon: Building2, "data-testid": "nav-collective-companies" },
      { href: "/collective/soft-circles", label: "Soft Circles", icon: Circle, "data-testid": "nav-collective-soft-circles" },
      /* v25.42 R1 + R8 — connections + member-facing partners directory. */
      { href: "/collective/connections", label: "Connections", icon: Network, "data-testid": "nav-collective-connections" },
      { href: "/collective/partners", label: "Partners", icon: Handshake, "data-testid": "nav-collective-partners" },
    ],
  },
  {
    title: "M&A INTELLIGENCE",
    items: [
      { href: "/collective/dsc/pipeline", label: "DSC Pipeline", icon: BarChart3, "data-testid": "nav-collective-dsc-pipeline" },
      { href: "/collective/dsc/scores", label: "Composite Scores", icon: TrendingUp, "data-testid": "nav-collective-dsc-scores" },
      { href: "/collective/dsc/prep", label: "Transaction Prep Tracker", icon: ClipboardList, "data-testid": "nav-collective-dsc-prep" },
    ],
  },
  /* W6 — COMMUNITY group. Surfaces first-class member community routes that
   * previously had NO nav entry (notably Ask-an-Expert, which existed at
   * /collective/ask-expert but was orphaned). No route is dropped; this only
   * adds visibility. Ask-an-Expert also hosts the W6 "connect a partner"
   * responder flow. */
  {
    title: "COMMUNITY",
    items: [
      { href: "/collective/ask-expert", label: "Ask an Expert", icon: MessageSquare, "data-testid": "nav-collective-ask-expert" },
      { href: "/collective/posts", label: "Posts", icon: Newspaper, "data-testid": "nav-collective-posts" },
      { href: "/collective/presentations", label: "Presentations", icon: FileText, "data-testid": "nav-collective-presentations" },
    ],
  },
  /* v19 Phase A — Events Calendar + Leaderboard. Placed in their own
   * group so they get dedicated visibility without disrupting existing
   * nav ordering. */
  {
    title: "CHAPTER LIFE",
    items: [
      { href: "/collective/calendar", label: "Calendar", icon: CalendarDays, "data-testid": "nav-collective-calendar" },
      { href: "/collective/leaderboard", label: "Leaderboard", icon: Trophy, "data-testid": "nav-collective-leaderboard" },
      /* v25.42 R2 + R3 + R4 — recaps, screening recaps, chapters. */
      { href: "/collective/chapters", label: "Chapters", icon: Building2, "data-testid": "nav-collective-chapters" },
      { href: "/collective/recaps", label: "Recaps", icon: FileText, "data-testid": "nav-collective-recaps" },
      { href: "/collective/screening-recaps", label: "Screening Recaps", icon: ClipboardCheck, "data-testid": "nav-collective-screening-recaps" },
    ],
  },
  {
    title: "YOUR ACCOUNT",
    items: [
      { href: "/collective/membership", label: "My Membership", icon: UserCircle, "data-testid": "nav-collective-membership" },
      /* v25.42 R5 — read-only requests portal. */
      { href: "/collective/portal/requests", label: "My Requests", icon: Inbox, "data-testid": "nav-collective-requests" },
      { href: "/collective/activity", label: "Activity", icon: Activity, "data-testid": "nav-collective-activity" },
      /* WAVE 149 · ITEM 2 — reachable by NAVIGATION, not only by typing a URL. The
         bell's dropdown is a shortcut, not a route: a member who wants their full
         inbox needs a nav entry, and `/notifications` renders outside this shell.
         Appended at the END of an existing group so no entry above it moves. */
      { href: COLLECTIVE_NOTIFICATIONS_HREF, label: "Notifications", icon: Bell, "data-testid": "nav-collective-notifications" },
      { href: "/collective/settings", label: "Settings", icon: Settings, "data-testid": "nav-collective-settings" },
    ],
  },
];

// Partner-workspace nav, added dynamically in CollectiveSidebar when the
// session has an active partner membership.
//
// v25.48.3 Phase-2B — the previously-flat "PARTNER WORKSPACE" group is now
// split into labeled sections (OVERVIEW / DEALS & SPVs / WORKSPACE / ACCOUNT)
// per the approved nav reorder. ALL 14 hrefs/labels/icons/data-testids are
// preserved byte-for-byte — this is a regrouping only, nothing dropped
// (Sacred Rule #78). The NETWORK group (Messages/Posts) is intentionally
// omitted while empty; Phase 3 adds it. Reuses the existing NavGroup pattern.
const PARTNER_WORKSPACE_GROUPS: NavGroup[] = [
  {
    title: "OVERVIEW",
    items: [
      { href: "/collective/partner/dashboard", label: "Dashboard", icon: LayoutDashboard, "data-testid": "nav-partner-dashboard" },
      /* W-MFCRM — Managed Founders engine (engagements + 3 CRM-layer drill-down).
         Additive entry; nothing existing was renamed/moved/removed. */
      { href: "/collective/partner/managed-founders", label: "Managed Founders", icon: Handshake, "data-testid": "nav-partner-managed-founders" },
      /* WAVE 20 XT-10 — the way IN to the Managed-Founder PERSONA surface.
         server/managedFounderPersonaRoutes.ts registers 17 partner routes
         (angel chapters + carry, accounting rebill/custody/fund-admin, law
         matters/counsel/conflicts), mounted at server/routes.ts:1014. A grep of
         client/ for `mfcrm/angel|mfcrm/acct|mfcrm/law` returned ZERO callers
         before this wave: seventeen live, gated, DB-backed endpoints with no
         page and no door. Same shape as FE-8 above — additive entry, nothing
         renamed, moved or removed. The page itself resolves the persona from
         the capability profile and renders an explanation when the firm type
         has no persona surface, so this entry is never a dead end. */
      { href: "/collective/partner/persona-tools", label: "Persona Tools", icon: Scale, "data-testid": "nav-partner-persona-tools" },
      /* WAVE 7B FE-8 (DEF-054) — WIRING, not a build. The partner onboarding
         checklist was fully shipped by CP Phase B: the page exists
         (client/src/pages/partner/OnboardingChecklistPage.tsx), the route is
         declared and mounted inside CollectiveShell (client/src/App.tsx:1326),
         and both halves of the engine are live — GET and PATCH
         /api/partner/onboarding/state. What was missing was any way in: a
         whole-app search for "/collective/partner/onboarding" found the route
         declaration and NOTHING else. No nav entry, no link, no redirect. A
         partner could only reach their own onboarding checklist by typing the
         URL. Same shape as W-5/W-8 in Wave 7. */
      { href: "/collective/partner/onboarding", label: "Onboarding", icon: ClipboardCheck, "data-testid": "nav-partner-onboarding" },
    ],
  },
  {
    title: "DEALS & SPVs",
    items: [
      { href: "/collective/partner/pipeline", label: "Pipeline", icon: Briefcase, "data-testid": "nav-partner-pipeline" },
      /* Wave B1 (3a) — create a net-new, independent company (founder-owned,
         tagged to this partner) directly below Pipeline. */
      { href: "/collective/partner/add-portfolio-company", label: "Add Portfolio Company", icon: Building2, "data-testid": "nav-partner-add-portfolio-company" },
      /* Ozan decision #4 — ONE canonical, user-facing SPVs engine + ONE nav entry.
         The duplicate "SPV Engine" and separate "Funds" entries were collapsed
         into this single "SPVs" link pointing at the canonical PartnerSpvEngine
         page. The legacy /spvs and /funds routes stay reachable (they redirect to
         the canonical surface) so no bookmark/link breaks — Sacred Rule #78. */
      { href: "/collective/partner/spv-engine", label: "SPVs", icon: Building2, "data-testid": "nav-partner-spvs" },
      /* WAVE 30 ENGINE 3 — "SPV Templates": reusable structure defaults for the
         SPV create form. `spv_template` was absent tree-wide before this wave
         (migration 0177 creates it), so this is its only entry point. Added as
         a SIBLING entry directly beneath the canonical SPVs link — no existing
         nav item's text was edited, per the guard's sibling rule. Applying a
         template does NOT create an SPV; the signed launch flow is unchanged. */
      { href: "/collective/partner/spv-templates", label: "SPV Templates", icon: LayoutTemplate, "data-testid": "nav-partner-spv-templates" },
      /* W2-A — "Clients" nav item restored. (The prior "(page deleted)" comment
         was inaccurate: PartnerClients.tsx / PartnerClientDetail.tsx were never
         deleted — only their routes/nav were trimmed in v25.50.0, and the read
         endpoints were re-added in W2-A.) */
      { href: "/collective/partner/clients", label: "Clients", icon: Users, "data-testid": "nav-partner-clients" },
      /* GROUP F1 — person-level CRM (partner_crm_contacts) now has a UI. */
      { href: "/collective/partner/contacts", label: "Contacts (CRM)", icon: Contact, "data-testid": "nav-partner-contacts" },
      /* W2-D — "Portfolio" nav item added; the /api/partner/me/portfolio API
         already existed but had no client route/nav to reach it. */
      { href: "/collective/partner/portfolio", label: "Portfolio", icon: PiggyBank, "data-testid": "nav-partner-portfolio" },
      /* WAVE 30 ENGINE 2 — "Relationship Map": the union across Managed Founder
         CRM, pipeline, clients and portfolio. Migration 0136 shipped the
         partner_company_relationship spine with no reader, route or nav; this
         is the entry point that makes it reachable. Added as a SIBLING entry
         — no existing nav item's text was edited. */
      { href: "/collective/partner/relationships", label: "Relationship Map", icon: Network, "data-testid": "nav-partner-relationships" },
    ],
  },
  {
    // v25.49 Phase-3B — NETWORK group added now that it has items (Phase-2B
    // left room for it). Reuses the shared comms Messages + Posts surfaces.
    title: "NETWORK",
    items: [
      { href: "/collective/partner/messages", label: "Messages", icon: MessageSquare, "data-testid": "nav-partner-messages" },
      { href: "/collective/partner/posts", label: "Posts", icon: Newspaper, "data-testid": "nav-partner-posts" },
    ],
  },
  {
    title: "WORKSPACE",
    items: [
      { href: "/collective/partner/team", label: "Team", icon: UserPlus, "data-testid": "nav-partner-team" },
      { href: "/collective/partner/notes", label: "Notes", icon: FileText, "data-testid": "nav-partner-notes" },
      /* WAVE 7 W-8 (DEF-057) + W-5 (DEF-056) — "Tasks" and "Files" restored.
         The v25.50.0 Phase 6 note that stood here said the pages were deleted;
         they were not — PartnerTasks.tsx and PartnerFiles.tsx were on disk the
         whole time, as were partnerTasksStore/partnerFilesStore and the
         partner_tasks/partner_files tables. Only the route, the nav entry and
         the server route surface had been removed, which is precisely the
         "functionality that exists is not reflected in the UI" shape. The
         original hrefs, labels and data-testids are restored unchanged. */
      { href: "/collective/partner/tasks", label: "Tasks", icon: ListTodo, "data-testid": "nav-partner-tasks" },
      { href: "/collective/partner/files", label: "Files", icon: FolderOpen, "data-testid": "nav-partner-files" },
    ],
  },
  {
    title: "ACCOUNT",
    items: [
      /* v25.32 A3 — consortium partner commission ledger (not subscription billing). */
      { href: "/collective/partner/billing", label: "Billing", icon: Receipt, "data-testid": "nav-partner-billing" },
      /* v25.50.0 Phase 6 (spec 9a) — "Subscribe" nav item removed; the subscribe
         flow is merged into the Billing → Subscription tab (Phase 7). */
      { href: "/collective/partner/agreement", label: "Agreement", icon: FileSignature, "data-testid": "nav-partner-agreement" },
      { href: "/collective/partner/tax-form", label: "Tax Forms", icon: FileCheck, "data-testid": "nav-partner-tax-form" },
      /* WAVE 149 · ITEM 2 — a partner-only session renders ONLY these groups
         (`:359-363` before this wave), so without an entry here a partner's own
         inbox would be reachable through the bell alone. Same route, same page;
         which shell it renders in is decided by the route, not by the persona. */
      { href: PARTNER_NOTIFICATIONS_HREF, label: "Notifications", icon: Bell, "data-testid": "nav-partner-notifications" },
      { href: "/collective/partner/settings", label: "Settings", icon: Settings, "data-testid": "nav-partner-settings" },
    ],
  },
];

/* ============================================================
 * Sidebar nav item
 * ============================================================ */

function NavLink({ item }: { item: NavItem }) {
  const [location] = useLocation();
  const isActive =
    location === item.href ||
    (item.href !== "/collective/dashboard" && location.startsWith(item.href));

  return (
    <Link
      href={item.href}
      data-testid={item["data-testid"]}
      className={[
        "w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
        /* v25.43 R3-2 — sidebar active/hover re-skinned from the old plum
           (#8E2A4E) to the capavate.com brand red (#cc0001) at a soft 8%
           tint, matching the live site's nav treatment. */
        isActive
          ? "bg-[rgba(204,0,1,0.08)] text-[var(--cv-color-primary)]"
          : "text-[var(--cv-color-text-secondary)] hover:bg-[rgba(204,0,1,0.08)] hover:text-[var(--cv-color-primary)]",
      ].join(" ")}
      style={{ textDecoration: "none" }}
    >
      <item.icon className="h-4 w-4 shrink-0" />
      <span>{item.label}</span>
    </Link>
  );
}

/* ============================================================
 * Sidebar
 * ============================================================ */

function CollectiveSidebar({ onClose, returnFocusRef }: {
  onClose?: () => void; returnFocusRef?: RefObject<HTMLElement | null>;
}) {
  const [location] = useLocation();
  const dashboardHref = workspaceDashboard(location);
  const { openDrawer } = useLegalDrawer();
  const partner = usePartnerMembership();
  // v16 Fix 6 — honest invite-only beta: when COLLECTIVE_ENABLED is false,
  // the full Collective nav is hidden and a single "Join the Waitlist" link
  // is shown instead. The partner-workspace group still flows through its
  // own gate.
  const flagsQ = useQuery<{ COLLECTIVE_ENABLED?: boolean }>({
    queryKey: ["/api/feature-flags"],
    queryFn: async () => (await apiRequest("GET", "/api/feature-flags")).json(),
  });
  const collectiveOn = flagsQ.data?.COLLECTIVE_ENABLED === true;
  const BETA_WAITLIST_GROUP: NavGroup = {
    title: "BETA — INVITE-ONLY",
    items: [
      // v25.13 NH1 — /collective/waitlist is not a registered route; the
      // existing public-style apply page is /investor/apply-to-collective
      // (or /founder/apply-to-collective for founders). Sending users to
      // the investor flow gives them a working surface instead of 404.
      { href: "/investor/apply-to-collective", label: "Join the Waitlist", icon: UserPlus, "data-testid": "nav-collective-waitlist" },
    ],
  };
  const baseGroups: NavGroup[] = collectiveOn ? NAV_GROUPS : [BETA_WAITLIST_GROUP];
  // v25.41 Bug-1 — partner-only users (partner role, NO active Collective
  // membership) see ONLY the partner workspace nav. Owner 2026-09-29:
  // dual-role users also see that view on partner routes; their combined
  // view is retained on Collective routes. Pure-Collective users are unchanged.
  // React #310 FIX — useCollectiveMembershipActive() MUST be called
  // unconditionally. Inlining it after `partner.isPartner &&` short-circuited
  // the hook whenever isPartner was false, so the hook count changed between
  // the pending render (isPartner=false, hook skipped) and the resolved render
  // (isPartner=true, hook run), crashing the whole partner shell with a
  // hooks-order violation on every page.
  const collectiveMemberActive = useCollectiveMembershipActive();
  const partnerOnly = partner.isPartner && !collectiveMemberActive;
  // Presentation follows the exact workspace after identity resolves. Keep
  // partnerOnly as the account fact: it must not change logout/portal gates.
  const onPartnerWorkspace = dashboardHref === "/collective/partner/dashboard";
  const partnerView = partner.isPartner && (partnerOnly || onPartnerWorkspace);
  const groups: NavGroup[] = partnerView
    ? [...PARTNER_WORKSPACE_GROUPS]
    : partner.isPartner
      ? [...baseGroups, ...PARTNER_WORKSPACE_GROUPS]
      : baseGroups;

  return (
    /* WAVE 96 · ITEM 2 — THE COLOUR MOVES OUT OF THIS COMPONENT AND INTO THE
       SCOPED CSS LAYER. NOTHING ELSE ON THIS ELEMENT CHANGES.

       WHAT WAS WRONG. The rail's colour was a LITERAL here — #F7F6F2 cream with
       #E8E4E0 warm rules. An inline `style=` attribute beats every author
       stylesheet that is not `!important`, so the whole logged-in product moved
       to the ratified cool off-white in Waves 1D and 2D+3D while this rail stayed
       warm. Wave 2D+3D reported it (its OWNER QUESTION Q1) and deliberately did
       NOT patch it, because this ONE component draws BOTH the Collective rail and
       the Consortium Partner rail: hard-coding a cool value here would have moved
       the partner area it had to prove byte-identical, and overriding it for
       Collective alone would have made the two rails differ, which R74 forbids.

       THE RESOLUTION, AND IT IS WAVE 0's OWN MECHANISM. `CollectiveShell` already
       sets `data-product="collective" | "partner"` on its root (line 609), and
       BOTH scopes already shadow these exact `--cv-*` tokens with the ratified
       cool values — `ledger-collective.css` §1 and `ledger-partner.css` §1. So
       reading the TOKEN instead of a literal makes this one component render the
       right rail in each area WITHOUT naming either of them here. A shared
       component serving two areas with two per-area values is not an R74
       violation; it is the attribute R74 is enforced with.

       WHY NO NEW TOKEN NAME. `--cv-color-surface-cream` and `--cv-color-divider`
       already exist in the SACRED `capavate-tokens.css` (:root, entry 41/48,
       NOT opened), are already consumed for exactly this kind of surface by
       `collective-theme.css` and `partner-theme.css`, and each product scope
       already re-points them. A literal here would be the dead hardcoded value
       the owner's standing rule forbids; a NEW token would be a second one.
       Resolved values, measured in the browser, in build_log/wave96:
         collective / partner  surface-cream #F8FAFC · divider #E5EAF0
         :root fallback        #f9f6f1 / #e8e6e1 — i.e. essentially today's warm
                               values, so any future caller without a
                               `data-product` ancestor keeps today's look.

       COLOUR ONLY. No control, handler, label, layout, class, prop or condition
       on this element or any other in this file was touched. */
    <div
      className="flex flex-col h-full"
      style={{ backgroundColor: "var(--cv-color-surface-cream)", borderRight: "1px solid var(--cv-color-divider)" }}
    >
      {/* Brand header */}
      <div
        /* WALKTHROUGH WAVE F · ITEM 1a (owner: "make this logo bigger. It's too
           small and is not good for branding. This top area could be more
           'welcoming' and powerful.")

           SPACING ONLY on this element: py-4 → py-5. The brand lockup below grew
           from a 24px mark to a 36px mark, and a taller mark inside the same
           28px of vertical padding reads as crowding, not as presence. Nothing
           here is removed, renamed, reordered or hidden; the divider token and
           the close button are untouched. */
        className="flex items-center justify-between px-4 py-5"
        /* WAVE 96 · ITEM 2 — token, not a literal. See the note on the rail above. */
        style={{ borderBottom: "1px solid var(--cv-color-divider)" }}
      >
        {/* W-LOGO (Ozan) — use the REAL Capavate logo with the product name
            written UNDERNEATH it, replacing the old "C" tile + inline
            CONSORTIUM/COLLECTIVE badge. Partner presentation reads
            "Consortium Partner"; Collective/combined presentation reads "Collective".
            The logo asset already contains the Capavate wordmark. */}
        {/* WALKTHROUGH WAVE F · ITEM 1a — THE MARK IS BIGGER, MEASURED AGAINST
            THE RAIL IT SITS IN.

            The brand asset is 362×128, i.e. 2.83:1. At h-6 (24px) it rendered
            about 68px wide inside a 224px rail — under a third of the width it
            had available, which is why the owner read it as "too small" and "not
            good for branding". At h-9 (36px) it renders about 102px wide, a
            little under half the rail: unmistakably the brand, still clear of the
            close button on mobile, and consistent with the h-7 the landing page
            and both auth screens already use for the same asset on wider
            surfaces. Larger steps were rejected — h-12 (136px) crowds the
            mobile close button.

            SIZE ONLY. The image element, its alt text, its testid and the
            product label beneath it are unchanged. The label's uppercase setting
            and letter-spacing are applied in
            `client/src/styles/wave-f-partner-dashboard.css` so that the two
            halves of the lockup read as one deliberate unit; the label's TEXT is
            not touched, because the silent-drop guard treats a rewritten literal
            as a removal. */}
        <Link
          href={dashboardHref}
          onClick={() => onClose?.()}
          aria-label={`${partnerView ? "Consortium Partner" : "Collective"}: go to ${dashboardHref === "/collective/partner/dashboard" ? "Partner workspace dashboard" : dashboardHref === "/collective/dashboard" ? "Collective dashboard" : "Capavate home"}`}
          className="rounded focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4"
        >
        <div className="flex flex-col items-start gap-1" data-testid="brand-block">
          <CapavateLogo className="h-9 w-auto" />
          <span
            className="text-[11px] font-semibold tracking-wide"
            style={{ color: partnerView ? "var(--cv-color-navy)" : "var(--cv-color-primary)" }}
            data-testid="brand-product-label"
          >
            {partnerView ? "Consortium Partner" : "Collective"}
          </span>
        </div>
        </Link>
        {onClose && (
          <button
            onClick={onClose}
            className="md:hidden p-1 rounded hover:bg-black/05"
            data-testid="button-close-sidebar"
          >
            <X className="h-4 w-4 text-[var(--cv-color-text-secondary)]" />
          </button>
        )}
      </div>

      {/* Nav groups */}
      <ScrollArea className="flex-1 px-2 py-3">
        <nav>
          {/* Navigation only. Preserve both memberships without combining the
              member menu into the partner workspace the user selected. */}
          {partner.isPartner && (!onPartnerWorkspace || (collectiveMemberActive && collectiveOn)) && (
            <Link
              href={onPartnerWorkspace ? "/collective/dashboard" : "/collective/partner/dashboard"}
              data-testid={onPartnerWorkspace ? "button-switch-to-collective" : "button-switch-to-partner"}
              onClick={() => onClose?.()}
              className="flex items-center gap-3 px-3 py-2 mb-3 rounded-md text-sm font-medium text-[var(--cv-color-text-secondary)] hover:bg-[rgba(204,0,1,0.05)]"
            >
              <ArrowLeftRight className="h-4 w-4 shrink-0" />
              <span>{onPartnerWorkspace ? "Switch to Collective" : "Switch to Consortium Partner"}</span>
            </Link>
          )}
          {groups.map((group) => (
            <div key={group.title} className="mb-4">
              <p
                className="px-3 mb-1 text-[10px] font-semibold tracking-wider uppercase"
                /* v25.43 R3-2 — group labels re-skinned plum → brand red.
                   v25.48.3 Phase-2B — partner-only sessions use the muted
                   capavate.com navy (#041e41) for the new grouped section
                   headers; Collective/combined sessions keep brand red. */
                style={{ color: partnerView ? "var(--cv-color-navy)" : "var(--cv-color-primary)", opacity: 0.7 }}
              >
                {group.title}
              </p>
              <div className="space-y-0.5">
                {group.items.map((item) => (
                  <NavLink key={item.href} item={item} />
                ))}
              </div>
            </div>
          ))}
        </nav>
      </ScrollArea>

      {/* Bottom: Legal & Privacy */}
      {/* WAVE 96 · ITEM 2 — token, not a literal. See the note on the rail above. */}
      <div className="px-4 py-3 shrink-0 space-y-3" style={{ borderTop: "1px solid var(--cv-color-divider)" }}>
        <WishListLauncher beforeOpen={onClose} returnFocusRef={returnFocusRef} />
        <button
          onClick={() => openDrawer()}
          data-testid="button-legal-privacy"
          className="flex items-center gap-2 text-xs text-[var(--cv-color-text-muted)] hover:text-[var(--cv-color-text-secondary)] transition-colors w-full"
        >
          <Scale className="h-3 w-3" />
          Legal &amp; Privacy
        </button>
      </div>
    </div>
  );
}

/* ============================================================
 * Topbar
 * ============================================================ */

function CollectiveTopbar({ onMenuClick, mobileMenuRef }: {
  onMenuClick: () => void; mobileMenuRef?: Ref<HTMLButtonElement>;
}) {
  const { role } = useRole();
  const [location, navigate] = useLocation();
  /* 2026-09-19 — the bell's workspace follows the ROUTE this shell is showing:
     a partner page → partner notices and the partner inbox; any other
     Collective page → Collective notices and the Collective inbox. */
  const bellSurface = location.startsWith("/collective/partner") ? "partner" : "collective";
  const bellViewAllHref = bellSurface === "partner" ? PARTNER_NOTIFICATIONS_HREF : COLLECTIVE_NOTIFICATIONS_HREF;
  // Retain membership-based account controls independently from workspace
  // presentation. ChapterSelector keeps its own existing visibility rules.
  const partnerOnly = usePartnerOnlyMode();
  const partnerMembership = usePartnerMembership();
  const partnerView = partnerMembership.isPartner &&
    (partnerOnly || workspaceDashboard(location) === "/collective/partner/dashboard");

  function switchToCapavate() {
    // v25.13 NH2 — was only admin vs founder; investor users would land
    // on /founder/dashboard and trip 403s against /api/founder/*. Branch
    // for investor (and any other non-admin/non-founder role) properly.
    const dest =
      role === "admin" ? "/admin/dashboard" :
      role === "investor" ? "/investor/dashboard" :
      "/founder/dashboard";
    navigate(dest);
  }

  const [loggingOut, setLoggingOut] = useState(false);
  /* W2-B — partner logout. The LogOut icon was imported but never wired. This
     calls the existing server session-revoke route, clears the React Query
     cache so no stale authed data survives, and hard-navigates to the partner
     login (window.location so all in-memory app state is dropped). */
  async function logout() {
    if (loggingOut) return;
    setLoggingOut(true);
    try {
      await apiRequest("POST", "/api/auth/logout");
    } catch {
      /* fail-safe: even if the revoke call fails we still clear the client
         and redirect so the user is not left in a half-authed state. */
    } finally {
      try {
        await queryClient.resetQueries();
      } catch { /* non-fatal */ }
      window.location.href = "/partner/login";
    }
  }

  return (
    <header
      className="h-14 flex items-center justify-between px-4 gap-3"
      /* WAVE 96 · ITEM 2 — tokens, not literals. `--cv-color-surface` is #FFFFFF
         in :root AND in both product scopes, so the top bar's fill is unchanged
         to the byte; only the warm rule beneath it moves with the rail. */
      style={{
        backgroundColor: "var(--cv-color-surface)",
        borderBottom: "1px solid var(--cv-color-divider)",
      }}
    >
      <div className="flex items-center gap-3">
        {/* Mobile menu button */}
        <button
          ref={mobileMenuRef}
          onClick={onMenuClick}
          className="md:hidden p-2 rounded hover:bg-[var(--cv-color-surface-2)]"
          data-testid="button-mobile-menu"
          aria-label="Open navigation"
        >
          <Menu className="h-5 w-5 text-[var(--cv-color-text-secondary)]" />
        </button>

        <div
          className="text-sm font-medium hidden md:block"
          /* WAVE 96 · ITEM 2 — #1A1A2E was a FOURTH navy, hardcoded here only.
             `--cv-color-navy` is the ratified #041E41, LOCKED by Tier-9 rule 74
             in the sacred token file and never shadowed by any product scope, so
             this reads one navy platform-wide. 15.9:1 on white, AAA. */
          style={{ color: "var(--cv-color-navy)" }}
          data-testid="topbar-title"
        >
          {/* Owner 2026-09-29: title follows the selected workspace, not only membership exclusivity. */}
          {partnerView ? "Capavate Consortium Partner" : "Capavate Collective"}
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* ═══════════════════════════════════════════════════════════════════════
            WAVE 149 · ITEM 1 — THE BELL, AS A NEW STATIC SIBLING.
            ═══════════════════════════════════════════════════════════════════════
            THE DEFECT. The server writes notifications for partners and for every
            Collective persona and `registerNotificationsRoutes` serves them — but
            `NotificationBell` was mounted at `AppShell.tsx:715` ONLY. Partner and
            Collective pages render inside THIS shell, and `/collective/*` is forced
            bare at `App.tsx:457`, so AppShell never renders for them. Every one of
            those notifications was therefore unreachable: written, stored, and
            shown to nobody.

            WHY AN EXTRA SIBLING AND NOT A CONDITION. This is an ADDITIONAL child of
            the existing right-hand group. `ChapterSelector` below, the
            `!partnerOnly` switch button and the `partnerOnly` logout button are
            untouched and still evaluate exactly as before. Collapsing them into one
            conditional would read as a removal to `drop:restyle` and would
            restructure working chrome for no gain.

            NO `useRole()` BRANCHING. There is no `collective` role to branch on
            (`lib/role.tsx:3` — founder | investor | admin | partner, defaulting to
            "founder"), so a role test here would be wrong for the very personas the
            wave exists to serve. Mounting UNCONDITIONALLY is what makes every
            persona this shell hosts — Collective member, Consortium Partner, and the
            dual-role session — gain the bell from ONE mount. The bell already
            renders nothing for an anonymous session (`NotificationBell.tsx`:
            `if (!userId) return null`), so no gate is needed for that either.

            THE PERSONA STAYS IN ITS OWN SHELL. This renders inside CollectiveShell's
            OWN header. It pulls in no AppShell chrome; the AppShell mount at :715 is
            untouched, and so is the forced-bare rule at App.tsx:457 that this shell
            depends on. `viewAllHref` names the in-shell inbox route this wave adds,
            so "View all notifications" no longer ejects the reader to the
            shell-less `/notifications` through a role default that is wrong here. */}
        <NotificationBell viewAllHref={bellViewAllHref} surface={bellSurface} />
        {/* v17 Phase A — chapter selector. Renders null when COLLECTIVE_ENABLED!=1
            or when the user has zero chapter memberships, so the topbar layout
            matches the v16 Friday baseline by default. */}
        <ChapterSelector data-testid="topbar-chapter-selector" />
        {/* v25.41 Bug-1/Bug-2 — the "Switch to Capavate" affordance routes to the
            legacy company portal (founder/investor/admin dashboards). A pure
            consortium partner has no such home and would land on a 403; hide
            it for partner-only sessions. Dual-role and pure-Collective users
            keep the button exactly as before. */}
        {!partnerOnly && (
          <Button
            variant="outline"
            size="sm"
            onClick={switchToCapavate}
            data-testid="button-switch-to-capavate"
            className="gap-2 text-xs border-[var(--cv-color-primary)]/30 text-[var(--cv-color-primary)] hover:bg-[rgba(204,0,1,0.05)]"
          >
            <ArrowLeftRight className="h-3 w-3" />
            Switch to Capavate
          </Button>
        )}
        {/* W2-B — logout. Shown for partner-only sessions (whose only home is
            the partner workspace); dual-role/Collective users retain their
            existing Capavate portal logout via AppShell. */}
        {partnerOnly && (
          <Button
            variant="outline"
            size="sm"
            onClick={logout}
            disabled={loggingOut}
            data-testid="button-partner-logout"
            className="gap-2 text-xs border-[var(--cv-color-navy)]/30 text-[var(--cv-color-navy)] hover:bg-[rgba(4,30,65,0.05)]"
          >
            <LogOut className="h-3 w-3" />
            {loggingOut ? "Signing out…" : "Log out"}
          </Button>
        )}
      </div>
    </header>
  );
}

/* ============================================================
 * v25.48.2 MF7 (Q9) — member gate on the COMMON shell
 *
 * Previously ONLY /collective/dashboard was wrapped in <CollectiveMemberGate>
 * in App.tsx; every other member-only collective route (dealroom, members,
 * companies, soft-circles, DSC pages, recaps, calendar, ma-intel, …) mounted
 * its page and fired its member-only queries for a signed-in NON-member,
 * spraying 403s. Gating on the shared shell means membership resolves BEFORE
 * any member-only page mounts, for ALL of them, in one place.
 *
 * EXEMPT (intentionally reachable by a signed-in non-member):
 *   - /collective/partner/*        — the consortium PARTNER workspace. A
 *                                    partner-only user is NOT a collective
 *                                    member; gating these would wrongly wall
 *                                    them off from their own workspace.
 *   - /collective/membership*      — the apply/checkout + membership summary
 *                                    surface (how a non-member joins).
 *   - /syndicate/apply,
 *     /collective/syndicate/apply  — public apply surface.
 *
 * v25.48.2 MF-C — /collective/profile/:userId is NO LONGER exempt. The public
 * profile page (PublicProfile.tsx) resolves the member from the member-only
 * directory endpoint GET /api/collective/members (requireCollectiveMember), so
 * exempting it let a non-member mount the page and fire that member-only call —
 * the exact Q9 behavior the gate exists to prevent. There is no public,
 * non-member-safe profile endpoint, so the profile is treated as member-only:
 * a non-member now gets the marketing/apply gate instead.
 * ============================================================ */
function isMemberGateExempt(path: string): boolean {
  return (
    path.startsWith("/collective/partner") ||
    path.startsWith("/collective/membership") ||
    /* WAVE 149 · ITEM 2 — THE INBOX IS NOT MEMBER-ONLY, AND MUST NOT BE GATED.
       `/api/notifications` scopes strictly to the SESSION user
       (`server/notificationsStore.ts:246-255` — the userId comes from the auth
       context, never from a query param) and asks nothing about Collective
       membership; `/notifications` has always served it role-agnostically. A
       Consortium Partner and a signed-in non-member both legitimately RECEIVE
       notifications — partner referral, attribution, promotion and application
       kinds are addressed to exactly them — so putting the member gate in front of
       this page would replace their own inbox with a join-the-Collective wall and
       re-create the unreachability this wave exists to fix, one layer down. Listed
       explicitly rather than folded into the partner prefix because it serves EVERY
       persona this shell hosts, not just the partner. */
    path === COLLECTIVE_NOTIFICATIONS_HREF ||
    path === PARTNER_NOTIFICATIONS_HREF ||
    path === "/syndicate/apply" ||
    path.startsWith("/collective/syndicate/apply")
  );
}

/* ============================================================
 * CollectiveShell — main layout
 * ============================================================ */

interface CollectiveShellProps {
  children: ReactNode;
}

export function CollectiveShell({ children }: CollectiveShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const mobileMenuRef = useRef<HTMLButtonElement>(null);
  /* v25.31 Wave B — set data-product="collective" or "partner" on the shell
     so capavate.com design tokens defined in index.css can be applied via
     scoped selectors WITHOUT touching any existing inline color or className.
     This is purely additive presentation — zero functionality change, zero
     route change, zero auth-wrapper change. Capavate routes never receive
     this attribute (they go through AppShell, not CollectiveShell). */
  const [location] = useLocation();
  const product: "partner" | "collective" = location.startsWith("/collective/partner")
    ? "partner"
    : "collective";
  // The member-facing /collective/partners directory is not a partner workspace.
  const wishSurface = /^\/collective\/partner(?:\/|$)/.test(location) ? "partner" : "collective";

  return (
    <WishListProvider locator={{ surface: wishSurface }} sourceRouteKey={WISH_SOURCE_ROUTE_KEYS[wishSurface]} product={wishSurface}>
    <div data-product={product} className="flex h-screen overflow-hidden bg-white">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex w-56 shrink-0 flex-col h-full">
        <CollectiveSidebar />
      </aside>

      {/* Mobile sidebar overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="relative z-10 w-56 h-full">
            <CollectiveSidebar onClose={() => setMobileOpen(false)} returnFocusRef={mobileMenuRef} />
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex flex-col flex-1 min-w-0 h-full overflow-hidden">
        <CollectiveTopbar onMenuClick={() => setMobileOpen(true)} mobileMenuRef={mobileMenuRef} />
        {/* v25.43 R3-4 — persistent live ticker strip, always visible across the
            Collective + Consortium Partner shells, immediately under the top
            app header. */}
        <MarketTicker />
        <main className="flex-1 overflow-auto bg-[var(--cv-color-bg)]">
          {isMemberGateExempt(location)
            ? children
            : <CollectiveMemberGate>{children}</CollectiveMemberGate>}
          {/* WAVE 8 / ORP-047 — Terms/Privacy entry point for the Collective
              and Consortium Partner shells (see LegalFooterLinks.tsx). */}
          <LegalFooterLinks />
        </main>
      </div>
    </div>
    </WishListProvider>
  );
}

export default CollectiveShell;
