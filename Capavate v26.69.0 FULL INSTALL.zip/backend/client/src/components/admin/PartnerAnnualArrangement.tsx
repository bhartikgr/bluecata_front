/**
 * v26.67 — per-partner ONGOING ANNUAL arrangement (contacts.fee_override_json.subscription_annual).
 *
 * The annual override is the per-partner price the approval invoice engine and the annual
 * checkout consult. This card edits ONLY that key, through the per-key patch contract of
 * `PUT /api/admin/partners/:partnerId/fee-override`:
 *
 *   { feeOverridePatch: { subscription_annual: {amountMinor, currency} | null },
 *     expectedFeeOverrides: { subscription_annual: <value this card was loaded with> | null },
 *     reason: "<non-blank audit reason>" }
 *
 * The server merges the one key into the current JSON (monthly and unrelated keys are kept)
 * and refuses with 409 when the stored annual value no longer equals the expected one.
 *
 * Rules held here:
 *   - the mode is chosen explicitly; nothing is preselected;
 *   - "tier" clears the individual annual entry; "free" writes exactly 0; "custom" needs a
 *     safe integer >= 1 in MINOR units;
 *   - the currency is chosen from the server's ACTIVE currency list; there is no default;
 *   - amounts are exact integer strings, never parsed as floating-point money;
 *   - a review summary is confirmed before the write, and it states that saving does not
 *     charge, issue a retroactive invoice or start a subscription.
 */
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, ApiError } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CalendarClock } from "lucide-react";

export interface AnnualOverrideValue {
  amountMinor?: number;
  currency?: string;
}

export interface ActiveCurrency {
  code: string;
  minorUnitExponent: number;
}

export type AnnualMode = "" | "tier" | "free" | "custom";

export interface PartnerAnnualArrangementProps {
  partnerId: string;
  /** The stored `subscription_annual` value exactly as returned by GET (null/undefined = none). */
  current: AnnualOverrideValue | null | undefined;
  /** Active currencies from GET fee-override (`currencies`). */
  currencies: ActiveCurrency[] | undefined;
  /** Called after a successful save (the page invalidates its fee-override query). */
  onSaved?: () => void;
  /** Re-reads the server and returns the current stored annual value. It must REJECT when the
   *  read fails or the response is not ok; the card then keeps its old base and stale state. */
  onReload?: () => Promise<AnnualOverrideValue | null | undefined>;
}

/** Same select styling as the native selects on the Pricing & Payments console. */
const SELECT_CLASS =
  "h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50";

const TEXTAREA_CLASS =
  "flex min-h-[64px] w-full rounded-md border border-input bg-background px-3 py-2 text-base placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm";

/**
 * Exact integer check on the typed TEXT (no parseInt / parseFloat): digits only, no sign,
 * no leading zero (except "0" itself when min is 0), within Number.MAX_SAFE_INTEGER, >= min.
 */
export function exactMinorUnits(raw: string, min: 0 | 1): number | null {
  const s = raw.trim();
  if (!/^(0|[1-9][0-9]*)$/.test(s)) return null;
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < min) return null;
  return n;
}

/** Major-unit rendering by string arithmetic only (no floating-point money). */
export function minorToMajorText(minor: number, exponent: number): string {
  const digits = String(minor);
  if (!Number.isInteger(exponent) || exponent <= 0) return digits;
  const padded = digits.padStart(exponent + 1, "0");
  return `${padded.slice(0, padded.length - exponent)}.${padded.slice(padded.length - exponent)}`;
}

function exponentLabel(c: ActiveCurrency | undefined): string {
  if (!c) return "Choose a currency first";
  if (c.minorUnitExponent === 0) return `${c.code} has exponent 0: minor units are whole ${c.code}`;
  return `${c.code} has exponent ${c.minorUnitExponent}: 1 ${c.code} = ${"1".padEnd(c.minorUnitExponent + 1, "0")} minor units`;
}

function describeStored(v: AnnualOverrideValue | null | undefined, currencies: ActiveCurrency[]): string {
  if (!v || typeof v.amountMinor !== "number") {
    return "No individual annual arrangement is stored. The partner's tier annual price applies.";
  }
  const code = v.currency;
  const cur = code ? currencies.find((c) => c.code === code) : undefined;
  const ccyText = code ? code : "no currency recorded (the price resolver reads a missing currency as USD)";
  if (v.amountMinor === 0) return `Free: an individual annual exemption of 0 minor units, ${ccyText}.`;
  const major = cur ? ` (${minorToMajorText(v.amountMinor, cur.minorUnitExponent)} ${cur.code})` : "";
  return `Custom annual price: ${v.amountMinor} minor units, ${ccyText}${major}.`;
}

export const NO_CHARGE_BOUNDARY =
  "Saving this arrangement does not charge the partner, does not issue a retroactive invoice and does not start a subscription. It is used at the partner's next approval invoice or annual checkout.";

export function PartnerAnnualArrangement({ partnerId, current, currencies, onSaved, onReload }: PartnerAnnualArrangementProps) {
  const active = currencies ?? [];
  const [base, setBase] = useState<AnnualOverrideValue | null>(current ?? null);
  const [mode, setMode] = useState<AnnualMode>("");
  const [currency, setCurrency] = useState("");
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stale, setStale] = useState(false);
  const [savedNote, setSavedNote] = useState<string | null>(null);

  const selected = active.find((c) => c.code === currency);
  const resetForm = () => {
    setMode("");
    setCurrency("");
    setAmount("");
    setReason("");
    setReviewing(false);
    setError(null);
    setStale(false);
  };

  /** Validates the form; returns the exact patch value or an error message. */
  function build(): { ok: true; value: { amountMinor: number; currency: string } | null } | { ok: false; error: string } {
    if (mode === "") return { ok: false, error: "Choose how this partner's annual subscription is priced." };
    if (reason.trim() === "") return { ok: false, error: "Enter the reason for this annual arrangement (recorded in the admin audit)." };
    if (mode === "tier") {
      if (!base || typeof base.amountMinor !== "number") {
        return { ok: false, error: "Nothing to change: this partner already uses the tier annual price." };
      }
      return { ok: true, value: null };
    }
    if (!selected) return { ok: false, error: "Choose an active currency." };
    if (mode === "free") return { ok: true, value: { amountMinor: 0, currency: selected.code } };
    const n = exactMinorUnits(amount, 1);
    if (n === null) {
      return { ok: false, error: "The custom annual price must be a whole number of minor units, at least 1, with no sign, decimal point or separators." };
    }
    return { ok: true, value: { amountMinor: n, currency: selected.code } };
  }

  const built = build();

  function summaryText(): string {
    if (!built.ok) return "";
    if (built.value === null) {
      return "Clear the individual annual arrangement. The partner's tier annual price will apply; if that tier has no annual price, a future approval invoice is refused.";
    }
    if (built.value.amountMinor === 0) {
      return `Free: record an individual annual exemption of exactly 0 minor units in ${built.value.currency}. A future approval raises no invoice for this partner.`;
    }
    const exp = selected?.minorUnitExponent ?? 0;
    return `Custom annual price: ${built.value.amountMinor} minor units of ${built.value.currency} (${minorToMajorText(built.value.amountMinor, exp)} ${built.value.currency}) per year.`;
  }

  const saveMut = useMutation({
    mutationFn: async (value: { amountMinor: number; currency: string } | null) => {
      const r = await apiRequest("PUT", `/api/admin/partners/${partnerId}/fee-override`, {
        feeOverridePatch: { subscription_annual: value },
        expectedFeeOverrides: { subscription_annual: base ?? null },
        reason: reason.trim(),
      });
      const j = await r.json();
      if (!j?.ok) throw new Error(j?.error || "save_failed");
      return value;
    },
    onSuccess: (value) => {
      setBase(value);
      resetForm();
      setSavedNote("Annual arrangement saved.");
      onSaved?.();
    },
    onError: (e: unknown) => {
      setReviewing(false);
      if (e instanceof ApiError && e.status === 409) {
        setStale(true);
        setError(
          "Nothing was saved: this partner's annual arrangement was changed elsewhere after this page loaded. Reload the current value and review again.",
        );
        return;
      }
      setError(`Nothing was saved. ${(e as Error | undefined)?.message ?? ""}`.trim());
    },
  });

  const [reloading, setReloading] = useState(false);
  async function reload() {
    if (!onReload) return;
    setReloading(true);
    try {
      const fresh = await onReload();
      setBase(fresh ?? null);
      resetForm();
    } catch (e) {
      /* The old base and the stale flag are kept, so a later save still expects the value
         this card last knew and the server keeps refusing until a reload succeeds. */
      setStale(true);
      setError(
        `Nothing was saved, and the current value could not be reloaded. Try reloading again. ${(e as Error | undefined)?.message ?? ""}`.trim(),
      );
    } finally {
      setReloading(false);
    }
  }

  const noCurrencies = active.length === 0;

  return (
    <Card className="p-5 mb-6" data-testid="admin-partner-annual-arrangement">
      <div className="flex items-center gap-2 mb-1">
        <CalendarClock className="h-4 w-4 text-muted-foreground" />
        <h3 className="font-semibold text-sm">Annual subscription arrangement</h3>
      </div>
      <p className="text-xs text-muted-foreground mb-3">
        The individual ANNUAL price for THIS partner. It supersedes the tier annual price for this partner only and is
        separate from the custom monthly price above. Amounts are entered in exact minor units of the chosen currency.
      </p>
      <p className="text-sm mb-4" data-testid="text-annual-current">
        <span className="font-medium">Currently stored: </span>
        {describeStored(base, active)}
      </p>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <div className="space-y-1">
          <Label htmlFor={`annual-mode-${partnerId}`} className="text-xs">Annual pricing</Label>
          <select
            id={`annual-mode-${partnerId}`}
            data-testid="select-annual-mode"
            className={SELECT_CLASS}
            value={mode}
            onChange={(e) => { setMode(e.target.value as AnnualMode); setReviewing(false); setError(null); setSavedNote(null); }}
          >
            <option value="">Choose…</option>
            <option value="tier">Tier price (clear the individual annual price)</option>
            <option value="free" disabled={noCurrencies}>Free (individual exemption, 0)</option>
            <option value="custom" disabled={noCurrencies}>Custom annual price</option>
          </select>
        </div>
        <div className="space-y-1">
          <Label htmlFor={`annual-currency-${partnerId}`} className="text-xs">Currency</Label>
          <select
            id={`annual-currency-${partnerId}`}
            data-testid="select-annual-currency"
            className={SELECT_CLASS}
            value={currency}
            disabled={mode !== "free" && mode !== "custom"}
            onChange={(e) => { setCurrency(e.target.value); setReviewing(false); setError(null); }}
          >
            <option value="">Choose a currency…</option>
            {active.map((c) => (
              <option key={c.code} value={c.code}>{c.code}</option>
            ))}
          </select>
          {noCurrencies && (
            <p className="text-xs text-destructive" data-testid="text-annual-no-currencies">
              No active currency is available, so a free or custom annual price cannot be set here.
            </p>
          )}
        </div>
        <div className="space-y-1">
          <Label htmlFor={`annual-amount-${partnerId}`} className="text-xs">Annual price (minor units)</Label>
          <Input
            id={`annual-amount-${partnerId}`}
            data-testid="input-annual-minor"
            inputMode="numeric"
            disabled={mode !== "custom"}
            value={mode === "free" ? "0" : amount}
            onChange={(e) => { setAmount(e.target.value); setReviewing(false); setError(null); }}
            placeholder="whole number, at least 1"
          />
          <p className="text-xs text-muted-foreground" data-testid="text-annual-exponent">{exponentLabel(selected)}</p>
        </div>
        <div className="space-y-1 sm:col-span-2 lg:col-span-3">
          <Label htmlFor={`annual-reason-${partnerId}`} className="text-xs">Reason (required, recorded in the admin audit)</Label>
          <textarea
            id={`annual-reason-${partnerId}`}
            data-testid="input-annual-reason"
            className={TEXTAREA_CLASS}
            value={reason}
            maxLength={1000}
            onChange={(e) => { setReason(e.target.value); setReviewing(false); setError(null); }}
            placeholder="e.g. founding member arrangement approved by the partnerships lead"
          />
        </div>
      </div>

      {error && (
        <div className="mt-3 rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm" role="alert" data-testid="text-annual-error">
          <p>{error}</p>
          {stale && onReload && (
            <Button size="sm" variant="outline" className="mt-2" data-testid="button-annual-reload" disabled={reloading} onClick={() => { void reload(); }}>
              {reloading ? "Reloading..." : "Reload current value"}
            </Button>
          )}
        </div>
      )}
      {savedNote && !error && (
        <p className="mt-3 text-sm text-muted-foreground" role="status" data-testid="text-annual-saved">{savedNote}</p>
      )}

      {reviewing && built.ok ? (
        <div className="mt-4 rounded-md border border-border/60 p-3 space-y-2" data-testid="annual-confirmation">
          <p className="text-sm font-medium">Review before saving</p>
          <p className="text-sm" data-testid="text-annual-summary">{summaryText()}</p>
          <p className="text-sm" data-testid="text-annual-summary-reason">Reason: {reason.trim()}</p>
          <p className="text-xs text-muted-foreground" data-testid="text-annual-boundary">{NO_CHARGE_BOUNDARY}</p>
          <div className="flex justify-end gap-2">
            <Button size="sm" variant="outline" data-testid="button-annual-cancel" onClick={() => setReviewing(false)} disabled={saveMut.isPending}>
              Back
            </Button>
            <Button
              size="sm"
              data-testid="button-annual-confirm"
              disabled={saveMut.isPending}
              onClick={() => saveMut.mutate(built.value)}
            >
              {saveMut.isPending ? "Saving..." : "Confirm and save"}
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex justify-end mt-4">
          <Button
            size="sm"
            data-testid="button-annual-review"
            onClick={() => {
              setSavedNote(null);
              if (!built.ok) { setError(built.error); setStale(false); return; }
              setError(null);
              setReviewing(true);
            }}
          >
            Review annual arrangement
          </Button>
        </div>
      )}
    </Card>
  );
}

export default PartnerAnnualArrangement;
