import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import type { AnnualArrangement, ApprovalSetup, AnnualPreview } from "@shared/partnerApprovalSetup";
/* PP2669 B9 rule — the annual figure through the shared formatter, flag-driven. */
import { describeAnnualPrice } from "@shared/pricingDisplay";
import { usePriceDisplayPolicy } from "@/lib/priceDisplayPolicy";

export type ApprovalSetupState = { enabled: boolean; setup: ApprovalSetup | null };
type TierOption = {
  slug: string; label: string; state: "active" | "frozen" | "archived";
  price: { amountMinor: number; currency: string; cadence: string } | null;
  freeAttested: boolean;
};
type Options = {
  options: TierOption[];
  excludedTiers: Pick<TierOption, "slug" | "label" | "state">[];
  currencies: { code: string; minorUnitExponent: number }[];
};

function optionPrice(option: TierOption, currencies: Options["currencies"]): string {
  if (!option.price) return "Price not attested on the sold cadence";
  const { amountMinor, currency, cadence } = option.price;
  const exponent = currencies.find(c => c.code === currency)?.minorUnitExponent;
  const price = exponent === undefined
    ? `${amountMinor} ${currency} minor units`
    : `${currency} ${(amountMinor / (10 ** exponent)).toFixed(exponent)}`;
  return `${price} / ${cadence}${option.freeAttested ? " (attested free)" : ""}`;
}

export function PartnerApprovalSetup({ applicationId, disabled, onChange }: {
  applicationId: string; disabled?: boolean; onChange: (state: ApprovalSetupState) => void;
}) {
  const [enabled, setEnabled] = useState(false);
  const [options, setOptions] = useState<Options | null>(null);
  const [tier, setTier] = useState("");
  const [mode, setMode] = useState<AnnualArrangement["mode"]>("tier_price");
  const [currency, setCurrency] = useState("");
  const [minor, setMinor] = useState("");
  const [reason, setReason] = useState("");
  const [preview, setPreview] = useState<{ key: string; value: AnnualPreview } | null>(null);
  const showMonthlyEquivalent = usePriceDisplayPolicy()?.showMonthlyEquivalent === true;
  const annualLine = (minor: number, ccy: string) =>
    Number.isInteger(minor) && minor >= 0 ? describeAnnualPrice(minor, { currency: ccy, showMonthlyEquivalent }).line : `${minor} ${ccy}`;
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const key = JSON.stringify([applicationId, tier, mode, currency, minor]);
  const currentPreview = preview?.key === key ? preview.value : null;
  const selectedOption = options?.options.find(t => t.slug === tier);
  const assignable = selectedOption?.state === "active";
  const base = `/api/admin/consortium/applications/${encodeURIComponent(applicationId)}/approval-preview`;
  const values: AnnualArrangement = {
    tier, mode, reason: reason.trim(),
    ...(mode !== "tier_price" ? { currency, amountMinor: mode === "free_exemption" ? 0 : Number(minor) } : {}),
  };
  const validAmount = mode !== "custom_annual" || (/^\d+$/.test(minor) && Number.isSafeInteger(Number(minor)) && Number(minor) > 0);

  useEffect(() => {
    onChange({ enabled, setup: enabled && assignable && currentPreview && reason.trim() && validAmount
      ? { ...values, expectedCharge: currentPreview.charge } : null });
  }, [enabled, key, reason, preview, onChange, assignable]);

  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    setError("");
    fetch(base, { credentials: "include" }).then(async r => {
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || "Membership options could not be loaded.");
      if (!Array.isArray(data.options) || !Array.isArray(data.excludedTiers) || !Array.isArray(data.currencies)) {
        throw new Error("Membership options are incomplete. Refresh before approving.");
      }
      if (alive) setOptions(data);
    }).catch(e => { if (alive) setError(e.message); });
    return () => { alive = false; };
  }, [enabled, base]);

  async function refreshPreview() {
    setLoading(true); setError(""); setPreview(null);
    const requestedKey = key;
    try {
      if (!assignable) throw new Error("Select an active tier for a new assignment.");
      if (!validAmount) throw new Error("Enter a positive whole number of minor units.");
      const qs = new URLSearchParams({ tier, mode });
      if (mode !== "tier_price") {
        qs.set("currency", currency);
        qs.set("amountMinor", String(mode === "free_exemption" ? 0 : Number(minor)));
      }
      const r = await fetch(`${base}?${qs}`, { credentials: "include" });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || "The annual charge could not be resolved.");
      setPreview({ key: requestedKey, value: data });
    } catch (e) { setError((e as Error).message); }
    finally { setLoading(false); }
  }

  const control = "w-full border border-border rounded p-2 text-sm bg-background";
  const exponent = options?.currencies.find(c => c.code === currency)?.minorUnitExponent;
  return <fieldset className="border border-border rounded p-3 mb-4 space-y-3" disabled={disabled}>
    <legend className="text-sm font-semibold px-1">Membership setup at approval</legend>
    <label className="flex items-start gap-2 text-sm">
      <input type="checkbox" checked={enabled} onChange={e => { setEnabled(e.target.checked); setPreview(null); }} />
      Choose a membership tier and annual arrangement
    </label>
    {!enabled ? <p className="text-xs text-muted-foreground">
      Existing approval behavior is unchanged. A new partner otherwise starts on Catalyst; its annual price must resolve.
    </p> : <>
      <div className="grid gap-3 sm:grid-cols-2">
        <div><label className="text-sm">Membership tier
          <select className={control} value={tier} onChange={e => setTier(e.target.value)}>
            <option value="">Select a tier</option>
            {/* PP2669 · A2 · PP-03: only the server catalogue supplies choices.
                Frozen remains visible; neither frozen nor archived is assignable. */}
            {options?.options.map(t => <option key={t.slug} value={t.slug} disabled={t.state !== "active"}>
              {t.label || t.slug} — {t.state} — {optionPrice(t, options.currencies)}
            </option>)}
          </select>
        </label>
          {!!options?.excludedTiers.length && <span className="block text-xs text-muted-foreground">
            Not available for new assignments: {options.excludedTiers.map(t => `${t.label || t.slug} (${t.state})`).join("; ")}.
            Existing partner arrangements are retained.
          </span>}
        </div>
        <label className="text-sm">Annual arrangement
          <select className={control} value={mode} onChange={e => setMode(e.target.value as AnnualArrangement["mode"])}>
            <option value="tier_price">Use current price (retain any existing annual override)</option>
            <option value="free_exemption">Individual free exemption</option>
            <option value="custom_annual">Custom paid annual price</option>
          </select>
        </label>
        {mode !== "tier_price" && <label className="text-sm">Annual price currency
          <select className={control} value={currency} onChange={e => setCurrency(e.target.value)}>
            <option value="">Select an active currency</option>
            {options?.currencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
          </select>
        </label>}
        {mode === "custom_annual" && <label className="text-sm">Annual amount (integer minor units)
          <input className={control} inputMode="numeric" value={minor} onChange={e => setMinor(e.target.value)} />
          {exponent !== undefined && <span className="text-xs text-muted-foreground">{10 ** exponent} minor units = 1 {currency}.</span>}
        </label>}
      </div>
      <label className="block text-sm">Membership setup reason (required)
        <textarea className={control} maxLength={1000} value={reason} onChange={e => setReason(e.target.value)} />
      </label>
      <p className="text-xs text-muted-foreground">
        {/* PP2669 B3-b (R2) — Founding Member is full access at zero when its tier price is attested free; the preview says so. */}
        Founding Member is free only when its tier price is attested free (the preview shows the attestation). Select Individual free exemption to approve one partner without an annual invoice.
        This sets only the partner's own membership price, not company referral discounts or partner referral fees.
      </p>
      <Button type="button" variant="outline" size="sm" disabled={loading || !assignable || !options || !validAmount ||
        (mode !== "tier_price" && !currency)} onClick={() => void refreshPreview()}>
        {loading ? "Checking annual charge…" : "Preview annual charge"}
      </Button>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      {currentPreview && <div role="status" className="rounded border p-3 text-sm space-y-1">
        <p data-testid="approval-preview-outcome">{currentPreview.outcome === "exempt" ? "Explicit free exemption: no annual invoice will be raised." :
          currentPreview.outcome === "tier_free"
            ? `${annualLine(0, currentPreview.charge.currency)} — attested free${currentPreview.attestation?.reason ? ` (${currentPreview.attestation.reason})` : ""}. Approval issues a zero-amount invoice marked free-attested and an open-ended complimentary membership.`
            : `Approval will raise one annual invoice for ${annualLine(currentPreview.charge.amountMinor, currentPreview.charge.currency)} (${currentPreview.charge.amountMinor} ${currentPreview.charge.currency} minor units).`}</p>
        <p>Source: {currentPreview.charge.source === "partner_override" ? "individual partner arrangement" : currentPreview.charge.source === "tier_free" ? "tier catalogue (attested free)" : "tier catalogue"}.
          This preview is advisory; approval rechecks the price and all existing agreement and compliance requirements.</p>
      </div>}
      {!currentPreview && <p className="text-xs text-muted-foreground">Preview the current charge before approving. Changing a pricing field invalidates the preview.</p>}
    </>}
  </fieldset>;
}
