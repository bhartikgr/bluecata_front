/**
 * WAVE 38 · ROW 5 — what an admin actually SEES on the founder-channels panel.
 *
 * The server half is exercised in
 * `server/__tests__/wave36_row9_dead_promise_and_orphan.test.ts` (P10-P10d).
 * This file closes the other half: the panel is RENDERED against each response
 * shape the endpoint can produce, and the assertions read the rendered text.
 *
 * The prior harness only searched `FounderChannelsPanel.tsx` for strings, which
 * is why Review 3B's broken-output mutation went unnoticed. A rendered refusal
 * is a UI claim and has to be proven in the UI.
 *
 * S4d preserves those JPY/USD/zero money values under explicit recorded states
 * while withholding the old intent-inclusive raised scalar even for one code.
 * A failed request remains an error, not an empty or zero money card.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import { QueryClient, QueryCache, QueryClientProvider } from "@tanstack/react-query";

const apiRequestMock = vi.fn();
vi.mock("@/lib/queryClient", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queryClient")>("@/lib/queryClient");
  return { ...actual, apiRequest: (...a: unknown[]) => apiRequestMock(...a) };
});

import { FounderChannelsPanel } from "../FounderChannelsPanel";

const COMPANY = "co_w38_r5_panel";

function serve(body: unknown) {
  apiRequestMock.mockImplementation(async () => ({ json: async () => body, ok: true }) as unknown as Response);
}

function renderPanel() {
  const qc = new QueryClient({
    /* The shipped app's QueryClient installs a QueryCache onError handler
       (client/src/lib/queryClient.ts). Installing one here too keeps a failed
       query's rejection owned by the cache, exactly as in production, instead
       of escaping as an unhandled rejection in the runner. */
    queryCache: new QueryCache({ onError: () => {} }),
    defaultOptions: { queries: { retry: false, staleTime: Infinity } },
  });
  return render(
    <QueryClientProvider client={qc}>
      <FounderChannelsPanel companyId={COMPANY} />
    </QueryClientProvider>,
  );
}

/* BLOCK BODIES, deliberately. `beforeEach(() => mock.mockReset())` returns the
   mock FUNCTION, and vitest treats a value returned from a hook as that hook's
   teardown callback — so it invoked `apiRequestMock()` after every test. With
   the error pole's implementation still installed that produced a rejected
   promise nobody owned, and the runner attributed the stray rejection to the
   test as a failure even though every assertion in it had passed. Returning
   nothing is the whole fix. */
beforeEach(() => { apiRequestMock.mockReset(); });
afterEach(() => { cleanup(); });

describe("Wave 38 · Row 5 — FounderChannelsPanel renders the server's answer", () => {
  it("POLE A — a USD commitment retains its exact amount without a raised scalar", async () => {
    serve({
      ok: true,
      companyId: COMPANY,
      totalRaisedMinor: null,
      totalRaisedCurrency: null,
      totalRaisedByCurrency: null,
      totalRaisedUnavailableReason: "intent_inclusive_raised_not_comparable",
      byStateCurrency: [{ state: "committed", currency: "USD", minor: "400000" }],
      byChannel: { direct: {
        countSCs: 2, totalMinor: null, currency: null, byCurrency: null,
        unavailableReason: "intent_inclusive_raised_not_comparable",
        byStateCurrency: [{ state: "committed", currency: "USD", minor: "400000" }],
      } },
    });
    renderPanel();
    const refusal = await waitFor(() => screen.getByTestId("admin-founder-channels-total-unavailable"));
    expect(refusal.textContent).toMatch(/indications, signed commitments and received funds/);
    expect(screen.queryByTestId("admin-founder-channels-total")).toBeNull();
    expect(screen.getByTestId("admin-founder-channels-total-by-state-currency-committed-USD").textContent)
      .toContain("USD 4,000.00");
    expect(screen.getByTestId("admin-founder-channels-direct-by-state-currency-committed-USD").textContent)
      .toContain("USD 4,000.00");
    expect(screen.getByTestId("admin-founder-channels-direct-count").textContent).toContain("2 soft circles");
  });

  it("POLE B — JPY committed amount uses exponent zero, without scaling", async () => {
    serve({
      ok: true,
      totalRaisedMinor: null,
      totalRaisedCurrency: null,
      totalRaisedByCurrency: null,
      totalRaisedUnavailableReason: "intent_inclusive_raised_not_comparable",
      byStateCurrency: [{ state: "committed", currency: "JPY", minor: "250000" }],
      byChannel: { direct: { countSCs: 1, totalMinor: null, currency: null } },
    });
    renderPanel();
    const total = await waitFor(() => screen.getByTestId("admin-founder-channels-total-by-state-currency-committed-JPY"));
    expect(total.textContent).toContain("250,000");
    expect(total.textContent).not.toContain("2,500.00");
    expect(total.textContent).not.toContain("250,000.00");
  });

  it("POLE C — mixed currencies retain both state-labelled legs but no FX sum", async () => {
    serve({
      ok: true,
      totalRaisedMinor: null,
      totalRaisedCurrency: null,
      totalRaisedUnavailableReason: "intent_inclusive_raised_not_comparable",
      totalRaisedByCurrency: null,
      byStateCurrency: [
        { state: "committed", currency: "JPY", minor: "250000" },
        { state: "funded", currency: "USD", minor: "400000" },
      ],
      byChannel: {
        direct: {
          countSCs: 2,
          totalMinor: null,
          currency: null,
          unavailableReason: "intent_inclusive_raised_not_comparable",
          byCurrency: null,
          byStateCurrency: [
            { state: "committed", currency: "JPY", minor: "250000" },
            { state: "funded", currency: "USD", minor: "400000" },
          ],
        },
      },
    });
    renderPanel();
    const refusal = await waitFor(() => screen.getByTestId("admin-founder-channels-total-unavailable"));
    expect(refusal.textContent).toContain("indications, signed commitments and received funds");
    // No scalar total is rendered at all — not a 0, not a blank, not an em-dash.
    expect(screen.queryByTestId("admin-founder-channels-total")).toBeNull();
    expect(screen.getByTestId("admin-founder-channels-total-by-state-currency-committed-JPY").textContent)
      .toContain("JPY 250,000");
    expect(screen.getByTestId("admin-founder-channels-total-by-state-currency-funded-USD").textContent)
      .toContain("USD 4,000.00");
    // And the summed figure is nowhere on screen.
    expect(document.body.textContent ?? "").not.toContain("650,000");
  });

  it("POLE D — genuine recorded zero is preserved in a named bucket, not as raised", async () => {
    serve({
      ok: true,
      totalRaisedMinor: null,
      totalRaisedCurrency: null,
      totalRaisedByCurrency: null,
      totalRaisedUnavailableReason: "intent_inclusive_raised_not_comparable",
      byStateCurrency: [{ state: "committed", currency: "USD", minor: "0" }],
      byChannel: { direct: { countSCs: 1, totalMinor: null, currency: null } },
    });
    renderPanel();
    const total = await waitFor(() => screen.getByTestId("admin-founder-channels-total-by-state-currency-committed-USD"));
    expect(total.textContent).toContain("0.00");
    expect(screen.queryByTestId("admin-founder-channels-total")).toBeNull();
    expect(screen.getByTestId("admin-founder-channels-direct-count").textContent).toContain("1 soft circle");
  });

  it("malformed and unclassified rows cannot become printable money", async () => {
    serve({
      ok: true,
      totalRaisedMinor: null, totalRaisedCurrency: null,
      totalRaisedUnavailableReason: "intent_inclusive_raised_not_comparable",
      unknownRows: 2,
      byStateCurrency: [
        { state: "funded", currency: "AAA", minor: "100" },
        { state: "surprise", currency: "USD", minor: "200" },
      ],
    });
    renderPanel();
    await waitFor(() => screen.getByTestId("admin-founder-channels-total-unavailable"));
    expect(screen.getByTestId("admin-founder-channels-total-by-state-currency-funded-AAA").textContent)
      .toContain("Amount unavailable");
    expect(screen.getByTestId("admin-founder-channels-total-by-state-currency-surprise-USD").textContent)
      .toContain("Amount unavailable");
    expect(document.body.textContent).toContain("2 row(s) could not be classified or denominated");
    expect(screen.queryByTestId("admin-founder-channels-total")).toBeNull();
  });

  it("POLE E — a failed request says so; it never renders a zero or an empty card", async () => {
    apiRequestMock.mockImplementation(() => Promise.reject(new Error("boom")));
    renderPanel();
    const err = await waitFor(() => screen.getByTestId("admin-founder-channels-error"));
    expect(err.textContent).toContain("Could not load the channel breakdown");
    expect(screen.queryByTestId("admin-founder-channels-total")).toBeNull();
    expect(document.body.textContent ?? "").not.toContain("0.00");
  });
});
