/**
 * Close Round panel — sign-off flow gated by dual-engine reconciliation.
 *
 * Steps:
 * 1. Run reconciliation → primary vs reference engines.
 * 2. If divergence: BLOCKING red card; close cannot proceed.
 * 3. If match: founder confirms → admin counter-signs → commit close transaction.
 * 4. After close: round is locked, ledger sealed, audit trail visible.
 */
import { useLayoutEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
 ShieldCheck, AlertTriangle, RefreshCw, GitCompareArrows, Stamp, Lock,
 CheckCircle2, ChevronRight,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
 runReconciliation, buildDemoComputeOpts, useSprint3, emit,
} from "@/lib/sprint3";
import { useRole } from "@/lib/role";
import { useEntitlement } from "@/lib/entitlement";
import { appendTransaction, type ReconciliationResult } from "@capavate/cap-table-engine";
import { apiRequest, queryClient, ApiError } from "@/lib/queryClient"; /* v25.20 Lane 4 — real server close */
/* WAVE 124 · FINDING 1 — the platform's OWN display library, not a new one.
   `partyReferenceLabel` (WAVE 115) turns a storage key into a labelled
   reference; `humanizeMachineKey` turns a machine key into a sentence. Both are
   reused here rather than re-derived, so the round-close screen cannot word this
   differently from the twelve partner tables wave 115 fixed. */
import { partyReferenceLabel, humanizeMachineKey } from "@/lib/partnerDisplay";
/* v26.65 U6 — the platform's timezone-safe date-only formatter (WAVE 87). */
import { fmtDate } from "@/lib/format";

type Props = {
 roundId: string;
 companyId?: string;
 roundName?: string;
 founderName?: string;
};

/* ============================================================
 * WAVE 22 · ITEM 1 (REVIEW B F-2) — NO FABRICATED AUDIT METADATA.
 *
 * THE DEFECT. This file used to carry two generators:
 *   • `fakeIp()`        → `"203.0.113." + Math.floor(Math.random() * 255)`
 *   • `identityHash()`  → a "demo-grade FNV" of `actor + "|" + ts`
 * Their output was written into the founder and admin round-close sign-offs,
 * into the `signoff.requested` / `signoff.granted` / `round.closed` telemetry
 * context, into the appended `round_close` ledger transaction, and — via
 * `setCloseState` → `mirrorSignoffToAuditLog` — into the durable server-side
 * audit log. An invented IP inside an evidence record is strictly worse than
 * an absent one: absent is honest, invented is a false statement that reads
 * as fact to anyone auditing the close.
 *
 * THE RULE APPLIED. Record the real value, or record an explicit
 * "not captured". Never synthesise, and never silently drop the field.
 *
 * WHAT IS ACTUALLY AVAILABLE HERE. A browser cannot observe its own public
 * address, and this component has no identity-attestation service to hash
 * against. Both values are therefore genuinely unavailable AT THIS POINT, so
 * both are persisted as `null` carrying a machine-readable reason
 * (`ipAddressUnavailableReason` / `identityHashUnavailableReason`), and the
 * UI renders "not captured" instead of a value.
 *
 * WHERE THE REAL IP NOW COMES FROM. The server stamps the address it actually
 * observed on the socket: `POST /api/admin/audit-log/append`
 * (`server/adminPlatformStore.ts`) overwrites any client-supplied `ipAddress`
 * with `serverObservedIp`, resolved through the same hardened trusted-hop
 * resolver as Wave 22 ITEM 2. The canonical close is likewise recorded
 * server-side by `POST /api/founder/rounds/:id/close`. The client no longer
 * claims to know something it cannot know.
 * ============================================================ */

/** Persisted in place of a value the client genuinely cannot observe. Never a
 *  synthesised stand-in; consumers must render it as "not captured". */
const AUDIT_VALUE_NOT_CAPTURED = null;

const IP_NOT_CAPTURED_REASON =
 "client-side capture unavailable: a browser cannot observe its own public address. " +
 "The server stamps the peer address it observed (serverObservedIp) on the durable audit record.";

const IDENTITY_HASH_NOT_CAPTURED_REASON =
 "no identity-attestation service is wired to this surface; a locally computed hash would attest to nothing.";

/** Display text for an audit field that was not captured. Used only for
 *  rendering — the persisted value stays `null`. */
function auditDisplay(value: string | null | undefined): string {
 return value == null || value === "" ? "not captured" : value;
}

/* ============================================================
 * v26.65 #7 — THE SERVER DECIDES WHETHER THE ROUND IS CLOSED.
 *
 * Previously the panel sealed the local ledger, set `closed:true` and emitted
 * `round.closed` (with a fabricated `finalAmount:"0"`) BEFORE the server call,
 * posted a hard-coded `finalCurrency:"USD"`, fire-and-forgot the request and
 * kept the local seal on failure. A failed pending preview also counted as
 * zero pending commitments.
 *
 * Now:
 *  · the POST carries only `{reason, lapsePending}`; the server records the
 *    round's own fixed currency;
 *  · single-flight (ref lock + disabled control) while closing or unknown;
 *  · the round is shown closed ONLY on a verified, round-bound, terminal
 *    durable receipt, or on the strict `close-state` read;
 *  · a 4xx is a definitive refusal; a 5xx / network failure / malformed body
 *    is an UNKNOWN outcome, reconciled by `GET close-state`, never retried
 *    automatically;
 *  · the close is enabled only when the pending preview really loaded;
 *  · the sign-offs stay as local preview acknowledgements and say so.
 * ============================================================ */
/* Same vocabulary as the server's strict terminal read (roundsStore
   STRICT_TERMINAL_STATES), which includes an existing `funded` round. This is
   READ vocabulary only; the panel never requests `funded` as a new close. */
const TERMINAL_CLOSE_STATES = new Set(["closed", "closed_funded", "closed_aborted", "funded"]);

/** Verified close proof, bound to the round, company and signed-in actor it
 *  was obtained for. `currency` null = the round has no recorded currency. */
type DurableClose = { roundId: string; companyId: string; actorId: string; closeState: string; closeDate: string | null; currency: string | null };
type CloseContext = { roundId: string; companyId: string; actorId: string };

/** A durable close-state object is accepted only when its terminal flag agrees
 *  with the terminal vocabulary, it is bound to this round and company, and
 *  its currency is a non-empty string or an explicit null. */
function durableCloseFrom(v: unknown, ctx: CloseContext): DurableClose | null {
 const d = v as { roundId?: unknown; companyId?: unknown; state?: unknown; terminal?: unknown; closeDate?: unknown; currency?: unknown } | null;
 if (!d || typeof d !== "object") return null;
 if (d.roundId !== ctx.roundId || d.companyId !== ctx.companyId) return null;
 if (typeof d.state !== "string" || !TERMINAL_CLOSE_STATES.has(d.state) || d.terminal !== true) return null;
 if (!(d.currency === null || (typeof d.currency === "string" && d.currency.length > 0))) return null;
 if (d.closeDate != null && typeof d.closeDate !== "string") return null;
 return {
 roundId: ctx.roundId, companyId: ctx.companyId, actorId: ctx.actorId,
 closeState: d.state, closeDate: (d.closeDate as string | null | undefined) ?? null, currency: d.currency as string | null,
 };
}

function closeStateLabel(s: string): string {
 if (s === "closed_funded") return "Closed, funded";
 if (s === "closed_aborted") return "Closed, aborted";
 if (s === "funded") return "Funded";
 return "Closed";
}

function closeCurrencyLabel(c: string | null): string {
 return c === null ? "currency not recorded" : c;
}

const CLOSE_REFUSAL_COPY: Record<string, string> = {
 NOT_ROUND_OWNER: "Only a founder of this round's company can close it.",
 ROUND_NOT_FOUND: "This round could not be found. It may have been removed.",
 INVALID_FINAL_STATE: "The closing state was not accepted.",
 FINAL_CURRENCY_MISMATCH: "The closing currency must be the round's own currency.",
 UNAUTHENTICATED: "Your session has ended. Sign in again, then retry.",
};

type CloseStateRead = { ok: true; terminal: boolean; durable: DurableClose | null };

/** Strict close-state read. The terminal flag must agree with the state:
 *  a contradictory body is unverified (thrown), never an "open" grant. */
async function readCloseState(ctx: CloseContext): Promise<CloseStateRead> {
 const res = await apiRequest("GET", `/api/founder/rounds/${encodeURIComponent(ctx.roundId)}/close-state`);
 const body = await res.json() as { ok?: unknown; roundId?: unknown; companyId?: unknown; terminal?: unknown; state?: unknown };
 if (body?.ok !== true || body.roundId !== ctx.roundId || typeof body.terminal !== "boolean" || typeof body.state !== "string") {
 throw new Error("close-state response could not be verified");
 }
 if (body.terminal !== TERMINAL_CLOSE_STATES.has(body.state)) throw new Error("close-state response is contradictory");
 if (!body.terminal) return { ok: true, terminal: false, durable: null };
 /* The GET reports the round's company through the bound round id; it must
    still agree with this panel's company when present. */
 const durable = durableCloseFrom({ companyId: ctx.companyId, ...body, terminal: true }, ctx);
 if (!durable) throw new Error("close-state response could not be verified");
 return { ok: true, terminal: true, durable };
}

type ClosePhase = "idle" | "closing" | "refused" | "unknown" | "verifying" | "not_closed";

/* v26.65 #7 U3 — the panel's close state is isolated per signed-in actor,
   company and round: a context change remounts the inner panel, so no proof,
   phase, acknowledgement or in-flight continuation crosses contexts. The actor
   comes from the authenticated session (useEntitlement), never the role chip. */
export default function CloseRoundPanel(props: Props) {
 const ent = useEntitlement();
 const actorId = ent.data?.isAuthed === true && typeof ent.data.userId === "string" && ent.data.userId.length > 0 ? ent.data.userId : null;
 const companyId = props.companyId ?? "co-acme";
 return (
 <CloseRoundPanelInner
 key={`${actorId ?? "no-session"}|${companyId}|${props.roundId}`}
 {...props}
 companyId={companyId}
 actorId={actorId}
 sessionLoading={ent.isLoading}
 />
 );
}

function CloseRoundPanelInner({ roundId, companyId = "co-acme", roundName = "this round", founderName = "Avi Barnes", actorId, sessionLoading }: Props & { actorId: string | null; sessionLoading: boolean }) {
 const { role } = useRole();
 const { toast } = useToast();
 const closeStates = useSprint3((s) => s.closeStates);
 const setCloseState = useSprint3((s) => s.setCloseState);
 const ledger = useSprint3((s) => s.ledger);
 const setLedger = useSprint3((s) => s.setLedger);

 const state = closeStates[roundId] ?? { roundId, closed: false };
 const [running, setRunning] = useState(false);
 const closeLock = useRef(false);
 /* Unmount guard. The inner panel is keyed by actor/company/round, so a
    context replacement unmounts this instance: no continuation started here
    may seal, append, emit, toast or set state afterwards. */
 const live = useRef(true);
 /* Pending demo-reconciliation timer; cleared on unmount/context replacement.
    Layout-effect cleanup runs synchronously in the commit that removes this
    instance (keyed replacement or unmount), so no stale continuation can run
    between that commit and a deferred passive-effect flush. */
 const reconTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
 useLayoutEffect(() => {
 live.current = true;
 return () => {
 live.current = false;
 if (reconTimer.current !== null) { clearTimeout(reconTimer.current); reconTimer.current = null; }
 };
 }, []);
 const mountedAt = useRef(Date.now());
 const ctx: CloseContext | null = actorId ? { roundId, companyId, actorId } : null;
 const [phase, setPhase] = useState<ClosePhase>("idle");
 const [refusal, setRefusal] = useState<string | null>(null);
 const [verified, setVerified] = useState<DurableClose | null>(null);
 /* v26.65 #7 — strict durable close state; never the cached round. Keyed by
    actor/company/round and always refetched on mount; only a successful read
    completed after this mount is proof. Cached data from an earlier mount or
    retained after a failed refetch is not. */
 const closeStateQuery = useQuery<CloseStateRead>({
   queryKey: [`/api/founder/rounds/${roundId}/close-state`, actorId, companyId],
   queryFn: () => readCloseState(ctx!),
   enabled: ctx !== null,
   staleTime: 0,
   refetchOnMount: "always",
   retry: false,
 });
 const freshRead = closeStateQuery.status === "success" && !closeStateQuery.isFetching &&
   closeStateQuery.dataUpdatedAt >= mountedAt.current ? closeStateQuery.data : undefined;
 const boundVerified = verified && ctx && verified.roundId === ctx.roundId && verified.companyId === ctx.companyId && verified.actorId === ctx.actorId ? verified : null;
 const serverClosed: DurableClose | null = boundVerified ?? freshRead?.durable ?? null;
 const isClosed = serverClosed !== null;
 // v25.48.2 Q13 — pending (un-confirmed) soft-circle commitments that a close
 // will lapse. Drives the pre-finalize warning + acknowledgement.
 const [ackLapse, setAckLapse] = useState(false);
 const pending = useQuery<{ ok: boolean; count: number; totalMinor: number }>({
   queryKey: [`/api/founder/rounds/${roundId}/pending-commitments`, actorId, companyId],
   queryFn: async () => (await apiRequest("GET", `/api/founder/rounds/${encodeURIComponent(roundId)}/pending-commitments`)).json(),
   enabled: !isClosed && ctx !== null,
   staleTime: 10_000,
 });
 /* v26.65 #7 — a failed or malformed preview is NOT zero pending commitments. */
 const pendingReady = pending.isSuccess && pending.data?.ok === true &&
   Number.isSafeInteger(pending.data?.count) && (pending.data?.count ?? -1) >= 0;
 const pendingCount = pendingReady ? (pending.data!.count) : 0;
 const closeBusy = phase === "closing" || phase === "verifying" || phase === "unknown";

 function runRecon() {
 if (reconTimer.current !== null || !live.current) return;
 setRunning(true);
 reconTimer.current = setTimeout(() => {
 reconTimer.current = null;
 /* The timer belongs to this actor/company/round instance only. */
 if (!live.current) return;
 const opts = buildDemoComputeOpts(companyId);
 const r = runReconciliation(opts, {
 actorId: role === "admin" ? "admin-platform" : "founder-avi",
 actorRole: role === "admin" ? "admin" : "founder",
 companyId,
 /* WAVE 22 · ITEM 1 — was `fakeIp()`. Undefined here means the telemetry
    context carries no address at all rather than an invented one; the
    durable record's address is stamped server-side. */
 ipAddress: undefined,
 });
 setCloseState({ ...state, reconciliation: r });
 setRunning(false);
 toast({
 title: r.status === "match" ? "Reconciliation match" : "Reconciliation divergence",
 description: r.status === "match"
 ? `Both engines agree. ${r.runDurationMs}ms · ${r.formulaIdsUsed.length} formulas.`
 : `${r.diffs.length} diffs detected. Round close is BLOCKED.`,
 });
 }, 200);
 }

 function founderSign() {
 const ts = new Date().toISOString();
 const sig = {
 actorId: "founder-avi",
 actorName: founderName,
 actorRole: "founder" as const,
 ts,
 /* WAVE 22 · ITEM 1 — explicit not-captured, never a synthesised address. */
 ipAddress: AUDIT_VALUE_NOT_CAPTURED,
 ipAddressUnavailableReason: IP_NOT_CAPTURED_REASON,
 identityHash: AUDIT_VALUE_NOT_CAPTURED,
 identityHashUnavailableReason: IDENTITY_HASH_NOT_CAPTURED_REASON,
 };
 setCloseState({ ...state, founderSignoff: sig });
 emit({ type: "signoff.requested", payload: { signoffId: `so-${roundId}-f`, roundId, signerRole: "founder" } }, { companyId, roundId, actorId: "founder-avi", actorRole: "founder", ipAddress: sig.ipAddress ?? undefined });
 emit({ type: "signoff.granted", payload: { signoffId: `so-${roundId}-f`, roundId, signerRole: "founder", identityHash: sig.identityHash } }, { companyId, roundId, actorId: "founder-avi", actorRole: "founder", ipAddress: sig.ipAddress ?? undefined });
 toast({ title: "Founder sign-off captured", description: `Identity ${auditDisplay(sig.identityHash)} · ${new Date(sig.ts).toLocaleTimeString()}` });
 }

 function adminSign() {
 const ts = new Date().toISOString();
 const sig = {
 actorId: "admin-platform",
 actorName: "Capavate Admin",
 actorRole: "admin" as const,
 ts,
 /* WAVE 22 · ITEM 1 — explicit not-captured, never a synthesised address. */
 ipAddress: AUDIT_VALUE_NOT_CAPTURED,
 ipAddressUnavailableReason: IP_NOT_CAPTURED_REASON,
 identityHash: AUDIT_VALUE_NOT_CAPTURED,
 identityHashUnavailableReason: IDENTITY_HASH_NOT_CAPTURED_REASON,
 };
 setCloseState({ ...state, adminSignoff: sig });
 emit({ type: "signoff.requested", payload: { signoffId: `so-${roundId}-a`, roundId, signerRole: "admin" } }, { companyId, roundId, actorId: "admin-platform", actorRole: "admin", ipAddress: sig.ipAddress ?? undefined });
 emit({ type: "signoff.granted", payload: { signoffId: `so-${roundId}-a`, roundId, signerRole: "admin", identityHash: sig.identityHash } }, { companyId, roundId, actorId: "admin-platform", actorRole: "admin", ipAddress: sig.ipAddress ?? undefined });
 toast({ title: "Admin counter-signature captured", description: `Identity ${auditDisplay(sig.identityHash)}` });
 }

 /* v26.65 #7 — local effects run ONLY after the server close is verified. */
 function sealVerified(durable: DurableClose, alreadyClosed: boolean) {
 if (!live.current) return;
 setVerified(durable);
 setPhase("idle");
 setRefusal(null);
 queryClient.invalidateQueries({ queryKey: ["/api/rounds"] });
 queryClient.invalidateQueries({ queryKey: [`/api/founder/rounds/${roundId}/pending-commitments`] });
 queryClient.invalidateQueries({ queryKey: [`/api/founder/rounds/${roundId}/close-state`] });
 if (alreadyClosed) {
 toast({ title: "Round already closed", description: "The server had already recorded this round as closed. Nothing was changed." });
 return;
 }
 const r = state.reconciliation;
 const founder = state.founderSignoff;
 const admin = state.adminSignoff;
 if (r && founder && admin) appendLocalClose(r, founder, admin, durable);
 /* v26.65 U6 — the server confirms terminal state/currency but does not report
    when the close was performed. rounds.close_date is the round's recorded
    (possibly scheduled, future) close date, retained by the strict close, so it
    is not an execution time; a browser clock is not one either. The optional
    closedAt is therefore omitted (and any stale value cleared) rather than
    guessed. The durable round.closed audit record carries the server time. */
 const { closedAt: _unknownExecutionTime, ...priorCloseState } = state;
 setCloseState({ ...priorCloseState, closed: true });
 toast({ title: "Round closed", description: "The server recorded the close in the round's own currency. Audit trail in /admin/audit-log." });
 }

 async function reconcileUnknown() {
 if (!live.current || !ctx) return;
 setPhase("verifying");
 try {
 const read = await readCloseState(ctx);
 if (!live.current) return;
 if (read.terminal && read.durable) { sealVerified(read.durable, false); return; }
 setPhase("not_closed");
 toast({ title: "Round not closed", description: "The server shows this round is still open. You can try closing it again." });
 } catch {
 if (!live.current) return;
 setPhase("unknown");
 toast({ title: "Close outcome unknown", description: "The close could not be confirmed. Verify again before taking any other action.", variant: "destructive" });
 }
 }

 async function commitClose() {
 if (closeLock.current || closeBusy || isClosed || !ctx) return;
 if (!state.reconciliation || !state.founderSignoff || !state.adminSignoff) return;
 if (!pendingReady || (pendingCount > 0 && !ackLapse)) return;
 closeLock.current = true;
 setPhase("closing");
 setRefusal(null);
 try {
 let body: { ok?: unknown; alreadyClosed?: unknown; round?: { id?: unknown } | null; durable?: unknown } | null = null;
 try {
 const res = await apiRequest("POST", `/api/founder/rounds/${encodeURIComponent(roundId)}/close`, {
 reason: "manual_close",
 // v25.48.2 Q13 — founder acknowledged the warning; lapse un-confirmed
 // commitments server-side (confirmed/wired/committed are preserved).
 lapsePending: pendingCount > 0,
 });
 body = await res.json();
 } catch (err) {
 if (!live.current) return;
 if (err instanceof ApiError && err.status >= 400 && err.status < 500) {
 const code = (err.payload as { error?: unknown } | null)?.error;
 const copy = (typeof code === "string" && CLOSE_REFUSAL_COPY[code]) || "The server refused to close this round. Nothing was changed.";
 setRefusal(copy);
 setPhase("refused");
 toast({ title: "Round not closed", description: copy, variant: "destructive" });
 return;
 }
 await reconcileUnknown();
 return;
 }
 if (!live.current) return;
 const durable = body?.ok === true && body.round?.id === roundId ? durableCloseFrom(body.durable, ctx) : null;
 if (durable && typeof body?.alreadyClosed === "boolean") { sealVerified(durable, body.alreadyClosed); return; }
 await reconcileUnknown();
 } finally {
 closeLock.current = false;
 }
 }

 function appendLocalClose(
 r: NonNullable<typeof state.reconciliation>,
 founder: NonNullable<typeof state.founderSignoff>,
 admin: NonNullable<typeof state.adminSignoff>,
 durable: DurableClose,
 ) {
 // Append immutable close entry to the ledger
 const newLedger = appendTransaction(ledger, {
 id: `close-${roundId}-${Date.now()}`,
 companyId,
 type: "round_close",
 instrumentRef: null,
 /* v26.65 U6 — required local ledger timestamp: the actual LOCAL ENTRY
    CREATION time in this browser, NOT the server execution time of the close.
    The round's recorded close date can be a scheduled future date and is never
    used as this entry's timestamp. */
 timestamp: new Date().toISOString(),
 actorId: admin.actorId,
 actorRole: "admin",
 /* WAVE 22 · ITEM 1 — the field is KEPT (not silently dropped) and carries
    an explicit null; the reason lives on the sign-off record below. */
 ipAddress: admin.ipAddress ?? undefined,
 idempotencyKey: `close-${roundId}`,
 payload: {
 type: "round_close",
 data: {
 roundId,
 primaryHash: r.primaryHash,
 referenceHash: r.referenceHash,
 founderSignoff: { actorId: founder.actorId, ts: founder.ts, ipAddress: founder.ipAddress, identityHash: founder.identityHash, ipAddressUnavailableReason: founder.ipAddressUnavailableReason, identityHashUnavailableReason: founder.identityHashUnavailableReason },
 adminSignoff: { actorId: admin.actorId, ts: admin.ts, ipAddress: admin.ipAddress, identityHash: admin.identityHash, ipAddressUnavailableReason: admin.ipAddressUnavailableReason, identityHashUnavailableReason: admin.identityHashUnavailableReason },
 },
 },
 });
 setLedger(newLedger);
 /* Telemetry for the verified close. The final amount is not known to this
    panel, so it is left absent rather than fabricated as "0". */
 emit({ type: "round.closed", payload: { roundId, primaryHash: r.primaryHash, referenceHash: r.referenceHash } }, { companyId, roundId, actorId: admin.actorId, actorRole: "admin", ipAddress: admin.ipAddress ?? undefined });
 emit({ type: "cap_table.mutated", payload: { beforeHash: r.referenceHash, afterHash: r.primaryHash, reason: `round close: ${roundId}` } }, { companyId, roundId, actorId: admin.actorId, actorRole: "admin" });
 }

 return (
 <div className="space-y-4" data-testid="panel-close-round">
 {/* Step 1 — reconciliation */}
 <Card>
 <CardHeader className="pb-3">
 <CardTitle className="text-base flex items-center gap-2"><GitCompareArrows className="h-4 w-4 text-[hsl(0_100%_40%)]" />Step 1 — Run reconciliation</CardTitle>
 </CardHeader>
 <CardContent>
 <p className="text-sm text-muted-foreground mb-3">Compute the projected post-close cap table with both the primary engine (decimal.js) and the independent reference engine (BigInt scaled fixed-point). They must agree to the share / cent for the round to close.</p>
 <p className="text-xs text-muted-foreground mb-3" data-testid="close-recon-preview-note">This check runs in your browser on preview data. It does not read the server ledger.</p>
 <div className="flex items-center gap-2 mb-3">
 <Button onClick={runRecon} disabled={running || isClosed || closeBusy} className="bg-[hsl(0_100%_40%)] hover:bg-[hsl(0_100%_32%)] text-white" data-testid="button-run-recon">
 <RefreshCw className={`h-4 w-4 mr-2 ${running ? "animate-spin" : ""}`} />
 {state.reconciliation ? "Re-run reconciliation" : "Run reconciliation"}
 </Button>
 {state.reconciliation && (
 state.reconciliation.status === "match"
 ? <Badge className="bg-emerald-100 text-emerald-900 border-0"><ShieldCheck className="h-3 w-3 mr-1" />Match · {state.reconciliation.runDurationMs}ms</Badge>
 : <Badge className="bg-rose-100 text-rose-900 border-0"><AlertTriangle className="h-3 w-3 mr-1" />Divergence · {state.reconciliation.diffs.length} diffs</Badge>
 )}
 </div>

 {state.reconciliation && (
 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
 <HashCard label="Primary engine" hash={state.reconciliation.primaryHash} total={state.reconciliation.primaryTotal} />
 <HashCard label="Reference engine" hash={state.reconciliation.referenceHash} total={state.reconciliation.referenceTotal} />
 </div>
 )}
 </CardContent>
 </Card>

 {/* Block if divergence */}
 {state.reconciliation?.status === "divergence" && (
 <Card className="border-rose-300 bg-rose-50 ">
 <CardContent className="py-4">
 <div className="flex items-start gap-3">
 <AlertTriangle className="h-5 w-5 text-rose-700 flex-shrink-0 mt-0.5" />
 <div>
 <div className="font-semibold text-rose-900 ">Round close blocked — divergence detected</div>
 <p className="text-sm text-rose-800 mt-1">
 The primary and reference engines disagree on the projected cap table. <strong>You cannot close this round until the divergence is resolved.</strong>
 Contact your platform admin and share the diff details below.
 </p>
 <div className="mt-3 bg-card border border-rose-300 rounded p-2 text-xs">
 <table className="w-full">
 <thead><tr className="text-muted-foreground"><th className="text-left py-1">Holder</th><th className="text-left py-1">Kind</th><th className="text-right py-1">Primary</th><th className="text-right py-1">Reference</th><th className="text-right py-1">Δ</th></tr></thead>
 <tbody>
 {state.reconciliation.diffs.map((d) => (
 <tr key={d.key} className="border-t border-rose-200 ">
 {/* WAVE 124 · FINDING 1 — THE SCREEN THAT GATES A ROUND CLOSE NO LONGER
     PRINTS A DATABASE KEY UNDER A COLUMN HEADED "Holder".
     This table read `co_…` / `u_…` in the Holder cell and `unit`-style
     machine keys in the Kind cell, on the blocking card a founder is told to
     forward to his platform admin. `HolderDiff`
     (packages/cap-table-engine/src/reconcile/reconcile.ts:34-45) carries NO
     name field, so there is no name to print and NOTHING IS FABRICATED: the
     id is presented as what it is, a labelled reference, via wave 115's
     helper. The reference stays unique wherever the id was unique, so two
     diverging holders are still told apart and support can still read the
     value aloud. The row `key` above is untouched: that is machine-readable.
     The element shape is unchanged — one `td` per column, no sibling added or
     removed — so the silent-drop guard's positional child identity holds. */}
 <td className="py-1">{partyReferenceLabel(d.holderId)}</td>
 <td className="py-1">{humanizeMachineKey(d.kind)}</td>
 <td className="py-1 text-right font-mono">{d.primaryShares}</td>
 <td className="py-1 text-right font-mono">{d.referenceShares}</td>
 <td className="py-1 text-right font-mono text-rose-700">{d.shareDelta}</td>
 </tr>
 ))}
 </tbody>
 </table>
 </div>
 </div>
 </div>
 </CardContent>
 </Card>
 )}

 {/* Step 2 — sign-offs (only when match) */}
 {state.reconciliation?.status === "match" && !isClosed && (
 <Card>
 <CardHeader className="pb-3">
 <CardTitle className="text-base flex items-center gap-2"><Stamp className="h-4 w-4 text-[hsl(0_100%_40%)]" />Step 2 — Sign-offs</CardTitle>
 </CardHeader>
 <CardContent>
 <p className="text-xs text-muted-foreground mb-3" data-testid="close-signoff-preview-note">These sign-offs are local preview acknowledgements. They are not server-authenticated approvals; the server records the close under your signed-in account.</p>
 <SignoffRow label={`I, ${founderName}, confirm the projected post-close cap table is correct.`}
 role="founder" sig={state.founderSignoff} onSign={founderSign} canSign={role !== "investor"}
 testid="signoff-founder" />
 <SignoffRow label="Capavate platform admin counter-signature (local preview acknowledgement)"
 role="admin" sig={state.adminSignoff} onSign={adminSign} canSign={role === "admin"}
 hint={role === "admin" ? undefined : "Switch to admin role chip on landing to counter-sign (preview only, not a server-authenticated approval)."}
 testid="signoff-admin" />
 </CardContent>
 </Card>
 )}

 {/* v25.48.2 Q13 — pending-commitment warning (shown before finalize when any
     un-confirmed soft-circle exists). Confirmed/wired/committed are preserved. */}
 {state.reconciliation?.status === "match" && state.founderSignoff && state.adminSignoff && !isClosed && (pending.isError || (pending.isSuccess && !pendingReady)) && (
 <Card className="border-amber-300 bg-amber-50" data-testid="close-pending-unavailable">
 <CardContent className="py-4 flex items-start gap-3">
 <AlertTriangle className="h-5 w-5 text-amber-700 flex-shrink-0 mt-0.5" />
 <div className="flex-1">
 <div className="font-semibold text-amber-900">Pending commitments could not be checked</div>
 <p className="text-sm text-amber-800 mt-1">The round cannot be closed until Capavate can show which pending commitments a close would lapse.</p>
 <Button size="sm" variant="outline" className="mt-3" onClick={() => void pending.refetch()} data-testid="button-retry-pending">Retry</Button>
 </div>
 </CardContent>
 </Card>
 )}

 {state.reconciliation?.status === "match" && state.founderSignoff && state.adminSignoff && !isClosed && pendingReady && pendingCount > 0 && (
 <Card className="border-amber-300 bg-amber-50" data-testid="close-pending-warning">
 <CardContent className="py-4">
 <div className="flex items-start gap-3">
 <AlertTriangle className="h-5 w-5 text-amber-700 flex-shrink-0 mt-0.5" />
 <div className="flex-1">
 <div className="font-semibold text-amber-900">
 {pendingCount} pending commitment{pendingCount === 1 ? "" : "s"} will be closed out and marked lapsed
 </div>
 <p className="text-sm text-amber-800 mt-1">
 These are un-confirmed / open soft-circles. Closing the round will mark them
 <strong> lapsed</strong> (not funded) with an audit-trail entry. Confirmed, wired, and
 committed commitments are <strong>not</strong> affected.
 </p>
 <label className="flex items-center gap-2 mt-3 text-sm text-amber-900 cursor-pointer">
 <input
 type="checkbox"
 checked={ackLapse}
 onChange={(e) => setAckLapse(e.target.checked)}
 data-testid="checkbox-ack-lapse"
 />
 I understand these {pendingCount} pending commitment{pendingCount === 1 ? "" : "s"} will be lapsed.
 </label>
 </div>
 </div>
 </CardContent>
 </Card>
 )}

 {/* Step 3 — commit close */}
 {state.reconciliation?.status === "match" && state.founderSignoff && state.adminSignoff && !isClosed && (
 <Card className="border-[hsl(0_100%_40%)] bg-[hsl(0_100%_40%)]/5">
 <CardContent className="py-4 flex items-center gap-3">
 {/* WAVE 101 - this card renders ONLY when reconciliation matched and both
   sign-offs are captured, i.e. an unambiguously good state, yet the check
   glyph was the negative anchor.  The card border and the CTA stay brand
   red (brand chrome, R80/Wave-99 Q4); only the glyph moves. */}
            <CheckCircle2 className="h-5 w-5 text-emerald-700" />
 <div className="flex-1">
 <div className="font-semibold">All sign-offs captured</div>
 <p className="text-sm text-muted-foreground">Click <strong>Close round</strong> to write the closing to the ledger permanently.</p>
 </div>
 <Button onClick={() => void commitClose()} disabled={!ctx || closeBusy || !pendingReady || (pendingCount > 0 && !ackLapse)} className="bg-[hsl(0_100%_40%)] hover:bg-[hsl(0_100%_32%)] text-white" data-testid="button-commit-close">
 {phase === "closing" ? "Closing…" : "Close round"} <ChevronRight className="h-4 w-4 ml-1" />
 </Button>
 </CardContent>
 {refusal && phase === "refused" && (
 <CardContent className="pt-0 pb-4"><p role="alert" className="text-sm text-rose-800" data-testid="close-refused">Round not closed. {refusal}</p></CardContent>
 )}
 {phase === "not_closed" && (
 <CardContent className="pt-0 pb-4"><p role="status" className="text-sm" data-testid="close-not-closed">Round not closed. The server shows it is still open; you can try again.</p></CardContent>
 )}
 {(phase === "unknown" || phase === "verifying") && (
 <CardContent className="pt-0 pb-4 flex items-center gap-3">
 <p role="status" className="text-sm flex-1" data-testid="close-outcome-unknown">Close outcome unknown. The server response could not be confirmed; closing stays disabled until the round's state is verified.</p>
 <Button size="sm" variant="outline" disabled={phase === "verifying"} onClick={() => void reconcileUnknown()} data-testid="button-verify-close">{phase === "verifying" ? "Verifying…" : "Verify again"}</Button>
 </CardContent>
 )}
 </Card>
 )}

 {!ctx && !sessionLoading && (
 <p role="status" className="text-xs text-muted-foreground" data-testid="close-session-unavailable">Your signed-in session could not be confirmed, so this round cannot be closed from here.</p>
 )}

 {!isClosed && closeStateQuery.isError && (
 <p role="status" className="text-xs text-muted-foreground" data-testid="close-state-unavailable">The round's recorded close state could not be read. It is not shown as closed.</p>
 )}

 {serverClosed && (
 <Card className="border-emerald-300 bg-emerald-50 ">
 <CardContent className="py-5 flex items-start gap-3">
 <Lock className="h-5 w-5 text-emerald-700 mt-0.5" />
 <div>
 <div className="font-semibold text-emerald-900 " data-testid="close-server-closed">Round closed and sealed</div>
 <p className="text-sm text-emerald-800 mt-1">
 The server recorded this round as {closeStateLabel(serverClosed.closeState).toLowerCase()}, in {closeCurrencyLabel(serverClosed.currency)}.
 {" "}Recorded close date: <span data-testid="close-recorded-close-date">{serverClosed.closeDate ? fmtDate(serverClosed.closeDate) : "not recorded"}</span>.
 {" "}<span data-testid="close-execution-time-note">This is the round's stored close date, which can be a scheduled date; the time the close was performed is not shown here.</span>{" "}
 Founder close recorded under the signed-in founder account; any sign-offs on this screen were local preview acknowledgements.
 Audit trail in <span className="font-mono text-xs">/admin/audit-log</span>.
 </p>
 {/* WAVE 22 · ITEM 1 — sibling paragraph (never text appended into the node
     above). States plainly why the client-side evidence fields are empty, so a
     "not captured" is never mistaken for a lost value. */}
 <p className="text-xs text-emerald-800/80 mt-2" data-testid="close-audit-capture-note">
 Client-side IP and identity hash are recorded as <strong>not captured</strong>: a browser cannot observe its own
 public address and no identity-attestation service is wired to this surface. The address the server actually
 observed is stamped on the durable audit record.
 </p>
 </div>
 </CardContent>
 </Card>
 )}
 </div>
 );
}

function HashCard({ label, hash, total }: { label: string; hash: string; total: string }) {
 return (
 <div className="rounded-md border border-border bg-card p-3">
 <div className="text-[10px] uppercase text-muted-foreground mb-1">{label}</div>
 <div className="text-muted-foreground text-[10px]">Total shares</div>
 <div className="font-mono tabular-nums text-sm font-semibold mb-1.5">{Number(total).toLocaleString()}</div>
 <div className="text-muted-foreground text-[10px]">Hash</div>
 <div className="font-mono text-[9px] break-all leading-snug">{hash}</div>
 </div>
 );
}

function SignoffRow({ label, role, sig, onSign, canSign, hint, testid }: {
 label: string;
 role: "founder" | "admin";
 /* WAVE 22 · ITEM 1 — both evidence fields are nullable: `null` means "not
    captured", carried with a machine-readable reason. */
 sig?: {
 actorName: string;
 ts: string;
 ipAddress?: string | null;
 ipAddressUnavailableReason?: string;
 identityHash: string | null;
 identityHashUnavailableReason?: string;
 };
 onSign: () => void;
 canSign: boolean;
 hint?: string;
 testid: string;
}) {
 return (
 <div className="border-b border-border/60 py-3 last:border-b-0 last:pb-0 first:pt-0">
 <div className="flex items-start gap-3">
 <div className="flex-1">
 <div className="text-sm font-medium">{label}</div>
 {sig ? (
 <div className="text-xs text-muted-foreground mt-1">
 Signed by <strong className="text-foreground">{sig.actorName}</strong> at {new Date(sig.ts).toLocaleString()}
 {sig.ipAddress && <span> · IP <span className="font-mono">{sig.ipAddress}</span></span>}
 {/* WAVE 22 · ITEM 1 — SIBLING element, deliberately not text appended inside
     the node above (that reads to the silent-drop guard as a removal plus an
     addition). Renders the explicit not-captured state instead of a
     synthesised address; `title` carries the documented reason. */}
 {!sig.ipAddress && (
 <span data-testid={`${testid}-ip-not-captured`} title={sig.ipAddressUnavailableReason}> · IP <span className="font-mono">{auditDisplay(sig.ipAddress)}</span></span>
 )}
 <span> · identity <span className="font-mono" title={sig.identityHash ? undefined : sig.identityHashUnavailableReason}>{auditDisplay(sig.identityHash)}</span></span>
 </div>
 ) : hint ? (
 <div className="text-xs text-muted-foreground italic mt-1">{hint}</div>
 ) : (
 <div className="text-xs text-muted-foreground mt-1">Awaiting {role} sign-off…</div>
 )}
 </div>
 {sig
 ? <Badge className="bg-emerald-100 text-emerald-900 border-0"><CheckCircle2 className="h-3 w-3 mr-1" />Signed</Badge>
 : <Button size="sm" disabled={!canSign} onClick={onSign} data-testid={`button-${testid}`}>{role === "founder" ? "I confirm" : "Counter-sign"}</Button>}
 </div>
 </div>
 );
}
