/**
 * v19 Wave A / Change 4 — PersonaSwitcher dropdown.
 *
 * Replaces the binary CapCollectiveToggle button with a 4-persona dropdown:
 *   • Capavate (founder app)            → /founder/dashboard
 *   • Collective (investor app)         → /collective
 *   • Consortium Partner (partner app)  → /collective/partner/dashboard
 *   • Admin (admin console)             → /admin/dashboard
 *
 * Behavior:
 *   • Visibility uses the same predicate as CapCollectiveToggle
 *     (`shouldShowToggleFromCtx`). When hidden, renders a probe span for tests.
 *   • Selection persists to localStorage (key: `capavate.persona`) when
 *     available — sandbox-safe: falls back to in-memory if Storage throws.
 *   • Shows a "Demo" badge when VITE_ENABLE_DEMO_SEED === "1".
 *   • URL pattern: `?portal={founder|investor|admin|collective|partner}` is
 *     appended on navigation, matching the v19 spec.
 *   • Persona items that the user is NOT entitled to (e.g. non-admin viewing
 *     the Admin option) are rendered as disabled.
 *
 * NOTE: This file does NOT remove the legacy `CapCollectiveToggle` export —
 * the pure-function visibility predicates (`shouldShowToggle`,
 * `shouldShowToggleFromCtx`) are still imported by sprint12 / sprint15 tests.
 * AppShell renders `<CapCollectiveToggle />` which (post-Change-4) delegates
 * to this PersonaSwitcher.
 */
import { useEffect, useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ChevronDown, Sparkles, Building2, ShieldCheck, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useEntitlement, type UserContext } from "@/lib/entitlement";
import { shouldShowToggleFromCtx } from "./CapCollectiveToggle";

/**
 * v19 Wave A — Persona identifiers.
 *
 * `capavate` = founder app, `collective` = investor surface, `partner` =
 * consortium partner workspace, `admin` = admin console. The `portal` query
 * param uses these short keys (plus `investor` as a synonym for backward
 * compat with /investor/* routes).
 */
export type Persona = "capavate" | "collective" | "partner" | "admin";

interface PersonaDef {
  id: Persona;
  label: string;
  portalKey: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}

export const PERSONA_OPTIONS: readonly PersonaDef[] = [
  {
    id: "capavate",
    // W-V44 FIX A: disambiguate the multi-role switcher. This persona IS the
    // founder app (href=/founder/dashboard) and is only offered when the account
    // owns >=1 company; label it "Capavate (Founder)" so a dual-role user
    // (investor + founder) knows "Switch to Capavate" opens their FOUNDER
    // workspace, not a generic surface. No behavior change — label only.
    label: "Capavate (Founder)",
    portalKey: "founder",
    href: "/founder/dashboard",
    icon: Building2,
    description: "Founder workspace — cap table, rounds, dataroom.",
  },
  {
    id: "collective",
    label: "Collective",
    portalKey: "collective",
    href: "/collective",
    icon: Sparkles,
    description: "Investor / Collective member surface.",
  },
  {
    id: "partner",
    label: "Consortium Partner",
    portalKey: "partner",
    href: "/collective/partner/dashboard",
    icon: Briefcase,
    description: "Angel network / consortium partner workspace.",
  },
  {
    id: "admin",
    label: "Admin",
    portalKey: "admin",
    href: "/admin/dashboard",
    icon: ShieldCheck,
    description: "Platform admin console.",
  },
] as const;

const PERSONA_STORAGE_KEY = "capavate.persona";

// In-memory fallback when localStorage is unavailable (sandbox / SSR).
let inMemoryPersona: Persona | null = null;

/** Safe localStorage getter. Falls back to module-scoped variable. */
function readStoredPersona(): Persona | null {
  try {
    if (typeof window !== "undefined" && window.localStorage) {
      const v = window.localStorage.getItem(PERSONA_STORAGE_KEY);
      if (v === "capavate" || v === "collective" || v === "partner" || v === "admin") return v;
    }
  } catch {
    /* localStorage may throw in private mode */
  }
  return inMemoryPersona;
}

/** Safe localStorage setter. */
function writeStoredPersona(p: Persona): void {
  inMemoryPersona = p;
  try {
    if (typeof window !== "undefined" && window.localStorage) {
      window.localStorage.setItem(PERSONA_STORAGE_KEY, p);
    }
  } catch {
    /* swallow — in-memory fallback already updated */
  }
}

/**
 * Pure helper — determines which personas a given UserContext can access.
 *
 * Exported for unit-test parity with `shouldShowToggleFromCtx`.
 *
 * v23.4.7 Phase 7 / BUG 002 fix — strictly gate every persona by membership
 * predicates from UserContext so the role/persona dropdown NEVER shows an
 * option the user is not actually a member of:
 *   - Capavate   → `founder.companies.length > 0`  OR  `isAdmin`
 *   - Collective → `investor.state !== "NONE"`     OR  founder of an
 *                  active Collective company       OR  `isAdmin`
 *   - Partner    → `isAdmin` OR an active partner-team membership
 *   - Admin      → `isAdmin`
 *
 * v25.23 NH-Q2 — partner gating was previously gated on `ctx.isAdmin` ONLY,
 * which (a) hid the Partner option from legitimate non-admin consortium
 * partners and (b) showed it to admins with zero partner membership. We now
 * accept a DB-backed partner-team membership signal (`ctx.partner`, sourced
 * from a successful `GET /api/partner/me`) as a parallel sufficient condition.
 * The flag is OPTIONAL on UserContext so callers that don't populate it keep
 * the prior admin-only behavior.
 */
export function entitledPersonas(ctx: UserContext | null | undefined): Set<Persona> {
  const out = new Set<Persona>();
  if (!ctx) return out;
  // Capavate (founder) — must actually be a founder of at least one company.
  if (ctx.founder?.companies?.length && ctx.founder.companies.length > 0) {
    out.add("capavate");
  }
  // Collective — visible if the user has any investor state OR is a founder
  // of an active Collective company (the shouldShowToggleFromCtx path). This
  // closes BUG 002: founder users with no investor state never see Collective
  // unless they belong to a Collective-active company.
  const hasInvestorState =
    !!ctx.investor && typeof ctx.investor.state === "string" && ctx.investor.state !== "NONE";
  if (hasInvestorState) out.add("collective");
  if (shouldShowToggleFromCtx(ctx).visible) out.add("collective");
  // v25.52 Track 0.2 — CONSISTENCY with the Login Track 0.3 chooser. The chooser
  // qualifies the Collective workspace on `collective.status === "active"` ALONE
  // (an active membership IS a workspace, matching RequireActiveCollective /
  // entitlement.tsx:139 which gates access purely on status==="active"). The two
  // predicates above additionally require investor-state or a company/cap-table
  // position, so a PURE active Collective member (no company, not on any cap
  // table — e.g. an approved investor-member) would be offered Collective at
  // login but then NOT see it in the top-bar switcher — exactly the mis-redirect
  // class Track 0 exists to kill. This addition is purely ADDITIVE (only ever
  // ADDS "collective"; never removes an option) and uses the same authoritative
  // `active` signal, so it introduces no new exposure beyond what the chooser +
  // access gate already permit. Non-active states (none/applied/pending/
  // suspended/lapsed) are intentionally still excluded.
  if (ctx.collective && ctx.collective.status === "active") out.add("collective");
  // Partner — v25.23 NH-Q2: admin OR a real partner-team membership. The
  // `partner` field is DB-backed (GET /api/partner/me) and merged onto the
  // context by PersonaSwitcher; non-admin partners now see the option, and
  // membership — not just the admin flag — is a sufficient condition.
  const hasPartnerMembership =
    !!ctx.partner && typeof ctx.partner.partnerId === "string" && ctx.partner.partnerId.length > 0;
  if (ctx.isAdmin || hasPartnerMembership) out.add("partner");
  // Admin — explicit flag only.
  if (ctx.isAdmin) out.add("admin");
  // Always expose capavate to admins (gives them a way back to founder UI).
  if (ctx.isAdmin) out.add("capavate");
  return out;
}

/** Returns true if VITE_ENABLE_DEMO_SEED === "1" (matches existing lib/entitlement.tsx). */
function isDemoMode(): boolean {
  try {
    const env = (import.meta as { env?: { MODE?: string; VITE_ENABLE_DEMO_SEED?: string } }).env;
    return env?.VITE_ENABLE_DEMO_SEED === "1";
  } catch {
    return false;
  }
}

/** Detects current persona from the URL path (best-effort). */
function detectCurrentPersona(pathname: string): Persona {
  if (pathname.startsWith("/admin")) return "admin";
  if (pathname.startsWith("/collective/partner")) return "partner";
  if (pathname.startsWith("/collective")) return "collective";
  if (pathname.startsWith("/investor")) return "collective";
  return "capavate";
}

/** Appends `?portal=<key>` to a path, preserving any existing query string. */
function withPortalParam(href: string, portalKey: string): string {
  const sep = href.includes("?") ? "&" : "?";
  return `${href}${sep}portal=${portalKey}`;
}

export interface PersonaSwitcherProps {
  /** Optional override for the entitlement context — used in tests. */
  ctxOverride?: UserContext | null;
  /** Suppress the demo badge regardless of env. Default false. */
  hideDemoBadge?: boolean;
}

export function PersonaSwitcher({ ctxOverride, hideDemoBadge }: PersonaSwitcherProps = {}) {
  const [location, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { data: liveCtx } = useEntitlement();
  const baseCtx = ctxOverride !== undefined ? ctxOverride : (liveCtx ?? null);

  // v25.23 NH-Q2 / v25.24 NH-2 — read the DB-backed partner-team membership
  // directly from the shared React Query cache. Two keys exist:
  //   ["/api/partner/me"]            — populated by `useRequirePartnerRole`
  //                                    which mounts only on /partner/* pages.
  //   ["/api/partner/me", "soft"]    — populated by `usePartnerMembership`
  //                                    which mounts on the Collective shell
  //                                    (CollectiveShell.tsx:136).
  //
  // v25.23 NH-Q2 only probed the FIRST key, so a non-admin partner browsing
  // Collective never saw the Partner option (the exact first-pass bug). v25.24
  // now probes BOTH keys, taking whichever has populated data first.
  const partnerMeHard = queryClient.getQueryData<{ partnerId?: string; subRole?: string | null }>([
    "/api/partner/me",
  ]);
  const partnerMeSoft = queryClient.getQueryData<{ partnerId?: string; subRole?: string | null }>([
    "/api/partner/me",
    "soft",
  ]);
  const partnerMe =
    partnerMeHard && typeof partnerMeHard.partnerId === "string"
      ? partnerMeHard
      : partnerMeSoft && typeof partnerMeSoft.partnerId === "string"
      ? partnerMeSoft
      : undefined;
  const ctx =
    ctxOverride === undefined && baseCtx && partnerMe && typeof partnerMe.partnerId === "string"
      ? { ...baseCtx, partner: { partnerId: partnerMe.partnerId, subRole: partnerMe.subRole ?? null } }
      : baseCtx;

  const { visible, reason } = useMemo(
    () => shouldShowToggleFromCtx(ctx ?? null),
    [ctx]
  );

  const entitled = useMemo(() => entitledPersonas(ctx), [ctx]);
  const currentPersona = detectCurrentPersona(location);

  // Initialize selected persona from URL or stored value.
  const [selected, setSelected] = useState<Persona>(() => readStoredPersona() ?? currentPersona);

  // Keep selection in sync with URL changes (so URL is the source of truth).
  useEffect(() => {
    setSelected(currentPersona);
    writeStoredPersona(currentPersona);
  }, [currentPersona]);

  const demo = !hideDemoBadge && isDemoMode();

  // v23.4.7 Phase 7 / BUG 002 — the switcher must remain available whenever
  // the user is entitled to MORE THAN ONE persona, even if the legacy
  // shouldShowToggleFromCtx predicate (Collective-membership-gated) returns
  // hidden. A founder with no Collective membership still needs the dropdown
  // hidden (they only have Capavate), but multi-role users (e.g. admin +
  // founder) must see it.
  if (!visible && entitled.size <= 1) {
    // Keep parity with legacy `toggle-hidden-marker` so existing tests/snapshots stay green.
    return (
      <span
        data-testid="persona-switcher-hidden-marker toggle-hidden-marker"
        data-toggle-visible="false"
        data-toggle-reason={reason}
        className="hidden"
      />
    );
  }

  const onSelect = (p: PersonaDef) => {
    setSelected(p.id);
    writeStoredPersona(p.id);
    navigate(withPortalParam(p.href, p.portalKey));
    // v25.23 NH-Q1 — invalidate the ENTIRE React Query cache after switching
    // persona so stale, prior-persona-scoped data (e.g. ["/api/auth/me"],
    // ["/api/partner/me"], and every role-scoped list) is refetched fresh and
    // never bleeds across the role boundary. Called after navigation so the
    // new persona's surfaces mount against a cleared cache.
    void queryClient.invalidateQueries();
  };

  const currentDef = PERSONA_OPTIONS.find((p) => p.id === selected) ?? PERSONA_OPTIONS[0]!;
  const CurrentIcon = currentDef.icon;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          size="sm"
          variant="ghost"
          data-testid="button-persona-switcher"
          data-persona-current={selected}
          data-toggle-visible="true"
          data-toggle-reason={reason}
          className="hidden md:inline-flex h-8 gap-2 text-white/90 hover:text-white hover:bg-white/10 border border-white/10"
        >
          <CurrentIcon className="h-3.5 w-3.5" />
          <span className="text-[11px] font-medium">{currentDef.label}</span>
          {demo && (
            <Badge
              className="bg-amber-400/30 border-0 text-amber-50 text-[9px] uppercase"
              data-testid="persona-demo-badge"
            >
              Demo
            </Badge>
          )}
          <ChevronDown className="h-3 w-3 opacity-70" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64" data-testid="persona-switcher-menu">
        <DropdownMenuLabel className="text-xs">
          Switch persona
          {demo && (
            <span className="ml-2 text-amber-600 font-normal" data-testid="persona-demo-label">
              · Demo seed
            </span>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {/* ----- Wave B FIX 9 (I-BUG-009) -----
         * QA flagged that the dropdown listed Capavate/Collective/Partner/Admin
         * for every user, with the ineligible items shown disabled. Investors
         * with no founder membership saw a greyed-out "Capavate" entry that
         * looked like a bug, and partner/admin entries leaked the existence of
         * admin surfaces to non-admins. The fix is to filter to only the
         * personas the caller is entitled to (per `entitledPersonas`). The
         * `data-testid="persona-option-<id>"` markers therefore only appear
         * for personas the user can actually switch into. */}
        {PERSONA_OPTIONS.filter((p) => entitled.has(p.id)).map((p) => {
          const Icon = p.icon;
          const allowed = true; // post-filter, every item is allowed
          const isCurrent = p.id === selected;
          return (
            <DropdownMenuItem
              key={p.id}
              onSelect={(e) => {
                if (!allowed) {
                  e.preventDefault();
                  return;
                }
                onSelect(p);
              }}
              data-testid={`persona-option-${p.id}`}
              data-persona-allowed={allowed ? "true" : "false"}
              data-persona-current={isCurrent ? "true" : "false"}
              className="flex items-start gap-2 text-xs"
            >
              <Icon className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <div className="flex-1">
                <div className="font-medium flex items-center gap-1.5">
                  {p.label}
                  {isCurrent && (
                    <Badge className="text-[9px] h-4 px-1.5" data-testid={`persona-current-badge-${p.id}`}>
                      Current
                    </Badge>
                  )}
                </div>
                <div className="text-[10px] text-muted-foreground">{p.description}</div>
              </div>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default PersonaSwitcher;
