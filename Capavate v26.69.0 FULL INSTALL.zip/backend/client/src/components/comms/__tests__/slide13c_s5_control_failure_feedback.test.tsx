import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { RoleProvider } from "@/lib/role";

const toastMock = vi.fn();
const apiRequestMock = vi.fn();
vi.mock("@/hooks/use-toast", () => ({ useToast: () => ({ toast: toastMock }) }));
vi.mock("@/lib/queryClient", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queryClient")>("@/lib/queryClient");
  return { ...actual, apiRequest: (...args: unknown[]) => apiRequestMock(...args) };
});
import { MessagesPage } from "../MessagesPage";
import { queryClient } from "@/lib/queryClient";

type Deferred<T = unknown> = {
  promise: Promise<T>;
  resolve: (value: T) => void;
  reject: (reason: unknown) => void;
};
function deferred<T = unknown>(): Deferred<T> {
  let resolve!: (value: T) => void;
  let reject!: (reason: unknown) => void;
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
function hostile(status: number) {
  return Object.assign(new Error("RAW_DB_CANARY secret row ch_private"), { status });
}

const channel = (id: string, title: string) => ({
  id, kind: "dm", participantUserIds: ["u_me", "u_them"], displayTitle: title,
  displaySubtitle: "Direct message", unread: 1, starred: false, kindBadge: "DM",
  metadata: {}, lastMessage: { id: `last_${id}`, preview: "hello", senderLabel: "Them", ts: "2026-01-01" },
});
const message = (starred = false) => ({
  id: "msg_1", channelId: "ch_a", authorUserId: "u_them", body: "Hello",
  createdAt: "2026-01-01T00:00:00Z", starredByUserIds: starred ? ["u_me"] : [],
  reactions: [{ emoji: "👍", userIds: ["u_them"] }], readByUserIds: ["u_them"],
  authorLabel: "Them", authorIsAnonymous: false, authorRoleBadge: "Investor",
});

function mount(role: "founder" | "investor" = "investor", starred = false) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false, staleTime: Infinity }, mutations: { retry: false } },
  });
  const a = channel("ch_a", "Alpha Person");
  const b = channel("ch_b", "Beta Person");
  qc.setQueryData(["/api/comms/channels"], [a, b]);
  qc.setQueryData(["/api/comms/me"], { id: "u_me", legalName: "Me" });
  // Non-demo tests use the empty session hint. Entitlement identity takes
  // precedence over /comms/me, so seed the same fictional actor at both sources.
  qc.setQueryData(["/api/auth/me", ""], {
    userId: "u_me", isAuthed: true, isAdmin: false,
    identity: { id: "u_me", name: "Me", email: "me@s5-ui.invalid" },
  });
  qc.setQueryData(["/api/comms/channels", "ch_a"], { channel: a, messages: [message(starred)] });
  qc.setQueryData(["/api/comms/channels", "ch_b"], { channel: b, messages: [] });
  qc.setQueryData(["/api/comms/channels", "ch_a", "read-receipts"], { receipts: [] });
  qc.setQueryData(["/api/comms/channels", "ch_b", "read-receipts"], { receipts: [] });
  // The component imports the actual exported singleton for invalidations.
  const invalidate = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined as never);
  render(<QueryClientProvider client={qc}><RoleProvider><MessagesPage role={role} /></RoleProvider></QueryClientProvider>);
  return { qc, invalidate };
}
function requests(suffix: string) {
  return apiRequestMock.mock.calls.filter((c) => String(c[1]).endsWith(suffix));
}
function activePane() {
  return within(screen.getByTestId("pane-messages"));
}
async function openMenu() {
  const trigger = await screen.findByTestId("button-thread-menu");
  fireEvent.pointerDown(trigger, { button: 0, ctrlKey: false });
  fireEvent.mouseDown(trigger, { button: 0, ctrlKey: false });
  return await screen.findByRole("menu");
}
async function selectMenu(label: RegExp) {
  const menu = await openMenu();
  const item = within(menu).getByText(label).closest('[role="menuitem"]') as HTMLElement;
  fireEvent.pointerMove(item);
  fireEvent.click(item);
}

describe("S5 shared messaging controls report request failures without claiming success", () => {
  beforeEach(() => {
    toastMock.mockReset();
    apiRequestMock.mockReset();
    apiRequestMock.mockImplementation((method: string, url: string) => {
      if (method === "POST" && url.endsWith("/read")) return Promise.resolve({});
      return Promise.resolve({ json: async () => ({ ok: true }) });
    });
  });
  afterEach(() => { cleanup(); vi.restoreAllMocks(); });

  it.each([
    ["Mute notifications", "/mute", 503, "Couldn't mute notifications."],
    ["Archive thread", "/archive", 404, "Couldn't archive this thread."],
    ["Pin thread", "/pin", 409, "Couldn't pin this thread."],
  ])("%s rejection reports exactly once and preserves active channel A", async (label, suffix, status, copy) => {
    const action = deferred();
    apiRequestMock.mockImplementation((method: string, url: string) =>
      method === "POST" && url.endsWith(String(suffix)) ? action.promise :
      method === "POST" && url.endsWith("/read") ? Promise.resolve({}) : Promise.resolve({}));
    const { invalidate } = mount("founder");
    await screen.findByTestId("button-thread-menu");
    await waitFor(() => expect(requests("/read")).toHaveLength(1));
    await waitFor(() => expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] }));
    invalidate.mockClear();
    await selectMenu(new RegExp(String(label), "i"));
    await act(async () => {
      action.reject(hostile(Number(status)));
      await action.promise.catch(() => undefined);
    });
    await waitFor(() => expect(toastMock).toHaveBeenCalledWith({
      title: copy, variant: "destructive",
    }));
    expect(toastMock).toHaveBeenCalledTimes(1);
    expect(toastMock).toHaveBeenNthCalledWith(1, { title: copy, variant: "destructive" });
    for (const successTitle of ["Notifications muted", "Thread archived", "Thread pinned"]) {
      expect(toastMock).not.toHaveBeenCalledWith({ title: successTitle });
    }
    expect(apiRequestMock).toHaveBeenCalledWith(
      "POST", `/api/comms/channels/ch_a${String(suffix)}`,
    );
    expect(requests(String(suffix))).toHaveLength(1);
    // A swallowed rejection, accidental clear/reselect, or retry would violate
    // these exact counts/identity assertions.
    expect(requests("/read")).toHaveLength(1);
    expect(invalidate).not.toHaveBeenCalled();
    expect(activePane().getByText("Alpha Person")).toBeTruthy();
    expect(document.body.textContent).not.toContain("RAW_DB_CANARY");
    expect(JSON.stringify(toastMock.mock.calls)).not.toContain("RAW_DB_CANARY");
  });

  it("keeps all three menu success toast/invalidation branches", async () => {
    const { invalidate } = mount();
    await screen.findByTestId("button-thread-menu");
    await waitFor(() => expect(requests("/read")).toHaveLength(1));
    await waitFor(() => expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] }));
    for (const [label, suffix, title] of [
      ["Mute notifications", "/mute", "Notifications muted"],
      ["Pin thread", "/pin", "Thread pinned"],
    ]) {
      toastMock.mockClear(); invalidate.mockClear();
      await selectMenu(new RegExp(label, "i"));
      await waitFor(() => expect(toastMock).toHaveBeenCalledWith({ title }));
      expect(toastMock).toHaveBeenCalledTimes(1);
      expect(requests(suffix)).toHaveLength(1);
      expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] });
      expect(screen.getByTestId("button-thread-menu")).toBeTruthy();
      expect(requests("/read")).toHaveLength(1);
    }
    toastMock.mockClear(); invalidate.mockClear();
    await selectMenu(/archive thread/i);
    await waitFor(() => expect(toastMock).toHaveBeenCalledWith({ title: "Thread archived" }));
    expect(toastMock).toHaveBeenCalledTimes(1);
    expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] });
    expect(requests("/archive")).toHaveLength(1);
    // Existing archive success clears selection, then the unchanged initial
    // selection effect reselects first channel A; a second read demonstrates it.
    await waitFor(() => expect(requests("/read")).toHaveLength(2));
  });

  it("star POST, reaction pill and emoji failures expose fixed copy only and never invalidate", async () => {
    const failures = [deferred(), deferred(), deferred(), deferred()];
    let n = 0;
    apiRequestMock.mockImplementation((method: string, url: string) => {
      if (method === "POST" && url.endsWith("/read")) return Promise.resolve({});
      if (url.includes("/star") || url.includes("/reactions")) return failures[n++].promise;
      return Promise.resolve({});
    });
    const { invalidate } = mount("investor");
    await screen.findByTestId("button-star-msg_1");
    await waitFor(() => expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] }));
    invalidate.mockClear();
    const controls = [
      [screen.getByTestId("button-star-msg_1"), "Couldn't update the star."],
      [screen.getByTestId("reaction-msg_1-👍"), "Couldn't update the reaction."],
      [screen.getByTestId("button-react-msg_1"), "Couldn't update the reaction."],
      [screen.getByText("❤️"), "Couldn't update the reaction."],
    ] as const;
    for (let i = 0; i < controls.length; i += 1) {
      toastMock.mockClear();
      fireEvent.click(controls[i][0]);
      failures[i].reject(hostile(i % 2 ? 409 : 503));
      await waitFor(() => expect(toastMock).toHaveBeenCalledWith({
        title: controls[i][1], variant: "destructive",
      }));
      expect(toastMock).toHaveBeenCalledTimes(1);
      expect(toastMock).toHaveBeenNthCalledWith(1, {
        title: controls[i][1], variant: "destructive",
      });
      expect(invalidate).not.toHaveBeenCalled();
    }
    expect(requests("/star")).toHaveLength(1);
    expect(requests("/reactions")).toHaveLength(3);
    expect(document.body.textContent).not.toContain("RAW_DB_CANARY");
    expect(JSON.stringify(toastMock.mock.calls)).not.toContain("RAW_DB_CANARY");
  });

  it("failed unstar uses DELETE, reports once, and preserves selection without invalidation", async () => {
    const unstar = deferred();
    apiRequestMock.mockImplementation((method: string, url: string) =>
      method === "POST" && url.endsWith("/read") ? Promise.resolve({}) :
      method === "DELETE" && url.endsWith("/star") ? unstar.promise : Promise.resolve({}));
    const { invalidate } = mount("investor", true);
    await screen.findByTestId("button-star-msg_1");
    await waitFor(() => expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] }));
    invalidate.mockClear();
    toastMock.mockClear();
    expect(screen.getByTestId("button-star-msg_1").querySelector("svg")?.getAttribute("class")).toContain("fill-amber-400");
    fireEvent.click(screen.getByTestId("button-star-msg_1"));
    await waitFor(() => expect(requests("/star")).toHaveLength(1));
    expect(apiRequestMock).toHaveBeenCalledWith("DELETE", "/api/comms/messages/msg_1/star");
    await act(async () => {
      unstar.reject(hostile(409));
      await unstar.promise.catch(() => undefined);
    });
    await waitFor(() => expect(toastMock).toHaveBeenCalledTimes(1));
    expect(toastMock).toHaveBeenNthCalledWith(1, {
      title: "Couldn't update the star.", variant: "destructive",
    });
    expect(invalidate).not.toHaveBeenCalled();
    expect(requests("/read")).toHaveLength(1);
    expect(activePane().getByText("Alpha Person")).toBeTruthy();
    expect(screen.getByTestId("button-star-msg_1").querySelector("svg")?.getAttribute("class")).toContain("fill-amber-400");
  });

  it("successful unstar and reaction retain the exact invalidation keys", async () => {
    const { invalidate } = mount("investor", true);
    await screen.findByTestId("button-star-msg_1");
    await waitFor(() => expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] }));
    invalidate.mockClear();
    expect(screen.getByTestId("button-star-msg_1").querySelector("svg")?.getAttribute("class")).toContain("fill-amber-400");
    fireEvent.click(screen.getByTestId("button-star-msg_1"));
    await waitFor(() => expect(apiRequestMock).toHaveBeenCalledWith("DELETE", "/api/comms/messages/msg_1/star"));
    expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels", "ch_a"] });
    expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels"] });
    invalidate.mockClear();
    fireEvent.click(screen.getByTestId("button-react-msg_1"));
    await waitFor(() => expect(invalidate).toHaveBeenCalledWith({ queryKey: ["/api/comms/channels", "ch_a"] }));
    expect(toastMock).not.toHaveBeenCalledWith(expect.objectContaining({ variant: "destructive" }));
  });

  it("mark-read is inline/no-toast and stale A failure cannot mark B", async () => {
    const a = deferred(), b = deferred();
    const reads = [a, b];
    apiRequestMock.mockImplementation((method: string, url: string) =>
      method === "POST" && url.endsWith("/read") ? reads.shift()!.promise : Promise.resolve({}));
    const { invalidate } = mount();
    await waitFor(() => expect(requests("/read")).toHaveLength(1));
    fireEvent.click(screen.getByTestId("channel-row-ch_b"));
    await waitFor(() => expect(requests("/read")).toHaveLength(2));
    expect(screen.queryByTestId("status-mark-read-failed")).toBeNull();
    // First A request is stale after the switch.
    // Reject the stale A attempt, then resolve current B: no warning or toast.
    await act(async () => {
      a.reject(hostile(503));
      b.resolve({});
      await Promise.all([a.promise.catch(() => undefined), b.promise]);
    });
    await waitFor(() => expect(invalidate).toHaveBeenCalledTimes(1));
    expect(screen.queryByTestId("status-mark-read-failed")).toBeNull();
    expect(requests("/read")).toHaveLength(2);
    expect(screen.queryByRole("button", { name: /mark.*read/i })).toBeNull();
    expect(toastMock).not.toHaveBeenCalled();
  });

  it("A→B→A stale success still invalidates but cannot clear the current A failure warning", async () => {
    const a1 = deferred(), b = deferred(), a2 = deferred(), b2 = deferred(), a3 = deferred();
    const queue = [a1, b, a2, b2, a3];
    apiRequestMock.mockImplementation((method: string, url: string) =>
      method === "POST" && url.endsWith("/read") ? queue.shift()!.promise : Promise.resolve({}));
    const { invalidate } = mount();
    await waitFor(() => expect(requests("/read")).toHaveLength(1));
    fireEvent.click(screen.getByTestId("channel-row-ch_b"));
    await waitFor(() => expect(requests("/read")).toHaveLength(2));
    await act(async () => {
      b.resolve({});
      await b.promise;
    });
    await waitFor(() => expect(invalidate).toHaveBeenCalledTimes(1));
    fireEvent.click(screen.getByTestId("channel-row-ch_a"));
    await waitFor(() => expect(requests("/read")).toHaveLength(3));
    await act(async () => {
      a2.reject(hostile(404));
      await a2.promise.catch(() => undefined);
    });
    const fullWarning = "Couldn't mark this thread as read. Its unread count may be out of date.";
    expect((await screen.findByTestId("status-mark-read-failed")).textContent?.trim()).toBe(fullWarning);
    expect(screen.getAllByTestId("status-mark-read-failed")).toHaveLength(1);
    expect(invalidate).toHaveBeenCalledTimes(1);
    // The original A success is stale after returning to the same ID. Its
    // unconditional invalidation MUST still occur, then it must leave A2's
    // current warning untouched. Removing the success-side currentness guard
    // would make the assertion after the flush fail.
    await act(async () => {
      a1.resolve({});
      await a1.promise;
    });
    await waitFor(() => expect(invalidate).toHaveBeenCalledTimes(2));
    expect(screen.getByTestId("status-mark-read-failed").textContent?.trim()).toBe(fullWarning);
    expect(requests("/read")).toHaveLength(3);
    fireEvent.click(screen.getByTestId("channel-row-ch_b"));
    await waitFor(() => expect(requests("/read")).toHaveLength(4));
    fireEvent.click(screen.getByTestId("channel-row-ch_a"));
    await waitFor(() => expect(requests("/read")).toHaveLength(5));
    await act(async () => {
      b2.reject(hostile(409));
      a3.resolve({});
      await Promise.all([b2.promise.catch(() => undefined), a3.promise]);
    });
    await waitFor(() => expect(invalidate).toHaveBeenCalledTimes(3));
    await waitFor(() => expect(screen.queryByTestId("status-mark-read-failed")).toBeNull());
    expect(requests("/read")).toHaveLength(5);
    expect(toastMock).not.toHaveBeenCalled();
    expect(screen.queryByRole("button", { name: /mark.*read/i })).toBeNull();
  });

  it("A→B→A late first-A failure cannot warn on a later successful visit to A", async () => {
    const a1 = deferred(), b = deferred(), a2 = deferred();
    const queue = [a1, b, a2];
    apiRequestMock.mockImplementation((method: string, url: string) =>
      method === "POST" && url.endsWith("/read") ? queue.shift()!.promise : Promise.resolve({}));
    const { invalidate } = mount();
    await waitFor(() => expect(requests("/read")).toHaveLength(1));
    fireEvent.click(screen.getByTestId("channel-row-ch_b"));
    await waitFor(() => expect(requests("/read")).toHaveLength(2));
    await act(async () => { b.resolve({}); await b.promise; });
    await waitFor(() => expect(invalidate).toHaveBeenCalledTimes(1));
    fireEvent.click(screen.getByTestId("channel-row-ch_a"));
    await waitFor(() => expect(requests("/read")).toHaveLength(3));
    await act(async () => { a2.resolve({}); await a2.promise; });
    await waitFor(() => expect(invalidate).toHaveBeenCalledTimes(2));
    expect(screen.queryByTestId("status-mark-read-failed")).toBeNull();
    // Both visits have channelId "ch_a"; only per-run cleanup can suppress A1.
    // This fails if the rejection-side currentness guard is removed.
    await act(async () => {
      a1.reject(hostile(503));
      await a1.promise.catch(() => undefined);
    });
    expect(screen.queryByTestId("status-mark-read-failed")).toBeNull();
    expect(activePane().getByText("Alpha Person")).toBeTruthy();
    expect(requests("/read")).toHaveLength(3);
    expect(invalidate).toHaveBeenCalledTimes(2);
    expect(toastMock).not.toHaveBeenCalled();
  });
});
