/** Real component with labelled transport stubs. Not mounted DB evidence. */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import RoundCarryForwardPanel from "../RoundCarryForwardPanel";
const observed = vi.hoisted(() => ({ toast: vi.fn() }));
vi.mock("@/hooks/use-toast", () => ({ useToast: () => ({ toast: observed.toast }) }));
const result = () => ({
  companyId: "co_ui", proposedRoundType: "priced_equity", computedAt: "2026-10-08T12:00:00.000Z",
  fields: {}, warnings: ["Executed-conversion lineage is not verified."], auditDigest: "digest",
  conversionExecutionVerified: false,
  unrealizedInstruments: [{
    instrumentId: "sec_exact", investorId: "u_private", holderName: "Private Investor",
    instrumentType: "note", principal: "9007199254740993.123456", cap: null, discount: null,
    currency: null, mfn: null, safeCapType: null, interestRate: null, maturityMonths: null,
    sourceRoundId: "round_prior", sourceRoundName: "Prior note", projectedConversionPriceUsd: null,
    projectedShares: null, effectivePricePerShare: null, conversionStatus: "unknown_execution",
    sources: ["kv:sec_exact"], conversionDecisions: [], rationale: "Recorded candidate; execution not verified.",
  }],
  inventory: [{ instrumentId: "generic", investorId: null, sourceRoundId: null, principal: null, cap: null,
    currency: null, status: "unbound", reason: "No verified source-round binding", sources: ["kv:generic"] }],
  conversionDisclosures: [{ id: "decision_1", roundId: "round_new", recordedInstrumentId: "ambiguous_alias",
    status: "converts_in_this_round", attribution: "ambiguous" }],
});
let readStatus = 200;
let data: any;
function response(status: number, body: unknown): Response {
  return { status, ok: status >= 200 && status < 300, json: async () => body,
    text: async () => JSON.stringify(body), clone: () => response(status, body) } as Response;
}
beforeEach(() => {
  readStatus = 200; data = result(); observed.toast.mockReset();
  vi.stubGlobal("fetch", vi.fn(async (_url, init) => init?.method === "POST"
    ? response(503, { message: "Unavailable" })
    : response(readStatus, readStatus === 200 ? { ok: true, result: data } : { message: "Canonical carry-forward inputs could not be verified." })));
});
afterEach(() => { cleanup(); vi.unstubAllGlobals(); });
const mount = () => render(<RoundCarryForwardPanel companyId="co_ui" roundId="round_new" roundType="priced_equity" />);
describe("v26.65 canonical carry UI", () => {
  it("retains exact decimals and explicitly renders unknown MFN/currency/cap and execution", async () => {
    mount();
    fireEvent.click(await screen.findByText("Recorded SAFE/note candidates (1)"));
    fireEvent.click(screen.getByText("Private Investor"));
    expect(screen.getAllByText("9007199254740993.123456 (currency not recorded)").length).toBeGreaterThan(0);
    expect(screen.getByText("MFN: Not recorded")).toBeTruthy();
    expect(screen.getByText("Currency: Not recorded")).toBeTruthy();
    expect(screen.getByText("Executed conversion: Not verified")).toBeTruthy();
    expect(screen.getByText(/not a statement that the instrument is uncapped/)).toBeTruthy();
    expect(screen.getByText("u_private")).toBeTruthy();
    expect(screen.getByText(/Canonical sources: kv:sec_exact/)).toBeTruthy();
    expect(screen.queryByText(/instruments will convert when/)).toBeNull();
    expect(document.body.textContent).not.toContain("USD");
    expect(document.body.textContent).not.toContain("$");
  });
  it("shows unbound inventory and ambiguous recorded decisions rather than silently dropping them", async () => {
    mount();
    await screen.findByTestId("carry-inventory");
    expect(screen.getByText("generic")).toBeTruthy();
    expect(screen.getByText(/No verified source-round binding/)).toBeTruthy();
    expect(screen.getByText(/attribution: ambiguous/)).toBeTruthy();
    expect(screen.getByText(/Not executed-conversion evidence/)).toBeTruthy();
  });
  it("shows source failures, not an empty successful recommendation", async () => {
    readStatus = 503; mount();
    await screen.findByText("Canonical carry-forward inputs could not be verified.");
    expect(screen.queryByText("Carry-forward suggestions")).toBeNull();
    expect(screen.queryByTestId("carry-inventory")).toBeNull();
  });
  it("shows raw recorded zero and source-term conflicts without offering an invented suggestion", async () => {
    data.inventory[0].cap = "0.000";
    data.inventory[0].currency = "CAD";
    data.inventory[0].recordedTerms = { discountPercentAsWritten: "0.000" };
    data.warnings.push("sec_exact: cap recorded as 0.000 is shown in canonical inventory but not used as a cap.");
    data.warnings.push("safeType is not carried forward: the prior source records conflicting values.");
    mount();
    await screen.findByTestId("carry-inventory");
    expect(screen.getByText(/Cap: CAD 0.000/)).toBeTruthy();
    expect(screen.getByText("Recorded discount: 0.000%")).toBeTruthy();
    expect(screen.getByText(/cap recorded as 0.000/)).toBeTruthy();
    expect(screen.getByText(/safeType is not carried forward: the prior source records conflicting values/)).toBeTruthy();
    expect(screen.queryByText("Use suggested")).toBeNull();
  });
  it("local selection never claims an audit write; uncertain saves do not claim that nothing was recorded", async () => {
    data.fields = { safeType: { fieldName: "safeType", suggestedValue: "pre_money_cap", source: "prev_round",
      sourceRoundId: "round_prior", sourceRoundName: "Prior SAFE", confidence: "high", rationale: "Recorded convention", warnings: [] } };
    mount();
    fireEvent.click(await screen.findByText("Use suggested"));
    expect(screen.getByText("Choice selected locally. Save decisions below to record it.")).toBeTruthy();
    expect(screen.queryByText("Suggestion accepted and recorded in audit log.")).toBeNull();
    expect(screen.getByText("pre_money_cap")).toBeTruthy();
    fireEvent.click(screen.getByText("Record decisions in audit log"));
    await waitFor(() => expect(observed.toast).toHaveBeenCalledWith(expect.objectContaining({
      title: "Could not save audit record",
      description: "Saving was not confirmed. Refresh and check the round before retrying; a lost response may follow a completed save.",
    })));
  });
});
