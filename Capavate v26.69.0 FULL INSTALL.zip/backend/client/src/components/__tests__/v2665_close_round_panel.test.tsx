/**
 * v26.65.0 #7 — mounted CloseRoundPanel DOM tests against the r5 strict close
 * receipt and GET close-state. AUTHORED, NOT EXECUTED (Main runs it).
 * Stubbed transport only: this is DOM/contract coverage, not financial or
 * runtime proof. Only toast and telemetry emit are mocked; the sprint3 store,
 * cap-table engine and query client are real. The signed-in actor comes from a
 * stubbed /api/auth/me read through the real useEntitlement hook.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClientProvider } from "@tanstack/react-query";
import CloseRoundPanel from "../CloseRoundPanel";
import { RoleProvider } from "@/lib/role";
import { queryClient } from "@/lib/queryClient";
import { useSprint3 } from "@/lib/sprint3";

const spies = vi.hoisted(() => ({ toast: vi.fn(), emit: vi.fn() }));
vi.mock("@/hooks/use-toast", () => ({
  useToast: () => ({ toast: (v: unknown) => spies.toast(v) }),
  toast: (v: unknown) => spies.toast(v),
}));
vi.mock("@/lib/sprint3", async () => ({
  ...(await vi.importActual<Record<string, unknown>>("@/lib/sprint3")),
  emit: spies.emit,
}));

const ROUND = "rnd_v2665_close_ui";
const COMPANY = "co_v2665_close_ui";
const CLOSE_URL = `/api/founder/rounds/${ROUND}/close`;
const STATE_URL = `/api/founder/rounds/${ROUND}/close-state`;
const PENDING_URL = `/api/founder/rounds/${ROUND}/pending-commitments`;
const ROUND2 = "rnd_v2665_close_ui_other";
const ACTOR = "u_v2665_founder_a";
const ACTOR2 = "u_v2665_founder_b";

type Reply = { status: number; body: unknown } | (() => Promise<Response>);
type Call = { method: string; url: string; body?: unknown; emitsBefore: number };
let calls: Call[] = [];
let closeReply: Reply;
let stateReplies: Reply[];
let pendingReply: Reply;
let meReply: Reply;
const meOf = (userId: string) => ({ status: 200, body: { userId, isAuthed: true, isAdmin: false, role: "founder", identity: { id: userId, name: "Founder", email: "" }, founder: { companies: [], activeCompanyId: COMPANY } } });
const deferred = () => { let release!: (r: Response) => void; const p = new Promise<Response>((resolve) => { release = resolve; }); return { reply: () => p, release }; };

const response = (status: number, body: unknown): Response => {
  const raw = JSON.stringify(body);
  return {
    ok: status >= 200 && status < 300, status, statusText: String(status),
    headers: new Headers({ "content-type": "application/json" }),
    text: async () => raw, json: async () => JSON.parse(raw), clone: () => response(status, body),
  } as unknown as Response;
};
const answer = (r: Reply) => (typeof r === "function" ? r() : Promise.resolve(response(r.status, r.body)));
const durable = (state = "closed", currency: string | null = "CAD") => ({ roundId: ROUND, companyId: COMPANY, state, terminal: state !== "active", closeDate: "2026-10-08T12:00:00.000Z", currency });
const receipt = (over: Record<string, unknown> = {}) => ({
  ok: true, alreadyClosed: false, round: { id: ROUND, companyId: COMPANY, state: "closed" },
  durable: durable(), frozenChainHead: "CARRY_FORWARD_GENESIS", lapsedCommitments: 0, ...over,
});
const openState = { status: 200, body: { ok: true, roundId: ROUND, terminal: false, state: "active", closeDate: null, currency: "CAD" } };
const closedState = { status: 200, body: { ok: true, roundId: ROUND, terminal: true, state: "closed", closeDate: "2026-10-08T12:00:00.000Z", currency: "CAD" } };
const stateBody = (over: Record<string, unknown>) => ({ status: 200, body: { ...closedState.body, ...over } });
const unavailableState = { status: 503, body: { ok: false, error: "CLOSE_STATE_UNAVAILABLE" } };

const roundClosedEmits = () => spies.emit.mock.calls.filter((c) => (c[0] as { type?: string })?.type === "round.closed");
const toastTitles = () => spies.toast.mock.calls.map((c) => String((c[0] as { title?: string })?.title ?? ""));
const posts = () => calls.filter((c) => c.method === "POST" && c.url === CLOSE_URL);
const stateReads = () => calls.filter((c) => c.method === "GET" && c.url === STATE_URL).length;

function seedReadyToClose(extra: Record<string, unknown> = {}) {
  const sig = (actorRole: "founder" | "admin") => ({
    actorId: actorRole === "admin" ? "admin-platform" : "founder-avi", actorName: actorRole, actorRole,
    ts: "2026-10-08T11:00:00.000Z", ipAddress: null, identityHash: null,
  });
  useSprint3.setState({
    closeStates: {
      [ROUND]: {
        roundId: ROUND, closed: false,
        reconciliation: { status: "match", runDurationMs: 1, formulaIdsUsed: [], diffs: [], primaryHash: "p1", referenceHash: "p1", primaryTotal: "100", referenceTotal: "100" } as never,
        founderSignoff: sig("founder") as never, adminSignoff: sig("admin") as never, ...extra,
      },
    },
  });
}
const tree = (roundId = ROUND, companyId = COMPANY) => (
  <QueryClientProvider client={queryClient}><RoleProvider><CloseRoundPanel roundId={roundId} companyId={companyId} roundName="Seed" /></RoleProvider></QueryClientProvider>
);
function mount() {
  return render(tree());
}
/** Switch the signed-in actor and wait for the ACTUAL new authenticated
 *  render: the replacement instance (new actor key) issues its own close-state
 *  read. Only after that may a test release an old instance's promise/timer. */
async function switchActor(userId: string) {
  const before = stateReads();
  meReply = meOf(userId);
  await act(async () => { await queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] }); });
  await waitFor(() => expect(stateReads()).toBeGreaterThan(before));
}
/** Flush pending microtasks/timers so any guarded continuation would have run. */
const settle = () => act(async () => { await new Promise((r) => setTimeout(r, 30)); });
const roundStore = (id = ROUND) => useSprint3.getState().closeStates[id];
/** The panel is keyed by the signed-in actor: it first renders a no-session
 *  instance, then remounts once /api/auth/me resolves. Wait for the auth read
 *  and the actor instance's own pending/close-state reads, then acquire the
 *  CURRENT button (never a node from the replaced no-session instance). */
async function readyButton() {
  await screen.findByTestId("button-commit-close");
  await waitFor(() => expect(calls.some((c) => c.method === "GET" && c.url.startsWith("/api/auth/me"))).toBe(true));
  await waitFor(() => expect(calls.some((c) => c.url === PENDING_URL)).toBe(true));
  await waitFor(() => expect(stateReads()).toBeGreaterThan(0));
  await waitFor(() => expect(screen.queryByTestId("close-session-unavailable")).toBeNull());
  return screen.getByTestId("button-commit-close") as HTMLButtonElement;
}

beforeEach(() => {
  calls = [];
  spies.toast.mockReset();
  spies.emit.mockReset();
  closeReply = { status: 200, body: receipt() };
  stateReplies = [openState];
  pendingReply = { status: 200, body: { ok: true, count: 0, totalMinor: 0 } };
  meReply = meOf(ACTOR);
  seedReadyToClose();
  vi.stubGlobal("fetch", vi.fn(async (url: unknown, init?: RequestInit) => {
    const u = String(url);
    const method = String(init?.method ?? "GET").toUpperCase();
    calls.push({ method, url: u, body: init?.body ? JSON.parse(String(init.body)) : undefined, emitsBefore: roundClosedEmits().length });
    if (method === "POST" && u === CLOSE_URL) return answer(closeReply);
    if (method === "GET" && u === STATE_URL) return answer(stateReplies.length > 1 ? stateReplies.shift()! : stateReplies[0]!);
    if (method === "GET" && u === PENDING_URL) return answer(pendingReply);
    if (method === "GET" && u.startsWith("/api/auth/me")) return answer(meReply);
    return response(200, {});
  }));
});
afterEach(() => {
  cleanup(); queryClient.clear(); vi.unstubAllGlobals(); vi.restoreAllMocks();
  useSprint3.setState({ closeStates: {} });
});

describe("CloseRoundPanel — server-verified close (r5 receipt)", () => {
  it("posts only reason and lapsePending; shows closed and emits telemetry only after a verified terminal receipt", async () => {
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    expect(posts()).toHaveLength(1);
    expect(posts()[0]!.body).toEqual({ reason: "manual_close", lapsePending: false });
    expect(posts()[0]!.emitsBefore).toBe(0);
    expect(roundClosedEmits()).toHaveLength(1);
    expect((roundClosedEmits()[0]![0] as { payload: Record<string, unknown> }).payload).not.toHaveProperty("finalAmount");
    expect(toastTitles()).toContain("Round closed");
    expect(screen.getByTestId("panel-close-round").textContent).toMatch(/in CAD/);
    expect(screen.getByTestId("panel-close-round").textContent).not.toMatch(/USD/);
    expect(useSprint3.getState().closeStates[ROUND]!.closed).toBe(true);
    expect(screen.queryByTestId("button-commit-close")).toBeNull();
  });

  it("single-flight: a second click while closing sends nothing", async () => {
    let release!: (r: Response) => void;
    closeReply = () => new Promise<Response>((resolve) => { release = resolve; });
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    fireEvent.click(btn);
    await waitFor(() => expect(btn.disabled).toBe(true));
    fireEvent.click(btn);
    expect(posts()).toHaveLength(1);
    release(response(200, receipt()));
    await screen.findByTestId("close-server-closed");
    expect(posts()).toHaveLength(1);
  });

  it("a 4xx is a definitive refusal: not closed, no local seal, no telemetry, no automatic retry", async () => {
    closeReply = { status: 403, body: { ok: false, error: "NOT_ROUND_OWNER" } };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    const refused = await screen.findByTestId("close-refused");
    expect(refused.textContent).toMatch(/Only a founder of this round's company can close it/);
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
    expect(roundClosedEmits()).toHaveLength(0);
    expect(useSprint3.getState().closeStates[ROUND]!.closed).toBe(false);
    await waitFor(() => expect(btn.disabled).toBe(false));
    expect(posts()).toHaveLength(1);
  });

  it("a 5xx is an unknown outcome reconciled by close-state; terminal there means verified closed", async () => {
    closeReply = { status: 503, body: { ok: false, error: "CLOSE_UNAVAILABLE" } };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    const readsBefore = stateReads();
    stateReplies = [closedState];
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    expect(stateReads()).toBeGreaterThan(readsBefore);
    expect(posts()).toHaveLength(1);
    expect(roundClosedEmits()).toHaveLength(1);
  });

  it.each([
    ["wrong round id", receipt({ round: { id: "rnd_other" } })],
    ["non-terminal durable state", receipt({ durable: durable("active") })],
    ["durable bound to another round", receipt({ durable: { ...durable(), roundId: "rnd_other" } })],
    ["empty durable currency", receipt({ durable: { ...durable(), currency: "" } })],
    ["absent durable currency", receipt({ durable: { ...durable(), currency: undefined } })],
    ["durable bound to another company", receipt({ durable: { ...durable(), companyId: "co_other" } })],
    ["durable terminal flag contradicts state", receipt({ durable: { ...durable(), terminal: false } })],
    ["missing alreadyClosed", receipt({ alreadyClosed: undefined })],
  ] as const)("a malformed 200 (%s) is never closed; reconcile shows still open; no automatic second POST", async (_label, body) => {
    closeReply = { status: 200, body };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-not-closed");
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
    expect(roundClosedEmits()).toHaveLength(0);
    expect(useSprint3.getState().closeStates[ROUND]!.closed).toBe(false);
    await waitFor(() => expect(btn.disabled).toBe(false));
    expect(posts()).toHaveLength(1);
  });

  it("unknown outcome with an unreadable close-state keeps close disabled until Verify again confirms", async () => {
    closeReply = () => Promise.reject(new TypeError("network down"));
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    stateReplies = [unavailableState];
    fireEvent.click(btn);
    await screen.findByTestId("close-outcome-unknown");
    expect(btn.disabled).toBe(true);
    fireEvent.click(btn);
    expect(posts()).toHaveLength(1);
    expect(toastTitles()).toContain("Close outcome unknown");
    expect(toastTitles()).not.toContain("Round closed");
    stateReplies = [closedState];
    fireEvent.click(screen.getByTestId("button-verify-close"));
    await screen.findByTestId("close-server-closed");
    expect(posts()).toHaveLength(1);
  });

  it.each([
    ["503 preview", { status: 503, body: { ok: false, error: "PENDING_UNAVAILABLE" } }],
    ["non-integer count", { status: 200, body: { ok: true, count: "3", totalMinor: 0 } }],
    ["ok:false", { status: 200, body: { ok: false, count: 0 } }],
  ] as const)("a failed or malformed pending preview (%s) is not zero: close stays disabled", async (_label, reply) => {
    pendingReply = reply;
    mount();
    const btn = await readyButton();
    await screen.findByTestId("close-pending-unavailable");
    await waitFor(() => expect(btn.disabled).toBe(true));
    fireEvent.click(btn);
    expect(posts()).toHaveLength(0);
    expect(screen.queryByTestId("close-pending-warning")).toBeNull();
  });

  it("pending commitments require acknowledgement and are lapsed by the server close", async () => {
    pendingReply = { status: 200, body: { ok: true, count: 2, totalMinor: 500000 } };
    mount();
    const btn = await readyButton();
    await screen.findByTestId("close-pending-warning");
    expect(btn.disabled).toBe(true);
    fireEvent.click(screen.getByTestId("checkbox-ack-lapse"));
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    expect(posts()[0]!.body).toEqual({ reason: "manual_close", lapsePending: true });
  });

  it("on mount a server-terminal round shows the closed banner with no close control and no POST", async () => {
    stateReplies = [closedState];
    mount();
    await screen.findByTestId("close-server-closed");
    expect(screen.queryByTestId("button-commit-close")).toBeNull();
    expect(posts()).toHaveLength(0);
  });

  it("a local-only seal is never shown as closed when the server says the round is open", async () => {
    seedReadyToClose({ closed: true, closedAt: "2026-10-01T00:00:00.000Z" });
    mount();
    const btn = await readyButton();
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
    await waitFor(() => expect(btn.disabled).toBe(false));
  });

  it("an unreadable close-state on mount is not shown as closed", async () => {
    stateReplies = [{ status: 503, body: { ok: false, error: "CLOSE_STATE_UNAVAILABLE" } }];
    mount();
    await screen.findByTestId("close-state-unavailable");
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it("alreadyClosed receipt: banner, 'already closed' toast, no new local close telemetry", async () => {
    closeReply = { status: 200, body: receipt({ alreadyClosed: true }) };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    expect(toastTitles()).toContain("Round already closed");
    expect(roundClosedEmits()).toHaveLength(0);
  });

  it("sign-offs are labelled as local preview acknowledgements, not server approvals", async () => {
    useSprint3.setState({
      closeStates: { [ROUND]: { ...useSprint3.getState().closeStates[ROUND]!, adminSignoff: undefined } },
    });
    mount();
    const note = await screen.findByTestId("close-signoff-preview-note");
    expect(note.textContent).toMatch(/local preview acknowledgements/);
    expect(note.textContent).toMatch(/not server-authenticated approvals/);
    expect(screen.getByTestId("panel-close-round").textContent).toMatch(/admin counter-signature \(local preview acknowledgement\)/);
    expect(screen.getByTestId("close-recon-preview-note").textContent).toMatch(/preview data/);
  });
});

describe("CloseRoundPanel — U3 actor/company/round isolation and strict read proof", () => {
  it("a verified close on one round is not shown after the same instance switches to another round", async () => {
    const view = mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    view.rerender(tree(ROUND2));
    await waitFor(() => expect(screen.queryByTestId("close-server-closed")).toBeNull());
    await settle();
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it("a verified close is not shown after the same instance switches company", async () => {
    const view = mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    view.rerender(tree(ROUND, "co_v2665_other_company"));
    await waitFor(() => expect(screen.queryByTestId("close-server-closed")).toBeNull());
    await settle();
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it("a verified close is not carried to a different signed-in actor", async () => {
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    stateReplies = [openState];
    await switchActor(ACTOR2);
    await waitFor(() => expect(screen.queryByTestId("close-server-closed")).toBeNull());
    await settle();
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it.each([
    ["round replaced", "round"],
    ["actor replaced", "actor"],
    ["unmounted", "unmount"],
  ] as const)("a delayed POST completion after the context was %s does not seal, append, emit or toast", async (_label, how) => {
    const d = deferred();
    closeReply = d.reply;
    const view = mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await waitFor(() => expect(posts()).toHaveLength(1));
    if (how === "round") view.rerender(tree(ROUND2));
    else if (how === "actor") { stateReplies = [openState]; await switchActor(ACTOR2); }
    else view.unmount();
    await act(async () => { d.release(response(200, receipt())); });
    await settle();
    expect(roundClosedEmits()).toHaveLength(0);
    expect(spies.emit.mock.calls.some((c) => (c[0] as { type?: string })?.type === "cap_table.mutated")).toBe(false);
    expect(toastTitles()).not.toContain("Round closed");
    expect(roundStore()!.closed).toBe(false);
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it("a delayed close-state reconcile after an actor change does not seal, emit or toast into the new context", async () => {
    closeReply = { status: 503, body: { ok: false, error: "CLOSE_UNAVAILABLE" } };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    const d = deferred();
    stateReplies = [d.reply];
    const readsBefore = stateReads();
    fireEvent.click(btn);
    await waitFor(() => expect(posts()).toHaveLength(1));
    await waitFor(() => expect(stateReads()).toBeGreaterThan(readsBefore));
    stateReplies = [openState];
    await switchActor(ACTOR2);
    await act(async () => { d.release(response(200, closedState.body)); });
    await settle();
    expect(roundClosedEmits()).toHaveLength(0);
    expect(toastTitles()).not.toContain("Round closed");
    expect(toastTitles()).not.toContain("Close outcome unknown");
    expect(roundStore()!.closed).toBe(false);
  });

  it("no confirmed signed-in session: close is disabled, nothing is read or posted", async () => {
    meReply = { status: 200, body: { userId: "", isAuthed: false } };
    mount();
    await screen.findByTestId("close-session-unavailable");
    const btn = screen.getByTestId("button-commit-close") as HTMLButtonElement;
    expect(btn.disabled).toBe(true);
    fireEvent.click(btn);
    await settle();
    expect(posts()).toHaveLength(0);
    expect(stateReads()).toBe(0);
  });

  it("normal same-context close and Verify again still work after the guards", async () => {
    closeReply = { status: 503, body: { ok: false, error: "CLOSE_UNAVAILABLE" } };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    stateReplies = [unavailableState];
    fireEvent.click(btn);
    await screen.findByTestId("close-outcome-unknown");
    stateReplies = [closedState];
    fireEvent.click(screen.getByTestId("button-verify-close"));
    await screen.findByTestId("close-server-closed");
    expect(roundClosedEmits()).toHaveLength(1);
    expect(roundStore()!.closed).toBe(true);
  });

  it.each([
    ["terminal:false with a terminal state", stateBody({ terminal: false, state: "closed" })],
    ["terminal:true with an open state", stateBody({ terminal: true, state: "active" })],
  ] as const)("a contradictory close-state (%s) on mount is unverified, not closed", async (_label, reply) => {
    stateReplies = [reply];
    mount();
    await screen.findByTestId("close-state-unavailable");
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it.each([
    ["terminal:false with a terminal state", stateBody({ terminal: false, state: "closed_funded" })],
    ["terminal:true with an open state", stateBody({ terminal: true, state: "active" })],
  ] as const)("a contradictory close-state (%s) during reconcile is unknown, not an open retry grant", async (_label, reply) => {
    closeReply = { status: 503, body: { ok: false, error: "CLOSE_UNAVAILABLE" } };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    stateReplies = [reply];
    fireEvent.click(btn);
    await screen.findByTestId("close-outcome-unknown");
    expect(screen.queryByTestId("close-not-closed")).toBeNull();
    expect(btn.disabled).toBe(true);
    expect(roundClosedEmits()).toHaveLength(0);
  });

  it.each([
    ["403", { status: 403, body: { ok: false, error: "NOT_ROUND_OWNER" } }],
    ["404", { status: 404, body: { ok: false, error: "ROUND_NOT_FOUND" } }],
    ["503", unavailableState],
  ] as const)("cached terminal data followed by a %s read is not fresh proof of closed", async (_label, failure) => {
    stateReplies = [closedState];
    const first = mount();
    await screen.findByTestId("close-server-closed");
    first.unmount();
    stateReplies = [failure];
    mount();
    await screen.findByTestId("close-state-unavailable");
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it("a read-only closed banner disappears when its refetch fails", async () => {
    stateReplies = [closedState];
    mount();
    await screen.findByTestId("close-server-closed");
    stateReplies = [unavailableState];
    await act(async () => { await queryClient.invalidateQueries({ queryKey: [STATE_URL] }); });
    await screen.findByTestId("close-state-unavailable");
    expect(screen.queryByTestId("close-server-closed")).toBeNull();
  });

  it("the panel's own verified POST proof is retained when a later refresh fails", async () => {
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    stateReplies = [unavailableState];
    await act(async () => { await queryClient.invalidateQueries({ queryKey: [STATE_URL] }); });
    await settle();
    expect(screen.getByTestId("close-server-closed")).toBeTruthy();
    expect(roundClosedEmits()).toHaveLength(1);
  });

  it("an existing funded round reads as terminal on mount, labelled Funded, with no close control", async () => {
    stateReplies = [stateBody({ state: "funded" })];
    mount();
    await screen.findByTestId("close-server-closed");
    expect(screen.getByTestId("panel-close-round").textContent).toMatch(/recorded this round as funded/);
    expect(screen.queryByTestId("button-commit-close")).toBeNull();
    expect(posts()).toHaveLength(0);
  });

  it("a terminal round with no recorded currency shows 'currency not recorded', never USD", async () => {
    stateReplies = [stateBody({ currency: null })];
    mount();
    await screen.findByTestId("close-server-closed");
    expect(screen.getByTestId("panel-close-round").textContent).toMatch(/in currency not recorded/);
    expect(screen.getByTestId("panel-close-round").textContent).not.toMatch(/USD/);
  });

  it("an alreadyClosed receipt with null currency is verified and shows 'currency not recorded'", async () => {
    closeReply = { status: 200, body: receipt({ alreadyClosed: true, durable: durable("closed", null) }) };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    expect(screen.getByTestId("panel-close-round").textContent).toMatch(/in currency not recorded/);
    expect(toastTitles()).toContain("Round already closed");
    expect(roundClosedEmits()).toHaveLength(0);
    expect(screen.getByTestId("panel-close-round").textContent).not.toMatch(/USD/);
  });
});

describe("CloseRoundPanel — U4 demo-reconciliation timer is bound to its context", () => {
  const reconToasts = () => toastTitles().filter((t) => t.startsWith("Reconciliation"));
  function seedUnreconciled() {
    seedReadyToClose({ reconciliation: undefined, founderSignoff: undefined, adminSignoff: undefined });
  }

  it("same context: Run reconciliation completes and stores the local preview result", async () => {
    seedUnreconciled();
    mount();
    await waitFor(() => expect(stateReads()).toBeGreaterThan(0));
    const run = await screen.findByTestId("button-run-recon");
    fireEvent.click(run);
    await waitFor(() => expect(reconToasts()).toHaveLength(1));
    expect(roundStore()!.reconciliation).toBeTruthy();
  });

  it.each([
    ["round replaced", "round"],
    ["actor replaced", "actor"],
    ["unmounted", "unmount"],
  ] as const)("a pending reconciliation timer after the context was %s stores nothing and toasts nothing", async (_label, how) => {
    seedUnreconciled();
    const view = mount();
    await waitFor(() => expect(stateReads()).toBeGreaterThan(0));
    const run = await screen.findByTestId("button-run-recon");
    /* Capture the panel's 200 ms reconciliation timer so it fires only AFTER
       the context change has really rendered/unmounted (deterministic). */
    const realSetTimeout = globalThis.setTimeout;
    let staleRecon: (() => void) | null = null;
    const fakeId = realSetTimeout(() => undefined, 0);
    const setSpy = vi.spyOn(globalThis, "setTimeout").mockImplementation(((fn: () => void, ms?: number, ...rest: unknown[]) => {
      if (ms === 200 && staleRecon === null) { staleRecon = fn; return fakeId; }
      return realSetTimeout(fn, ms, ...rest);
    }) as typeof setTimeout);
    const clearSpy = vi.spyOn(globalThis, "clearTimeout");
    fireEvent.click(run);
    setSpy.mockRestore();
    expect(staleRecon).not.toBeNull();
    if (how === "round") { view.rerender(tree(ROUND2)); await waitFor(() => expect(calls.some((c) => c.url === `/api/founder/rounds/${ROUND2}/close-state`)).toBe(true)); }
    else if (how === "actor") await switchActor(ACTOR2);
    else view.unmount();
    /* The replaced/unmounted instance cleared its timer ... */
    expect(clearSpy).toHaveBeenCalledWith(fakeId);
    clearSpy.mockRestore();
    /* ... and even if the stale callback still runs, its live guard stops it. */
    await act(async () => { staleRecon!(); });
    await act(async () => { await new Promise((r) => setTimeout(r, 400)); });
    expect(reconToasts()).toHaveLength(0);
    expect(roundStore()!.reconciliation).toBeUndefined();
    expect(roundStore(ROUND2)?.reconciliation).toBeUndefined();
  });
});

describe("CloseRoundPanel — U6 recorded close date is not an execution time", () => {
  const PLANNED = "2026-12-31";
  const mirrorBodies = () => calls.filter((c) => c.method === "POST" && c.url === "/api/admin/audit-log/append").map((c) => c.body as { payload?: Record<string, unknown> });

  it("a future planned close date is shown as the recorded close date, never as when the close happened", async () => {
    stateReplies = [stateBody({ closeDate: PLANNED })];
    mount();
    await screen.findByTestId("close-server-closed");
    expect(screen.getByTestId("close-recorded-close-date").textContent).toBe("Dec 31, 2026");
    expect(screen.getByTestId("close-execution-time-note").textContent).toMatch(/the time the close was performed is not shown here/);
    const text = screen.getByTestId("panel-close-round").textContent ?? "";
    expect(text).toMatch(/recorded this round as closed, in CAD/);
    expect(text).not.toMatch(/recorded this round as closed on/);
    expect(text).not.toMatch(/12\/30\/2026|Dec 30, 2026/);
  });

  it("a terminal round with no recorded close date says so", async () => {
    stateReplies = [stateBody({ closeDate: null })];
    mount();
    await screen.findByTestId("close-server-closed");
    expect(screen.getByTestId("close-recorded-close-date").textContent).toBe("not recorded");
    expect(screen.getByTestId("panel-close-round").textContent).not.toMatch(/a date not shown/);
  });

  it("a verified close with a future planned close date omits closedAt locally and in the sign-off mirror, clearing a stale value", async () => {
    seedReadyToClose({ closedAt: "2026-10-01T00:00:00.000Z" });
    closeReply = { status: 200, body: receipt({ durable: { ...durable(), closeDate: PLANNED } }) };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    expect(roundClosedEmits()).toHaveLength(1);
    expect(roundStore()!.closed).toBe(true);
    expect(roundStore()!).not.toHaveProperty("closedAt");
    await waitFor(() => expect(mirrorBodies().length).toBeGreaterThan(0));
    for (const b of mirrorBodies()) {
      expect(b.payload).toBeDefined();
      expect(b.payload!).not.toHaveProperty("closedAt");
      expect(JSON.stringify(b)).not.toContain(PLANNED);
    }
    expect(screen.getByTestId("close-recorded-close-date").textContent).toBe("Dec 31, 2026");
  });
});

describe("CloseRoundPanel — U6 local ledger entry time is its creation time, not the recorded close date", () => {
  it("the local round_close ledger entry is stamped within its local creation interval, not with a future planned close date", async () => {
    closeReply = { status: 200, body: receipt({ durable: { ...durable(), closeDate: "2026-12-31" } }) };
    mount();
    const btn = await readyButton();
    await waitFor(() => expect(btn.disabled).toBe(false));
    const entriesBefore = useSprint3.getState().ledger.entries.length;
    const before = Date.now();
    fireEvent.click(btn);
    await screen.findByTestId("close-server-closed");
    const after = Date.now();
    const added = useSprint3.getState().ledger.entries.slice(entriesBefore).filter((e) => e.type === "round_close");
    expect(added).toHaveLength(1);
    const ts = added[0]!.timestamp;
    expect(ts).not.toContain("2026-12-31");
    expect(Date.parse(ts)).toBeGreaterThanOrEqual(before);
    expect(Date.parse(ts)).toBeLessThanOrEqual(after);
  });
});
