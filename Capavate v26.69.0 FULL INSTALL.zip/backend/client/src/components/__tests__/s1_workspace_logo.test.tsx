// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router } from "wouter";
import type { ReactNode } from "react";
import { AppShell } from "../AppShell";
import { CollectiveShell } from "../CollectiveShell";
import { RoleProvider } from "@/lib/role";

let partner = true;
let chapters: Array<{id:string}> = [];
let ent = {
  identity: { name: "Multi-role Person" },
  isAdmin: true,
  founder: { companies: [{id:"co_s1"}] },
  investor: {state:"ACTIVE"},
};
const api = vi.fn();
vi.mock("@/lib/queryClient", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queryClient")>("@/lib/queryClient");
  return { ...actual, apiRequest: (...args: unknown[]) => api(...args) };
});
vi.mock("@/lib/entitlement", () => ({ useEntitlement: () => ({ data: ent }) }));
vi.mock("@/lib/useActiveCompany", () => ({ useActiveCompany: () => ({ data: {company:{kpi:{activeRoundsCount:0}}} }) }));
vi.mock("@/lib/partner/usePartnerMembership", () => ({
  usePartnerMembership: () => ({ ready:true, isPartner:partner,
    identity:partner ? { partnerId:"p_s1", tier:"catalyst", subRole:"managing_partner",
      identity:{userId:"u_s1",name:"Partner",email:"p@example.test"} } : null }),
}));
vi.mock("@/lib/legalDrawer", () => ({ useLegalDrawer: () => ({ openDrawer: vi.fn() }) }));
vi.mock("@/components/ChapterSelector", () => ({ ChapterSelector: () => null }));
vi.mock("@/components/feeds/MarketTicker", () => ({ MarketTicker: () => null }));
vi.mock("@/components/NotificationBell", () => ({ NotificationBell: () => null }));
vi.mock("@/components/CompanySwitcher", () => ({ CompanySwitcher: () => null }));
vi.mock("@/components/CapCollectiveToggle", () => ({ CapCollectiveToggle: () => null }));
vi.mock("@/components/LegalFooterLinks", () => ({ LegalFooterLinks: () => null }));
vi.mock("@/components/ArchivedWorkspaceBanner", () => ({ ArchivedWorkspaceBanner: () => null }));
vi.mock("@/components/AuditChainP0Banner", () => ({ AuditChainP0Banner: () => null }));
vi.mock("@/components/CollectiveMemberGate", () => ({
  CollectiveMemberGate: ({children}:{children:ReactNode}) => <>{children}</>,
}));

const response = (body:unknown) => ({ok:true,status:200,json:async()=>body}) as Response;
beforeEach(() => {
  partner = true; chapters = [];
  api.mockReset();
  api.mockImplementation(async (_method:string,url:string) => {
    if (url === "/api/me/chapters") return response({ok:true,chapters});
    if (url === "/api/feature-flags") return response({COLLECTIVE_ENABLED:true,PARTNER_WORKSPACE_ENABLED:true});
    if (url === "/api/investor/invitations") return response([]);
    return response({});
  });
});
afterEach(() => { cleanup(); vi.restoreAllMocks(); });
function mount(kind:"app"|"collective", route:string) {
  window.history.pushState({}, "", route);
  const qc = new QueryClient({defaultOptions:{queries:{retry:false,refetchOnWindowFocus:false,
    queryFn:async({queryKey})=>(await api("GET",String(queryKey[0]))).json()}}});
  render(<QueryClientProvider client={qc}><Router><RoleProvider>
    {kind === "app" ? <AppShell><div>Content</div></AppShell> : <CollectiveShell><div>Content</div></CollectiveShell>}
  </RoleProvider></Router></QueryClientProvider>);
}
function brandLink(brand:HTMLElement) {
  const a = brand.closest("a");
  expect(a?.tagName).toBe("A"); // real Wouter Link; not a mocked span.
  return a as HTMLAnchorElement;
}

describe("S1 real shell logo navigation", () => {
  it.each([
    ["/founder/company?step=3#legal","/founder/dashboard"],
    ["/investor/invitations?tab=active#round","/investor/dashboard"],
    ["/admin/users?filter=all#top","/admin/dashboard"],
  ])("AppShell on %s anchors its real logo to %s even for a multi-role session", (path,dashboard) => {
    mount("app",path);
    const anchor=brandLink(screen.getByTestId("link-home"));
    expect(anchor.getAttribute("href")).toBe(dashboard);
    expect(within(anchor).getByAltText(/Capavate/i)).toBeTruthy();
    fireEvent.click(anchor);
    expect(window.location.pathname).toBe(dashboard);
  });

  it.each([
    ["/collective/partner/managed-founders?view=all#mode","/collective/partner/dashboard","Consortium Partner"],
    ["/collective/posts?tab=new#top","/collective/dashboard","Collective"],
  ])("CollectiveShell on %s preserves the brand label and navigates %s",async(path,dashboard,label)=>{
    partner = label === "Consortium Partner";
    mount("collective",path);
    const block=screen.getByTestId("brand-block");
    const anchor=brandLink(block);
    expect(anchor.getAttribute("href")).toBe(dashboard);
    expect(within(block).getByTestId("brand-product-label").textContent).toBe(label);
    expect(within(block).getByAltText(/Capavate/i)).toBeTruthy();
    fireEvent.click(anchor);
    expect(window.location.pathname).toBe(dashboard);
  });

  it("dual-role partner + Collective member still routes by workspace, not the role switch",async()=>{
    chapters=[{id:"chapter_s1"}];
    mount("collective","/collective/partner/managed-founders");
    await waitFor(()=>expect(screen.getByTestId("brand-product-label").textContent).toBe("Consortium Partner"));
    expect(brandLink(screen.getByTestId("brand-block")).getAttribute("href")).toBe("/collective/partner/dashboard");
  });

  it("mobile brand click closes exactly one overlay; separate close button remains operable",()=>{
    mount("collective","/collective/partner/managed-founders");
    fireEvent.click(screen.getByTestId("button-mobile-menu"));
    const brands=screen.getAllByTestId("brand-block");
    expect(brands).toHaveLength(2);
    const mobile=brandLink(brands[1]);
    expect(mobile.getAttribute("href")).toBe("/collective/partner/dashboard");
    fireEvent.click(mobile);
    expect(window.location.pathname).toBe("/collective/partner/dashboard");
    expect(screen.getAllByTestId("brand-block")).toHaveLength(1);
    fireEvent.click(screen.getByTestId("button-mobile-menu"));
    expect(screen.getAllByTestId("brand-block")).toHaveLength(2);
    fireEvent.click(screen.getByTestId("button-close-sidebar"));
    expect(screen.getAllByTestId("brand-block")).toHaveLength(1);
  });
});
