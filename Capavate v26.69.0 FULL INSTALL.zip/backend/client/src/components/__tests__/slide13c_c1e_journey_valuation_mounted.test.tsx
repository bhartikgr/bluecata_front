import React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { fmtUSD } from "@/lib/format";
import { readRoundMoneyOnRecord } from "@shared/roundMoneyOnRecordView";
import { founderHoldingVerdict } from "@/lib/captable/founderHoldingOnRecord";
import { countCapTableHolders } from "@/lib/captable/capTableHolderCount";
import {
  OWNERSHIP_UNDEFINED, ownershipPercentCellText, sumOwnershipPercent,
} from "@/lib/captable/ownershipPercent";

const dotCoordinates = vi.hoisted(() => ({ cx: 50 as number | null, cy: 60 as number | null }));
const engineObservations = vi.hoisted(() => [] as Array<{
  args: unknown[];
  result?: unknown;
  error?: unknown;
}>);
vi.mock("@/lib/engineDemo", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/engineDemo")>();
  return {
    ...actual,
    runEngine: (...args: Parameters<typeof actual.runEngine>) => {
      const detachedArgs = structuredClone(args);
      try {
        const result = actual.runEngine(...args);
        engineObservations.push({ args: detachedArgs, result: structuredClone(result) });
        return result;
      } catch (error) {
        engineObservations.push({ args: detachedArgs, error });
        throw error;
      }
    },
  };
});
vi.mock("recharts", async () => {
  const React = await import("react");
  const ChartRows = React.createContext<any[]>([]);
  const wrap = (tag: string) => ({ children, data, dataKey, connectNulls, tickFormatter, formatter, content, dot }: any) => {
    const parentRows = React.useContext(ChartRows);
    const currentRows = data ?? parentRows;
    const body = (
    <div data-chart-node={tag} data-chart-key={dataKey} data-connect-nulls={String(connectNulls)}
      data-chart-data={data ? JSON.stringify(data.map((r: any) => ({
        id: r.id, preMoneyPlot: r.preMoneyPlot, postMoneyPlot: r.postMoneyPlot,
        cumulativeRaised: r.cumulativeRaised, stepUp: r.stepUp,
        ...(tag === "AreaChart" ? {
          date: r.date, roundName: r.roundName, founder: r.founder, pool: r.pool,
          preferred: r.preferred, safe: r.safe, note: r.note, warrant: r.warrant,
          common: r.common,
        } : {}),
      }))) : undefined}
      data-tick={tickFormatter ? tickFormatter(50) : undefined}
      data-tooltip-bar={formatter && currentRows[0] ? String(formatter(50, "Cumulative raised", { dataKey: "cumulativeRaised", payload: currentRows[0] })?.[0]) : undefined}
      data-tooltip-post={formatter && currentRows[0] ? String(formatter(50, "Post-money valuation", { dataKey: "postMoneyPlot", payload: currentRows[0] })?.[0]) : undefined}>
      {content && currentRows[0]?.valuation ? React.cloneElement(content as React.ReactElement<any>, { active: true, payload: [{ payload: currentRows[0] }] }) : null}
      {typeof dot === "function" && currentRows.map((entry, index) =>
        <React.Fragment key={entry.id}>{dot({ payload: entry, index, cx: dotCoordinates.cx === null ? null : dotCoordinates.cx + index, cy: dotCoordinates.cy })}</React.Fragment>)}
      {children}
    </div>
    );
    return data ? <ChartRows.Provider value={currentRows}>{body}</ChartRows.Provider> : body;
  };
  return Object.fromEntries([
    "ResponsiveContainer", "ComposedChart", "Line", "XAxis", "YAxis", "CartesianGrid",
    "Tooltip", "Area", "AreaChart", "ReferenceLine", "Legend", "Bar",
  ].map(key => [key, wrap(key)]));
});

class ResizeObserverStub {
  observe() {}
  disconnect() {}
  unobserve() {}
}
(globalThis as unknown as { ResizeObserver: unknown }).ResizeObserver = ResizeObserverStub;

import CapitalizationJourney from "../CapitalizationJourney";
import { roundMoneyOnRecord } from "../../../../server/lib/roundRaisedTotals";

const companyId = "co_c1e_fixture";
const security = {
  id: "s_c1e", companyId, holderName: "Fictional Founder", holderType: "founder",
  instrument: "common", series: null, shares: 100, pricePerShare: 1,
  investmentAmount: 100, cap: null, discount: null, issuedAt: "2026-01-01",
};
const row = (id: string, closeDate: unknown, preMoney: unknown, postMoney: unknown, currency: unknown) => ({
  id, companyId, name: id, type: "seed", state: "closed", closeDate, openDate: "2026-01-01",
  preMoney, postMoney, targetAmount: 0, currency,
  moneyOnRecord: roundMoneyOnRecord({
    roundId: id,
    rows: [{ id: `sc_${id}`, roundId: id, status: "confirmed", currency: "CAD", amountMinor: 10000 }],
    roundCurrency: "CAD",
    targetAmount: 1000,
  }),
});

function mount(input: unknown[]) {
  vi.stubGlobal("fetch", vi.fn(async () => ({ ok: true, status: 200, json: async () => [security] })) as unknown as typeof fetch);
  const query = new QueryClient({ defaultOptions: { queries: { retry: false,
    queryFn: async ({ queryKey }) => queryKey[0] === "/api/rounds" ? input : [security],
  } } });
  return render(<QueryClientProvider client={query}><TooltipProvider>
    <CapitalizationJourney companyId={companyId} />
  </TooltipProvider></QueryClientProvider>);
}
function charts() {
  return [...document.querySelectorAll('[data-chart-node="ComposedChart"]')] as HTMLElement[];
}
function nodes(kind: string) {
  return [...document.querySelectorAll(`[data-chart-node="${kind}"]`)] as HTMLElement[];
}
function cardTargetValue(id: string) {
  const card = screen.getByTestId(`journey-card-target-${id}`);
  const value = card.querySelector("div.font-mono.tabular-nums.font-medium") as HTMLElement | null;
  expect(value).toBeTruthy();
  return value!;
}
function firstRowTooltipTargetValue() {
  const tooltip = nodes("Tooltip").find(node => node.textContent?.includes("Round size"));
  expect(tooltip).toBeTruthy();
  const values = tooltip!.querySelectorAll("span.font-mono.font-medium");
  expect(values.length).toBeGreaterThanOrEqual(3);
  return values[2] as HTMLElement;
}
function preMoneyLine() {
  return document.querySelector('[data-chart-node="Line"][data-chart-key="preMoneyPlot"]') as HTMLElement | null;
}
function subscribedDisplay(input: unknown) {
  const view = readRoundMoneyOnRecord(input);
  return view.canPrintFigures && view.money ? view.money.subscribedDisplay : "—";
}
function assertCardMoney(input: { id: string; moneyOnRecord?: unknown }) {
  expect(screen.getByTestId(`journey-card-money-${input.id}`).textContent)
    .toBe(subscribedDisplay(input.moneyOnRecord));
}
function assertOwnershipFromObservedEngine(observations: typeof engineObservations) {
  const current = observations.filter(v => v.args.length === 3 && v.result);
  expect(current.length).toBeGreaterThan(0);
  const fd = current[0].result as ReturnType<typeof import("@/lib/engineDemo").runEngine>;
  const verdict = founderHoldingVerdict(fd.rows, fd.totalShares as unknown as bigint);
  const percentage = verdict.refuse ? OWNERSHIP_UNDEFINED :
    ownershipPercentCellText(sumOwnershipPercent(fd.rows.filter(v => v.holderType === "founder")));
  const label = percentage === OWNERSHIP_UNDEFINED ? percentage : `${percentage}%`;
  expect(screen.getByText("Founder ownership").parentElement?.parentElement?.textContent).toContain(label);
  expect(screen.getByText("Cap-table holders").parentElement?.parentElement?.textContent)
    .toContain(String(countCapTableHolders(fd.rows)));
}
const transcriptText = (value: unknown) => JSON.stringify(
  value,
  (_key, item) => typeof item === "bigint" ? `${item.toString()}n` : item,
);
const observationFamilies = (observations: typeof engineObservations) => {
  const families = new Map<string, string[]>();
  for (const observation of observations) {
    const key = transcriptText(observation.args);
    const values = families.get(key) ?? [];
    values.push(transcriptText(observation.result ?? { error: observation.error }));
    families.set(key, values);
  }
  return families;
};
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  dotCoordinates.cx = 50;
  dotCoordinates.cy = 60;
  engineObservations.length = 0;
});

describe("C1E real mounted Journey with observable Recharts props", () => {
  it("shows exact CAD terms, a known zero and two independent lines while retaining engine/KPI/cards", async () => {
    mount([row("prior", "2026-01-01T10:20:30.123Z", 0, 100, "CAD"),
      { ...row("later", "2026-02-01", 150, 200, "CAD"), targetAmount: 1000 }]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const first = JSON.parse(charts()[0].dataset.chartData!);
    const second = JSON.parse(charts()[1].dataset.chartData!);
    expect(first.map((r: any) => r.preMoneyPlot)).toEqual([0, 150]);
    expect(second.map((r: any) => r.postMoneyPlot)).toEqual([100, 200]);
    expect(second[1].stepUp).toBe(0.5);
    expect(nodes("Line").map(n => n.dataset.chartKey)).toEqual(["preMoneyPlot", "postMoneyPlot"]);
    expect(nodes("Line").every(n => n.dataset.connectNulls === "false")).toBe(true);
    expect(nodes("YAxis").some(n => n.dataset.tick === "CAD 50")).toBe(true);
    expect(nodes("Tooltip")[0].textContent).toContain("CAD 0.00");
    expect(nodes("Tooltip")[1].dataset.tooltipPost).toBe("CAD 100.00");
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent).toContain("CAD 200.00");
    expect(screen.getByTestId("journey-card-prior").textContent).toContain("CAD 0.00");
    expect(screen.getByTestId("journey-card-prior").textContent).toContain("2026-01-01T10:20:30.123Z UTC");
    expect(screen.getByTestId("journey-card-later").textContent).toContain("Step-up vs prior");
    expect(screen.getByTestId("journey-card-target-later").textContent).toContain("CAD 1000.00");
    assertCardMoney(row("prior", "2026-01-01T10:20:30.123Z", 0, 100, "CAD"));
    assertCardMoney({ ...row("later", "2026-02-01", 150, 200, "CAD"), targetAmount: 1000 });
    expect(screen.getByText("Founder ownership")).toBeTruthy();
    expect(screen.getByText("Cap-table holders")).toBeTruthy();
    expect(screen.getByTestId("journey-composition-denominator")).toBeTruthy();
    expect(document.querySelector('a[href="/founder/rounds/later"]')).toBeTruthy();
  });

  it("routes CAD subscribed and USD post-money independently; retains the subscribed bar", async () => {
    mount([row("single", "2026-01-01", 100, 200, "USD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(nodes("YAxis").some(n => n.dataset.tick === "USD 50")).toBe(true);
    expect(nodes("Bar").some(n => n.dataset.chartKey === "cumulativeRaised")).toBe(true);
    expect(nodes("YAxis")[1].dataset.tick).toBe(fmtUSD(50, { compact: true, currency: "CAD" }));
    expect(nodes("YAxis")[1].dataset.tick).not.toBe(fmtUSD(50, { compact: true, currency: "USD" }));
    expect(nodes("Tooltip")[1].dataset.tooltipBar).toBe(fmtUSD(50, { compact: true, currency: "CAD" }));
    expect(nodes("Tooltip")[1].dataset.tooltipBar).not.toBe(fmtUSD(50, { compact: true, currency: "USD" }));
    expect(nodes("Tooltip")[1].dataset.tooltipPost).toBe("USD 200.00");
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent).toContain("USD 200.00");
  });

  it("withholds only mixed valuation lines, never hides round cards, links or subscription panel", async () => {
    mount([row("usd", "2026-01-01", 100, 200, "USD"), row("cad", "2026-02-01", 150, 300, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(screen.getByTestId("journey-pre-curve-unavailable").textContent).toContain("mixed valuation currencies");
    expect(screen.getByTestId("journey-post-curve-unavailable").textContent).toContain("mixed valuation currencies");
    expect(screen.getByTestId("journey-post-legend-unavailable").textContent).toContain("unavailable");
    expect(nodes("Line")).toHaveLength(0);
    expect(nodes("Bar")).toHaveLength(1);
    expect(screen.getByTestId("journey-card-usd").textContent).toContain("USD 100.00");
    expect(screen.getByTestId("journey-card-cad").textContent).toContain("CAD 300.00");
    expect(screen.getByTestId("stepup-cad").textContent).toContain("unavailable");
    expect(screen.getByText("Founder ownership")).toBeTruthy();
  });

  it("retains rows and refuses unknown date, tied latest, absent latest post-money and invalid intermediate chronology", async () => {
    mount([row("a", "2026-01-01", 100, 200, "CAD"),
      row("unknown", "not-a-date", 120, 230, "CAD"),
      row("latest", "2026-02-01", 150, null, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(screen.getByTestId("journey-pre-curve-unavailable").textContent).toContain("date unavailable");
    expect(screen.getByTestId("stepup-latest").textContent).toContain("date unavailable");
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent).toContain("Post-money not on record");
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent).toContain("excluded");
    expect(screen.getByTestId("journey-card-unknown")).toBeTruthy();
  });

  it("tied UTC day with mixed date shapes has no latest pulse or comparable point", async () => {
    mount([row("one", "2026-01-01", 100, 200, "CAD"),
      row("two", "2026-01-01T20:00:00.000Z", 150, 250, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent).toContain("Latest dated round is not unique");
    expect(JSON.parse(charts()[0].dataset.chartData!).map((r: any) => r.preMoneyPlot)).toEqual([null, null]);
    expect(screen.getByTestId("journey-pre-curve-unavailable").textContent).toContain("no comparable valuation points");
    expect(screen.getByTestId("stepup-two").textContent).toContain("unavailable");
    expect(preMoneyLine()).toBeNull();
  });

  it("pulses the unique latest active recorded point, not an array-position fallback", async () => {
    mount([{ ...row("later", "2026-02-01", 150, 250, "CAD"), state: "active" },
      row("earlier", "2026-01-01", 100, 200, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent).toContain("later");
    const preLine = preMoneyLine();
    expect(preLine).toBeTruthy();
    expect(preLine!.querySelectorAll('circle animate[attributeName="r"]')).toHaveLength(1);
  });
  it("retains independently validated denomination, target refusal, and subscribed coordinates on absent or malformed valuation", async () => {
    mount([
      { ...row("absent", "2026-01-01", null, null, "CAD"), targetAmount: null },
      { ...row("malformed", "2026-02-01", "bad", 12.345, "CAD"), targetAmount: 0 },
    ]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const plotted = JSON.parse(charts()[0].dataset.chartData!);
    const subscribed = JSON.parse(charts()[1].dataset.chartData!);
    expect(plotted.map((v: any) => v.preMoneyPlot)).toEqual([null, null]);
    expect(subscribed.map((v: any) => v.cumulativeRaised)).toEqual([100, 200]);
    expect(screen.getByTestId("journey-card-absent").textContent).toContain("Pre-money not on record");
    expect(screen.getByTestId("journey-card-absent").textContent).toContain("Recorded denomination: CAD");
    expect(screen.getByTestId("journey-card-malformed").textContent).toContain("Pre-money unavailable: amount invalid");
    expect(screen.getByTestId("journey-card-malformed").textContent).toContain("Post-money unavailable: precision unproved");
    const absentTarget = "Round target not on record — goal, not a limit";
    const zeroTarget = "Round target unavailable: zero may represent an absent target — goal, not a limit";
    expect(screen.getByTestId("journey-card-target-absent").textContent).toContain("Round target not on record");
    expect(screen.getByTestId("journey-card-target-malformed").textContent)
      .toContain("Round target unavailable: zero may represent an absent target");
    expect(cardTargetValue("absent").textContent).toBe(absentTarget);
    expect(cardTargetValue("malformed").textContent).toBe(zeroTarget);
    expect(firstRowTooltipTargetValue().textContent).toBe(absentTarget);
    for (const value of [cardTargetValue("absent"), cardTargetValue("malformed"), firstRowTooltipTargetValue()])
      expect(value.textContent?.match(/ — goal, not a limit/g)).toHaveLength(1);
    expect(screen.getByTestId("journey-card-target-absent").textContent).toContain("Round target (not a limit)");
    expect(nodes("Tooltip").find(node => node.textContent?.includes("Round size"))?.textContent)
      .toContain("(target, not a limit)");
    expect(screen.getByTestId("journey-card-target-malformed").textContent).toContain("Recorded denomination: CAD");
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent)
      .toContain("Recorded denomination: CAD");
    expect(nodes("Tooltip")[0].textContent).toContain("Recorded denomination: CAD");
    expect(nodes("Bar")).toHaveLength(1);
    expect(screen.getByTestId("journey-card-absent").textContent).toContain("Subscribed");
    assertCardMoney({ ...row("absent", "2026-01-01", null, null, "CAD"), targetAmount: null });
    assertCardMoney({ ...row("malformed", "2026-02-01", "bad", 12.345, "CAD"), targetAmount: 0 });
    expect(screen.getByTestId("journey-card-founders-absent")).toBeTruthy();
    expect(screen.getByText("Founder ownership")).toBeTruthy();
    expect(screen.getByText("Cap-table holders")).toBeTruthy();
    for (const cell of [
      screen.getByTestId("journey-card-absent").querySelectorAll("div.font-mono.tabular-nums.font-medium")[0],
      screen.getByTestId("journey-card-absent").querySelectorAll("div.font-mono.tabular-nums.font-medium")[1],
      screen.getByTestId("journey-card-money-absent"),
    ]) expect(cell?.textContent).not.toContain("goal, not a limit");
  });
  it("renders the complete zero-target refusal in both first-row card and tooltip values", async () => {
    mount([{ ...row("zero-first", "2026-01-01", 100, 200, "CAD"), targetAmount: 0 }]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const expected = "Round target unavailable: zero may represent an absent target — goal, not a limit";
    const cardValue = cardTargetValue("zero-first");
    const tooltipValue = firstRowTooltipTargetValue();
    expect(cardValue.textContent).toBe(expected);
    expect(tooltipValue.textContent).toBe(expected);
    expect(cardValue.textContent?.match(/ — goal, not a limit/g)).toHaveLength(1);
    expect(tooltipValue.textContent?.match(/ — goal, not a limit/g)).toHaveLength(1);
    expect(screen.getByTestId("journey-card-target-zero-first").textContent)
      .toContain("Round target (not a limit)");
    expect(nodes("Tooltip").find(node => node.textContent?.includes("Round size"))?.textContent)
      .toContain("(target, not a limit)");
    expect(screen.getByTestId("journey-card-money-zero-first").textContent).not.toContain("goal, not a limit");
    expect(screen.getByTestId("journey-card-zero-first").textContent).toContain("Subscribed");
  });
  it("refuses a plot for unknown denomination even when its amount is absent, without borrowing the neighbor's code", async () => {
    mount([row("known", "2026-01-01", 100, 200, "CAD"),
      { ...row("unknown-code", "2026-02-01", null, null, null), targetAmount: null }]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(screen.getByTestId("journey-pre-curve-unavailable").textContent).toContain("valuation currency unavailable");
    expect(screen.getByTestId("journey-post-curve-unavailable").textContent).toContain("valuation currency unavailable");
    expect(screen.getByTestId("journey-card-unknown-code").textContent).toContain("Pre-money not on record");
    expect(screen.getByTestId("journey-card-unknown-code").textContent).not.toContain("Recorded denomination: CAD");
    expect(JSON.parse(charts()[1].dataset.chartData!).map((v: any) => v.cumulativeRaised)).toEqual([100, 200]);
  });
  it("admits pre-money independently of an entirely absent post-money plot with retained null coordinates", async () => {
    mount([row("pre-only", "2026-01-01", 100, null, "CAD"),
      row("pre-next", "2026-02-01", 200, null, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const preRows = JSON.parse(charts()[0].dataset.chartData!);
    const postRows = JSON.parse(charts()[1].dataset.chartData!);
    expect(preRows.map((v: any) => v.preMoneyPlot)).toEqual([100, 200]);
    expect(postRows.map((v: any) => v.postMoneyPlot)).toEqual([null, null]);
    expect(nodes("Line").map(n => n.dataset.chartKey)).toEqual(["preMoneyPlot"]);
    expect(screen.getByTestId("journey-post-legend-unavailable").textContent).toContain("unavailable");
    expect(screen.getByTestId("journey-card-pre-next").textContent).toContain("Post-money not on record");
  });
  it("admits post-money independently of an entirely absent pre-money plot with retained subscription routing", async () => {
    const inputs = [row("post-only", "2026-01-01", null, 100, "CAD"),
      row("post-next", "2026-02-01", null, 200, "CAD")];
    mount(inputs);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const preRows = JSON.parse(charts()[0].dataset.chartData!);
    const postRows = JSON.parse(charts()[1].dataset.chartData!);
    expect(preRows.map((v: any) => v.preMoneyPlot)).toEqual([null, null]);
    expect(postRows.map((v: any) => v.postMoneyPlot)).toEqual([100, 200]);
    expect(nodes("Line").map(n => n.dataset.chartKey)).toEqual(["postMoneyPlot"]);
    expect(screen.getByTestId("journey-pre-curve-unavailable").textContent)
      .toBe("Pre-money curve unavailable: no comparable valuation points");
    expect(screen.queryByTestId("journey-post-legend-unavailable")).toBeNull();
    expect(nodes("YAxis").some(n => n.dataset.tick === "CAD 50")).toBe(true);
    expect(nodes("Tooltip")[1].dataset.tooltipPost).toBe("CAD 100.00");
    expect(nodes("Bar").some(n => n.dataset.chartKey === "cumulativeRaised")).toBe(true);
    expect(screen.getByTestId("journey-card-post-only").textContent).toContain("Pre-money not on record");
    expect(screen.getByTestId("journey-card-post-only").textContent).toContain("Recorded denomination: CAD");
    inputs.forEach(assertCardMoney);
  });
  it("keeps admitted CAD valuation beside mixed and undetermined subscribed totals", async () => {
    const usd = row("sub-usd", "2026-02-01", 200, 300, "CAD");
    usd.moneyOnRecord = roundMoneyOnRecord({
      roundId: usd.id, rows: [{ id: "sc_sub-usd", roundId: usd.id, status: "confirmed",
        currency: "USD", amountMinor: 10000 }], roundCurrency: "USD", targetAmount: 1000,
    });
    mount([row("sub-cad", "2026-01-01", 100, 200, "CAD"), usd]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(JSON.parse(charts()[0].dataset.chartData!).map((v: any) => v.preMoneyPlot)).toEqual([100, 200]);
    expect(JSON.parse(charts()[1].dataset.chartData!).map((v: any) => v.cumulativeRaised)).toEqual([null, null]);
    expect(nodes("Line").map(n => n.dataset.chartKey)).toEqual(["preMoneyPlot", "postMoneyPlot"]);
    const usdView = readRoundMoneyOnRecord(usd.moneyOnRecord);
    expect(usdView.canPrintFigures).toBe(true);
    expect(usdView.money).not.toBeNull();
    expect(usdView.money?.currency).toBe("USD");
    expect(screen.getByTestId("journey-card-money-sub-usd").textContent)
      .toBe(subscribedDisplay(usd.moneyOnRecord));
    assertCardMoney(row("sub-cad", "2026-01-01", 100, 200, "CAD"));
    assertCardMoney(usd);
    cleanup();
    mount([row("determined", "2026-01-01", 100, 200, "CAD"),
      { ...row("no-subscription", "2026-02-01", 200, 300, "CAD"), moneyOnRecord: null }]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(JSON.parse(charts()[0].dataset.chartData!).map((v: any) => v.preMoneyPlot)).toEqual([100, 200]);
    expect(JSON.parse(charts()[1].dataset.chartData!).map((v: any) => v.cumulativeRaised)).toEqual([100, null]);
    expect(screen.getByTestId("journey-card-no-subscription").textContent).toContain("CAD 200.00");
    expect(screen.getByTestId("journey-card-money-no-subscription").textContent).toBe("—");
    assertCardMoney({ ...row("no-subscription", "2026-02-01", 200, 300, "CAD"), moneyOnRecord: null });
  });
  it("uses guarded valuation name, state, archive, Lead and Investors branches without hiding valid neighbor", async () => {
    mount([
      { ...row("bad", "2026-01-01", 1, 2, "CAD"), name: { invalid: true },
        state: { invalid: true }, archivedAt: {}, leadInvestor: {},
        investorCount: Infinity, type: {}, targetAmount: null },
      { ...row("valid", "2026-02-01", 3, 4, "CAD"), name: "Recorded Round",
        archivedAt: "2026-04-01", leadInvestor: "Fictional Lead", investorCount: 2 },
    ]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const badCard = screen.getByTestId("journey-card-bad").textContent!;
    expect(badCard).toContain("Round name unavailable");
    expect(badCard).toContain("Round state unavailable");
    expect(badCard).toContain("Round type unavailable");
    expect(badCard).not.toContain("[object Object]");
    expect(badCard).not.toContain("Archived");
    expect(badCard).not.toContain("Lead");
    expect(screen.getByTestId("stepup-bad").textContent).toContain("Round name unavailable");
    const validCard = screen.getByTestId("journey-card-valid").textContent!;
    expect(validCard).toContain("Recorded Round");
    expect(validCard).toContain("Archived");
    expect(validCard).toContain("Fictional Lead");
    expect(validCard).toContain("2 investors");
    expect(nodes("Tooltip")[0].textContent).not.toContain("[object Object]");
    expect(nodes("Tooltip")[0].textContent).not.toContain("Lead");
    expect(nodes("Tooltip")[0].textContent).not.toContain("Investors");
  });
  it("does not draw invalid or null dot coordinates and does not pulse an admitted plot with tied latest day", async () => {
    dotCoordinates.cx = null;
    mount([row("one", "2026-01-01", 10, 20, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(preMoneyLine()).toBeTruthy();
    expect(preMoneyLine()!.querySelectorAll("circle")).toHaveLength(0);
    cleanup();
    dotCoordinates.cx = NaN;
    mount([row("nonfinite", "2026-01-01", 10, 20, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(preMoneyLine()).toBeTruthy();
    expect(preMoneyLine()!.querySelectorAll("circle")).toHaveLength(0);
    cleanup();
    dotCoordinates.cx = 50;
    mount([row("earlier", "2026-01-01", 10, 20, "CAD"),
      row("tie-a", "2026-02-01", 30, 40, "CAD"),
      row("tie-b", "2026-02-01T12:00:00.000Z", 50, 60, "CAD")]);
    await waitFor(() => expect(charts()).toHaveLength(2));
    expect(preMoneyLine()).toBeTruthy();
    expect(JSON.parse(charts()[0].dataset.chartData!).map((v: any) => v.preMoneyPlot)).toEqual([10, null, null]);
    expect(preMoneyLine()!.querySelectorAll("circle")).toHaveLength(1);
    expect(preMoneyLine()!.querySelector('circle animate[attributeName="r"]')).toBeNull();
    expect(screen.getByText("Latest valuation").parentElement?.parentElement?.textContent)
      .toContain("Latest dated round is not unique");
  });
  it("preserves real engine, snapshots, ownership and subscribed projections when only valuation display terms refuse", async () => {
    const admitted = [row("matched-a", "2026-01-01", 100, 200, "CAD"),
      row("matched-b", "2026-02-01", 200, 300, "CAD")];
    const refused = admitted.map(item => ({ ...item, preMoney: null, postMoney: null }));

    mount(admitted);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const admittedEngine = structuredClone(engineObservations);
    const admittedOwnership = screen.getByText("Founder ownership").parentElement?.parentElement?.textContent;
    const admittedHolders = screen.getByText("Cap-table holders").parentElement?.parentElement?.textContent;
    const admittedSnapshots = nodes("AreaChart")[0].dataset.chartData;
    expect(JSON.parse(admittedSnapshots ?? "[]")).toHaveLength(2);
    assertOwnershipFromObservedEngine(admittedEngine);
    admitted.forEach(assertCardMoney);
    expect(admittedEngine.length).toBeGreaterThan(0);
    expect(new Set(admittedEngine.filter(v => v.args.length === 5)
      .map(v => transcriptText(v.args))).size).toBe(2);
    expect(admittedEngine.every(v => {
      const result = v.result as { rows?: unknown[]; totalShares?: bigint } | undefined;
      return Array.isArray(result?.rows) && result.rows.length > 0 && typeof result.totalShares === "bigint";
    })).toBe(true);

    cleanup();
    engineObservations.length = 0;
    mount(refused);
    await waitFor(() => expect(charts()).toHaveLength(2));
    const refusedEngine = structuredClone(engineObservations);
    refused.forEach(assertCardMoney);
    expect(refusedEngine.length).toBeGreaterThan(0);
    expect(new Set(refusedEngine.filter(v => v.args.length === 5)
      .map(v => transcriptText(v.args))).size).toBe(2);
    expect(refusedEngine.every(v => {
      const result = v.result as { rows?: unknown[]; totalShares?: bigint } | undefined;
      return Array.isArray(result?.rows) && result.rows.length > 0 && typeof result.totalShares === "bigint";
    })).toBe(true);
    expect(screen.getByTestId("journey-pre-curve-unavailable").textContent)
      .toContain("no comparable valuation points");
    expect(screen.getByTestId("journey-post-curve-unavailable").textContent)
      .toContain("no comparable valuation points");
    expect(nodes("Line")).toHaveLength(0);
    expect(screen.getByText("Founder ownership").parentElement?.parentElement?.textContent).toBe(admittedOwnership);
    expect(screen.getByText("Cap-table holders").parentElement?.parentElement?.textContent).toBe(admittedHolders);
    expect(nodes("AreaChart")[0].dataset.chartData).toBe(admittedSnapshots);
    assertOwnershipFromObservedEngine(refusedEngine);

    const admittedFamilies = observationFamilies(admittedEngine);
    const refusedFamilies = observationFamilies(refusedEngine);
    expect([...refusedFamilies.keys()].sort()).toEqual([...admittedFamilies.keys()].sort());
    for (const [key, results] of admittedFamilies) {
      expect(new Set(results).size).toBe(1);
      expect(new Set(refusedFamilies.get(key)).size).toBe(1);
      expect(refusedFamilies.get(key)?.[0]).toBe(results[0]);
    }
    console.log("C1E_REAL_ENGINE_TRANSCRIPT", transcriptText({
      admitted: admittedEngine,
      refused: refusedEngine,
    }));
  });
});
