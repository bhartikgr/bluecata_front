// @vitest-environment jsdom
/**
 * Wish List W2: SHELL COVERAGE. Independent reviewer test (Opus).
 *
 * The real AppShell and CollectiveShell are mounted, with real wouter routing,
 * the real RoleProvider, real React Query, the real Radix Sheet and the real
 * Collective mobile overlay. Unrelated widgets and hooks are stubbed the same
 * way as s1_workspace_logo.test.tsx.
 *
 * STRUCTURAL MOCK (clearly labelled): `@/components/wishlist/WishList` is
 * replaced by a recording Provider/Launcher pair. The pair keeps the real
 * provider -> launcher context relationship, so a launcher outside a provider,
 * or under a second provider, is detected. The REAL modal, network and
 * submission behaviour is tested separately in the Wish List component tests.
 * This file only proves the shell wiring.
 *
 * Proved here:
 *  §1 exactly ONE provider per shell; the desktop and mobile launchers are both
 *     wired to that same provider instance.
 *  §2 the mobile launcher's beforeOpen closes the drawer, and returnFocusRef is
 *     the STABLE ref of the real menu button. The desktop launcher gets neither.
 *  §3 surface, locator and sourceRouteKey come from the ACTUAL path: founder,
 *     investor, admin, account, Collective and partner, including the
 *     /collective/partners directory case.
 *  §4 the founder company comes from the real /api/founder/active-company query,
 *     never from localStorage or the useActiveCompany cache.
 *  §5 contextReady is false while fetching and on error (an error never falls
 *     through to the null-company state); it is true after a successful server
 *     200, including a 200 with a null/empty company (WIRE line 21: the server
 *     resolves founder:onboarding / user scope and does its own eligibility checks).
 *     Non-founder surfaces never fetch it.
 *  §6 preservation: legal/privacy control, navigation and account controls stay
 *     mounted. Every baseline (46ebb62) href and data-testid is still in source.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, act } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router } from "wouter";
import fs from "node:fs";
import path from "node:path";
import type { ReactNode } from "react";

/* ---------------- structural WishList mock (recording) ---------------- */
type ProviderRecord = { id: number; locator: any; sourceRouteKey: string | undefined; product: string; contextReady: boolean };
type OpenRecord = { providerId: number | null; hadBeforeOpen: boolean; returnFocusRef: any };
const wl = vi.hoisted(() => ({
  nextId: 1,
  renders: [] as ProviderRecord[],
  mounted: new Set<number>(),
  opens: [] as OpenRecord[],
}));
vi.mock("@/components/wishlist/WishList", async () => {
  const React = await import("react");
  const Ctx = React.createContext<number | null>(null);
  function WishListProvider(props: { locator: any; sourceRouteKey?: string; product: string; contextReady?: boolean; children: ReactNode }) {
    const idRef = React.useRef<number>(0);
    if (idRef.current === 0) idRef.current = wl.nextId++;
    const id = idRef.current;
    wl.renders.push({ id, locator: props.locator, sourceRouteKey: props.sourceRouteKey, product: props.product, contextReady: props.contextReady ?? true });
    React.useEffect(() => { wl.mounted.add(id); return () => { wl.mounted.delete(id); }; }, [id]);
    return React.createElement(Ctx.Provider, { value: id }, props.children);
  }
  function WishListLauncher(props: { beforeOpen?: () => void; returnFocusRef?: any }) {
    const providerId = React.useContext(Ctx);
    return React.createElement("button", {
      type: "button",
      "data-testid": "button-wishlist",
      "data-provider": providerId === null ? "none" : String(providerId),
      onClick: () => {
        wl.opens.push({ providerId, hadBeforeOpen: typeof props.beforeOpen === "function", returnFocusRef: props.returnFocusRef });
        props.beforeOpen?.();
      },
    }, "Wish List");
  }
  return { WishListProvider, WishListLauncher };
});

/* ---------------- unrelated widgets/hooks (same stubs as s1) ---------------- */
let partner = false;
const openDrawer = vi.fn();
const api = vi.fn();
vi.mock("@/lib/queryClient", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queryClient")>("@/lib/queryClient");
  return { ...actual, apiRequest: (...args: unknown[]) => api(...args) };
});
vi.mock("@/lib/entitlement", () => ({
  useEntitlement: () => ({ data: { identity: { name: "Shell Person" }, isAdmin: true, founder: { companies: [{ id: "co_server" }] }, investor: { state: "ACTIVE" } } }),
}));
// The hook's cached/localStorage value is deliberately DIFFERENT from the server value.
vi.mock("@/lib/useActiveCompany", () => ({
  useActiveCompany: () => ({ data: { activeCompanyId: "co_hook_cache", company: { kpi: { activeRoundsCount: 0 } } } }),
}));
vi.mock("@/lib/partner/usePartnerMembership", () => ({
  usePartnerMembership: () => ({ ready: true, isPartner: partner,
    identity: partner ? { partnerId: "p_shell", tier: "catalyst", subRole: "viewer", identity: { userId: "u_shell", name: "Partner", email: "p@example.test" } } : null }),
}));
vi.mock("@/lib/legalDrawer", () => ({ useLegalDrawer: () => ({ openDrawer }) }));
vi.mock("@/components/ChapterSelector", () => ({ ChapterSelector: () => null }));
vi.mock("@/components/feeds/MarketTicker", () => ({ MarketTicker: () => null }));
vi.mock("@/components/NotificationBell", () => ({ NotificationBell: () => null }));
vi.mock("@/components/CompanySwitcher", () => ({ CompanySwitcher: () => null }));
vi.mock("@/components/CapCollectiveToggle", () => ({ CapCollectiveToggle: () => null }));
vi.mock("@/components/LegalFooterLinks", () => ({ LegalFooterLinks: () => null }));
vi.mock("@/components/ArchivedWorkspaceBanner", () => ({ ArchivedWorkspaceBanner: () => null }));
vi.mock("@/components/AuditChainP0Banner", () => ({ AuditChainP0Banner: () => null }));
vi.mock("@/components/CollectiveMemberGate", () => ({ CollectiveMemberGate: ({ children }: { children: ReactNode }) => <>{children}</> }));

import { AppShell } from "../AppShell";
import { CollectiveShell } from "../CollectiveShell";
import { RoleProvider } from "@/lib/role";

const ok = (body: unknown) => ({ ok: true, status: 200, json: async () => body }) as Response;
const fail = (status: number) => ({ ok: false, status, json: async () => ({}) }) as Response;
type Mode = "server" | "pending" | "error" | "nocompany" | "emptyid";
let activeCompanyMode: Mode = "server";
let releasePending: (() => void) | null = null;

beforeEach(() => {
  partner = false; activeCompanyMode = "server"; releasePending = null;
  wl.renders.length = 0; wl.opens.length = 0; wl.mounted.clear();
  openDrawer.mockReset();
  localStorage.setItem("capavate:activeCompanyId", "co_from_storage");
  api.mockReset();
  api.mockImplementation(async (_m: string, url: string) => {
    if (url === "/api/founder/active-company") {
      if (activeCompanyMode === "error") return fail(500);
      if (activeCompanyMode === "nocompany") return ok({ activeCompanyId: null, company: null });
      if (activeCompanyMode === "emptyid") return ok({ activeCompanyId: "", company: null });
      if (activeCompanyMode === "pending") {
        await new Promise<void>((r) => { releasePending = r; });
      }
      return ok({ activeCompanyId: "co_server", company: { companyId: "co_server", companyName: "Server Co" } });
    }
    if (url === "/api/me/chapters") return ok({ ok: true, chapters: [] });
    if (url === "/api/feature-flags") return ok({ COLLECTIVE_ENABLED: true, PARTNER_WORKSPACE_ENABLED: true });
    if (url === "/api/investor/invitations") return ok([]);
    return ok({});
  });
});
afterEach(() => { cleanup(); localStorage.clear(); });

function mount(kind: "app" | "collective", route: string) {
  window.history.pushState({}, "", route);
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false,
    queryFn: async ({ queryKey }) => {
      const r = await api("GET", String(queryKey[0]));
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.json();
    } } } });
  return render(<QueryClientProvider client={qc}><Router><RoleProvider>
    {kind === "app" ? <AppShell><div>Content</div></AppShell> : <CollectiveShell><div>Content</div></CollectiveShell>}
  </RoleProvider></Router></QueryClientProvider>);
}
const lastRender = () => wl.renders[wl.renders.length - 1];
const launchers = () => screen.queryAllByTestId("button-wishlist");
const activeCompanyCalls = () => api.mock.calls.filter((c) => c[1] === "/api/founder/active-company").length;

/* ======================================================================== */
describe("§1 one provider per shell; every launcher wired to it", () => {
  it.each([["app", "/founder/dashboard", "Open menu"], ["collective", "/collective/dashboard", "button-mobile-menu"]] as const)(
    "%s shell at %s", async (kind, route, menu) => {
      mount(kind, route);
      await waitFor(() => expect(launchers()).toHaveLength(1)); // desktop only while the drawer is closed
      expect(wl.mounted.size).toBe(1);
      const [pid] = [...wl.mounted];
      expect(launchers()[0].getAttribute("data-provider")).toBe(String(pid));
      const btn = menu === "Open menu" ? screen.getByLabelText("Open menu") : screen.getByTestId(menu);
      fireEvent.click(btn);
      await waitFor(() => expect(launchers()).toHaveLength(2));
      expect(wl.mounted.size).toBe(1); // the drawer did NOT create a second provider
      for (const l of launchers()) expect(l.getAttribute("data-provider")).toBe(String(pid));
    });
});

describe("§2 mobile beforeOpen closes the drawer; returnFocusRef is the stable menu-button ref", () => {
  it.each([["app", "/investor/dashboard"], ["collective", "/collective/posts"]] as const)("%s shell", async (kind, route) => {
    mount(kind, route);
    const menuBtn = () => (kind === "app" ? screen.getByLabelText("Open menu") : screen.getByTestId("button-mobile-menu"));
    await waitFor(() => expect(launchers()).toHaveLength(1));
    fireEvent.click(launchers()[0]); // desktop
    expect(wl.opens[0]).toMatchObject({ hadBeforeOpen: false, returnFocusRef: undefined });

    const refs: any[] = [];
    for (let i = 0; i < 2; i++) {
      fireEvent.click(menuBtn());
      await waitFor(() => expect(launchers()).toHaveLength(2));
      fireEvent.click(launchers()[1]); // mobile launcher
      await waitFor(() => expect(launchers()).toHaveLength(1)); // beforeOpen closed the drawer
      const rec = wl.opens[wl.opens.length - 1];
      expect(rec.hadBeforeOpen).toBe(true);
      expect(rec.returnFocusRef?.current).toBe(menuBtn());
      refs.push(rec.returnFocusRef);
    }
    expect(refs[0]).toBe(refs[1]); // same ref object across re-renders/openings
  });
});

describe("§3 surface / locator / sourceRouteKey come from the actual path", () => {
  it.each([
    ["app", "/founder/dashboard", "founder", "founder.workspace"],
    ["app", "/investor/portfolio?tab=x", "investor", "investor.workspace"],
    ["app", "/admin/users", "admin", "admin.workspace"],
    ["app", "/privacy-policy", "account", "account.workspace"],
    ["app", "/founderish", "account", "account.workspace"], // prefix lookalike is NOT founder
    ["collective", "/collective/dashboard", "collective", "collective.workspace"],
    ["collective", "/collective/partner/dashboard", "partner", "partner.workspace"],
    ["collective", "/collective/partner", "partner", "partner.workspace"],
    // The Collective member-facing PARTNER DIRECTORY is Collective, not the partner workspace.
    ["collective", "/collective/partners", "collective", "collective.workspace"],
  ] as const)("%s %s -> %s", async (kind, route, surface, key) => {
    partner = surface === "partner";
    mount(kind, route);
    await waitFor(() => expect(lastRender()?.locator?.surface).toBe(surface));
    const r = lastRender();
    expect(r.sourceRouteKey).toBe(key);
    if (surface !== "founder") expect(r.locator.companyId ?? null).toBeNull();
    expect(r.locator.partnerId ?? null).toBeNull(); // partner id is server-derived, never client-supplied
  });
});

describe("§4 founder company comes from the real server query, never localStorage/hook cache", () => {
  it("uses /api/founder/active-company", async () => {
    mount("app", "/founder/rounds");
    await waitFor(() => expect(lastRender().locator.companyId).toBe("co_server"));
    expect(wl.renders.some((r) => r.locator.companyId === "co_from_storage")).toBe(false);
    expect(wl.renders.some((r) => r.locator.companyId === "co_hook_cache")).toBe(false);
    expect(activeCompanyCalls()).toBeGreaterThanOrEqual(1);
  });
});

describe("§5 contextReady gating", () => {
  it("false while fetching, then true with the confirmed company", async () => {
    activeCompanyMode = "pending";
    mount("app", "/founder/dashboard");
    await waitFor(() => expect(releasePending).not.toBeNull());
    expect(lastRender().contextReady).toBe(false);
    expect(lastRender().locator.companyId ?? null).toBeNull();
    await act(async () => { releasePending?.(); });
    await waitFor(() => expect(lastRender().contextReady).toBe(true));
    expect(lastRender().locator.companyId).toBe("co_server");
  });
  it("false on fetch error, and an error NEVER falls through to the null-company ready state", async () => {
    activeCompanyMode = "error";
    mount("app", "/founder/dashboard");
    await waitFor(() => expect(activeCompanyCalls()).toBeGreaterThanOrEqual(1));
    // let the rejected query settle and the shell re-render in its error state
    await act(async () => { await new Promise((r) => setTimeout(r, 30)); });
    expect(wl.renders.length).toBeGreaterThan(1);
    expect(wl.renders.some((r) => r.contextReady === true)).toBe(false);
    // the locator's companyId is null here exactly as in the no-company case, so ONLY contextReady separates them
    expect((lastRender().locator.companyId ?? null)).toBeNull();
    expect(lastRender().contextReady).toBe(false);
  });
  it.each([["nocompany", "null"], ["emptyid", "empty-string"]] as const)(
    "a successful 200 with a %s company (%s id) is READY with companyId null (server decides onboarding/user scope)", async (mode) => {
      activeCompanyMode = mode;
      mount("app", "/founder/dashboard");
      await waitFor(() => expect(lastRender().contextReady).toBe(true));
      expect(lastRender().locator.companyId).toBeNull(); // normalized, never "" and never storage/hook cache
      expect(wl.renders.some((r) => ["co_from_storage", "co_hook_cache", ""].includes(r.locator.companyId))).toBe(false);
      // readiness came only after the fetch completed, not on first paint
      expect(wl.renders[0].contextReady).toBe(false);
    });
  it.each([["app", "/investor/dashboard"], ["app", "/admin/dashboard"], ["app", "/privacy-policy"], ["collective", "/collective/dashboard"]] as const)(
    "%s %s is ready without fetching the founder company", async (kind, route) => {
      mount(kind, route);
      await waitFor(() => expect(launchers().length).toBeGreaterThan(0));
      expect(lastRender().contextReady).toBe(true);
      expect(activeCompanyCalls()).toBe(0);
    });
});

describe("§6 preservation", () => {
  it.each([["app", "/founder/dashboard"], ["collective", "/collective/dashboard"]] as const)(
    "%s: legal/privacy control still works and shares the footer with the launcher; nav/home still mounted", async (kind, route) => {
      mount(kind, route);
      await waitFor(() => expect(launchers()).toHaveLength(1));
      const legal = screen.getAllByTestId("button-legal-privacy")[0];
      fireEvent.click(legal);
      expect(openDrawer).toHaveBeenCalledTimes(1);
      expect(legal.parentElement?.contains(launchers()[0])).toBe(true);
      if (kind === "app") {
        expect(screen.getByTestId("sidebar-nav")).toBeTruthy();
        expect(screen.getByTestId("link-home")).toBeTruthy();
        expect(screen.getByTestId("header-account-group")).toBeTruthy();
      } else {
        expect(screen.getByTestId("brand-block")).toBeTruthy();
      }
      expect(screen.getByText("Content")).toBeTruthy();
    });

  // Frozen from `git show 46ebb62:client/src/components/{AppShell,CollectiveShell}.tsx`
  // with the regex below. No baseline href or data-testid may disappear from source.
  const BASELINE = {
    AppShell: {
      hrefs: ["/admin/audit-chain-verify","/admin/audit-log","/admin/bridge","/admin/bridge-history","/admin/collective/applications","/admin/collective/members","/admin/collective/settings","/admin/collective/waitlist","/admin/companies","/admin/company-taxonomy","/admin/consortium-applications","/admin/crm-dedup-review","/admin/dashboard","/admin/email","/admin/fees","/admin/formulas","/admin/integrations","/admin/investors","/admin/lifecycle-policies","/admin/migration","/admin/notifications","/admin/partner-responders","/admin/partner-taxonomy","/admin/partners","/admin/platform-surfaces","/admin/reconciliation","/admin/regions","/admin/sync","/admin/telemetry","/admin/users","/founder/activity","/founder/apply-to-collective","/founder/billing","/founder/captable","/founder/captable/waterfall","/founder/collective","/founder/company","/founder/company-management","/founder/crm","/founder/dashboard","/founder/dataroom","/founder/messages","/founder/network-posts","/founder/reports","/founder/rounds","/founder/settings","/investor/apply-to-collective","/investor/crm","/investor/dashboard","/investor/earlier-investments","/investor/glossary","/investor/invitations","/investor/messages","/investor/network-posts","/investor/notifications","/investor/portfolio","/investor/profile","/investor/settings"],
      testids: ["avatar-user-initials","badge-admin-mode","button-legal-privacy","button-open-glossary","button-role-switch","button-user-menu","global-search","header-account-group","header-app","header-switcher-group","input-search","link-home","menuitem-sign-out","search-empty","search-results","sidebar-nav","text-avatar-no-name-on-record","text-page-title","text-user-name"],
    },
    CollectiveShell: {
      hrefs: ["/collective/activity","/collective/ask-expert","/collective/calendar","/collective/chapters","/collective/companies","/collective/connections","/collective/dashboard","/collective/dealroom","/collective/dsc/pipeline","/collective/dsc/prep","/collective/dsc/scores","/collective/leaderboard","/collective/members","/collective/membership","/collective/partner/add-portfolio-company","/collective/partner/agreement","/collective/partner/billing","/collective/partner/clients","/collective/partner/contacts","/collective/partner/dashboard","/collective/partner/files","/collective/partner/managed-founders","/collective/partner/messages","/collective/partner/notes","/collective/partner/onboarding","/collective/partner/persona-tools","/collective/partner/pipeline","/collective/partner/portfolio","/collective/partner/posts","/collective/partner/relationships","/collective/partner/settings","/collective/partner/spv-engine","/collective/partner/spv-templates","/collective/partner/tasks","/collective/partner/tax-form","/collective/partner/team","/collective/partners","/collective/portal/requests","/collective/posts","/collective/presentations","/collective/recaps","/collective/screening-recaps","/collective/settings","/collective/soft-circles","/investor/apply-to-collective"],
      testids: ["brand-block","brand-product-label","button-close-sidebar","button-legal-privacy","button-mobile-menu","button-partner-logout","button-switch-to-capavate","topbar-chapter-selector","topbar-title"],
    },
  } as const;
  const HREF = /href(?:=|:\s*)["'`]([^"'`]+)["'`]/g;
  const TESTID = /data-testid=["']([^"'{}]+)["']/g;
  it.each(["AppShell", "CollectiveShell"] as const)("%s source keeps every 46ebb62 href and data-testid", (name) => {
    const src = fs.readFileSync(path.resolve(__dirname, `../${name}.tsx`), "utf8");
    const hrefs = new Set([...src.matchAll(HREF)].map((m) => m[1]));
    const ids = new Set([...src.matchAll(TESTID)].map((m) => m[1]));
    expect(BASELINE[name].hrefs.filter((h) => !hrefs.has(h))).toEqual([]);
    expect(BASELINE[name].testids.filter((t) => !ids.has(t))).toEqual([]);
  });
  it("admin inbox is additive: nav entry + admin-guarded route, nothing else removed from App.tsx routes", () => {
    const shell = fs.readFileSync(path.resolve(__dirname, "../AppShell.tsx"), "utf8");
    expect(shell).toContain('{ href: "/admin/wishlist", label: "Wish List inbox"');
    const app = fs.readFileSync(path.resolve(__dirname, "../../App.tsx"), "utf8");
    expect(app).toMatch(/<Route path="\/admin\/wishlist">\s*\{\(\) => <RequireAuth role="admin" redirectTo="\/admin\/login"><AdminWishList \/><\/RequireAuth>\}/);
  });
});
