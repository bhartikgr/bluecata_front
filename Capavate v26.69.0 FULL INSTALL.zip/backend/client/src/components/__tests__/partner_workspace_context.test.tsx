// @vitest-environment jsdom
/**
 * Partner/Collective workspace context, mounted against the real CollectiveShell.
 * Only peripheral widgets and HTTP are replaced; navigation and membership hooks
 * are real. Baseline v26.61 fails the dual-member partner-route expectations.
 * Existing bell, Wish List and chapter-selector behavior is deliberately preserved.
 * No server authorization is inferred from these presentation assertions.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router } from "wouter";
import type { ReactNode } from "react";

const fixture = vi.hoisted(() => ({
  partner: true,
  pendingPartner: false,
  resolvePartner: null as null | (() => void),
  chapters: [{ id: "chapter_active" }] as Array<{ id: string }>,
  chaptersError: false,
  collectiveOn: true,
  calls: [] as Array<{ method: string; url: string }>,
}));

const identity = {
  partnerId: "pt_context", tier: "catalyst", subRole: "managing_partner",
  identity: { userId: "u_context", name: "Test Partner", email: "partner@example.test" },
};
const response = (body: unknown) => ({ ok: true, status: 200, json: async () => body }) as Response;

vi.mock("@/lib/queryClient", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queryClient")>("@/lib/queryClient");
  return {
    ...actual,
    apiRequest: vi.fn(async (method: string, url: string) => {
      fixture.calls.push({ method, url });
      if (url === "/api/partner/me") {
        if (fixture.pendingPartner) await new Promise<void>(resolve => { fixture.resolvePartner = resolve; });
        if (!fixture.partner) throw new actual.ApiError(403, "Not a partner", null, null);
        return response(identity);
      }
      if (url === "/api/me/chapters") {
        if (fixture.chaptersError) throw new actual.ApiError(503, "Collective unavailable", null, null);
        return response({ ok: true, chapters: fixture.chapters });
      }
      if (url === "/api/feature-flags") return response({
        COLLECTIVE_ENABLED: fixture.collectiveOn, PARTNER_WORKSPACE_ENABLED: true,
      });
      return response({});
    }),
  };
});
vi.mock("@/lib/legalDrawer", () => ({ useLegalDrawer: () => ({ openDrawer: vi.fn() }) }));
vi.mock("@/components/feeds/MarketTicker", () => ({ MarketTicker: () => null }));
vi.mock("@/components/ChapterSelector", () => ({
  ChapterSelector: () => <span data-testid="topbar-chapter-selector">Chapter selector</span>,
}));
vi.mock("@/components/NotificationBell", () => ({
  NotificationBell: ({ surface, viewAllHref }: { surface: string; viewAllHref: string }) =>
    <span data-testid="notification-context" data-surface={surface} data-href={viewAllHref} />,
}));
vi.mock("@/components/wishlist/WishList", () => ({
  WishListProvider: ({ product, locator, children }: {
    product: string; locator: { surface: string }; children: ReactNode;
  }) => <div data-testid="wishlist-context" data-product={product} data-surface={locator.surface}>{children}</div>,
  WishListLauncher: () => <button type="button">Wish List</button>,
}));
vi.mock("@/components/LegalFooterLinks", () => ({ LegalFooterLinks: () => null }));
vi.mock("@/components/CollectiveMemberGate", () => ({
  CollectiveMemberGate: ({ children }: { children: ReactNode }) => <>{children}</>,
}));

import { CollectiveShell } from "../CollectiveShell";
import { RoleProvider } from "@/lib/role";

function mount(path: string) {
  window.history.pushState({}, "", path);
  const qc = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false, refetchOnWindowFocus: false, gcTime: 0,
        queryFn: async () => ({}),
      },
    },
  });
  const mounted = render(
    <QueryClientProvider client={qc}>
      <Router><RoleProvider><CollectiveShell><div>Partner page</div></CollectiveShell></RoleProvider></Router>
    </QueryClientProvider>,
  );
  return { ...mounted, qc };
}

function expectContext(kind: "partner" | "collective") {
  expect(screen.getByTestId("wishlist-context").getAttribute("data-product")).toBe(kind);
  expect(screen.getByTestId("wishlist-context").getAttribute("data-surface")).toBe(kind);
  expect(screen.getByTestId("notification-context").getAttribute("data-surface")).toBe(kind);
  expect(screen.getByTestId("notification-context").getAttribute("data-href")).toBe(
    kind === "partner" ? "/collective/partner/notifications" : "/collective/notifications",
  );
}

beforeEach(() => {
  fixture.partner = true;
  fixture.pendingPartner = false;
  fixture.resolvePartner = null;
  fixture.chapters = [{ id: "chapter_active" }];
  fixture.chaptersError = false;
  fixture.collectiveOn = true;
  fixture.calls.length = 0;
});
afterEach(() => cleanup());

describe("route-aware partner workspace, without changing membership or authority", () => {
  it("dual member on agreement sees partner chrome, then explicit two-way navigation", async () => {
    mount("/collective/partner/agreement");
    await screen.findByTestId("nav-partner-dashboard");
    // This existing dual-member control appears only after chapters resolve.
    // Baseline then says "Collective" on the partner route: fail on that defect,
    // rather than first failing because the new workspace switch is absent.
    await screen.findByTestId("button-switch-to-capavate");
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Consortium Partner");
    expect(screen.getByTestId("topbar-title").textContent).toBe("Capavate Consortium Partner");
    await screen.findByTestId("button-switch-to-collective");
    expect(screen.getByTestId("brand-block").closest("a")?.getAttribute("href"))
      .toBe("/collective/partner/dashboard");
    expect(screen.getByTestId("nav-partner-agreement").getAttribute("href"))
      .toBe("/collective/partner/agreement");
    expect(screen.queryByTestId("nav-collective-dashboard")).toBeNull();
    expect(screen.getByTestId("topbar-chapter-selector")).toBeTruthy();
    // The existing logout gate is partner-only, not broadened to dual members.
    expect(screen.queryByTestId("button-partner-logout")).toBeNull();
    expect(screen.getByTestId("button-switch-to-capavate")).toBeTruthy();
    expectContext("partner");

    fireEvent.click(screen.getByTestId("button-mobile-menu"));
    expect(screen.getAllByTestId("nav-partner-dashboard")).toHaveLength(2);
    expect(screen.getAllByTestId("button-switch-to-collective")).toHaveLength(2);
    expect(screen.queryByTestId("nav-collective-dashboard")).toBeNull();
    fireEvent.click(screen.getByTestId("button-close-sidebar"));

    fireEvent.click(screen.getByTestId("button-switch-to-collective"));
    await waitFor(() => expect(window.location.pathname).toBe("/collective/dashboard"));
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Collective");
    expect(screen.getByTestId("topbar-title").textContent).toBe("Capavate Collective");
    expect(screen.getByTestId("nav-collective-dashboard")).toBeTruthy();
    expect(screen.getByTestId("nav-partner-dashboard")).toBeTruthy(); // legacy combined member nav
    expect(screen.getByTestId("topbar-chapter-selector")).toBeTruthy();
    expectContext("collective");

    fireEvent.click(screen.getByTestId("button-switch-to-partner"));
    await waitFor(() => expect(window.location.pathname).toBe("/collective/partner/dashboard"));
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Consortium Partner");
    expect(screen.queryByTestId("nav-collective-dashboard")).toBeNull();
    expectContext("partner");
    expect(fixture.calls.filter(c => c.method !== "GET")).toEqual([]);
  });

  it.each(["/collective/partners", "/collective/partnerish"])(
    "does not mistake member route %s for a partner workspace", async path => {
      mount(path);
      await screen.findByTestId("nav-partner-dashboard");
      expect(screen.getByTestId("brand-product-label").textContent).toBe("Collective");
      expect(screen.getByTestId("nav-collective-dashboard")).toBeTruthy();
      expect(screen.getByTestId("topbar-title").textContent).toBe("Capavate Collective");
      // The old startsWith scope for bell/Wish List is outside this repair.
    },
  );

  it("partner-only retains partner controls and cannot switch into Collective", async () => {
    fixture.chapters = [];
    mount("/collective/partner/dashboard");
    await screen.findByTestId("nav-partner-dashboard");
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Consortium Partner");
    expect(screen.queryByTestId("nav-collective-dashboard")).toBeNull();
    expect(screen.queryByTestId("button-switch-to-collective")).toBeNull();
    expect(screen.getByTestId("button-partner-logout")).toBeTruthy();
    expectContext("partner");
  });

  it("Collective-only member retains member navigation without partner switch", async () => {
    fixture.partner = false;
    mount("/collective/dashboard");
    await screen.findByTestId("nav-collective-dashboard");
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Collective");
    expect(screen.queryByTestId("nav-partner-dashboard")).toBeNull();
    expect(screen.queryByTestId("button-switch-to-partner")).toBeNull();
    expectContext("collective");
  });

  it("a nonpartner on a partner URL keeps the previous Collective chrome without partner links", async () => {
    fixture.partner = false;
    mount("/collective/partner/agreement");
    await screen.findByTestId("nav-collective-dashboard");
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Collective");
    expect(screen.getByTestId("topbar-title").textContent).toBe("Capavate Collective");
    expect(screen.queryByTestId("nav-partner-dashboard")).toBeNull();
    expect(screen.queryByTestId("button-switch-to-collective")).toBeNull();
    // The page/server partner guard, not the shell's cosmetic branding, owns access.
  });

  it("pending partner probe cannot expose partner links or a switch; resolution does not change hook order", async () => {
    fixture.pendingPartner = true;
    mount("/collective/partner/agreement");
    await waitFor(() => expect(fixture.resolvePartner).not.toBeNull());
    expect(screen.queryByTestId("nav-partner-dashboard")).toBeNull();
    expect(screen.queryByTestId("button-switch-to-collective")).toBeNull();
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Collective");
    expect(screen.getByTestId("topbar-chapter-selector")).toBeTruthy();
    await act(async () => { fixture.resolvePartner?.(); fixture.pendingPartner = false; });
    await screen.findByTestId("nav-partner-dashboard");
    await screen.findByTestId("button-switch-to-collective");
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Consortium Partner");
  });

  it("feature-off chapter data never creates a Collective switch", async () => {
    fixture.collectiveOn = false;
    mount("/collective/partner/dashboard");
    await screen.findByTestId("nav-partner-dashboard");
    expect(screen.queryByTestId("button-switch-to-collective")).toBeNull();
    expectContext("partner");
  });

  it("chapters 503 cannot manufacture a Collective switch for a confirmed partner", async () => {
    fixture.chaptersError = true;
    const { qc } = mount("/collective/partner/dashboard");
    await screen.findByTestId("nav-partner-dashboard");
    await waitFor(() => expect(qc.getQueryData(["/api/me/chapters"]))
      .toEqual({ ok: false, chapters: [] }));
    expect(screen.getByTestId("brand-product-label").textContent).toBe("Consortium Partner");
    expect(screen.queryByTestId("button-switch-to-collective")).toBeNull();
    expect(screen.getByTestId("button-partner-logout")).toBeTruthy();
  });

  it("partner-only on an exempt Collective page has an explicit return, not new member access", async () => {
    fixture.chapters = [];
    mount("/collective/membership");
    await screen.findByTestId("nav-partner-dashboard");
    const back = await screen.findByTestId("button-switch-to-partner");
    expect(back.getAttribute("href")).toBe("/collective/partner/dashboard");
    expect(screen.queryByTestId("button-switch-to-collective")).toBeNull();
    fireEvent.click(back);
    await waitFor(() => expect(window.location.pathname).toBe("/collective/partner/dashboard"));
    expect(fixture.calls.filter(c => c.method !== "GET")).toEqual([]);
  });

  it("nonpartner on member routes never receives either workspace switch", async () => {
    fixture.partner = false;
    mount("/collective/partners");
    await screen.findByTestId("nav-collective-dashboard");
    expect(screen.queryByTestId("button-switch-to-partner")).toBeNull();
    expect(screen.queryByTestId("button-switch-to-collective")).toBeNull();
    expect(screen.queryByTestId("nav-partner-dashboard")).toBeNull();
  });
});
