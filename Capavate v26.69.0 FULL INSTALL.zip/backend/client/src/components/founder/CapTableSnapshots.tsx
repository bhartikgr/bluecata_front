/* W-CT (2026-07-14) — read-only cap-table snapshots panel.
 *
 * Renders two read-only surfaces on the founder cap-table page:
 *   1. PENDING / PROJECTED — positions for rounds still active/live, shown with
 *      a clear banner that the FINAL cap table is set at round close (these
 *      figures are illustrative until then).
 *   2. PREVIOUS — the last COMMITTED round snapshot (ASK ACT.1 Option A).
 *      Hidden entirely when no prior committed round exists.
 *
 * Consumes ONLY the additive read endpoint GET /api/companies/:id/captable/snapshots.
 * No writes, no engine mutation — the money core is untouched.
 */
import { NO_CURRENCY_ON_RECORD_CELL } from "@/lib/currencyOnRecordDisplay"; /* WAVE 190 · ITEM A */
import { useMemo, useState } from "react";
import {
  COPY as DISPLAY_COPY,
  formatRecordedMoney,
  validateProofHeaders,
  validateSnapshotsDisplayTruth,
  type DisplayMoneyV1,
  type DisplayTruthScopeV1,
} from "@shared/capTableInterimSnapshotMoney"; /* Slide 13C · C1D */
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Info, Clock, ChevronDown, ChevronRight } from "lucide-react";
import { safePersonDisplayName } from "@/lib/personName";

/* WAVE 83 · ITEM 3 — the server no longer sends a raw id in this column, and
   this renderer will not print one either if any other writer ever does. The
   fallback says WHAT THE ROW IS rather than showing the key. */
function holderLabel(holderName: string, investorId: string | null): string {
  const fallback = investorId && /^u_redeemed_/.test(investorId)
    ? "Redeemed holder"
    : "Holder (name not recorded)";
  return safePersonDisplayName(holderName, fallback);
}

interface SnapshotPosition {
  id: string;
  holderName: string;
  instrument: string;
  shares: number;
  investmentAmount: number;
  roundId: string | null;
  /* WAVE 83 · ITEM 3 — already on the wire (server/captableSnapshotsStore.ts);
     read here only so the Holder fallback can say what the row IS. */
  investorId?: string | null;
  /* Slide 13C · C1D — validated opt-in exact-money sidecar. */
  displayMoney?: DisplayMoneyV1;
}
interface SnapshotsResponse {
  ok: boolean;
  /* ITEM 12 — `roundNames` is ADDITIVE and arrives from
     `server/captableSnapshotsStore.ts`. Optional here so an older cached
     response, or a fail-soft empty payload, renders the honest refusal below
     rather than crashing. */
  pending: { hasPending: boolean; roundIds: string[]; roundNames?: Record<string, string>; positions: SnapshotPosition[] };
  previous: {
    hasPrevious: boolean; roundId: string | null; roundName: string | null;
    committedAt: string | null; positions: SnapshotPosition[];
  };
  displayTruth?: DisplayTruthScopeV1;
}

/** Slide 13C · C1D — exact recorded amount or an explicit non-figure label. */
function displayAmountText(money?: DisplayMoneyV1): string {
  const fact = money?.amount;
  if (fact?.state === "recorded") return formatRecordedMoney(fact.decimal, fact.currencyCode);
  return fact?.state === "unrecorded" ? DISPLAY_COPY.amountNotOnRecord : DISPLAY_COPY.amountNotVerified;
}

/* Slide 13C · C1D — A→B→A guard (see CapTableInterim). */
let snapshotsVisitCounter = 0;

/* WAVE 190 · ITEM A — `sym` is now `string | null`. `null` means the company has
   NO CURRENCY ON RECORD, and this panel must not print an amount in a
   denomination nobody recorded (R6). The `sym = "$"` default that used to sit on
   the props below is exactly the fabricated dollar sign this wave exists to
   remove: it made a Hong Kong or Canadian company's snapshot read as US dollars
   whenever the parent did not pass a symbol. No amount changes and nothing is
   converted (R156.1) — only whether, and with which glyph, it is printed. */
function fmtMoney(sym: string | null, n: number): string {
  if (!Number.isFinite(n) || n === 0) return "—";
  if (sym === null) return NO_CURRENCY_ON_RECORD_CELL;
  return `${sym}${Math.round(n).toLocaleString()}`;
}
function fmtShares(n: number): string {
  if (!Number.isFinite(n) || n === 0) return "—";
  return Math.round(n).toLocaleString();
}

/* ITEM 12 — the Projected table had no round column, so a founder with two open
   rounds could not tell which round a projected row came from. The round is
   named, never printed as an id (item 9), and an unresolved round states its
   absence rather than rendering a blank cell or a bare dash. */
export const SNAPSHOT_ROUND_NOT_RECORDED = "Round not recorded";

export function snapshotRoundLabel(
  roundId: string | null | undefined,
  roundNames: Record<string, string> | undefined,
): string {
  const rid = String(roundId ?? "").trim();
  if (!rid) return SNAPSHOT_ROUND_NOT_RECORDED;
  const name = String(roundNames?.[rid] ?? "").trim();
  /* NEVER fall back to the id. An id is not a name. */
  return name || SNAPSHOT_ROUND_NOT_RECORDED;
}

function PositionRows({
  positions,
  sym,
  roundNames,
}: {
  positions: SnapshotPosition[];
  sym: string | null;
  /* Omitted by the `previous` table, which is a single committed round and does
     not need a per-row round column. */
  roundNames?: Record<string, string>;
}) {
  if (positions.length === 0) {
    return <p className="text-xs text-muted-foreground px-1 py-2">No positions in this snapshot.</p>;
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead>
          <tr className="text-muted-foreground border-b border-border">
            <th className="text-left font-medium px-2 py-1.5">Holder</th>
            {roundNames !== undefined && (
              <th className="text-left font-medium px-2 py-1.5" data-testid="snapshot-col-round">Round</th>
            )}
            <th className="text-left font-medium px-2 py-1.5">Instrument</th>
            <th className="text-right font-medium px-2 py-1.5">Shares</th>
            <th className="text-right font-medium px-2 py-1.5">Invested</th>
          </tr>
        </thead>
        <tbody>
          {positions.map((p) => (
            <tr key={p.id} className="border-b border-border/50" data-testid={`snapshot-row-${p.id}`}>
              <td className="px-2 py-1.5">{holderLabel(p.holderName, p.investorId ?? null)}</td>
              {roundNames !== undefined && (
                <td className="px-2 py-1.5" data-testid={`snapshot-row-round-${p.id}`}>
                  {snapshotRoundLabel(p.roundId, roundNames)}
                </td>
              )}
              <td className="px-2 py-1.5"><Badge variant="secondary" className="text-[10px]">{p.instrument}</Badge></td>
              <td className="px-2 py-1.5 text-right font-mono tabular-nums">{fmtShares(p.shares)}</td>
              <td className="px-2 py-1.5 text-right font-mono tabular-nums" data-testid={`snapshot-row-amount-${p.id}`}>{p.displayMoney ? displayAmountText(p.displayMoney) : fmtMoney(sym, p.investmentAmount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function CapTableSnapshots({ companyId, sym = null }: { companyId: string; sym?: string | null }) {
  const [showPrevious, setShowPrevious] = useState(false);

  const visitGeneration = useMemo(() => ++snapshotsVisitCounter, [companyId]);
  const q = useQuery<SnapshotsResponse>({
    /* Slide 13C · C1D — separate display-truth key; never the four-part legacy key. */
    queryKey: ["/api/companies", companyId, "captable", "snapshots", "display-truth", 1, visitGeneration],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/companies/${encodeURIComponent(companyId)}/captable/snapshots?displayTruth=1`);
      validateProofHeaders(res.headers);
      const body = await res.json();
      validateSnapshotsDisplayTruth(body, companyId);
      return body as SnapshotsResponse;
    },
    enabled: Boolean(companyId),
    retry: false,
  });

  // Loading — keep quiet (skeleton-free) so it doesn't compete with the main table.
  if (q.isLoading) {
    return (
      <Card className="mb-4" data-testid="snapshots-loading">
        <CardContent className="p-4">
          <p className="text-xs text-muted-foreground">Loading projected &amp; previous cap tables…</p>
        </CardContent>
      </Card>
    );
  }
  // Error — non-fatal; offer retry, never block the main cap table.
  if (q.isError || (q.data && !q.data.ok)) {
    return (
      <Card className="mb-4" data-testid="snapshots-error">
        <CardContent className="p-4 flex items-center justify-between gap-3">
          <p className="text-xs text-rose-600">Couldn’t load projected / previous cap tables.</p>
          <Button variant="outline" size="sm" onClick={() => q.refetch()} data-testid="snapshots-retry">Retry</Button>
        </CardContent>
        {/* WAVE 60 · A-5 (OWNER RULING R51 — APPEND ONLY). R44 was applied to the
            sentence above and it did NOT meet the bar for a REPLACE: it is true
            when it renders, it names the thing that failed, and it already
            offers a working Retry. So it, its <p>, its <Button> and both
            data-testids are BYTE-IDENTICAL, and this is one appended sentence
            distinguishing a load failure from an empty list. Appended as the
            LAST child of <Card> (a second CardContent, not a third item spliced
            into the justify-between row above) so no existing container ordinal
            shifts — see the WAVE 55b 18-panel incident. Allowlist stays 43. */}
        <CardContent className="px-4 pb-4 pt-0" data-testid="snapshots-error-note">
          <p className="text-xs text-muted-foreground">Nothing has been changed — this is a loading failure, not an empty list.</p>
        </CardContent>
      </Card>
    );
  }

  const pending = q.data?.pending;
  const previous = q.data?.previous;
  const hasPending = Boolean(pending?.hasPending);
  const hasPrevious = Boolean(previous?.hasPrevious);

  // Nothing to add beyond the live table — render nothing (empty state is the
  // absence of both a pending round and a prior committed snapshot).
  if (!hasPending && !hasPrevious) {
    return null;
  }

  return (
    <div className="mb-4 space-y-4" data-testid="captable-snapshots">
      {/* PENDING / PROJECTED */}
      {hasPending && (
        <Card data-testid="snapshot-pending">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              Projected cap table
              <Badge variant="outline" className="text-[10px]">pending round</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-2 p-3 rounded-md bg-secondary/40 border border-border text-xs text-muted-foreground" data-testid="snapshot-pending-banner">
              <Info className="h-3.5 w-3.5 mt-0.5 text-[hsl(0_100%_40%)] shrink-0" />
              <span>
                These positions are <span className="font-medium text-foreground">projected and illustrative</span> while the
                round is open. The <span className="font-medium text-foreground">final cap table is set when the round closes</span> and
                the engine commits the reconciled positions to the immutable ledger.
              </span>
            </div>
            {/* ITEM 12 — SIBLING SENTENCE. The banner above is ratified copy and
                is NOT edited: it discloses that the figures are provisional and
                that a close commits them. It says nothing about OTHER open
                rounds, which is the omission a founder actually hit.

                CONDITIONAL ON MORE THAN ONE OPEN ROUND. Shown to a
                single-round company it would be a new false statement, so the
                gate is the point of this block, not an optimisation.

                THE ARITHMETIC IS CORRECT AND IS NOT TOUCHED. This explains the
                figures; it does not change them. */}
            {(pending!.roundIds?.length ?? 0) > 1 && (
              <div
                className="flex items-start gap-2 p-3 rounded-md bg-secondary/40 border border-border text-xs text-muted-foreground"
                data-testid="snapshot-pending-cross-round-banner"
              >
                <Info className="h-3.5 w-3.5 mt-0.5 text-[hsl(0_100%_40%)] shrink-0" />
                <span>
                  This company has <span className="font-medium text-foreground">more than one open round</span>.
                  Recording an investor in any open round changes the projected ownership shown for every other
                  open round, because each projection divides by the same total share count. These figures are
                  correct and they will move again as other rounds record investors.{" "}
                  <span className="font-medium text-foreground">Only a close commits them.</span>
                </span>
              </div>
            )}
            <PositionRows positions={pending!.positions} sym={sym} roundNames={pending!.roundNames ?? {}} />
          </CardContent>
        </Card>
      )}

      {/* PREVIOUS — last committed snapshot (Option A). Hidden when none. */}
      {hasPrevious && (
        <Card data-testid="snapshot-previous">
          <CardHeader className="pb-2">
            <button
              type="button"
              className="flex items-center gap-2 text-left w-full"
              onClick={() => setShowPrevious((s) => !s)}
              data-testid="snapshot-previous-toggle"
            >
              {showPrevious ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              <CardTitle className="text-sm flex items-center gap-2">
                Previous cap table
                {previous!.roundName && <Badge variant="secondary" className="text-[10px]">{previous!.roundName}</Badge>}
              </CardTitle>
              {previous!.committedAt && (
                <span className="ml-auto flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Clock className="h-3 w-3" /> committed {previous!.committedAt.slice(0, 10)}
                </span>
              )}
              {q.data?.displayTruth?.endpoint === "snapshots" && q.data.displayTruth.previousTimestamp === "withheld_own_position" ? (
                <span className="ml-auto text-[11px] text-muted-foreground" data-testid="snapshot-previous-timestamp-withheld">
                  {DISPLAY_COPY.previousTimestampWithheld}
                </span>
              ) : null}
            </button>
          </CardHeader>
          {showPrevious && (
            <CardContent className="space-y-3">
              <div className="text-xs text-muted-foreground">
                The last committed round snapshot from the immutable ledger — a read-only historical view.
              </div>
              <div className="text-xs text-muted-foreground" data-testid="snapshot-previous-current-record">
                {DISPLAY_COPY.currentRecordProjection}
              </div>

              <PositionRows positions={previous!.positions} sym={sym} />
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}
