import { buildTickerPayload, resolveTickerProvider } from "./server/feedsStore";
import { rawDb } from "./server/db/connection";
import { setCollectiveSettings } from "./server/collectiveAdminSettingsStore";

async function run() {
  console.log("--- Initial State ---");
  console.log(resolveTickerProvider());

  console.log("--- Setting ENV ---");
  process.env.FEEDS_PROVIDER = "yahoo_coingecko";
  console.log(resolveTickerProvider());

  console.log("--- Changing ENV ---");
  process.env.FEEDS_PROVIDER = "alpha_vantage";
  console.log(resolveTickerProvider());
  
  console.log("--- Testing DB override ENV ---");
  // Env should override DB
  try {
    rawDb().prepare(`INSERT OR REPLACE INTO collective_admin_settings (key, value_json, updated_at) VALUES ('collective', '{"ventureProvider": "polygon"}', datetime('now'))`).run();
    console.log("DB set to polygon. Env is alpha_vantage. Resolution:");
    console.log(resolveTickerProvider());
  } catch (e) {
    console.log("DB set failed", e);
  }

  console.log("--- Removing ENV, should fallback to DB ---");
  delete process.env.FEEDS_PROVIDER;
  console.log(resolveTickerProvider());

  console.log("--- No provider anywhere ---");
  rawDb().prepare(`DELETE FROM collective_admin_settings WHERE key = 'collective'`).run();
  console.log(resolveTickerProvider());
  
  console.log("--- Ticker Payload with No Provider ---");
  const p = await buildTickerPayload();
  console.log(JSON.stringify(p, null, 2));

  console.log("--- Ticker Payload with fallback ---");
  rawDb().prepare(`INSERT OR REPLACE INTO collective_admin_settings (key, value_json, updated_at) VALUES ('collective', '{"ventureProvider": "alpha_vantage"}', datetime('now'))`).run();
  // no key configured in collectiveAdminSettingsStore
  console.log(resolveTickerProvider());
}

run().catch(console.error);