# Capavate — Live Environment Reference (W-AVI64)

Authoritative reference for the environment variables that gate the LIVE
behaviours touched by the W-AVI64 fix wave. This is a documentation-only file —
it changes no code and edits no SACRED file. Where a value is security- or
delivery-critical, the recommended production setting is called out.

For the full annotated list of every variable, see `.env.example`. This file is
the short "what Avi must set on the live box" companion.

---

## 1. Collective bridge outbound (W-AVI64 FIX 3 → **CORRECTED by W-AVI65 FIX 4**)

**Symptom fixed:** the outbound bridge was stuck (561 queued, 0 delivered)
because the live `.env` shipped the receiver under the legacy names while the
code read only the canonical names.

**W-AVI65 correction (live-confirmed, 568 queued / 0 delivered / chain broken):**
the W-AVI64 block above prescribed `https://collective.capavate.com/api/bridge/inbox`
— **that host does not exist.** The Collective is the SAME application on the
SAME domain, served at `capavate.com/collective`, and the inbound route is
`/api/bridge/inbound`. So the bridge is a **self-loop** back to capavate.com.
Two consequences, both required:

1. The URL must be `https://capavate.com/api/bridge/inbound`.
2. Because both ends are this same process, the **outbound signing secret and
   the inbound verifying secret must be the SAME value**. The outbound signer
   reads `COLLECTIVE_WEBHOOK_SECRET` (SACRED `server/lib/bridgeRuntime.ts:90`);
   the inbound verifier reads `BRIDGE_INBOUND_HMAC_SECRET` (falling back to
   `BRIDGE_HMAC_SECRET`) (`server/bridgeStore.ts:295-301`) and **never** consults
   `COLLECTIVE_WEBHOOK_SECRET`. If the two differ, every self-POST is rejected
   `401` and dead-letters — the exact confirmed live failure.

**What to set for LIVE delivery (canonical — required):**

```dotenv
BRIDGE_ENABLED=1
COLLECTIVE_WEBHOOK_URL=https://capavate.com/api/bridge/inbound
COLLECTIVE_WEBHOOK_SECRET=<secret>
BRIDGE_INBOUND_HMAC_SECRET=<SAME secret as COLLECTIVE_WEBHOOK_SECRET>
COLLECTIVE_APP_URL=https://capavate.com/collective
```

> ⚠ `BRIDGE_INBOUND_HMAC_SECRET` **must equal** `COLLECTIVE_WEBHOOK_SECRET`.
> This is not optional for the self-loop topology.

**Also fixed in code (W-AVI65 FIX 4, `server/index.ts`):** `hydrateBridgeStore()`
and `hydrateDurableMaps()` were nested *inside* the `maySendOutboundBridge()`
outbound gate, so with outbound disabled/misconfigured the durable maps and the
outbox were never rehydrated on boot — even though `/api/bridge/inbound`
dispatches into those maps regardless of send permission. Both hydrators now run
unconditionally at boot (read-only, idempotent); only `startBridgeWorker()`
remains behind the outbound gate.

Notes:

- The SACRED `server/lib/bridgeRuntime.ts` reads `COLLECTIVE_WEBHOOK_URL` /
  `COLLECTIVE_WEBHOOK_SECRET` **directly** for the actual send. You MUST set the
  canonical pair for live delivery — the alias fallback added in
  `bridgeOutboundGuard.ts` only widens what the *guard* recognises as a real
  receiver; it does not feed the sacred delivery path.
- The alias names (`BRIDGE_OUTBOUND_URL`, `BRIDGE_OUTBOUND_HMAC_SECRET`,
  `BRIDGE_INBOUND_HMAC_SECRET`) are now honoured as fallbacks by the non-sacred
  guard, so an existing live `.env` is not orphaned — but keep the canonical
  pair set as the source of truth.
- **Placeholder secrets are rejected.** The shipped `.env` contains
  `BRIDGE_INBOUND_HMAC_SECRET=YOUR_STRONG_SECRET`; `isPlaceholderSecret()`
  treats that (and `changeme`, `placeholder`, `todo`, `example`) as "no real
  receiver", so the bridge stays neutralized until Avi sets a REAL secret. Use
  the identical value on both the Capavate emitter and the Collective verifier:

  ```bash
  openssl rand -hex 32
  ```

- **Audit chain "broken@0".** If the outbox audit chain shows broken at genesis
  (prior hash `0000…0`), that is documented as a known condition, NOT
  auto-repaired by this wave (the chain math lives in the sacred runtime). Re-
  chaining, if ever needed, must be done through the sacred runtime's own tools
  — do not hand-edit the ledger.

---

## 2. Build / deploy markers (W-AVI64 FIX 7)

`/api/healthz` reports a `buildSha`. Resolution order (see `server/routes.ts`):

```
BUILD_SHA  →  GIT_SHA  →  `git rev-parse --short HEAD`  →  "unknown"
```

On a deploy dir that is not a git checkout, set `BUILD_SHA` explicitly so the
running build is identifiable:

```dotenv
BUILD_SHA=<ci-injected short sha>
BUILD_TIME=<ISO-8601 build timestamp>   # optional; unset → server boot time
```

---

## 3. Object storage (W-AVI64 FIX 7)

`server/lib/objectStorage.ts` (dataroom files, pitch decks, post attachments).

- **Default = local disk.** Nothing to set. Files land under
  `DATAROOM_STORAGE_DIR` → `UPLOADS_DIR` → `<cwd>/uploads` and are served only
  through authenticated API routes.
- **Stale `AWS_*` values are inert** unless you explicitly opt in with
  `STORAGE_BACKEND=s3`. This is why Avi's box uses local disk even though the
  live `.env` still contains `AWS_S3_BUCKET` / `AWS_KMS_KEY_ID` / credentials —
  uploads do NOT crash and do NOT silently try S3.
- **To opt into S3+KMS** you must set ALL of:

  ```dotenv
  STORAGE_BACKEND=s3
  AWS_S3_BUCKET=<bucket>
  AWS_KMS_KEY_ID=<kms-key>
  AWS_REGION=<region>
  # plus one credential mode:
  AWS_ACCESS_KEY_ID=<...>
  AWS_SECRET_ACCESS_KEY=<...>
  # or AWS_USE_INSTANCE_PROFILE / AWS_USE_IAM_ROLE / AWS_PROFILE
  ```

  A PARTIAL opt-in (bucket set, KMS/region/creds missing) fails fast at upload
  with an explicit message rather than silently falling back — this is intended.

---

## 4. Dev password-reset URL escape hatch (W-AVI64 FIX 7 — SECURITY)

```dotenv
RETURN_DEV_RESET_URL=0
```

When `1`, the forgot-password route returns the reset URL (and thus a valid
reset token) in the API response. Useful for testing without a mailbox, but it
exposes a live token to any caller of the endpoint. **Recommended production
value: `0` (or unset).** Flip to `1` only for a brief, controlled test and set
it back afterwards.

---

## 5. Quick LIVE checklist for Avi

- [ ] `BRIDGE_ENABLED=1` and canonical `COLLECTIVE_WEBHOOK_URL` +
      `COLLECTIVE_WEBHOOK_SECRET` set to REAL values (no placeholder secret).
- [ ] `BRIDGE_INBOUND_HMAC_SECRET` == `COLLECTIVE_WEBHOOK_SECRET` (self-loop).
- [ ] `RETURN_DEV_RESET_URL=0` in production.
- [ ] `BUILD_SHA` injected by the deploy pipeline (e.g. `wshadie`).
- [ ] Object storage left on local disk (no `STORAGE_BACKEND=s3`) unless S3 is
      fully configured.
- [ ] `NODE_ENV=production`.
- [ ] pm2 **fork** mode (NOT cluster) until the cache-only
      `listForInvestorEmail` is made cluster-safe (see §8).

---

# ====================================================================
# PERMANENT FINDINGS (SACRED KNOWLEDGE — do not re-discover each task)
# ====================================================================
# Everything below is durable, cross-wave truth about the live system.
# It exists so a fresh agent/session never has to re-investigate it.
# Update it (append, don't rewrite) whenever a new durable fact is proven.

## 6. LIVE access — portals & test credentials (capavate.com)

SINGLE DOMAIN: **capavate.com** only. There is NO `collective.capavate.com`,
no separate app domain. The Collective is the SAME app at `capavate.com/collective`.

| Persona | Login URL | Email | Credential handling |
|---|---|---|---|
| Founder | https://capavate.com/user/login | Ozan.isinak@gmail.com | Removed; use approved account recovery |
| Investor | https://capavate.com/investor/login | ozan@capavate.com | Removed; use approved account recovery |
| Partner | https://capavate.com/partner/login | ozan@trendwellventures.com | Removed; use approved account recovery |
| Admin | https://capavate.com/admin/login | ozan@capavate.io | Removed; use approved account recovery |

- Founder test company: **BluePrint Catalyst Limited** (`co_a2e5ca95c358`), PRO plan (not paywalled).
- Founder userId: `u_founder_1782301936139_9tqnpg`.
- **Login tip:** the sign-in endpoint rate-limits on rapid retries ("Sign-in failed. Try again in a moment."). On failure, wait 30-60s and retry ONCE; do not hammer it.
- **Payments are Airwallex LIVE (REAL MONEY).** NEVER exercise payment / funding / soft-circle-commit / SPV-commit flows on live during testing.

## 7. Deployer & delivery

- **Avi** (developer who installs on the live GoDaddy box): `avinaykumar.web@gmail.com`.
  Gmail strips his ZIP attachments, so he receives packages via WhatsApp; email is
  for the written install steps.
- Server path: `/var/www/html/backend/`. DB: SQLite `data.db` (better-sqlite3,
  SYNCHRONOUS — no async inside `db.transaction`). **Back up `data.db` before any migration/restart.**
- SMTP live: smtp.gmail.com:465.

## 8. THE recurring lesson — "code exists but does not execute on live"

The single most expensive mistake on this platform: **fixing a code path the live
product never runs.** Two waves (wfix/wavi64) shipped correct code on DEAD paths.
Before diagnosing ANY "still broken" report, PROVE the live code path first:

1. Trace the CLIENT to find which endpoint/field the UI actually calls (DevTools
   Network, or read the page component) BEFORE touching the server.
2. Capture the real request/response on live (status + JSON) to confirm the bug
   reproduces on the path you intend to fix.
3. Beware **bundle-fragile lazy `require()`**: `createRequire` lazy requires can
   resolve in dev/tests but FAIL in the production CJS bundle (`dist/index.cjs`),
   returning null → silent 403/empty. Prefer a static import or a DB-direct read
   via the already-imported `rawDb` handle. (This was the true cause of the round
   wizard 403 — see §9 Issue-1.)

**pm2 mode:** several read paths use in-process caches keyed by userId/email
(e.g. `RUNTIME_INVITATIONS`, `listForInvestorEmail` is cache-only). Under pm2
CLUSTER mode a write on worker A is invisible to worker B → intermittent
"missing" data. Stay on **fork** mode until these are DB-first, or the symptoms
will look like ghosts.

## 9. Confirmed root-cause registry (live-verified; fixed in the noted wave)

- **Issue 1 — round wizard 403 `not_round_owner` / investor never sees round / no email.**
  `PATCH /api/founder/rounds/:id/initial-shareholders`. Cause: `callerOwnsRound`
  resolved the round via a lazy `require("../roundsStore")` that fails in the prod
  bundle → owner check false → 403 → no invitation created. Fixed W-AVI65 FIX 1
  (DB-direct `rawDb` ownership; fail-closed; soft-deleted foreign round denied).
  Secondary: `buildInvitedRounds` (SACRED `userContext.ts`) only hydrated the
  invitation cache when EMPTY → an already-registered investor didn't see a new
  round until restart. Fixed W-AVI65 (authorized sacred edit: UNION DB rows every
  call, dedup by invitationId). **This is the same bug as Shadie 1a/1b.**
- **Issue 2 — founder↔investor DM shows "Private Investor".** UI reads
  `GET /api/comms/channels`→`displayTitle`. Cause: `areCoMembersOnAnyCapTable`
  (SACRED) is investor↔investor only → founder never a co-member → masked; plus
  `COMMS_USERS={}` in prod → raw `u_` id. Fixed W-AVI65 FIX 2 (non-sacred
  `dmCoMembership.ts` founder↔committed-holder predicate; names via
  `displayNameResolver`; email/raw-id never surfaced; opt-out still wins).
- **Issue 3 — admin/global header search returns nothing.** Header search calls
  `GET /api/founder/search` (NOT `/api/admin/search`, which had zero callers).
  Founder-scoped → empty for admin, never searched companies. Fixed W-AVI65 FIX 3
  (role-aware: admin→/api/admin/search with a company result kind; founder path
  gains a tenant-scoped company surface; parameterized + escaped SQL).
- **Duplicate round names — ALREADY ENFORCED (do not "fix" again).**
  `POST /api/rounds` returns **409 `ROUND_NAME_DUPLICATE`** scoped to company+STAGE
  (`routes.ts` ~5071; `roundsStore.roundNameExistsForCompany`), and the UI
  auto-suggests "<name> (2)". Verified live for Series C and Pre-Seed. There is NO
  inline while-typing warning — the block fires at final create only (acceptable).
  (Shadie 6a/7a were already fixed before their walkthrough was recorded.)

## 10. Invitation expiry semantics (Shadie 3a / W-SHADIE)

- `createInvitation` computes `expiresAt = plusDaysIso(args.expiryDays ?? 14)`
  (`roundInvitationsStore.ts:397`) with **NO minimum/clamp** — any day count is
  honoured verbatim. The `?? 14` is only a fallback when `expiryDays` is omitted.
- W-SHADIE sets the CLIENT default to **7 days** consistently across all invite
  surfaces (RoundNew manual dialog + RoundDetail invite dialog), 7 as the first
  option, and aligns the Bulk CSV path (server-set) to 7. Shared constants live in
  `client/src/lib/inviteExpiry.ts` (`DEFAULT_INVITE_EXPIRY_DAYS=7`,
  `INVITE_EXPIRY_OPTIONS=[7,14,30,60,90]`).
- **KNOWN pre-existing quirk (out of scope, do NOT claim fixed):** the RoundDetail
  "Never" option maps to omitted `expiryDays` → server `?? 14`, i.e. "Never" is
  really 14 days today, not truly never.
- The `resent` invitation state + `resentAt` timestamp already exist end-to-end
  (`publicView` returns `resentAt`); W-SHADIE 4a surfaces it as its own column.

## 11. Verification discipline (every wave)

- **Triple-verify with Opus + Gemini 3.1 Pro + GPT-5.6 (decider). NEVER ship on
  REVISE.** Auto-fix and re-verify until unanimous SHIP. Triple-test the DIAGNOSIS
  and the STRATEGY too, not just the final code — it repeatedly catches
  wrong-layer fixes and incomplete scope before a line is written.
- **Sacred gate 47/47** before AND after every wave (`npm run sacred`, i.e.
  `bash scripts/sacred_check.sh`). Use `npm run sacred` (waiver-aware; `SACRED OK: 47/47`, exit 0). The raw `sha256sum -c sacred_baseline/SACRED_SHA256.txt` reader is **waiver-blind** and reports the five owner-waived files as `FAILED` (35 OK of 40, exit 1) on a healthy tree — by design, not corruption.
  SACRED edits require explicit owner
  authorization + re-baseline of that ONE file's hash + documented old→new.
- Sandbox CANNOT `npm install` (native better-sqlite3 compile hangs) → gates are
  asserted by inspection + logic simulation here and RUN ON THE SERVER via the
  Gate Runbook (`npm run build`, `tsc --noEmit`, `npm run guard`, `npm run sacred`,
  `vitest run` the FULL suite — not just the new wave's tests, or you miss
  pre-existing/adjacent breakage).
- Additive + behavior-preserving; DB-driven (no in-memory canonical state on prod
  paths); per-tenant isolation is a fail-closed SECURITY boundary; money only via
  the single `commitFunded` ledger.
- Preserve **Avi hand-edits** (see `AVI_HAND_EDITS_INVENTORY.md`; home3compo
  hash-router href fix).
- Known pre-existing test to IGNORE: `sprint28_billing/hash-chain-replay` under
  pglite (42703) — reproduces on baseline, unrelated to changed files.
