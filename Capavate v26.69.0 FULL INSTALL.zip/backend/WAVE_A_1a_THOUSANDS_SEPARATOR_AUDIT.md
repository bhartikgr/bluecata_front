# 1a — Thousands-separator audit (currency + share counts)

**Ask:** every CURRENCY amount and every SHARE/UNIT count must render in
thousands-separator format across the ENTIRE platform (Consortium Partners,
Collective, Investor, Capavate/founder, Admin).

**Scope this wave (per Ozan, Q3=B):** start with the Consortium Partner
surfaces; expand platform-wide after the approach is confirmed.

## Finding: the platform is already largely compliant

The v25.37 / v25.38 / v25.40 currency sweeps already routed money through
grouping-aware formatters, and cap-table/share renders already use a grouping
helper. Concretely:

### Currency (already grouped)
- **Shared formatter** `formatMinor(minor, currency, { locale: "en-US" })` in
  `client/src/lib/currency.ts` uses `Intl.NumberFormat(style:"currency")`, which
  **always inserts thousands separators**. Example: `CA$1,200.00` (visible on
  the SPV Engine Review step, matching QA slide 3).
- **Consortium Partner surfaces** consume it everywhere amounts DISPLAY:
  `PartnerSpvEngine.tsx` (local `fmt` → `formatMinor`), `PartnerSpvDetail.tsx`,
  `PartnerDashboard.tsx` (`SPVs committed` / `Funds committed`),
  `PartnerContacts.tsx` (`money()` via `Intl.NumberFormat`), `PartnerBilling.tsx`,
  `PartnerFundDetail.tsx`. (9 partner pages import `formatMinor`.)
- The values shown WITHOUT separators in QA slide 2 (`120000`, `20000`,
  `30083`) are the **editable `<input type="number">`** fields (Target raise /
  Min check / Cap). A native numeric input **cannot** display grouping
  separators (the browser rejects a `type=number` value containing commas), so
  these are correctly left un-grouped while editing; their **display** on the
  Review step and the SPV list IS grouped via `formatMinor`.

### Share / unit counts (already grouped)
- Founder cap-table and investor share renders use a grouping helper `fmtNum`
  (`CapTable.tsx`, `RoundDetail.tsx`, `InvitationDetail.tsx`), e.g.
  `{fmtNum(w.shares)} sh` → `1,000,000 sh`.
- No Consortium Partner / Collective surface renders a raw ungrouped financial
  share count. (The only unformatted `shareCount` values are **social post
  share counts** — engagement metrics like `0`/`1` in `PostsFeed.tsx` /
  `PostDetail.tsx` — where grouping is irrelevant.)

## Change made this wave (robustness / future-proofing)

Added a **canonical count formatter** to `client/src/lib/currency.ts` so any
future non-currency quantity has a single grouped primitive to call (mirroring
the currency `formatMinor` convention):

```ts
export function formatShares(value, { maxFraction = 0 } = {}): string  // "1,000,000"
export function formatCount(value, opts): string                       // alias
```

- en-US grouping, whole-number by default, null/NaN → "—".
- No behavior change to existing renders; this is an additive primitive.

## Net result for 1a
- Consortium Partner currency + share displays: **already compliant** (grouped).
- Editable numeric inputs: correctly un-grouped (native `type=number` limitation).
- New shared `formatShares`/`formatCount` primitive available for the
  platform-wide expansion phase and any new surface.

## Recommended follow-up (platform-wide expansion, on greenlight)
A future pass can adopt `formatShares` at any new share/unit render and audit
Admin surfaces the same way. No currency changes are required — those already
group. This keeps 1a to a single, verifiable standard everywhere.
