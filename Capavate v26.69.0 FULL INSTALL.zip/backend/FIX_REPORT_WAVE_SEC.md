# FIX REPORT — Wave 1 (Security Hardening) — v26.2.0

**Baseline:** v26.1.2 (`edd6c56`). **Scope:** the W1 security items from
`ROADMAP_SPEC_SECURITY.md`. No payments/Airwallex code touched; no sacred file edited.

## Gates (final)
- Sacred: **40/40 OK** · Money sha16: **01cd36130ee1c0cb** (unchanged)
- tsc net-new: **0** (total **598**)
- Guard: **exit 0** — 929 routes / 194 pages / 92 nav (unchanged; no drops — all fixes
  hardened EXISTING routes, added none)
- Build: **EXIT 0** · No-silent-drop test: **pass**
- New suite `waveSEC_collective_gating.test.ts`: **16/16 pass** (14 + 2 round-2 H6 fail-open regression tests)
- Pre-existing failing suites UNCHANGED (verified identical on pristine HEAD via stash):
  `sprint21_invitations` 2 failed/12 passed, `spvEngine` 30 failed/4 passed. No regressions.

## Fixes

### C1/C2 — Partner compliance IDOR  (`spvEngineRoutes.ts`, `spvEngineStore.ts`)
- New `spvEngineStore.partnerCanAccessInvestorCompliance(partnerId, investorId)` —
  fail-closed relationship proof: non-withdrawn `spv_subscription` on a
  partner-sponsored `spv`, OR an active `partner_sourced_investors` row; independent
  try/catch per DB probe (missing lazily-created secondary table can't suppress the
  primary check) + in-memory fallback.
- `GET /api/partner/me/compliance/:investorId` and `PUT` now call the guard BEFORE any
  read/write → 403 `INVESTOR_NOT_RELATED_TO_PARTNER` for unrelated investors.
- `PUT` adds a strict `.strict()` zod schema (6 allowed fields) → 400
  `INVALID_COMPLIANCE_PROFILE_PATCH` on unknown keys / bad enums.

### H2 — `/api/collective/spvs` under-gated  (`spvEngineRoutes.ts`)
- Added `requireCollectiveMember` middleware (admin bypass included). Collective-only
  SPV visibility is now a member benefit, not available to any signed-in user.

### H3/H4 — Partner portfolio enumeration/upsert IDOR  (`partnerRoutes.ts`)
- New `partnerCanAccessCompanyPortfolio(partnerId, companyId)` — 6 relationship proofs
  (owned portfolio row, live attribution, consortium sponsor link, pipeline deal, live
  promotion, sponsored-SPV target). Following is intentionally NOT a proof.
- GET returns 404 `PORTFOLIO_COMPANY_NOT_FOUND` for unrelated companies (no global
  name/logo leak — 404 not 403 avoids an existence oracle). PATCH checks the
  relationship BEFORE body validation (no validation oracle).

### H5 — `/api/partner/me/soft-circles/source` partner-exposed  (`partnerConsortiumRoutes.ts`)
- Now **admin-only** (`getUserContext` → 401 unauth / 403 `ADMIN_REQUIRED` non-admin),
  with a strict `.strict()` zod schema (positive int amount, currency/status enums,
  required companyId) + company-existence check → 404 `COMPANY_NOT_VISIBLE`. Removes
  the partner path that could mint synthetic FUNDED, collective-visible rows. No
  client/test consumed the old behaviour (clean lock-down). Route path unchanged for
  backward-compatible denial; idempotent insert preserved. Reuses the file's existing
  `createRequire` shim (no new require idiom).

### H6 — Fail-closed membership deactivation  (new store + billing + worker + gate)
- New migration **0109** `collective_membership_deactivation_queue` (mirrored in
  `migrations/` + `server/db/migrations/` + inline self-heal
  `applyH6MembershipDeactivationQueueSchema` in `connection.ts`).
- New non-sacred `collectiveMembershipDeactivationStore.ts`:
  `enforceMembershipDeactivation` records intent BEFORE attempting deactivate (throws
  `MEMBERSHIP_DEACTIVATION_STATE_FAILED` if it can't even record); on deactivate
  success → resolve marker; on failure → leave OPEN + backoff.
  `hasOpenMembershipDeactivation` (fail-closed on read error),
  `resolvePendingMembershipDeactivationsForUser` (on billing recovery),
  `processPendingMembershipDeactivations` (retry loop).
- Gate: `requireCollectiveMember` now DENIES (403 `billing_deactivation_pending`) if an
  open marker exists — placed after admin bypass, before the 4-source active check
  (which could otherwise admit from a stale mirror).
- `collectiveBillingStore.ts`: Stripe + Airwallex cancel/past_due paths now call
  `enforceMembershipDeactivation`; active-recovery paths call
  `resolvePendingMembershipDeactivationsForUser`. **No Airwallex/payment charge code
  touched** — state tables only.
- `collectiveRenewalWorker.ts`: `cancelMembership` + `markPastDue` use
  `enforceMembershipDeactivation`; `tick()` runs `processPendingMembershipDeactivations`.

**ROUND-2 REVISE fix (deciding verifier GPT-5.5 found a fail-open):** the webhook/
worker paths commit the billing status transition (cancelled/past_due) BEFORE the
marker is written, so if the marker write itself failed, no open marker would exist
and the gate could still admit via stale active state. Fix = a SECOND, independent
fail-closed signal: new `hasCancelledOrPastDueBilling(userId)` reads the
`collective_memberships_billing` STATE table (persisted by the billing transition
itself, not dependent on the marker) and the gate now denies on
`hasOpenMembershipDeactivation(userId) || hasCancelledOrPastDueBilling(userId)`. Fails
CLOSED on read error. Still no Airwallex/payment code touched. New regression test
proves a cancelled billing row with NO marker is still denied.

### ELIG — eligibility `?userId` probe  (`collectiveAppStore.ts`)
- `?userId=` is now an ADMIN-ONLY diagnostic override; non-admins use their session id;
  anonymous/non-admin `?userId` is silently ignored (no 403, no shape change — avoids a
  format/existence oracle).

## Files changed (13; +889/−73) — see `WAVE_SEC_SOURCE.diff`
server/spvEngineStore.ts, spvEngineRoutes.ts, partnerRoutes.ts,
partnerConsortiumRoutes.ts, collectiveAppStore.ts, collectiveBillingStore.ts,
lib/collectiveRenewalWorker.ts, lib/requireCollectiveMember.ts, db/connection.ts,
collectiveMembershipDeactivationStore.ts (new),
migrations/0109 + server/db/migrations/0109 (new, mirrored),
server/__tests__/waveSEC_collective_gating.test.ts (new).

## Rule-#14 / sacred assurances
- No edits to `captableCommitStore.ts`, `paymentGatewayAdapter.ts`, `profileStore.ts`,
  `messagingStore.ts`, `userPrivacyResolver.ts`, or any sacred file (40/40 intact).
- No Airwallex/payment gateway code touched; H6 operates on membership/billing STATE
  tables + a new queue table only.
