import express from "express";
import request from "supertest";
import { registerRoundInitialShareholdersRoutes } from "./server/lib/roundInitialShareholdersStore";
import { listForRound } from "./server/roundInvitationsStore";
process.env.VITEST = "true";
process.env.SMTP_MODE = "dry_run";
const app = express();
app.use(express.json());
registerRoundInitialShareholdersRoutes(app);
const roundId = `rnd_c2_nonowner_${Date.now()}`;
const email = `c2_nonowner_${Date.now()}@example.com`;
const r = await request(app)
  .patch(`/api/founder/rounds/${roundId}/initial-shareholders`)
  .set("x-user-id", "u_aisha_patel")
  .send({ companyId: "co_novapay", shareholders: [{ name: "Blocked Investor", email, source: "manual" }] });
console.log(JSON.stringify({ status: r.status, body: r.body, inviteCount: listForRound(roundId).length }, null, 2));
