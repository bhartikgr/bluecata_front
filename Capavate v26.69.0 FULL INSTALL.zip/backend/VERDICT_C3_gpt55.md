# VERDICT: REVISE

## Blocking defect

1. `client/src/pages/founder/RoundDetail.tsx:203-212` builds the round-detail preview request without the invitation expiry, while `client/src/pages/founder/RoundDetail.tsx:147-165` sends the selected expiry (`inviteExpiry`, default `30`) on the real send. The server preview route also ignores expiry (`server/routes.ts:2732-2745`) and therefore `renderInvitationEmail()` falls back to `14` days (`server/roundInvitationsStore.ts:170,178`), but the real send route forwards `expiryDays` into `createInvitation()` (`server/routes.ts:2765,2822-2823`), which renders the email with the actual send expiry (`server/roundInvitationsStore.ts:532-539`). This violates PREVIEW == SEND: the founder can preview “expires in 14 days” and then send “expires in 30 days” (or 60 days) from the same dialog.

   Concrete fix: compute one normalized `expiryDays` value in the RoundDetail invite dialog and pass it to both preview and send, accept/validate `expiryDays` in `POST /api/rounds/:id/invitations/preview`, and pass it into `roundInvitationsRenderEmail()`. Add a route/client test asserting the preview HTML contains the same expiry text as the send path for the default 30-day selection and for 60 days.

## Gate results

- TypeScript gate: `npx tsc --noEmit 2>&1 | grep -c "error TS"` returned `598` (required exactly 598; net-new 0).
- Sacred hashes: `sha256sum -c sacred_baseline/SACRED_SHA256.txt | grep -c ": OK"` returned `40` (required 40/40).
- Sacred diff check: no path from `git diff HEAD~1 --name-only` appears in `sacred_baseline/SACRED_SHA256.txt`.
- C3 touched files check: `server/roundInvitationsStore.ts`, `server/roundsStore.ts`, `server/routes.ts`, `server/lib/roundInitialShareholdersStore.ts`, `client/src/pages/founder/RoundNew.tsx`, and `client/src/pages/founder/RoundDetail.tsx` are all non-sacred.
- Money checksum: `sha256sum server/captableCommitStore.ts | cut -c1-16` returned `01cd36130ee1c0cb`.
- Guard: `npm run guard` exited 0 with `OK: 929 routes, 194 pages, 92 nav — no silent drops`.
- Route delta from `git diff HEAD~1 -- server/routes.ts`: exactly three new route definitions were added: `POST /api/companies/:companyId/invitation-preview`, `POST /api/rounds/:id/invitations/preview`, and `GET /api/rounds/name-availability`. The guard’s broader informational list includes prior baseline deltas, but this Wave C3 diff adds only those three routes.
- Wave C3 targeted suite: `server/__tests__/waveC3_invite_preview_and_round_name.test.ts` passed `7/7`.
- Round regression suites: `roundPersistenceProof`, `roundDetailLoad`, `v2348_round_initial_shareholders`, and `v15_invitation_flow` passed `19/19` across `4/4` files.
- No migration, payments, or Airwallex files appeared in `git diff HEAD~1 --name-only`.

## Per-check findings

- Preview read-only/no leak: both preview routes only call `roundInvitationsRenderEmail()` and return JSON; they do not call token generation, `createInvitation()`, persistence, or `sendMail()`. Preview links are labelled placeholders, not real tokens (`server/routes.ts:2718-2724`, `server/routes.ts:2737-2745`).
- Ownership: round-scoped preview uses `requireFounderOwnsRound()` (`server/routes.ts:2728-2730`), company-scoped preview checks founder company ownership (`server/routes.ts:2709-2713`), and name availability checks founder company ownership (`server/routes.ts:4261-4268`).
- Client override: round-scoped preview server-resolves company and round name (`server/routes.ts:2733-2736`); Step-4 preview accepts draft `roundName` while server-resolving `companyName` (`server/routes.ts:2715-2722`). This is acceptable for pre-create preview, subject to the expiry defect above for round-detail preview.
- XSS: all HTML interpolations in `renderInvitationEmail()` are escaped through `escapeHtml` for investor name, round name, company name, link, note, and expiry (`server/roundInvitationsStore.ts:173-178`). The client renders this server HTML via `dangerouslySetInnerHTML` (`client/src/pages/founder/RoundDetail.tsx:904-908`, `client/src/pages/founder/RoundNew.tsx:1174-1177`), and I found no unescaped dynamic HTML input reaching that markup.
- Per-company name uniqueness: `roundNameExistsForCompany()` filters through `getRoundsForCompany(companyId)` and compares case-insensitively (`server/roundsStore.ts:164-172`), so uniqueness is per company. The cross-company test passed (`server/__tests__/waveC3_invite_preview_and_round_name.test.ts:79-91`).
- Duplicate guard: `createRound()` throws `ROUND_NAME_REQUIRED` or `ROUND_NAME_DUPLICATE` before constructing/inserting the row (`server/roundsStore.ts:209-219`), and the API maps duplicate errors to conflict responses downstream.
- Suggestion termination: `suggestUniqueRoundName()` increments suffixes through `(999)` and then returns a timestamp-suffixed fallback (`server/roundsStore.ts:179-187`), so it terminates and avoids known collisions in normal cases.
- Note persistence: `note` is included in the invitation row, DB insert, DB hydration, and Step-4 initial-shareholders call into `createInvitation()` (`server/roundInvitationsStore.ts:408,435-456,242-257`; `server/lib/roundInitialShareholdersStore.ts:181-190,267-277`).
