const db = require('better-sqlite3')('/tmp/freeze.db');

function testJson(name, jsonStr) {
  try {
    db.prepare(`INSERT INTO rounds (id, tenant_id, company_id, name, type, state, target_amount, raised_amount, extras_json) VALUES (?, 't', 'c', 'r', 'safe', 'draft', 0, 0, ?)`).run(name, jsonStr);
    console.log(`[PASS] ${name}`);
  } catch(e) {
    console.log(`[FAIL] ${name} - ${e.message.split('\\n')[0]}`);
  }
}

testJson("uncapped_safe_absent", `{"discount":20}`);
testJson("uncapped_safe_null", `{"discount":20, "valuationCap":null}`);
testJson("uncapped_safe_empty", `{"discount":20, "valuationCap":""}`);
testJson("uncapped_safe_0", `{"discount":20, "valuationCap":0}`);
testJson("uncapped_safe_0_string", `{"discount":20, "valuationCap":"0"}`);
testJson("no_interest_absent", `{}`);
testJson("no_interest_null", `{"interestRate":null}`);
testJson("no_interest_empty", `{"interestRate":""}`);
testJson("no_interest_0", `{"interestRate":0}`);
testJson("no_liquidation_pref", `{"valuationCap":5000000}`);
testJson("no_anti_dilution", `{"valuationCap":5000000}`);
testJson("strike_price_empty", `{"strikePrice":""}`);
testJson("strike_price_null", `{"strikePrice":null}`);
