# 1e — Analysis: "Engine legal-entity type" field on the SPV Engine wizard

**Surface:** Consortium Partner → SPV Engine → Step 1 "Name & jurisdiction"
(`/collective/partner/spv-engine`, `client/src/pages/partner/PartnerSpvEngine.tsx`).

## The three related fields today

The Step-1 form currently asks the user for **three** overlapping location/structure inputs:

| # | Field (label) | State key | Source | Purpose |
|---|---|---|---|---|
| 1 | **Jurisdiction (country)** \* | `jurisdictionCountry` | `SPV_TOP_JURISDICTION_COUNTRIES` (top-15 + Other) | The country the vehicle is domiciled in. Mandatory. |
| 2 | **Legal entity structure** | `legalEntityStructure` | `SPV_JURISDICTION_ENTITY_STRUCTURES[country]` (dependent on #1) | The formation vehicle (e.g. Delaware LLC, Cayman exempted company, BVI BC, Canadian LP). |
| 3 | **Engine legal-entity type** | `jurisdiction` | `SPV_JURISDICTIONS = ["delaware","cayman","bvi","canadian_lp"]` | A strict 4-value enum the SPV store historically validated against. |

## Root of the redundancy

Field #3 (`jurisdiction`) is a **legacy engine primitive**. It predates the richer country + structure pair (#1/#2), which were added later (spec 3b/2a) *additively* — deliberately kept separate so the strict enum and its store validation wouldn't have to change (rule #8, no migration).

From the user's perspective, #3 is **conceptually a subset of #1 + #2**:
- "delaware" ⊂ United States + LLC/LP
- "cayman" ⊂ Cayman Islands + exempted company
- "bvi" ⊂ British Virgin Islands + business company
- "canadian_lp" ⊂ Canada + Limited Partnership

Asking the user to *separately* pick "delaware" after they've already chosen "United States" + "Limited Partnership" is redundant and confusing — it looks like a fourth decision when it is really a machine detail.

## Is #3 still necessary? — No, not as a user-facing input

**Server behavior (authoritative):** In `server/partnerRoutes.ts` the create path does:

```ts
const canonicalJurisdiction = isSpvJurisdiction(jurisdiction) ? jurisdiction : "delaware";
```

i.e. the server already **falls back to `"delaware"`** for any non-enum value, and the original free-text is preserved in `terms.legacyJurisdiction`. The canonical wizard also stores the real country/structure on `terms.jurisdictionCountry` / `terms.legalEntityStructure`. So the strict enum is now only an **internal engine tag**, not a distinct piece of user information.

**Conclusion:** the "Engine legal-entity type" field **no longer adds distinct value at the interface** and should be **removed from the UI**. The enum itself stays in the engine (no enum change, no migration, rule #8 honored) — the wizard simply **auto-derives** it from the chosen country instead of asking the user.

## Recommended change (implemented in Wave A)

1. **Remove** the "Engine legal-entity type" `<select>` from Step 1.
2. **Auto-derive** the engine enum from `jurisdictionCountry` via a small pure mapper:
   - United States → `delaware`
   - Cayman Islands → `cayman`
   - British Virgin Islands → `bvi`
   - Canada → `canadian_lp`
   - anything else / Other → `delaware` (matches the server's existing fallback exactly)
3. The user's **true** intent is still captured verbatim in `terms.jurisdictionCountry` + `terms.legalEntityStructure` (unchanged), so no information is lost and the engine enum keeps working exactly as before.
4. `data-testid="spv-w-jurisdiction"` is **preserved** (the derived value is kept on state / a hidden input), so no test or the anti-silent-drop guard breaks.

## Investor-grade best practice (recommended global standard)

For an institutional SPV/fund formation flow, the recognized, globally-legible way to capture domicile is a **two-field model**, which is exactly #1 + #2:

1. **Jurisdiction (country of domicile)** — the sovereign jurisdiction. Best practice is to lead with the globally dominant SPV/fund domiciles and allow "Other":
   - **United States** (Delaware — the global default for onshore SPVs/LLCs/LPs)
   - **Cayman Islands** (the offshore standard for funds; exempted company / ELP)
   - **British Virgin Islands** (BC / limited partnership)
   - **Luxembourg** (SCSp / RAIF — the EU standard)
   - **Ireland** (ICAV), **Singapore** (VCC), **United Kingdom** (LP), **Jersey/Guernsey**, **Canada** (LP), **UAE/ADGM/DIFC**
2. **Legal entity structure** — the formation vehicle *within* that jurisdiction (dependent dropdown), e.g. LLC, LP, exempted company, SCSp, VCC, ICAV, LLP.

This mirrors how leading platforms (Carta, AngelList, Sydecar, Allocations) model it: **country first, then structure**, with the engine's internal classification derived automatically — never surfaced as a third user choice. Removing the "Engine legal-entity type" field brings Capavate in line with that standard.
