# FIX REPORT — Wave 3 (Privacy + Data-hygiene + Shadie round-flow) — v26.2.0-w3

**Baseline:** v26.2.0-w2m (HEAD `2653286`). **Scope:** W3 Privacy (ROADMAP_SPEC_SECURITY §7)
+ W3 Data-hygiene (ROADMAP_SPEC_FEATURES W3.1-W3.6) + **Shadie's round-flow findings**
(folded in per Ozan). No sacred file edited; no payments/Airwallex code touched.

## Gates (final)
- Sacred: **40/40** · Money sha16: **01cd36130ee1c0cb** · `messagingStore.ts` **17bd56080b6af4a7** (unchanged)
- tsc net-new: **0** (total **598**)
- Guard: **exit 0** — **932** routes / 194 pages / 92 nav (was 931; +1 = W3.3 pitch-deck
  download route; no drops)
- Build: **EXIT 0** · No-silent-drop test: **pass**
- New suites: `wave3_privacy_enforcement` 9/9, `wave3_hygiene` 18/18, `wave3_shadie_rounds`
  5/5 (+ client tests). No regressions (per-suite): rounds/invitations/userContext green;
  pre-existing `sprint21_invitations` 2, `spvEngine` 30 unchanged.

## Shadie round-flow fixes (verified live first, triple-verified vs code)
- **1a** — Open date + Target close date are now MANDATORY. Client: `scheduleInvalid` now
  includes empty-date checks + required markers/inline errors on both inputs. Server:
  fail-closed backstop in `POST /api/rounds` (400 OPEN_DATE_REQUIRED / CLOSE_DATE_REQUIRED).
- **3a** — manual-investor modal gains "Stage focus (optional)" + "Expires in" (preset days
  select that shows BOTH the day count AND the computed calendar date, per Ozan);
  `stageFocus`/`expiryDays` threaded through the initial-shareholders PATCH into the round
  invitation (backend already accepted them).
- **4a** — round-name uniqueness RE-SCOPED from per-company-all-stages to per **company +
  STAGE** (case- AND whitespace-insensitive). A company may run two Series A rounds with
  distinct names; a same-name-same-stage duplicate is rejected (409) with a stage-scoped
  auto-suggested editable name. `roundsStore.roundNameExistsForCompany` /
  `suggestUniqueRoundName` + `routes.ts` name-availability + create both updated.
- **5a** — on the "Upload my own term sheet" path the toast no longer declares the round
  "now active"; it reads upload-forward ("Once your term sheet is uploaded, the round will
  be created.").
- **6a** — RoundDetail Invitations SENT and EXPIRES now BOTH show the absolute date + the
  relative "Xd ago".
- **7a** — investor Invitations CTA no longer left-clips "Review Deal and Soft-Circle"
  (widened column, wrap-allowed, sized-to-fit button).
- **2a / 2b** — confirmed ALREADY working in code (Wave C2 attaches Step-4 investors +
  emails on round creation); locked with `wave3_shadie_rounds` + existing invitation suites.

## W3 Privacy (spec §7) — all NON-SACRED
- New `server/privacyVisibilityBridge.ts`: consumes `privacy.visibility.changed` outbox
  events (emitted by sacred profileStore) and mirrors them into the sacred resolver via
  `writeUserPrivacy` (merge present fields only; never blanks screenName). Registered at
  startup alongside `hydrateBridgeStore` in `server/index.ts`. Fail-safe on boot.
- **LIVE consumption (post-review fix, addresses GPT-5.5 REVISE round 1):** the sacred
  profileStore only APPENDS to its outbox on the live PATCH paths and exposes no subscribe
  hook, so a single startup drain missed every privacy change made after boot. Closed with
  (a) a production-gated, `.unref()`'d `setInterval` drain worker
  (`startPrivacyVisibilityBridgeWorker`, default 30s, env-tunable/opt-out, mirrors
  `chapterLeaderboardStore`) wired in `server/index.ts`, and (b) a zero-latency lazy drain
  on the `/api/collective/members` directory read (mirrors
  `commsStore.publishDueScheduledPosts`) so a just-saved toggle takes effect on the very
  next read. Both idempotent + fail-safe. New tests lock post-boot mirroring + worker
  start/stop (privacy suite now 9/9).
- Bypass fixes: `v2546Routes.ts` DM recipients now pass `isCoMember` from the `canDM`
  verdict; `collectiveRoutes.ts` social-directory now FAILS PRIVATE ("Private Investor")
  for contacts with no linked user id (no email leak) + removed a double-call bug.
- `wave3_privacy_enforcement.test.ts` (9/9 — incl. post-boot live-consumption + worker).

## W3 Data-hygiene (W3.1-W3.6) — all NON-SACRED
- **W3.1** seed/test-data guard (hide QA/seed rows in admin applications+members behind
  `HIDE_SEED_DATA`; reports `hiddenSeedCount`; never deletes).
- **W3.2** email/opaque-id-as-name display fixes via new `client/src/lib/personName.ts` +
  strict resolver usage (email kept in its own field).
- **W3.3** pitch-deck filename → real "Download pitch deck" link via a guarded streaming
  route (raw s3Key never exposed) — the +1 guard route.
- **W3.4** company slug `u_founder_*` → human `companyDisplayName`.
- **W3.5** partner-team duplicate active-seat dedupe (most-privileged → newest → stable id)
  + `duplicateSeatCount` meta + admin warning banner.
- **W3.6** new `client/src/lib/collectiveLabels.ts` humanizes snake_case fee/cadence/scope
  enums (display-only) across payment/fee/SPV tables.
- `wave3_hygiene.test.ts` (18/18).

## Rule assurances
- No sacred file edited (40/40); money + messagingStore byte-identical. No Airwallex/payment
  code. ESM only (reused existing createRequire shims; the one new commsStore-adjacent static
  import from W2M is unchanged). Migration ledger untouched (W3 adds no migration).
  Last-name-everywhere respected (personName helper composes First+Last).
