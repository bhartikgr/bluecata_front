#!/usr/bin/env bash
set -euo pipefail
cd /home/user/workspace/capavate_work
BASE=6f7a17f
VER=v26.2.0-w2m
OUT=/home/user/workspace/release_${VER}
mkdir -p "$OUT"
rm -f "$OUT/capavate_${VER}_PATCH.zip" "$OUT/capavate_${VER}_FULL_INSTALL.zip" "$OUT/SHA256SUMS_${VER}.txt" "$OUT/CHANGED_FILES.txt"
git checkout -- server/public 2>/dev/null || true
git clean -fdq server/public/assets dist 2>/dev/null || true
CHANGED=$(git diff --name-only ${BASE}..HEAD -- server client shared migrations scripts script package.json vitest.config.ts | grep -v '\.orig$' | grep -vE '^verify_|^uploads/' || true)
echo "$CHANGED" > "$OUT/CHANGED_FILES.txt"
zip -q "$OUT/capavate_${VER}_PATCH.zip" $(echo "$CHANGED")
zip -qr "$OUT/capavate_${VER}_FULL_INSTALL.zip" . \
  -x '*/node_modules/*' -x 'node_modules/*' -x '*/.git/*' -x '.git/*' \
  -x 'dist/*' -x '*/dist/*' -x 'server/public/assets/*' -x 'backups/*' \
  -x '*.orig' -x 'verify_*.txt' -x 'uploads/test/*' -x "release_${VER}/*"
( cd "$OUT" && sha256sum capavate_${VER}_PATCH.zip capavate_${VER}_FULL_INSTALL.zip > SHA256SUMS_${VER}.txt )
echo "patch files: $(echo "$CHANGED" | grep -c .)"; ls -la "$OUT"
