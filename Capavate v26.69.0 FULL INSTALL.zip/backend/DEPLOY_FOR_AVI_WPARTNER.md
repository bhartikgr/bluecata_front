# DEPLOY — Wave W-PARTNER (v26.2.0-wpartner)

**Read `FIX_REPORT_WAVE_WPARTNER.md` first.** This note is the mechanical deploy checklist.

## What's in the package
- `capavate_v26.2.0-wpartner_FULL_INSTALL.zip` — the complete app tree (no node_modules) at this wave. Use for a clean install.
- `capavate_v26.2.0-wpartner_PATCH.zip` — only the 32 changed/new files, same relative paths. Use to patch an existing wavi64+W-SHADIE checkout.
- `capavate_v26.2.0-wpartner_RELEASE_BUNDLE.zip` — FULL + PATCH + SHA + this report + fix report + source diff, together.
- `SHA256SUMS_v26.2.0-wpartner.txt` — checksums for the three zips.
- `WAVE_WPARTNER_SOURCE.diff` — unified diff vs the baseline for review.

## Prerequisite
This wave sits ON TOP of the pending **W-SHADIE** package (bridge HMAC + invite-expiry fixes). If W-SHADIE is not yet deployed, deploy the W-PARTNER FULL_INSTALL (it already contains the W-SHADIE changes carried in the build tree), or apply W-SHADIE first, then the W-PARTNER PATCH.

## Deploy steps (server: /var/www/html/backend, SQLite data.db)
1. **Back up** `data.db` before anything.
2. Unpack the chosen zip over the app root (FULL for clean, PATCH to overlay).
3. `npm ci` (installs deps; sandbox couldn't, the server must).
4. **Migrations** apply automatically on boot via the runner + self-heal. To pre-apply, ensure `migrations/0114_partner_attributions.sql` and `migrations/0115_partner_client_crm_lead.sql` are present (they are). The kv→typed attribution **backfill runs at boot** (guarded; logs `scanned/inserted/coerced/skipped`).
5. `npm test` — expect green except the known-red baseline (`sprint28_billing` / `hash-chain-replay`, pglite `42703`).
6. Start the server. Watch the boot logs for:
   - `hydrating N attribution(s) via the typed path` (or `kv` on first boot before backfill completes — both safe).
   - the backfill summary line.
7. **Smoke test the two streams:**
   - Stream 4: as a Consortium Partner, Add a portfolio company → it appears under Clients AND Portfolio → open the client → assign a designated lead (an active team member).
   - Stream 5: promote a company to Collective → chapter-admin approves → confirm it appears in the Deal Room for a non-admin member of that chapter.

## Rollback
- Every item is independently revertible. Re-deploy the prior build.
- `lead_user_id` is an inert nullable column — do NOT drop it (no down-migration convention).
- The typed attribution tables are inert if the store reverts to kv-only; the kv dual-write is retained THIS wave so a rollback loses no attribution.
- F9-B cleanup if needed: `UPDATE collective_directory_listings SET status='removed' WHERE application_id LIKE 'promo_%';`

## Do NOT
- Do NOT hand-edit `migrations-pg/` (drizzle-generated; breaks the PGlite harness).
- Do NOT trigger any Airwallex/funding/soft-circle flow while smoke-testing (LIVE = real money).
- Do NOT edit `founder/Company.tsx` (source-text contract-test pinned).
