# Capavate v25.49.0-rc1 — CHANGELOG (Consortium Partner rebuild — checkpoint)

> INTERIM checkpoint. Consortium Partner Phases 1-3 are complete and gate-green. The canonical SPV
> Engine (Phase 4) is NOT in this build yet — it lands in the final v25.49.0. This RC is safe to
> install on top of live v25.48.2; it is additive and drops nothing.

## Phase 1 — P0 crash fix (the whole partner workspace was down on live)
- **Fixed React error #310 that crashed the entire Consortium Partner workspace on every page.**
  Root cause in `client/src/components/CollectiveShell.tsx`: a membership hook was called
  conditionally via `partner.isPartner && useCollectiveMembershipActive()`. While membership data was
  still loading `isPartner` was false (hook skipped); once it resolved the hook ran — so the number of
  hooks changed between renders, which React forbids (#310). This matched the "reload several times and
  it eventually lets you through" symptom (cache-warm renders happened to keep hook order stable).
  Fix: the hook is now called unconditionally, above any branch, so hook order is render-invariant.
  No widget/section was removed to fix it (Sacred Rule #78).
- Regression test `client/src/components/__tests__/CollectiveShell.partnerHooks.test.ts` renders the
  partner shell in both loading and loaded states and asserts no hook-order violation.

## Phase 2 — Re-skin to capavate.com brand + grouped left-nav
- Retinted the partner module to the capavate.com palette (brand red `#cc0001`, navy `#041e41`, cream
  surfaces, Montserrat + Instrument Serif) by REUSING the app's existing on-brand `--cv-*` design
  tokens and the `[data-product="partner"]` block in `client/src/index.css` — no new palette invented
  (only a scoped `--destructive` brand-red added for the error card). Off-brand blue info banners and
  links across the partner pages are now brand navy/red. Semantic status colors kept.
- The global error boundary now inherits the partner brand theme on partner-route crashes only.
- Left-nav regrouped into labeled sections (all 14 items preserved, every route unchanged):
  **OVERVIEW** (Dashboard) · **DEALS & SPVs** (Pipeline, SPVs, Funds, Clients) · **WORKSPACE**
  (Team, Notes, Tasks, Files) · **NETWORK** (Messages, Posts — added in Phase 3) · **ACCOUNT**
  (Billing, Subscribe, Agreement, Tax Form, Settings).

## Phase 3 — Partner Clients CRM enhancement + Messaging & Posts widgets
- **Partner Clients CRM (kept as its own engine, per decision — not folded into the core CRM).**
  New migration `0083_v25_49_partner_client_crm.sql` (in BOTH `migrations/` and `server/db/migrations/`)
  adds two NEW parallel tables — `partner_client_crm` (durable CRM stage per partner+company) and
  `partner_client_activity` (append-only client timeline). Additive + idempotent (`IF NOT EXISTS`);
  existing `partner_attributions`/notes data and read paths untouched. New `partnerClientCrmStore.ts`
  + `partnerClientCrmRoutes.ts`, partner-scoped and fail-closed (a partner can only read/write its own
  clients' CRM). `PartnerClients.tsx` gains stages + list search/filter; `PartnerClientDetail.tsx`
  gains an activity timeline and the previously-empty "Cap table (read-only)" card now shows an honest
  state instead of a heading with no data.
- **Messaging + Posts inserted into the partner module (incl. dashboard).** New `PartnerMessages.tsx`
  and `PartnerPosts.tsx` pages (routes in `App.tsx`: `/collective/partner/messages`, `/posts`,
  `/posts/:id`), surfaced in the NETWORK nav group, plus compact Messages + Network-Posts cards on
  `PartnerDashboard.tsx`. These REUSE the shared comms components/endpoints (`MessagesWidget`,
  `PostsFeed`) — no parallel messaging/posts backend was built; partner access is scope-checked.
- Test `server/__tests__/partnerClientCrm.test.ts` covers the CRM engine + partner isolation.

## Known / expected (fixed in Phase 4)
- `server/__tests__/partner_workspace.test.ts` has 3 PRE-EXISTING failing tests (SPV creation → 500):
  a client↔server field-name contract drift in the OLD SPV/Fund create path. These are untouched by
  Phases 1-3 and will be REPLACED by the canonical SPV Engine in Phase 4 (final v25.49.0).

## Gates (this RC)
Sacred 39/39 byte-identical · tsc **601** (zero net-new) · build BUILD_EXIT=0 · no new `require()` in
server TS · Phase-1 + Phase-3 CRM tests pass · migrations additive+idempotent. Triple-verified
(Opus + Gemini + GPT-5.5) as a checkpoint.
