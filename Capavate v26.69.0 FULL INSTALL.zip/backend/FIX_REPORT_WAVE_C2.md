# FIX REPORT — Wave C2 (Shadie QA 1a/1b: CRM investor lands on round + email)

Founder → Rounds, round-creation Step 4. Non-sacred files only. No new
route/nav, no migration. All gates green (bottom).

## Reproduced on live (v26.0.0)
Round `QA CRM Test 2207` (rnd_6ec0fdc22ff2): a CRM investor added in Step 4
showed "Added" and appeared in "Selected for this round", but after create it
was **absent from Investor invitations (0), no email sent, and not in the cap
table** either. Repro report: `capavate_crm_round_bug_repro_2026-07-10.md`.

## Root cause
The Step-4 picks were sent only to `PATCH /api/founder/rounds/:id/initial-shareholders`,
which recorded them in the initial-shareholders store — a DIFFERENT store from
`roundInvitationsStore`, which is what the round's **Investor invitations** tab
reads (`GET /api/rounds/:id/invitations` → `roundInvitationsListForRound`) and
what sends the invitation email. So the pick was never issued a round
invitation: it didn't surface in the Invitations table (1a) and no email fired
(1b). The client also swallowed the PATCH result, so the founder got no feedback.

## Fix
- `server/lib/roundInitialShareholdersStore.ts` — after persisting the
  shareholder rows, the PATCH handler now issues a canonical round invitation
  (`roundInvitationsStore.createInvitation`) for each pick that has a valid
  email. That single call BOTH surfaces the investor in the Invitations table
  AND sends the invitation email via the existing path. Handler made `async`.
  Behavior:
  - **Idempotent** — an already-active invite throws `duplicate_invitation` and
    is counted as a benign skip, so a re-PATCH never double-sends.
  - **No email → no invite** — a pick without an email is recorded as a
    shareholder only and counted in `skippedNoEmail` (never a spurious invite).
  - **Fail-reported, not fail-silent** — per-invite failures are collected into
    `inviteErrors` and returned; they do NOT roll back the shareholder save that
    already persisted (the round exists; invites can be re-issued).
  - **Guarded lazy import** — `createInvitation` is loaded via the file's
    existing lazy-require shim, wrapped in try/catch so a load failure degrades
    gracefully (no crash) instead of failing the save.
  - Response now returns `{ invited, skippedNoEmail, skippedDuplicate, inviteErrors }`.
- `client/src/pages/founder/RoundNew.tsx` — the round-create `onSuccess` reads
  the PATCH summary and shows an accurate toast ("N investors invited by email",
  "N added without an email", "N invitations could not be sent"), instead of
  swallowing the result silently.

## Files
- `server/lib/roundInitialShareholdersStore.ts` (invite issuance + async + richer response)
- `client/src/pages/founder/RoundNew.tsx` (toast summary)
- **New** `server/__tests__/waveC2_crm_investor_lands_on_round.test.ts` — 3 tests
  (invitation makes the investor appear in `roundInvitationsListForRound`;
  re-issue refused / no double-send; no-email rejected). dryRun => no real email.

## Gates (end of C2)
| Gate | Result |
|---|---|
| Sacred files | **40/40** byte-identical (roundsStore.ts untouched) |
| Money core sha16 | **01cd36130ee1c0cb** (unchanged) |
| tsc `--noEmit` | **598** (net-new **0**) |
| Guard | **exit 0** — 926 / 194 / 92 (no route/nav/page change) |
| Build | **OK** |
| New `require()` idiom | none new (reuses this file's existing createRequire shim) |
| Payments / Airwallex | untouched |
| Migrations | none |
| Tests | C2 3/3; regression: existing initial-shareholders + C1 + v15 invitation flow pass (18/18) |

## Note on live vs. build
Live is still v26.0.0; this fix is in the v26.1.0 build (not yet deployed). Once
deployed, the Step-4 CRM/manual picks will land in the Invitations table and be
emailed. The unrelated "Pre/post-close projection" tab error seen during repro
(`Cannot read properties of null (reading 'toString')`) is logged separately —
NOT part of C2 (candidate for a later wave; confirm with Ozan).

## Next (Shadie QA)
- **C3:** 2a (manual-investor dialog fields: Stage focus, Personal note w/
  admin-editable default template, Expires-in; land + email) + 7a (round-name
  uniqueness per company, auto-suggest unique name). Personal-note default
  template lives in the Admin email-templates area and must be clearly TITLED
  (Ozan). Awaiting Ozan's 2a field-type answers before building.
