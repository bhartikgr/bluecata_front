# Capavate Security Recovery Runbook (Wave B)

Scope: account recovery when sign-in fails closed (MFA storage unreadable), when
an authenticator is lost, or when reset mail cannot be delivered. This runbook
contains no credentials. Never paste secrets, tokens, reset links or recovery
codes into tickets, chat or logs.

## 0. First: back up, then diagnose

1. Take a full database backup (file copy of the SQLite database and its WAL,
   taken with the service stopped or via the SQLite backup API) before any
   manual change. Record the backup path and checksum in the change record.
2. Read the server log for `MFA_UNAVAILABLE` or `AUTH_STATE_UNAVAILABLE`.
   - `MFA_UNAVAILABLE` (HTTP 503 on sign-in): MFA policy or enrolment storage
     could not be read. Sign-in is refused for everyone until it is readable.
     This is deliberate: MFA never silently turns off.
   - `AUTH_STATE_UNAVAILABLE` (HTTP 503 on forgot password): the durable rate
     limit store could not be read or written.
3. Fix storage first: restore missing MFA tables or the policy row from the
   backup / migration. The application repairs an absent policy row once per
   process (INSERT only, default `enrolled_only`). It never recreates missing
   MFA tables; restore them from backup.

## 1. User has lost the authenticator but has a recovery code

The user signs in and enters one unused recovery code at the MFA prompt. Each
code works once. Afterwards, the user should re-enrol and store the new codes.

## 2. Authenticated Admin MFA reset (preferred path)

An administrator signs in and calls `POST /api/admin/mfa/reset` with the
user id and a reason of at least 10 characters. This disables the enrolment,
invalidates recovery codes and writes the `mfa.admin_reset` audit row. The user
then signs in with the password only and re-enrols.

## 3. Reset mail cannot be delivered

Use the Admin password reset (`POST /api/admin/users/:id/reset-password`) from
an authenticated administrator session and hand the result to the verified user
through an approved out-of-band channel. Forgot-password requests are limited
(30 per IP per 15 minutes, 3 per account per 30 minutes, one per account per
60 seconds); repeated user retries will not produce more mails. Production never
returns a reset link in an HTTP response, whatever the debug settings.

## 4. Exceptional: per-user host SQL (owner authorization required)

Only when no administrator can sign in (for example, the only admin lost the
authenticator and has no recovery code).

1. Get written owner authorization naming the single affected user id.
2. Take and verify a backup (section 0).
3. In one transaction, for exactly that user id:

   ```sql
   BEGIN IMMEDIATE;
   UPDATE mfa_recovery_code SET used_at = <now_ms> WHERE user_id = '<user_id>' AND used_at IS NULL;
   UPDATE mfa_enrolment SET state = 'disabled', disabled_at = <now_ms>, last_used_step = NULL,
          totp_secret = NULL, updated_at = <now_ms> WHERE user_id = '<user_id>';
   -- expect exactly 1 row changed by the second statement; otherwise ROLLBACK;
   COMMIT;
   ```

   Never change `mfa_policy`, never drop or recreate MFA tables, never edit
   other users.
4. Audit: as soon as an administrator can sign in, call
   `POST /api/admin/mfa/reset` for the same user with the reason
   "host recovery <change-record id>". This writes the hash-chained
   `mfa.admin_reset` audit row. Do not insert into `audit_log` by hand.
5. Record the authorization, backup checksum, statements and audit row in the
   change record.

## 5. Host gate: trusted proxy configuration

Before release and after any proxy/load-balancer change, verify on the host:

- `TRUSTED_PROXY_HOPS` equals the number of reverse proxies in front of the
  app (0 when clients connect directly).
- `TRUSTED_PROXY_PEERS` lists only those proxies' addresses/CIDRs.
- If the log shows `[forgotResetRateLimit] X-Forwarded-For is present but
  TRUSTED_PROXY_HOPS is 0`, all clients behind the proxy share one IP quota;
  fix the configuration before launch.
