# Capavate v25.48 Install — for Avi

**Release:** 25.48.0
**Date:** Wed Jul 01, 2026
**Base:** v25.47.0
**Triple-verified:** Opus 4.8 · Gemini 3.1 Pro · GPT-5.5 (override) — see `build_spec/v25_48_verify_*.md`

---

## What's in v25.48

Every item below is implemented server-side, DB-driven, and via **parallel modules /
route-layer guards** — the 39 Sacred files are byte-identical to v25.47.

- **NEW-1** Collective-apply eligibility: company JOIN requires an active paid Capavate
  subscription (`403 not_active_subscriber` on both founder apply routes); investor JOIN
  requires ≥1 active cap-table position (`403 no_cap_table_position`); promote unchanged.
- **DSC-1a** compute/score gate also accepts a `dsc_roles`-granted DSC member.
- **DSC-1b** client DSC review/vote modal.
- **DSC-1c** signed, short-lived pitch-deck secure link on the DSC review surface.
- **CP-2a** `/consortium/pricing` fully dynamic from DB tiers (soft-delete hides / add appears).
- **CP-2b** advertised price = charged price (subscribe reads the advertised tier row).
- **CP** copy fixes (canonical tier taxonomy on PartnerSignup; dead activation link removed).
- **DATA-1** email templates → DB-backed `email_templates` + admin GET/GET:slug/PUT:slug + seed-on-boot.
- **DATA-2** no mock data served on live paths (`/api/companies` DB-driven; empty → `[]`).
- **HIGH-7** notifications feed clean empty state + `/founder/notifications` client route.
- **HIGH-8** legacy outbound bridge disabled in production via `BRIDGE_ENABLED` (default OFF).
- **HIGH-9** mock migration commit blocked in prod unless `MOCK_MIGRATION_ALLOWED=1`.
- **PF-1** `/founder/captable` fixed (read-only `GET /api/founder/captable` + client null-guard).
- **PF-UX-1** friendly "membership not active / pending approval" state on gated collective pages.
- **B1–B5** investment backlog (investor CRM auto-seed, batch founder-confirmed amount, docs-sent
  flag, investor "I wired" advisory, required founder attestation) — all via parallel modules.

New migrations (additive-only): **0078** subscription_docs_sent · **0079** investor_wired_signals ·
**0080** commit_attestations · **0081** email_templates.

New env flags: `BRIDGE_ENABLED` (default OFF in prod), `MOCK_MIGRATION_ALLOWED` (unset in prod).

---

## Live host facts (unchanged from v25.47)

- GoDaddy WHM VPS / AlmaLinux, Node 20, npm-only.
- Backend: `/var/www/html/backend` · Frontend: `/var/www/html/frontend`.
- Production runs the **TypeScript source via `tsx`** (`server/index.ts`), NOT `dist/index.cjs`.
- PM2 process name: `backend` → restart with `pm2 restart backend`.
- Env: `/var/www/html/backend/.env` · DB: `/var/www/html/backend/data.db` (+ `-shm`, `-wal`).
- **NEVER overwrite `.env` or `data.db*`.** The deploy script only sed-bumps `APP_VERSION`.
- Health: `https://capavate.com/api/healthz` and `/api/health` report the version.

---

## Option A — Automated deploy (recommended)

The release includes `deploy_v25_48_LIVE.sh`, aligned to the real live host. It backs up the
current tree (excluding `node_modules`, `uploads`, `.env`, `data.db*`), sed-bumps `APP_VERSION`,
runs `npm ci`, applies migrations **fail-closed** (aborts on any failure — no mask), builds,
refreshes the frontend from `dist/public`, `pm2 restart backend`, and smoke-checks `/api/healthz`
for `25.48.0`. On failure it prints a rollback hint.

```bash
# 0) BACK UP THE DB FIRST (belt-and-suspenders; the script never touches data.db)
cp /var/www/html/backend/data.db /var/www/html/backend/data.db.pre_v25_48.bak

# 1) Unpack the FULL_INSTALL zip over the backend tree (it EXCLUDES .env and data.db*)
cd /var/www/html/backend
unzip -o /path/to/capavate_v25.48.0_FULL_INSTALL.zip -d /var/www/html/backend

# 2) Run the deploy script
bash deploy_v25_48_LIVE.sh
```

The script aborts if `package.json` does not report `25.48.0`, if migrations fail, or if the
post-deploy health check does not report `25.48.0`.

---

## Option B — PATCH install (minimal footprint)

The PATCH zip contains ONLY the files changed/added vs the pristine v25.47 `capavateAIzip-48`
base (server modules, migrations, client files, config, docs). Use it for a surgical update.

```bash
# 0) Back up the DB
cp /var/www/html/backend/data.db /var/www/html/backend/data.db.pre_v25_48.bak

# 1) Overlay the patch (it contains no .env / data.db, so live state is safe)
cd /var/www/html/backend
unzip -o /path/to/capavate_v25.48.0_PATCH.zip -d /var/www/html/backend

# 2) Install deps (new dev/runtime deps unchanged from v25.47, but run to be safe), migrate, build, restart
npm ci --production=false
npm run db:migrate            # additive-only 0078..0081; fail-closed
npm run build
rsync -a --delete dist/public/ /var/www/html/frontend/
# bump APP_VERSION in .env (never overwrite the file)
sed -i.bak 's/^APP_VERSION=.*/APP_VERSION=25.48.0/' .env
pm2 restart backend --update-env
```

Then verify: `curl -fsS https://capavate.com/api/healthz | grep 25.48.0`.

---

## Migrations

Additive-only; the runner scans `./migrations`. v25.48 adds 0078–0081, each mirrored into
`server/db/migrations` and seeded on boot in `server/db/connection.ts` (`applyV2548Schema`), so a
fresh or live DB self-heals. Verified to apply cleanly AND idempotently against a copy of the live
`data.db` (exit 0 on first apply, exit 0 / 0-applied on re-apply). `email_templates` self-seeds its
canonical starter set on boot (INSERT OR IGNORE by slug — admin edits are never clobbered).

## S3 / object storage note

DSC-1c pitch-deck links are server-signed, short-lived (10-min) URLs that stream the object via the
existing `objectStorage` layer. In production with S3 configured (`AWS_S3_BUCKET`, `AWS_REGION`),
decks stored in S3 are streamed through the authed download route; otherwise the FS fallback is used.
No new storage configuration is required beyond the existing v25.47 setup.

## Rollback

The deploy script writes `${APP_DIR}.prev` (excluding `.env`/`data.db*`). To roll back:

```bash
rsync -a /var/www/html/backend.prev/ /var/www/html/backend/   # preserves .env + data.db*
pm2 restart backend
```

---

## Gates — all green (see `build_spec/v25_48_gate_results.md`)

| Gate | Required | Actual |
|------|----------|--------|
| TSC error count | ≤ 611 (zero net-new) | **611** |
| verify_avi_preserved | exit 0 | **exit 0** |
| Airwallex + partnerFee | 45/45 | **45/45** |
| v25_48 supertests | all pass | **30/30 (9 files)** |
| vite build | exit 0 | **exit 0** |
| npm run build | exit 0 | **exit 0** |
| Full canonical e2e | 0 failed | **862 passed / 2 skipped / 0 failed** |
| Sacred + Rule-76 byte-identity | 39/39 | **39/39, 0 FAILED** |
| Migration vs live-DB copy | applies + idempotent | **exit 0 twice; 4 new tables; email_templates seeds** |
