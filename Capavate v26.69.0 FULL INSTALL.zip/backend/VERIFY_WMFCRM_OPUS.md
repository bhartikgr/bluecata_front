# W-MFCRM — Adversarial Build Verification (Opus)

**Method.** node_modules is not installable in this sandbox, so no `tsc`/`vitest` was
run. Verification is by direct reading of the actual source against the in-tree
conventions (captableCommitStore, spvEngineStore, requirePartnerAuth,
partnerAttributionStore, partnerClientCrmStore) and the rev3 design doc. Every
claim in `_MFCRM_BUILD_RESULT.md` was checked against code, not taken on trust.

---

## AREA 1 — The six capability gates (present, fail-closed, correct, route-enforced)

**PASS.** All six gates live in `managedFounderStore.ts` as `GateError`-throwing
helpers (L302–350) and every read defaults through `getCapabilityProfile`, which
returns the most-restrictive `unclassifiedProfile` for an unseeded partner
(L261–264, L110–127) — fail-closed by construction.

- Gate 1 `assertClassified` (L302) — denies unclassified. Enforced at
  `createEngagement` (L361).
- Gate 6 `assertModeAEntry` (L309) — delegated_agency + present + non-expired
  artifact. Enforced on create-in-A (L364), B→A `setMode` (L444), and
  hand-over-confirm-into-A (L511) — the privilege-escalation surfaces are all
  covered.
- Gate 2 `assertSourcesCapital` (L317) — and `stampAttribution` structurally can
  NEVER emit `first_touch` when `sourcesCapital=false` (L593–600).
- **Gate 3 / D-9 `assertDelegatedWriteAuthority` (L325–334)** — checks, in order,
  `delegatedAgency` → `spvWriteAuthority` (when `requireSpvWrite`) →
  `status==='ACTIVE'` → `mode==='A'` → artifact present → artifact not expired.
  This is the critical control and it is fully bound: an ACTIVE **Mode-B**
  engagement with every global toggle ON still throws `ENGAGEMENT_MODE_NOT_A`.
  `createSpvOnBehalf` calls it with `{ requireSpvWrite: true }` **before** any SPV
  creation (L742). There is no code path that reaches SPV-on-behalf with only
  global toggles + ACTIVE Mode-B.
- Gate 4 `assertCollectivePush` (L337) — collective_fronting + ACTIVE; re-checked
  at the route before the push state moves (managedFounderRoutes L370).
- Gate 5 `assertGraduation` (L345) — ACTIVE + (sources_capital OR delegated_agency);
  enforced in `softCircleGraduate` (L686).

Route layer enforcement is genuine, not decorative: writes carry
`assertSubRole(...WRITE_ROLES)`, and the store gate throws propagate through
`sendError`, which maps unknown/authority codes to **403** (fail-closed default,
managedFounderRoutes L56). No defect.

## AREA 2 — Money path integrity

**PASS.** Two, and only two, money-adjacent paths:

1. `softCircleGraduate` (L674–717) routes solely through the sacred
   `commitFunded(...)` (L689) — signature matches captableCommitStore L675–689
   (default `fromState="funded"`). On `{ok:false}` it returns early and writes
   nothing to any ledger (L698). The Founder-CRM copy-in is wrapped in try/catch
   and explicitly must not roll back the sacred commit (L708–712) — correct
   ordering (money first, projection best-effort).
2. `createSpvOnBehalf` (L730–791): Gate 3 asserted first (L742) → durable
   `spvEngineStore.createSpv` (L745, signature matches spvEngineStore L260–270,
   returns `SpvDTO.id`) → a single **synchronous** `db.transaction(() => …)()`
   (L767–785) that reads the per-partner chain tip, computes the sha256 hash, and
   INSERTs the `mf_spv_on_behalf` audit row + queues the `mf_collective_push` row
   atomically. **No async/network inside the tx** (verified: only `db.prepare`
   calls). The async push is emitted OUTSIDE via `markCollectivePush` (L811). This
   matches design §3.3 exactly.

- **Hash-chain TOCTOU:** tip-read + insert are inside one better-sqlite3 sync
  transaction; the engine is synchronous and SQLite serializes the write with the
  tx lock, so there is no intra- or inter-process interleaving window. Sound.
- **Orphan-on-failure:** on a Gate-3 denial nothing is created (throw precedes
  `createSpv`) — the moneypath test asserts this (no on-behalf row, no push). One
  residual, design-sanctioned observation below.

## AREA 3 — Cross-partner isolation (SECURITY)

**PASS.** `partnerId` is *always* `req.partnerContext!.partnerId` (session-derived
via `requirePartnerAuth`, which reads the session and never the URL/body —
requirePartnerAuth L44–70). Verified across **every** partner endpoint in both
`managedFounderRoutes.ts` and `managedFounderPersonaRoutes.ts`: no handler reads a
body/query `partnerId`. Every company-scoped route calls `isAttributed(pid,
companyId)` and returns **404 `COMPANY_NOT_FOUND_OR_NOT_ATTRIBUTED`** before the
store is touched — no existence/state leak. Store methods add a second layer:
`getEngagement` returns null on `partnerId` mismatch (L404), and every SQL read is
`WHERE partner_id = ?`. Persona routes (angel/acct/law) carry the identical
attribution guard on every company-scoped path. Admin routes take a URL
`:partnerId` by design (platform operator), and sit behind both the `/api/admin`
requireAdmin mount and an in-handler `requireAdminCtx` isAdmin re-check
(belt-and-suspenders). Isolation test asserts cross-partner 404, body-partnerId
ignored, and viewer 403. No defect.

## AREA 4 — RF-1 (userContext.ts) additive & behavior-preserving

**PASS.** Diff confirms exactly three additive hunks: `| "INVITED_PRIVATE_ROUND"`
added to the union; optional `hasPrivateRoundInvite?: boolean` arg (commented
"Defaulted/absent for every existing caller → identical behaviour"); and the one
branch change `if (!hasCapTable) return args.hasPrivateRoundInvite ?
"INVITED_PRIVATE_ROUND" : "INVITED_ONLY"`. When the field is absent/false the
result is byte-identical to the prior behavior. `buildInvitedRounds` is NOT in the
diff (untouched). SHA re-baselined old `3a6d325c…` → new `d75d1321…` with
`SACRED_SHA256.txt` L16 and `CAPAVATE_SACRED_FILES.md` updated. No defect.

## AREA 5 — DB-driven, no in-memory/mock/seed on production paths

**PASS.** Both RAM Maps (`profileByPartner`, `engagementById`) are write-through
projections rebuilt at boot by `hydrateManagedFounderStore` from the durable
`mf_*` tables (L857–905) — the partnerClientCrmStore pattern. All other reads
(events, attribution, crossover, layers, trials, handovers, spv-on-behalf, push,
audit, all persona tables) hit the DB directly every call. `persist*` helpers are
STRICT (throw `STRICT_PERSIST_FAILED` on write failure → 500). No seed/mock on any
production path. No defect.

## AREA 6 — Edited existing files are additive only

**PASS.** The diff shows only additions (import lines, HYDRATE_ORDER entries,
`registerMfcrm*` calls, one nav entry, two client routes with detail-before-list
ordering, and the RF-1 hunks). Nothing renamed, moved, or removed. New route
prefixes (`/api/partner/me/mfcrm*`, `/api/admin/mfcrm*`, persona subpaths) are
distinct — no Express shadowing.

## AREA 7 — Schema: 12 additive tables, idempotent, partner_id + indexes

**PASS.** `applyMfcrmSchema()` is guarded and uses `CREATE TABLE IF NOT EXISTS`
for all 12 tables — idempotent, no destructive `ALTER`/`DROP`. Every
partner-scoped table has `partner_id` + `(partner_id, company_id)` indexes;
`mf_engagement` has `UNIQUE(partner_id, company_id)`, `mf_layer_membership` has
`UNIQUE(partner_id, company_id, contact_ref)`, `mf_spv_on_behalf` carries
`prev_hash/curr_hash`. Persona tables are created lazily via `ensureXTables()`
(kycDocumentStore pattern), also idempotent. No defect.

## AREA 8 — TypeScript soundness (by inspection)

**PASS.** `any` is confined to the established `rawDb() as any` handle and SQL row
mapping — consistent with the tree. `GateError.code` typed; `CommitResult` and
`SpvDTO` consumed per their declared shapes; `commitFunded`/`createSpv` call sites
match signatures verified in source. Discriminated `{ok:true}|{ok:false}` union on
`softCircleGraduate` handled correctly at the route (L296). No obvious type break.

## Test spot-check

**Adequate and adversarial.** `mfcrm_gates.test.ts` includes the mandated D-9
NEGATIVE (ACTIVE Mode-B + all toggles → `ENGAGEMENT_MODE_NOT_A`) AND the
Mode-A-after-setMode POSITIVE, plus expired-artifact and spv_write=false
negatives. `mfcrm_moneypath.test.ts` asserts a single `commitFunded` ledger row +
`verifyChain().ok`, `{ok:false}` writes zero rows, transactional SPV+push, no
orphan on Gate-3 denial, and prev_hash→curr_hash chain linkage. `mfcrm_isolation.test.ts`
hits real Express routes via supertest for cross-partner 404, body-partnerId
ignored, unauth 401/403, viewer 403. Persona test covers chapter fail-closed,
firm-of-record (never first-touch), pays/custody gates, conflict-never-blocks, and
investor-spine-forbidden. Tests assert behavior, not just existence.

---

## Numbered observations (non-blocking)

1. **SPV durable-before-audit ordering (design-sanctioned).** In
   `createSpvOnBehalf`, `spvEngineStore.createSpv` commits before the sync tx that
   writes the `mf_spv_on_behalf` audit + push queue. If that tx threw, the SPV row
   would exist without an on-behalf/push record. This is the ordering §3.3
   prescribes (durable SPV first, then atomic audit+queue, async push outside),
   the sacred `commitFunded` money ledger is not involved, and the only realistic
   throw source (the gate) runs *before* `createSpv`. Acceptable as built; if ever
   tightened, fold the `createSpv` into the same logical unit or add a
   reconciliation sweep. No action required to ship.

2. **`mark` route re-reads push then asserts Gate 4.** Correct and intended; noted
   only to confirm the route-layer re-check (not just store-layer) is present.

No hard-rule violations. No parallel money path. No isolation bypass. No
non-additive sacred edit beyond the authorized RF-1.

---

VERDICT: SHIP
