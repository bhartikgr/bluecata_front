# VERDICT — Wave C3 (Shadie 2a + 7a) — Independent verification (Opus)

## 1. VERDICT: **REVISE**

One real correctness defect breaks the central 2a guarantee ("preview == send")
for the round-detail invite path: the **expiry line differs** between the
founder's preview and the email the investor actually receives. All gates pass;
7a is fully correct; the rest of 2a is correct. This is a single, targeted fix.

---

## 2. Gate results (actual numbers)

| Gate | Expected | Actual | Result |
|------|----------|--------|--------|
| `tsc --noEmit` error count | 598 | **598** | PASS |
| Sacred baseline `: OK` | 40 | **40** | PASS |
| Money `captableCommitStore.ts` sha16 | 01cd36130ee1c0cb | **01cd36130ee1c0cb** | PASS |
| Guard exit code | 0 | **0** | PASS |
| Guard routes | 929 | **929** | PASS |
| Guard pages | 194 | **194** | PASS |
| Guard nav | 92 | **92** | PASS |
| +3 new routes present | preview x2 + name-availability | all 3 present | PASS |
| New migration | none | **none** | PASS |
| Payments/Airwallex changed | no | **no** | PASS |
| Sacred files in `git diff HEAD~1` | none | **none** | PASS |
| Wave C3 test | 7 pass | **7 pass** | PASS |
| Regression (roundPersistenceProof, roundDetailLoad, v2348_round_initial_shareholders, v15_invitation_flow) | no new fails | **19 pass** | PASS |
| Pre-existing sprint21_invitations | 2 fail (known) | **2 fail** | Confirmed pre-existing |

New routes confirmed via guard output:
- `GET /api/rounds/name-availability`
- `POST /api/companies/:companyId/invitation-preview`
- `POST /api/rounds/:id/invitations/preview`

Changed source files (only the 7 C3 files + docs; no sacred):
`client/src/pages/founder/RoundDetail.tsx`, `client/src/pages/founder/RoundNew.tsx`,
`server/__tests__/waveC3_invite_preview_and_round_name.test.ts`,
`server/lib/roundInitialShareholdersStore.ts`, `server/roundInvitationsStore.ts`,
`server/roundsStore.ts`, `server/routes.ts`.

`npm run build` was NOT run — no restore needed.

---

## 3. Per-check confirmation / defects

### DEFECT D1 (REVISE) — Round-detail preview ≠ send on the EXPIRY line
**Where:** `client/src/pages/founder/RoundDetail.tsx:203-213` (preview call) vs
`RoundDetail.tsx:145-166` (send) and `server/routes.ts:2728-2747` (preview
endpoint) + `server/roundInvitationsStore.ts:170` (renderer expiry default).

**What:** The round-detail invite dialog has an "Expires in" dropdown
(`RoundDetail.tsx:912-915`, options 14/30/60/never) that **defaults to 30**
(`RoundDetail.tsx:127` `useState("30")`). The real SEND passes the selected
value: `...(expiryDaysVal !== null ? { expiryDays: expiryDaysVal } : {})`
(`RoundDetail.tsx:165`), which reaches `createInvitation` → the shared renderer
with the chosen expiry (`roundInvitationsStore.ts:538`,
`expiryDays: args.expiryDays ?? 14`).

The PREVIEW, however, sends only `{ investorName, note }`
(`RoundDetail.tsx:208-211`); the preview endpoint's body type is
`{ investorName?; note? }` and it never passes `expiryDays`
(`server/routes.ts:2732, 2737-2745`), so the renderer falls back to its default
of 14 (`roundInvitationsStore.ts:170` `input.expiryDays ?? 14`).

**Impact:** In the default case the founder previews an email that reads
"This invitation expires in **14** days" while the investor actually receives
"expires in **30** days" (or 60 / "never" if selected). The in-dialog helper
text even asserts the opposite — *"The round terms, name and **expiry** are not
changed — only your message"* (`RoundDetail.tsx:896`) — yet the expiry IS
changed by the dropdown directly beneath it and IS reflected in the sent email
but NOT in the preview. This directly violates the 2a guarantee that
"what the founder sees == what the investor receives." The rendered
subject/HTML/text is NOT byte-identical between preview and send.

**Why the C3 test misses it:** `waveC3_invite_preview_and_round_name.test.ts`
exercises `renderInvitationEmail` in isolation with an explicit
`expiryDays: 30`; it never compares the round-detail PREVIEW endpoint's expiry
input against the SEND's expiry input, so the divergence is uncaught.

**Fix (minimal — choose one, keep expiry a server/fixed fact OR wire it through):**
- Preferred (keeps expiry fixed & honest): drop the "Expires in" dropdown from
  the round-detail invite dialog and stop sending `expiryDays` from
  `RoundDetail.tsx:165`, so both preview and send use the same fixed 14-day
  default — matching the helper text at `RoundDetail.tsx:896`. (Aligns with the
  Step-4 path, which has no expiry control and is already consistent.)
- OR (keeps the dropdown): thread `expiryDays` through the preview so it matches
  the send. In `RoundDetail.tsx:208-211` add
  `...(expiryDaysVal !== null ? { expiryDays: expiryDaysVal } : {})`; in the
  preview endpoint `server/routes.ts:2732` accept `expiryDays` and pass it into
  `roundInvitationsRenderEmail` at `:2737` (validate `typeof === "number"`). If
  the founder picks "Never", both send and preview must render the SAME expiry
  string (the send currently omits `expiryDays` → renderer shows 14 for
  "never" too, so pick a single consistent representation and use it in both).

Note: the Step-4 (company-scoped) path is NOT affected — it has no expiry
control and its `createInvitation` call omits `expiryDays`
(`roundInitialShareholdersStore.ts:267-279`), so both its preview and send
default to 14. Only the round-detail path diverges.

---

### Confirmed correct (no defect)

- **Single shared renderer / preview == send (except D1):** `renderInvitationEmail`
  is the one renderer (`roundInvitationsStore.ts:161-185`); the real send calls
  it (`:532-539`); both preview endpoints call it via
  `roundInvitationsRenderEmail` (`routes.ts:2718, 2737`). Subject, link, note,
  investorName and company/round-name interpolation are identical. The ONLY
  input divergence is expiry (D1).
- **HTML escaping:** every interpolated value is escaped with `e()` /
  `escapeHtml` — investorName, roundName, companyName, link, note, expiry
  (`roundInvitationsStore.ts:174-178`). Test asserts `<at>` → `&lt;at&gt;`.
- **Note included + persisted via EXISTING column (no migration):** note
  rendered at `:177`; INSERT writes `note` (`:437,456`); hydration reads it
  (`:1142, 189`). No migration file in the diff.
- **Preview is READ-ONLY:** neither preview endpoint mints a token, creates an
  invitation row, or sends email (`routes.ts:2709-2726`, `2728-2747`). Both use
  a labelled placeholder link ("a secure link is generated when you send").
- **Ownership-gated:** round-scoped preview uses `requireFounderOwnsRound`
  (`routes.ts:2729`, 403 on non-owner); company-scoped preview
  (`:2712-2713`) and name-availability (`:4266-4267`) reject non-owners with 403
  `FOUNDER_WRONG_COMPANY`.
- **Facts server-resolved / not client-overridable:** round-scoped preview
  resolves companyName + roundName server-side via `getCompanyNameById` /
  `roundsStoreGetById` (`routes.ts:2735-2736`); client supplies only
  investorName + note. Company-scoped (pre-create) preview takes ONLY `roundName`
  from the client (round doesn't exist yet) plus investorName/note, and escapes
  it (`routes.ts:2717-2724`).
- **7a per-company scope:** `roundNameExistsForCompany`
  (`roundsStore.ts:167-173`) compares only `getRoundsForCompany(companyId)`
  (`:327-329`, filters by companyId) — two different companies may reuse a name;
  one company may not. Cross-company test case PASSES
  (`waveC3_...test.ts:79-91`).
- **7a fail-closed server-side:** `createRound` throws `ROUND_NAME_REQUIRED`
  (empty) / `ROUND_NAME_DUPLICATE` (dup) BEFORE the insert
  (`roundsStore.ts:213-219`); route maps to 400/409 with `suggestedName`
  (`routes.ts:4604-4614`). A duplicate cannot be persisted even via direct API.
- **7a editable auto-suggestion + race backstop:** on-blur availability check
  auto-fills an editable suggestion + amber hint
  (`RoundNew.tsx:771-776`); create `onError` re-applies `suggestedName` from the
  409 payload as a race backstop (`RoundNew.tsx:435-443`).
- **Step-4 note flow:** manual dialog note → shareholder row → `initial-shareholders`
  → `createInvitation({ note })` (`RoundNew.tsx:1155, 1189, 405`;
  `roundInitialShareholdersStore.ts:189, 276`).
- **No regression:** existing round-creating suites use unique names; all 19
  regression tests pass. Sacred 40/40, money sha, payments untouched.
