# Capavate v26.57.0 full installation bundle

This is one cumulative application release for Avinay, not a marketing-only patch. The landing page is part of the application and is included in both source and the refreshed served frontend. The bundle contains frontend and backend source, shared modules, package manifests, migration files, tests, protected-check material and installation instructions.

## Included work

- **Marketing landing page:** unchanged Equity Social Network tagline and hero headline; Consortium Partner pipeline, client-raise and SPV benefits; the owner's three mission paragraphs verbatim immediately after the hero; supplied portrait/name/LinkedIn; trust section immediately before Pricing; stronger marketing sections ahead of procedural content; mobile layout polish.
- **v26.56 application work:** recipient review, founder-invitation handoff/recovery, existing-account claim protections, strict invitation authority and privacy, registration eligibility, canonical company/profile consistency, DB-backed sector taxonomy and metadata-only request logging.
- **v26.55 application work:** notification/persona and related Managed Founders repairs remain included.

Relative to the verified v26.56 backend, this release adds no new backend or database behavior. It integrates the approved landing-page UI changes and advances release metadata to 26.57.0. The old UI patch is unnecessary when installing this full bundle.

## Contents and installation

Start with `INSTALL_v26_57_0.md` in this archive. Extract to a new application directory, preserve the real environment/database/uploads, install dependencies and build using the established deployment procedure. Deploy the matching frontend and backend/source as a coherent release.

The development `node_modules`, real environment files, databases and SQLite sidecars, uploads, scratch build logs and local `dist` directory are intentionally excluded. This is a complete source installation package, not a copy of the production database or credentials. The refreshed `server/public` frontend is included; `npm run build` produces the target installation's `dist/index.cjs` and `dist/public`.

Both copies of migration 0236 and its runtime bootstrap dependencies are present. Preserve their deployed source layout and actual backend working directory. Do not blindly replay every historical migration to remove known chain-check debt.

## Verification

- Production build passed for the complete frontend and backend, and backend syntax check passed.
- `server/public` is byte-identical to the newly built `dist/public`.
- The actual full compiled application was opened in a browser: mission, portrait, partner benefits, original hero and exact section order were present; no observed page error; 375px layout width remained 375px.
- Final extended test execution: **55 files, 692 tests; 691 passed and one inherited assertion failed**. The 651 onboarding/notification/marketing tests in the release subset all passed within this execution.
- The additional legacy failure is `w235_frozen_footer_terms_href_dom.test.tsx` §W1. It expects only the Terms link to differ from the frozen footer, but the previously shipped W236 correction also repoints a dead education link. An independent reviewer reproduced the exact same failure on the pre-UI v26.56 Home bytes, with the unchanged test and related components. No assertion was weakened or skipped.
- Full typecheck remains nonzero: **578 diagnostics, rc 2**, with no change to the v26.56 per-file/per-code distribution. This is not a claim of clean platform-wide CI.
- Sacred checker passed **48/48**; the five specifically frozen files remain exact.
- Homepage pre-edit guard floor and restyle comparison passed. No protected baseline or floor was regenerated.
- Three independent scoped UI reviews accepted the landing-page change; their overlapping test counts are not added to the aggregate.

The existing PostCSS warning and large-bundle warning remain. Prior platform-wide compiler/gate debt and the earlier legacy route-shadow fixture remain open; this packaging request does not silently close them.

## Known carried application limitations

Transport failure/success caching, the revoked-sole-invitation recovery edge case, lack of a dedicated per-company reissue throttle and malformed persisted-handoff JSON handling remain recorded limitations from v26.56. A frozen runtime identity cache may require operator investigation after a failed new-user canonical write. Router-local operational-log patterns can collide, and response-body debug logging has deliberately been removed.

No live deployment, NOVA recipient correction, invitation send or inbox-delivery claim is made. After deployment verification and specific approval, NOVA's authorized recovery action can target `novaisinak@gmail.com`; never rewrite the original audit or create a duplicate company.

## Archive safety

This bundle excludes database files, SQLite sidecars, real `.env` files and nested dependency caches. The older v26.55.0 archive included sidecars and should not be redistributed; do not delete live SQLite WAL/SHM files as an archive-cleanup shortcut.

Checksums and byte-by-byte package verification accompany the download. Use this full bundle rather than assembling the old application archive and separate UI patch manually.
