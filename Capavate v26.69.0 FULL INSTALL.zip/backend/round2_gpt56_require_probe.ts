console.log(typeof require);
try { require('node:fs'); console.log('REQUIRE_OK'); } catch (e) { console.log((e as Error).name + ': ' + (e as Error).message); }
