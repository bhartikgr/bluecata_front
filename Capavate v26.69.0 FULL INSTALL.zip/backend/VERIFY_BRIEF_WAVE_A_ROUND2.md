# RE-VERIFICATION brief — Capavate Wave A (round 2, after fixes)

You are the DECIDING independent verifier (rule #7 — your verdict decides
whether this ships; never rubber-stamp). In round 1 you (GPT-5.5) returned
REVISE with 4 defects. All 4 have been fixed. Confirm each fix holds and that
nothing regressed, then return APPROVE or REVISE.

Build tree: `/home/user/workspace/capavate_work` (deps installed). Full source
diff: `WAVE_A_SOURCE.diff`. Read the actual files.

## The 4 round-1 defects and the fixes to verify

1. **Sign-off could be bypassed if persistence failed.**
   Fix: `server/spvLaunchSignoffStore.ts` `recordSignoff` now THROWS
   `SIGNOFF_PERSIST_FAILED` on a durable INSERT failure (no swallow, no
   in-memory fallback). `server/spvEngineRoutes.ts` now records the sign-off
   FIRST (inside a try that returns 500 on throw) and only creates the SPV
   AFTER a durable sign-off exists, then links the real spvId via
   `linkSignoffToSpv`. VERIFY: there is no path where an SPV is created without
   a durably-recorded sign-off; missing name / unaccepted attestation still 400.

2. **signerSubRole always null (read wrong field).**
   Fix: route now uses `ctx.partnerSubRole` (the real `PartnerContext` field).
   VERIFY: `server/lib/requirePartnerAuth.ts` exposes `partnerSubRole`, and the
   route reads it.

3. **Claimed 20 titles but shipped 18.**
   Fix: reconciled to the ACTUAL QA-slide list of 18 titles; wording corrected
   in `shared/partnerTitles.ts`, `client/src/pages/partner/PartnerTeam.tsx`, and
   `FIX_REPORT_WAVE_A_CONSORTIUM_QA.md`. A new test
   `server/__tests__/waveA_consortium_qa.test.ts` asserts the exact 18-title
   list + order. VERIFY: count/list is consistent everywhere now (18), and the
   test passes.

4. **Invitation title not carried onto member after redemption.**
   Fix: `server/partnerWorkspaceStore.ts` redeem path now, for a brand-new
   member with a title, upserts `durable.title` into
   `partner_team_member_contact.positionNote` (best-effort, logged on failure),
   which is exactly the field the team-list read maps to `title`. VERIFY: a
   redeemed member surfaces its invitation title; subRole is untouched.

Also reconcile the round-1 correctness note: the 1e comment now states the
mapper ALWAYS returns a valid enum member (unmapped -> delaware) which the
store's strict `isSpvJurisdiction` check therefore accepts — VERIFY that wording
is now accurate.

## Gates (must all hold)
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # exit 0
diff migrations/0108_1c_spv_launch_signoffs.sql server/db/migrations/0108_1c_spv_launch_signoffs.sql  # identical
npx vitest run server/__tests__/waveA_consortium_qa.test.ts  # 4 pass
grep -nE "\brequire\(" server/spvLaunchSignoffStore.ts server/spvEngineRoutes.ts shared/partnerTitles.ts   # none
```

## Output
Write to `/home/user/workspace/capavate_work/VERDICT_gpt55_round2.md`:
1. **VERDICT: APPROVE** or **VERDICT: REVISE**
2. Confirmation (per-defect) that each of the 4 fixes holds, with file:line.
3. Gate results (actual numbers).
4. Any NEW defect found (with file:line + fix). Do not invent nits.
