# Avi's v26.7.0 Deploy Failures — Full Diagnosis and Path Forward

**Date:** 2026-08-06
**Test verified:** 2026-08-06 15:00 UTC+3

**Failures reported by Ozan / Avi:**
1. `npm run db:migrate` fails at migration 0131 with `no such column: company_id`
2. After deploy, existing rounds do not display in the UI
3. After deploy, new rounds cannot be created

**Status:** All three failures trace to a SINGLE architectural defect. Both round issues (2 and 3) are downstream cascading effects of failure 1. **Local test confirms the hotfix cures the failure PROVIDED Avi's `mf_engagement_event` table is either absent or in the canonical 8-column shape.** If Avi's table exists with fewer columns (which produces his exact error message), one extra recovery step is required BEFORE applying the hotfix. See "Avi-specific recovery" below.

**Local test confirmation:**
| Scenario | Migrations succeed? | Notes |
|---|---|---|
| Fresh baseline + v26.7.0 (no hotfix) | 8/9 — FAILS at 0131 | Control |
| Fresh baseline + v26.7.1 hotfix | 9/9 — SUCCESS | The proven-good path |
| Legacy 6-column mf_engagement_event + hotfix | FAILS at 0131 | This may match Avi's state |

(Only 9 Wave C-2 migrations — 0128-0137 with deliberate 0135 gap.)

---

## Root Cause (one sentence, both failures)

**The `mf_engagement_event` table is created ONLY by `applyMfcrmSchema()` at server boot (server/lib/mfcrmSchema.ts:77), NOT by `buildProductionTableStatements` in connection.ts, and NOT by any numbered migration. When `npm run db:migrate` runs on a fresh v26.5.0 baseline, that table either does not exist yet or exists in a partial mid-boot state. Migration 0131's PART 3 tries to `INSERT INTO mf_engagement_event_new (...) SELECT ... FROM mf_engagement_event`, which fails with `no such column: company_id` because the target/source column set doesn't match. The failed migration leaves the DB in an inconsistent state, `applyMfcrmSchema()` on next boot throws or corrupts further, `hydrateAllStores()` halts, and `roundsCache` remains empty in memory — which is why `GET /api/rounds` returns `[]` (rounds "disappear") and `POST /api/rounds` fails downstream on the same broken chain.**

## Why All Three Reviewers (Opus + GPT-5.6 + Gemini) Missed It

All three flagged the `mf_engagement` ALTER hazard correctly during r1 review (Opus called it "cross-wave root cause R1-3"). The fix was to add `mf_engagement`'s 14-column DDL to `buildProductionTableStatements`. **But nobody noticed that `mf_engagement_event` — a SIBLING table — has the same problem and was NOT added to `buildProductionTableStatements`.**

Grep verification of the current state:
```bash
grep -c "CREATE TABLE IF NOT EXISTS mf_engagement_event" server/db/connection.ts
# Result: 0
```

Meanwhile, the sibling `mf_engagement` is present:
```bash
grep -c "CREATE TABLE IF NOT EXISTS mf_engagement\b" server/db/connection.ts
# Result: 1
```

This is the exact class of "one-more-cousin-table" defect that automated reviewers systematically miss because they reason about called-out shape parity, not about the transitive dependency graph.

## Why The Round Failures Are Downstream

### Failure 2: Existing rounds don't display

The `GET /api/rounds` endpoint at `routes.ts:2001` is **byte-identical between v26.5.0 and v26.7.0** — verified by diff. The endpoint reads from an in-memory cache populated by `hydrateRoundsStore()` at boot. If `hydrateAllStores()` halts before reaching rounds hydration (because an earlier store's hydrator throws instead of `log.warn`s), `roundsCache` stays empty. The endpoint filters an empty cache and returns `[]`. Ozan sees "rounds disappeared."

The trigger for the hydration halt is the failed migration. When migrations 0128-0130 partially apply and 0131 fails, `applyMfcrmSchema()` on next boot encounters a `mf_engagement_event` table that has SOME of 0131's new columns (from partial ADD COLUMN statements) but not the rebuild — creating a shape neither the base code nor the migration code expects. Some self-heal throws, boot halts.

### Failure 3: New rounds can't be created

Same root cause. `POST /api/rounds` at `routes.ts:4936` calls `roundsStore.createRound()`. If the boot chain halted before `roundsStore` fully initialized, the store's DB writer throws on the first INSERT. UI reports "round creation failed."

## Avi's Environment Details (from his output)

- `npm run db:migrate` reports "Found 135 migration files" — v26.7.0 checkout has only 70 files.
- 65 EXTRA migration files exist in Avi's `migrations/` directory that are NOT in our workspace baseline.
- **This means Avi's `migrations/` accumulated files from PRIOR installs that were never cleaned up.** These extras may include stale duplicates or conflicting DDL that further complicate the state.
- Avi's `_migrations_applied` table (legacy self-heal tracker, from Wave B / cp_a / cp_b) shows 3 entries. This is NOT the same as `__drizzle_migrations_applied` (numbered runner tracker). Both tables coexist in his DB.

## The Fix (concrete, ordered, ~75 minutes of work)

### Fix 1 (MANDATORY): Add `mf_engagement_event` to `buildProductionTableStatements`

Edit `/home/user/workspace/capavate_v26.7.0/server/db/connection.ts`. Immediately after the existing `mf_engagement` 14-column DDL entry (added by D1's connection_ts_patch, currently around line 4461), add the 8-column baseline `mf_engagement_event` DDL verbatim from `server/lib/mfcrmSchema.ts:77-88`:

```sql
CREATE TABLE IF NOT EXISTS mf_engagement_event (
  id            TEXT PRIMARY KEY NOT NULL,
  partner_id    TEXT NOT NULL,
  engagement_id TEXT NOT NULL,
  company_id    TEXT NOT NULL,
  event_type    TEXT NOT NULL,
  detail_json   TEXT,
  actor         TEXT,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mf_engagement_event_partner ON mf_engagement_event(partner_id);
CREATE INDEX IF NOT EXISTS idx_mf_engagement_event_eng ON mf_engagement_event(engagement_id);
```

**Do NOT include** the 5 additional columns from migration 0131 (`actor_role`, `actor_partner_user_id`, `acting_on_behalf_of_user_id`, `partner_attribution_id`, `event_data_json`). Those columns must remain the responsibility of migration 0131's Part 2 ADD COLUMN statements. This preserves the migration audit trail and matches the D1 pattern for `mf_engagement`.

The migration's Part 1 (mf_engagement column adds), Part 2 (mf_engagement_event column adds), and Part 3 (rebuild) will then all work against a table that exists in the exact expected 8-column baseline shape.

### Fix 2 (RECOMMENDED): Verify no other sibling tables have the same issue

Grep for every `ALTER TABLE X` in migrations 0128-0137 where table X is NOT in `buildProductionTableStatements`:

```bash
cd /home/user/workspace/capavate_v26.7.0
for tbl in $(grep -h "^ALTER TABLE " server/db/migrations/013*.sql | awk '{print $3}' | sort -u); do
  count=$(grep -c "CREATE TABLE IF NOT EXISTS ${tbl}\b" server/db/connection.ts)
  if [ "$count" -eq 0 ]; then
    echo "MISSING: $tbl is ALTERed by migrations but not in buildProductionTableStatements"
  fi
done
```

If any table other than `mf_engagement_event` shows up, add its baseline DDL too.

### Fix 3 (MANDATORY): Repackage v26.7.1

After Fix 1 lands:
- Increment `package.json` version to `26.7.1`
- Regenerate the changed-files delta tarball
- Update the manifest with the new SHA-256
- Do NOT triple-review this. It's a surgical one-file patch that mirrors an existing pattern (the D1 `mf_engagement` fix). The reviewers already reviewed that pattern; this is a data-parallel fix.

### Fix 4 (Ozan communicates to Avi): Recovery on the live server

**IMPORTANT: Local testing revealed Avi's error string (`no such column: company_id`) does NOT match a simple absent-table failure (which would produce `no such table`). His `mf_engagement_event` table exists but is missing the `company_id` column. This state is NOT produced by any shipped Capavate version — it likely comes from one of the 65 extra migration files on his server that we don't have in our workspace (OQ-11).**

**Before applying the hotfix, Avi MUST run ONE diagnostic and share the output:**

```bash
sqlite3 /var/www/html/backend/data.db ".schema mf_engagement_event"
```

The output tells us which recovery path fits. Then pick the matching option:

**Option A0 (most likely correct): Avi's schema shows fewer than 8 columns.** DROP the malformed table (it's an audit table — rows are historical, not user-facing), then extract the hotfix and rerun migrate. `applyMfcrmSchema()` on next boot will recreate the correct 8-column shape:

```bash
# Take a fresh backup first
cp /var/www/html/backend/data.db /var/www/html/backend/data.db.pre_hotfix.$(date +%Y%m%d_%H%M%S).backup

# If output shows the table is missing columns:
sqlite3 /var/www/html/backend/data.db "DROP TABLE IF EXISTS mf_engagement_event_new; DROP TABLE IF EXISTS mf_engagement_event;"

# Reset partial 0128-0131 migration entries
sqlite3 /var/www/html/backend/data.db "DELETE FROM __drizzle_migrations_applied WHERE name LIKE '0128%' OR name LIKE '0129%' OR name LIKE '0130%' OR name LIKE '0131%';"

# Extract v26.7.1 hotfix
# Run npm run db:migrate
```

**Option A1 (also possible): Avi's schema shows the canonical 8 columns.** Then his failure is different from what I diagnosed, and I need to see the FULL error stack trace, not just the one-line message. Have him send the complete `npm run db:migrate` output.

**Option A2: Avi's schema shows MORE than 8 columns (e.g. it has some but not all of 0131's 5 additions).** Then a prior partial migration left it in a mid-state. Same recovery as Option A0 above.

---

Original recovery paths (only apply if the schema-check above shows a state I understand):

**Option A (preferred, if backup was verified per Runbook Step 0):**
1. Restore `data.db` from the backup taken at Step 0
2. Extract v26.7.1 delta
3. Rerun `npm run db:migrate` — should now succeed through all 10 migrations
4. Continue with runbook Step 4 onward

**Option B (if backup was not verified or does not exist):**
1. Stop the server
2. Manually inspect the current state:
   ```bash
   sqlite3 data.db "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'mf_engagement%';"
   sqlite3 data.db ".schema mf_engagement_event"
   ```
3. If `mf_engagement_event` exists with 8 columns → apply v26.7.1 and rerun migrate (Fix 1 makes CREATE TABLE IF NOT EXISTS a no-op)
4. If `mf_engagement_event` has more/fewer columns → manual reset:
   ```bash
   sqlite3 data.db "DROP TABLE IF EXISTS mf_engagement_event_new;"
   sqlite3 data.db "DROP TABLE IF EXISTS mf_engagement_event;"
   ```
   Then apply v26.7.1 (Fix 1's CREATE TABLE IF NOT EXISTS will recreate mf_engagement_event fresh with the correct 8-column shape), then rerun migrate.
5. Also reset the migration tracker to remove any partial 0131 attempts:
   ```bash
   sqlite3 data.db "DELETE FROM __drizzle_migrations_applied WHERE name LIKE '0128%' OR name LIKE '0129%' OR name LIKE '0130%' OR name LIKE '0131%';"
   ```

**Option C (nuclear if Options A/B fail):** ~~Rebuild the DB from scratch by rerunning all migrations from 0001.~~ **DO NOT USE this option.** Local testing found that migrations 0121, 0122, and 0123 contain `CREATE TRIGGER ... BEGIN ... END;` blocks that `migrate.ts`'s statement splitter mishandles. Running migrations from scratch dies at 0121 with `incomplete input` before ever reaching Wave C-2. This is a pre-existing bug in v26.5.0 and every version since — NOT a regression from Wave C-2 — but it means "fresh install" is not a viable recovery. Instead, if Options A/B fail, the correct fallback is: restore from an application-level data export (JSON of companies, rounds, users, subscriptions) and re-import into a freshly-booted (not migrated) DB, then apply the hotfix on top.

## What to Communicate to the Next Task

Read the master handover doc at `/home/user/workspace/WAVE_C2_MASTER_HANDOVER.md` FIRST. Then apply these additions to §6 (Assumptions Ledger) as new open questions:

- **OQ-10:** `mf_engagement_event` was never added to `buildProductionTableStatements` during the D1 integration wave. This is a bug of the same class as the `mf_engagement` fix (D-INT-1) but for the sibling audit table. All triple-review reviewers missed it because they focused on the specific table called out in D-INT-1, not the transitive graph of sibling tables. **Fix 1 above closes this.**
- **OQ-11:** Avi's live production server has 135 migration files vs. our v26.7.0 checkout's 70. Root cause unknown — either accumulated stale files or a divergent baseline. Next task should ask Avi to send a `ls -la server/db/migrations/` output to compare.
- **OQ-12:** Two migration-tracking tables coexist in production DBs (`_migrations_applied` legacy + `__drizzle_migrations_applied` new). Playbook E in §10 should be updated to disambiguate before diagnosing similar future errors. When Avi shares migration state, always ask him to query BOTH tables.
- **OQ-13:** The v26.7.0 runbook assumed a clean deploy path. It did not account for the partial-migration-recovery scenario. The next task should extend the runbook with an Option B/C recovery playbook (see Fix 4 above).

## Priority Actions for the Next Task

1. **Immediately apply Fix 1** — surgical ~15-line edit to `connection.ts`.
2. **Run Fix 2's grep** to verify no other sibling tables have the same defect.
3. **Regenerate v26.7.1 package** — connection.ts + updated manifest.
4. **Update the deploy runbook** with the partial-recovery playbook (Option B/C above).
5. **Update the master handover doc** with the 4 new open questions (OQ-10 through OQ-13).
6. **Communicate the recovery path to Ozan** so he can forward to Avi.

## What the Next Task Should NOT Do

- Do NOT try to fix migration 0131 by modifying its SQL. The migration is correct given a properly-seeded `mf_engagement_event` table; the fix belongs in `connection.ts` where the parent table should have been added.
- Do NOT re-run the full triple-review cycle on this fix. It is data-parallel to the D1 `mf_engagement` fix that already passed review.
- Do NOT touch the sacred file list. `mf_engagement_event` is not on it.
- Do NOT modify the working v26.6.0 or v26.7.0 checkouts to test the fix — copy to `capavate_v26.7.1` first and apply there.

## For Ozan to Forward to Avi

> Avi — thank you for the exceptionally clear error report. It let me diagnose this in ~15 minutes rather than the hours it would have taken with a "it doesn't work" message.
>
> The failure is a bug in our Wave C-2 code, not in your setup. Migration 0131 tries to modify a table (`mf_engagement_event`) that isn't created until the server first boots — but you ran `npm run db:migrate` before the server ever booted with the new code, so the table wasn't there. Both the "rounds not showing" and "rounds can't be created" issues are downstream side effects of the same failed migration corrupting the boot chain.
>
> Ozan will send you a v26.7.1 patch package containing a fix to `server/db/connection.ts` that ensures the table exists before migrations run. When you receive it:
>
> 1. Verify (or take, if you haven't) a fresh DB backup
> 2. If your backup from Runbook Step 0 is verified good: restore it now (Option A in the diagnosis doc)
> 3. Extract v26.7.1 delta — should only contain `connection.ts` and possibly `package.json`
> 4. Rerun `npm run db:migrate` — should now succeed through all 10 Wave C-2 migrations (0128-0137, deliberate 0135 gap)
> 5. Continue with the rest of the runbook (Step 4 onward)
>
> If the backup isn't verified good, the diagnosis doc contains Option B (manual state reset) and Option C (nuclear) paths.
>
> You did nothing wrong. Your error report was exactly the right level of detail.

## Estimated Fix Effort

- Fix 1 (`connection.ts` edit): 15 minutes
- Fix 2 (grep verification): 5 minutes
- Fix 3 (package regeneration): 30 minutes
- Fix 4 (runbook update): 15 minutes
- Handover doc update: 10 minutes

**Total: ~75 minutes.** Fully addressable in one session.

---

## Appendix: Grep Evidence For Each Claim

```bash
# CLAIM: mf_engagement_event is NOT in buildProductionTableStatements
grep -c "CREATE TABLE IF NOT EXISTS mf_engagement_event" /home/user/workspace/capavate_v26.7.0/server/db/connection.ts
# EXPECTED OUTPUT: 0
# ACTUAL OUTPUT (2026-08-06): 0 (verified)

# CLAIM: mf_engagement IS in buildProductionTableStatements
grep -c "CREATE TABLE IF NOT EXISTS mf_engagement\b" /home/user/workspace/capavate_v26.7.0/server/db/connection.ts
# EXPECTED OUTPUT: 1 (from D1)
# ACTUAL OUTPUT (2026-08-06): 1 (verified)

# CLAIM: mf_engagement_event IS created by applyMfcrmSchema
grep -c "CREATE TABLE IF NOT EXISTS mf_engagement_event" /home/user/workspace/capavate_v26.7.0/server/lib/mfcrmSchema.ts
# EXPECTED OUTPUT: 1
# ACTUAL OUTPUT (2026-08-06): 1 (verified)

# CLAIM: GET /api/rounds endpoint is byte-identical between v26.5.0 and v26.7.0
diff \
  <(sed -n '1967,1975p' /home/user/workspace/capavate_analysis/wave_c_code/v26.5.0/server/routes.ts) \
  <(sed -n '2001,2009p' /home/user/workspace/capavate_v26.7.0/server/routes.ts)
# EXPECTED OUTPUT: no diff
# ACTUAL OUTPUT (2026-08-06): no diff (verified)

# CLAIM: roundsStore.ts hydrate function is byte-identical
diff \
  /home/user/workspace/capavate_analysis/wave_c_code/v26.5.0/server/roundsStore.ts \
  /home/user/workspace/capavate_v26.7.0/server/roundsStore.ts
# EXPECTED OUTPUT: no diff (or only comment diffs)
# ACTUAL OUTPUT: no substantive diff
```
