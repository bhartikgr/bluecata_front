# Independent verification brief — Capavate Wave C3 (Shadie QA 2a + 7a)

You are an INDEPENDENT verifier. Return APPROVE or REVISE with concrete file:line
defects + fixes. Read the real files. Be adversarial; flag only REAL issues. Work
is committed at HEAD — use `git diff HEAD~1`. Do NOT run `git checkout -- .` /
`git reset` / any broad checkout that discards the working tree.

Build tree: `/home/user/workspace/capavate_work` (deps installed). Diff:
`WAVE_C3_SOURCE.diff`. Report: `FIX_REPORT_WAVE_C3.md`.

## What C3 does
Founder → Rounds. Non-sacred files. **No migration** (the invitation `note`
column already exists + persists).

**2a — personalize + EXACT-HTML preview of the invitation email:**
- `server/roundInvitationsStore.ts` exports `renderInvitationEmail()` — the
  SINGLE renderer used by BOTH the real send (`createInvitation`) and the
  preview, so preview == what is sent. All interpolated values HTML-escaped.
- Preview endpoints (READ-ONLY: no token, no invite, no email), both
  ownership-gated, company/round facts server-resolved (not client-overridable):
  - `POST /api/rounds/:id/invitations/preview` (round-detail invite)
  - `POST /api/companies/:companyId/invitation-preview` (Step-4 pre-create)
- Note persists via the EXISTING `note` column (no migration).
- Client: `RoundDetail.tsx` (round-detail invite) + `RoundNew.tsx` (Step-4
  manual dialog) each add a Personal-note field + "Preview email" that renders
  the exact server HTML. Only the note is editable; terms/duration/name fixed.
  The Step-4 note flows shareholder → `initial-shareholders` PATCH →
  `createInvitation` (server/lib/roundInitialShareholdersStore.ts).

**7a — round-name uniqueness PER COMPANY (not platform-wide):**
- `server/roundsStore.ts` `createRound` rejects a duplicate name for the SAME
  company (case-insensitive) → `ROUND_NAME_DUPLICATE`; empty → `ROUND_NAME_REQUIRED`.
  New exports `roundNameExistsForCompany()` (same-company only) +
  `suggestUniqueRoundName()`.
- `POST /api/rounds` → 409 (with `suggestedName`) / 400. New read-only
  `GET /api/rounds/name-availability` (owner-gated).
- Client `RoundNew.tsx`: on-blur availability check auto-fills an editable
  unique suggestion + amber hint; create `onError` applies the suggestion as a
  race backstop.

## HARD RULES (any violation = REVISE)
1. Sacred 40/40 byte-identical (confirm none in `git diff HEAD~1 --name-only`).
2. Money `server/captableCommitStore.ts` sha16 `01cd36130ee1c0cb`.
3. tsc net-new = 0 → exactly **598**.
4. Guard exit 0. Route count is **929** (was 926; +3 informational: 2 preview
   endpoints + name-availability). pages 194 / nav 92 unchanged.
5. No new migration. Payments/Airwallex untouched.

## Correctness to verify (adversarial)
- **Preview == send:** confirm `createInvitation` renders via
  `renderInvitationEmail` (same fn the preview endpoints call), so the founder's
  preview is byte-identical to the sent email. Confirm the note is included and
  HTML-escaped; confirm round facts (company/round name) are NOT taken from the
  client in the round-scoped preview (server-resolved); the Step-4 company-scoped
  preview may take roundName from the wizard draft (round doesn't exist yet) —
  confirm that's the only client-provided fact and it's escaped.
- **Preview is READ-ONLY:** no token minted, no invitation row created, no email
  sent by either preview endpoint. The preview link is a labelled placeholder.
- **Ownership:** both preview endpoints + name-availability reject a non-owner
  (403). The round-scoped preview uses requireFounderOwnsRound; the others check
  company ownership.
- **7a PER-COMPANY scope:** confirm `roundNameExistsForCompany` only compares
  rounds of the SAME companyId — two DIFFERENT companies may reuse a name; one
  company may not. RUN the test's cross-company case.
- **7a fail-closed:** a duplicate can't be persisted even via direct API
  (server throws before insert); the client UX is convenience only.
- **Note persistence:** confirm the note round-trips (INSERT `note` + hydrate)
  and that the Step-4 path passes `note` into `createInvitation`.
- **No regression:** the 7a guard must not break existing round-creating tests
  (they use unique names). RUN the round suites below.

Run:
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # exit 0, 929/194/92
npx vitest run server/__tests__/waveC3_invite_preview_and_round_name.test.ts   # 7 pass
npx vitest run server/__tests__/roundPersistenceProof.test.ts server/__tests__/roundDetailLoad.test.ts server/__tests__/v2348_round_initial_shareholders.test.ts server/__tests__/v15_invitation_flow.test.ts   # no new fails
git diff HEAD~1 --name-only    # only the C3 files + docs; no sacred file
```
If you run `npm run build`, restore ONLY: `git checkout -- server/public && git clean -fdq server/public/assets dist`. Do NOT commit.

## Known pre-existing (NOT a regression)
`server/__tests__/sprint21_invitations.test.ts` (2 co-soft-circle) and
`server/__tests__/spvEngine.test.ts` (30 sign-off fixture) fail on pristine HEAD.

## Output
Write to `/home/user/workspace/capavate_work/VERDICT_C3_<model>.md`:
1. VERDICT: APPROVE / REVISE
2. Gate results (actual numbers)
3. Per-check confirmation or defect (file:line + fix)
