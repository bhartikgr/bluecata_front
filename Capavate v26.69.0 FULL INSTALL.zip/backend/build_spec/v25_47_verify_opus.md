# v25.47 Independent Verification — Opus

**Verdict: READY**

Independent re-run of all gates (claims in `v25_47_gate_results.md` NOT trusted; everything below was re-executed in this tree). No project files were modified. The migration test ran against a copy at `/tmp/verify_opus.db`; the live `data.db`/`.env` were never touched.

## Gate results (independently re-run)

| # | Gate | Command | Required | Actual | Status |
|---|------|---------|----------|--------|--------|
| 1 | TSC error count | `npx tsc --noEmit \| grep -c "error TS"` | ≤ 611 | **611** | ✅ |
| 2 | AVI preserved | `bash scripts/verify_avi_preserved.sh` | exit 0 | exit 0 ("no Avi-preserved-edit regressions") | ✅ |
| 3 | Airwallex + partnerFee | `vitest run partnerFeeResolver/airwallexGateway/v24_2_airwallex_billing` | 45 pass | **3 files / 45 passed** | ✅ |
| 4 | v25_47 supertests | `vitest run server/__tests__/v25_47_*` | all pass | **18 files / 63 passed** | ✅ |
| 5 | vite build | `npx vite build` | exit 0 | exit 0 (built in 48s; only chunk-size warning) | ✅ |
| 6 | npm run build | `npm run build` | exit 0 | exit 0 (dist/index.cjs 3.0mb) | ✅ |
| 7 | Sacred SHA256 | `sha256sum -c SACRED_SHA256.txt` | all present OK, 0 FAILED | **20/20 OK, 0 FAILED**; 3 MISSING entries confirmed legitimately absent | ✅ |
| 8 | Migration (copy of data.db) | `DATABASE_URL=file:/tmp/verify_opus.db npm run db:migrate` | exit 0 | exit 0 (**10 applied, 69 skipped**) | ✅ |

### Gate 8 detail (post-migration schema on the copy)
- 0068–0077 all listed as Applying → "All migrations applied successfully", Exit 0.
- `platform_fees` has `billing_period`: **True**, `deleted_at`: **True**.
- New tables EXIST: `audit_chain_health`, `collective_admin_settings`, `spv_deployments`, `pulse_index_symbols`, `moderation_log`.

## Sacred / contract audit

- **Tier 1 byte-identity (cap-table/math/ledger + AVI Tier-2):** all present sacred files hash-MATCH the baseline (Gate 7). 0 modified. The 3 `MISSING` baseline entries (`server/cap-table-engine.ts`, `server/math-fns.ts`, `server/collectiveRenewalWorker.ts`) are confirmed legitimately absent at those paths — not regressions.
- **Rule 76 (founder/investor subscription path):** `paymentGatewayAdapter.ts`, `canonicalPlanResolver.ts`, `profileStore.ts`, `client/src/pages/founder/Billing.tsx`, `subscriptionStore.ts` all hash-MATCH → byte-identical. ✅
- **Zero in-memory / 100% DB-driven (new stores):**
  - `spvDeploymentStore`, `pulseSymbolStore`, `postModerationStore`, `postAttachmentsStore`, `collectiveAdminSettingsStore` — each performs both `SELECT` reads and `INSERT/UPDATE` writes via `rawDb()/getDb()`; canonical state persists to its DB table and is re-read. No Map-only/array-only canonical state.
  - `lib/collectiveMemberSubscriptionResolver.ts` — read-only projection over `platform_fees` via `subscriptionTierStore`; adds no state. Literal `24900` is an explicit seed fallback matching connection.ts, not the canonical source. ✅
  - `lib/partnerTiers.ts` — 5-tier amounts DB-resolved via `getTier(CONSORTIUM_SUBSCRIPTION_PREFIX, slug)`; in-file literals are seed fallbacks + tier order/labels (structural metadata), not canonical prices. ✅
  - `founderCrmStore` invite path — persists via `rawDb` (verified in build phase); `audit_chain_health` is a DB table queried by route.
- **No lazy `require(` in new server files:** grepped `spvDeploymentStore`, `pulseSymbolStore`, `postModerationStore`, `postAttachmentsStore`, `collectiveAdminSettingsStore`, `collectiveMemberSubscriptionResolver`, `partnerTiers`, `postModerationRoutes`, `postAttachmentRoutes` → **0 `require(`, 0 `createRequire`**. Safe under the tsx ESM production loader. (The pervasive `require()` hits elsewhere are pre-existing files carrying the v25.25.2 createRequire shim — out of scope, sacred files among them unchanged.)
- **No silent drops:** all 6 new client surfaces present (`PostsModeration`, `PulseSymbols`, `CollectiveSettings`, `ConsortiumPricing`, `MembershipPage`, `AuditChainP0Banner`); routes `/consortium/pricing`, `/investor/inbox`, `/admin/collective-settings`, `/admin/pulse-symbols`, `/admin/posts` all wired in `App.tsx`. No routes/widgets removed.
- **Migrations additive-only:** 0068–0077 contain no `DROP TABLE/COLUMN/CONSTRAINT`, `TRUNCATE`, or `DELETE FROM`. ✅

## Notes (non-blocking)

1. **Version is 25.47.0** in both `package.json` and `.env` (`APP_VERSION=25.47.0`), consistent with each other and with the REBUILD_SPEC's final-step target. The `v25_47_gate_results.md` note claiming "25.46.1, NOT bumped" is **stale** — the present state is the correct release version, so this is an improvement, not a defect.
2. Verifier Gate 4 scope was the `v25_47_*` server suite (per the instruction), not the full 143-file canonical e2e. The parent reported that suite green (836 passed / 2 skipped / 0 failed); I did not independently re-run the full e2e.
3. vite emits a chunk-size (>500kB) advisory only — not an error.

## Blockers

**None.**

Every gate passes on independent re-run, sacred Tier 1 + Rule 76 files are byte-identical, new stores are DB-driven, new server files are free of lazy `require()`, migrations are additive-only and apply cleanly against a copy of the live DB, and no routes/widgets were silently dropped.
