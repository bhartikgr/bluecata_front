# v25.47 — SENIOR INDEPENDENT Verification (GPT-5.5)

**Role:** Senior independent verifier. Per Sacred Tier 3 #32, this DO-NOT-SHIP verdict overrides Opus + Gemini.
**Mode:** Verification only — no source files modified. Migration tested against a `/tmp` copy of the live DB; the only file written is this report.
**Date:** 2026-06-30
**Tree:** `/home/user/workspace/capavate_v25_47` (package.json version = **25.47.0**)

---

## VERDICT: ✅ READY (code) — with 2 NON-CODE packaging deliverables to author before Avi deploys

All 8 build gates pass independently. The full v25.47 delta (APD-019 → APD-038, migrations 0068–0077) is present, additive, DB-driven, and byte-identity-clean on every sacred file. Migrations apply cleanly **and idempotently** against a copy of the real production `data.db`.

The only outstanding items are **packaging artifacts that do not exist in the tree** (`INSTALL_v25.47.md`, `deploy_v25_47_LIVE.sh`). These are not code-shippability blockers — the build is shippable — but Avi cannot run a correct live deploy until the deploy script is authored to the spec in §"Deploy packaging" below. I classify these as **DEFERRED packaging tasks**, not DO-NOT-SHIP.

---

## Gate table (all independently re-run)

| # | Gate | Required | Actual | Status |
|---|------|----------|--------|--------|
| 1 | `tsc --noEmit \| grep -c "error TS"` | ≤ 611, zero net-new | **611**, 0 errors in any new/edited file | ✅ |
| 2 | `bash scripts/verify_avi_preserved.sh` | exit 0 | exit 0 — "no Avi-preserved-edit regressions" | ✅ |
| 3 | Airwallex/partnerFee tests | 45 passed | **45/45** (3 files) | ✅ |
| 4 | Full e2e (`vitest.e2e.v2534.config.ts`) | 0 failed | **836 passed / 2 skipped / 0 failed** (142 files +1 skipped) | ✅ |
| 5 | `vite build` | exit 0 | exit 0 (built in 17.82s) | ✅ |
| 6 | `npm run build` | exit 0 | exit 0 (dist/index.cjs emitted) | ✅ |
| 7 | `vitest run server/__tests__/v25_47_*` | all pass | **18 files / 63 tests, 0 failed** | ✅ |
| 8 | `sha256sum -c SACRED_SHA256.txt` | 20 OK / 0 FAILED | **20 OK / 0 FAILED** (3 MISSING-format lines expected) | ✅ |

Gate 1 confirmed: the parent's `String(req.params.id)` coercion in `postModerationRoutes.ts` / `postAttachmentRoutes.ts` is present — TSC is back to the 611 baseline with zero errors attributable to any v25.47 file.

---

## CRITICAL live-deploy verification (Sacred Tier 6 — highest priority)

### Migration against a COPY of the real production DB
`cp data.db /tmp/verify_gpt.db` then `DATABASE_URL="file:/tmp/verify_gpt.db" npm run db:migrate`:

- **First run:** exit **0** — 10 applied (0068–0077), 69 skipped.
- **Second run (idempotency / restart sim):** exit **0** — 0 applied, 79 skipped. No dupes, no crash.

Post-migration content (queried directly against `/tmp/verify_gpt.db`):
- `platform_fees` columns: `key, amount_minor, currency, updated_at, updated_by_user_id, billing_period, deleted_at` ✅ (billing_period + deleted_at added)
- 5 new tables EXIST: `audit_chain_health` (1 seed row), `collective_admin_settings`, `spv_deployments`, `pulse_index_symbols` (10 symbols), `moderation_log` ✅
- `network_posts.attachments` column present ✅
- `collective.member_subscription.standard = 24900` ✅ — legacy `basic 9900 / pro 24900 / enterprise 99900` **preserved** (no silent drops) ✅
- Consortium 5 tiers: `catalyst 49900 / builder 99900 / amplifier 149900 / nexus 499900 / founding_member 0` ✅ — legacy `partner_basic/pro/enterprise` **preserved** ✅
- `audit_chain_health` seeds the `tenant_admin_capavate` incident row ✅

### Zero in-memory / 100% DB-driven (Ozan's hard rule)
Audited every new store — all canonical reads/writes hit a real table via `rawDb().prepare(...)` (or `subscriptionTierStore` → `platform_fees`); none hold canonical state in a Map/array. Survives process restart.

| Store | Backing | Verdict |
|-------|---------|---------|
| `spvDeploymentStore.ts` | `spv_deployments` (UNIQUE spv_id, idempotent insert; fee DB-resolved from `consortium.spv_deployment_fee`) | ✅ DB |
| `pulseSymbolStore.ts` | `pulse_index_symbols` (upsert/list/toggle; NO hardcoded watchlist) | ✅ DB |
| `postModerationStore.ts` | `network_posts.deleted_at` soft-delete + `moderation_log` (immutable, reversible) | ✅ DB |
| `postAttachmentsStore.ts` | `network_posts.attachments` JSON; bytes via `objectStorage.putObject` | ✅ DB |
| `collectiveAdminSettingsStore.ts` | `collective_admin_settings` (one JSON row; defaults are fallback only) | ✅ DB |
| `collectiveMemberSubscriptionResolver.ts` | reads `platform_fees` via `subscriptionTierStore`; literals are documented seed fallbacks | ✅ DB |
| `partnerTiers.ts` | amounts DB-resolved via `subscriptionTierStore`; `PARTNER_TIERS` holds ORDER/label metadata only, prices are fallbacks | ✅ DB |

The seed-fallback literals (24900, 49900, …) are reached only when the DB row is absent; against the live DB every `fromDb` path is true. This satisfies the zero-canonical-in-memory rule.

### ESM/tsx (production runs `tsx server/index.ts`, ESM)
Grepped all new server `.ts` (7 stores + 4 route modules) for lazy `require(` → **NONE**. All use static `import`. Compliant with the no-lazy-require rule.

### Sacred byte-identity (Tier 1 + Rule 76)
Gate 8 = 20/20 OK, 0 FAILED. The Rule-76 subscription-path files and Tier-1 cap-table/math files are byte-identical to the baseline snapshot. New subscription structures (single-tier member, 5-tier partner) are SEPARATE/PARALLEL modules — they do not touch the frozen files.

---

## Deploy packaging — DEFERRED items (author before Avi deploys)

**`INSTALL_v25.47.md` and `deploy_v25_47_LIVE.sh` do NOT exist in this tree** (latest present: `INSTALL_v25.45.md`, `deploy_v25_45_LIVE.sh`). They must be authored. When the deploy script is regenerated it MUST contain (vs LIVE_SERVER_TRUTH.md and the divergences in the stale `deploy_v25_45_LIVE.sh`):

1. **APP_DIR = `/var/www/html/backend`** — `deploy_v25_45_LIVE.sh:22` defaults to `/opt/capavate` (WRONG).
2. **Restart = `pm2 restart backend`** — `deploy_v25_45_LIVE.sh:78` does `pm2 restart capavate || pm2 start dist/index.cjs --name capavate` and `:79` falls back to `systemctl … capavate`. Both WRONG: process name is `backend`, and production runs **`tsx server/index.ts`** (fork mode), not `dist/index.cjs`.
3. **Health probe** — app serves BOTH `/api/healthz` (routes.ts:1011) and `/api/health` (routes.ts:1026); live convention is `/api/healthz`. Either works; smoke-check `/api/healthz` and confirm version == `25.47.0`.
4. **Frontend refresh** — after build, copy fresh `dist/public` → `/var/www/html/frontend`. The v25.45 script does NOT do this (nginx would serve a stale SPA).
5. **Never overwrite** live `.env` / `data.db*` — only `sed`-bump `APP_VERSION` to `25.47.0` in place. (The v25.45 script's `cp .env`/`cp data.db` to a backup dir is safe; do NOT rsync over them.)
6. **S3 env naming** — objectStorage (APD-038) requires `AWS_S3_BUCKET` + `AWS_KMS_KEY_ID` + `AWS_REGION` AND a credential mode; live `.env` has `AWS_BUCKET` (no KMS key). INSTALL must instruct Avi to set `AWS_S3_BUCKET` + `AWS_KMS_KEY_ID` or post-attachment uploads fail-fast in production (this fail-fast is correct/intended — verified by `v25_47_apd038_s3_failfast.test.ts`).
7. **`MIGRATIONS_PRESENT:` claim — CONFIRMED:** `server/db/migrate.ts` emits NO `MIGRATIONS_PRESENT:` line. Any regenerated deploy script must NOT grep for it (it would FATAL). The runner scans `./migrations` (MIGRATIONS_DIR default); migrations 0069–0077 are present there AND mirrored in `server/db/migrations`. Runner output to assert on: `All migrations applied successfully` / `Exit 0`.

These are documentation/ops deliverables. They do not affect the correctness of the built artifact.

---

## Blocker list

**Code blockers (DO-NOT-SHIP): NONE.**

**Packaging blockers (DEFERRED — must complete before live cutover, not before code freeze):**

| # | Item | File | Fix |
|---|------|------|-----|
| P1 | No v25.47 deploy script | (absent) `deploy_v25_47_LIVE.sh` | Author per §"Deploy packaging" items 1–7 |
| P2 | No v25.47 install doc | (absent) `INSTALL_v25.47.md` | Author; document AWS_S3_BUCKET/AWS_KMS_KEY_ID requirement (item 6) prominently |

---

## Notes on expected non-failures
- Gate 4 "1 skipped file" = `v25_45_gpt55_privacy_norow_probe_e2e.mjs`, a verifier-owned shim whose probe (`build_spec/v25_45_round2_gpt55_archive_probe.mjs`) is intentionally absent from Avi's tree; the import is `existsSync`-guarded so it skips cleanly. Pre-existing, test-only, zero real tests.
- Gate 8 "3 improperly formatted lines" = the 3 baseline `MISSING` entries (`server/cap-table-engine.ts`, `server/math-fns.ts`, `server/collectiveRenewalWorker.ts` at root — they live elsewhere or are absent by design); expected, 0 FAILED among the 20 real hashes.
- `v25_38_application_fee_e2e.mjs` asserts APD-028 canonical `$300 = 30000` minor units; production resolver `DEFAULT_APPLICATION_FEE_MINOR = 30000` is untouched (tests aligned to the locked spec, code not weakened).

## Bottom line
Code is **READY to ship**. Triple-verify gate set is fully green and reproduced independently; live-DB migration is exit-0 and idempotent; DB-driven and byte-identity constraints hold. Gate the live deploy on authoring `deploy_v25_47_LIVE.sh` + `INSTALL_v25.47.md` to the 7-point spec above.
