# CAPAVATE v25.48 — BUILD SPEC (as-built)

Base: v25.47.0 → v25.48.0. Runtime: Node 20 + tsx (ESM). Sacred set: 39 files (byte-identical).
Triple-verified: Opus 4.8 (SHIP) · Gemini 3.1 Pro (SHIP) · GPT-5.5 override (SHIP, after a
2-blocker fix pass). See build_spec/v25_48_verify_*.md.

## Principles honored
- Every fix works on the LIVE site: prod runs TS via tsx (ESM). No new lazy require() in server TS
  (dynamic await import() only where needed). Migrations additive-only + idempotent against a copy
  of the live data.db.
- The 39 Sacred files are NEVER edited — every sacred-adjacent change is a PARALLEL module or a
  route-layer guard that CALLS the sacred exports read-only.
- Zero in-memory canonical state; 100% DB-driven; no mock data served on live paths.

## Items implemented (all locked in the audit DOCX)

| ID | What | Where (non-sacred) | Server-enforced |
|----|------|--------------------|-----------------|
| NEW-1 | Company JOIN = active paid subscriber (403 not_active_subscriber, both apply routes); investor JOIN = ≥1 active cap-table position (403 no_cap_table_position); promote unchanged | founderCollectiveApplyStore.ts, collectiveWaitlistRoutes.ts | ✅ |
| DSC-1a | compute/score gate also accepts isDscMember (dsc_roles) | collectiveRoutes.ts | ✅ |
| DSC-1b | client DSC review/vote modal wired to vote + compute endpoints | client CollectiveDscPipeline.tsx | UI |
| DSC-1c | signed short-lived pitch-deck secure link, DSC-gated | server/lib/dscPitchDeckV2548.ts + client | ✅ |
| CP-2a | /consortium/pricing fully dynamic from listTiers() (soft-delete hides, add appears) | server/lib/partnerTiers.ts | ✅ |
| CP-2b | advertised == charged (subscribe reads the advertised tier row; NO legacy fallback, fail-closed) | server/lib/partnerSelfServiceRoutes.ts | ✅ |
| CP fixes | canonical tier copy; dead activation-link removed; portfolio-count field already correct | client PartnerSignup.tsx, ConsortiumApplyPage.tsx | UI |
| DATA-1 | email_templates DB table + admin GET/GET:slug/PUT:slug + seed-on-boot (DB-first, restart-safe) | emailStore.ts, connection.ts, migration 0081 | ✅ |
| DATA-2 | /api/companies unconditionally DB-backed (getAllCompaniesFromDb); empty DB → []; never mock | routes.ts | ✅ |
| HIGH-7 | notifications feed clean empty state (already 200 {items:[]}) + /founder/notifications client route | client App.tsx | ✅ (route) |
| HIGH-8 | legacy outbound bridge default-OFF in prod via BRIDGE_ENABLED (no 501/DLQ) | server/lib/bridgeEnabled.ts, index.ts | ✅ |
| HIGH-9 | mock migration commit blocked in prod unless MOCK_MIGRATION_ALLOWED=1 (route-layer guard) | routes.ts (before registerMigrationRoutes) | ✅ |
| PF-1 | read-only GET /api/founder/captable via exported captable readers + client null-guard; empty→safe | routes.ts, client CapTable.tsx | ✅ |
| PF-UX-1 | friendly "membership not active/pending" state on 7 gated collective pages | client collectiveGateError.ts + 7 pages | UI |
| B1 | investor-side CRM auto-seed at invitation redeem (invitation-sourced tag) | server/lib/investorCrmInvitationSeed.ts | ✅ |
| B2 | batch commit accepts per-entry FOUNDER-confirmed amount (parallel wrapper → commitFunded) | server/lib/captableCommitV2548.ts | ✅ |
| B3 | persisted per-investor "docs sent" flag + founder-visible list | server/lib/investmentSignalsV2548.ts, migration 0078 | ✅ |
| B4 | optional investor "I wired" advisory signal (does NOT move cap table) | server/lib/investmentSignalsV2548.ts, migration 0079 | ✅ |
| B5 | REQUIRED founder attestation at commit (fail-closed); attestor id+timestamp | server/lib/captableCommitV2548.ts, migration 0080 | ✅ |

## Investment-flow canonical model (B1–B5 semantics)
intent → soft-circle (non-binding) → FOUNDER confirms soft-circle → founder sends sub-docs OFFLINE
(B3) → wired (investor advisory, B4) → FOUNDER confirms funds-in-bank OFFLINE → committed (+declined)
→ cap table auto-updates on the FOUNDER-confirmed amount. Founder is the authoritative amount owner
on BOTH single and batch paths. member=investor=cap-table member (FREE); company=subscriber (pays).

## Migrations (additive-only; mirrored in ./migrations AND server/db/migrations + base CREATE in connection.ts applyV2548Schema)
- 0078 subscription_docs_sent · 0079 investor_wired_signals · 0080 commit_attestations · 0081 email_templates

## Gates (all green)
TSC 611 (zero net-new) · verify_avi exit 0 · Airwallex 45/45 · v25_48 supertests 30/30 ·
vite build exit 0 · npm run build exit 0 · full e2e 862 passed / 2 skipped / 0 failed ·
sacred 39/39 · migration applies + idempotent on a copy of the live data.db (email_templates seeds 21 rows on boot).

## Pre-existing tests adapted for NEW-1 (production code NOT weakened)
v25_41_founder_apply_chapter_resolution_e2e.mjs and v25_35_persistence_integrity_e2e.mjs now seed an
active paid subscription (subscriptionStore.recordPendingSubscription + activateByPaymentIntent).

## New env flags
BRIDGE_ENABLED (default OFF in prod) · MOCK_MIGRATION_ALLOWED (unset in prod).
