# v25.47 Independent Verification — Gemini dispatch

**Verifier:** independent (Gemini lane). Tree: `/home/user/workspace/capavate_v25_47`.
**Method:** all 8 gates RE-RUN from scratch (prior claims not trusted) + sacred/DB-driven/lazy-require/APD audits.
**Date:** 2026-06-30.

## VERDICT: DEFERRED-PENDING-LIVE-CHECK

All 8 sandbox gates GREEN (8/8) and all static audits clean. The verdict is **not READY** for one reason only: the mandatory authenticated live-site browser pass (Tier 4 #39 / Tier 6 #49) could not be performed — **no live credentials are available in this session**. Per the standing rule, absent an in-session live-credential pass the verdict defaults to DEFERRED-PENDING-LIVE-CHECK rather than READY. There are **no code-level DO-NOT-SHIP blockers.**

## Gate results (independently re-run)

| # | Gate | Command | Result | Status |
|---|------|---------|--------|--------|
| 1 | TSC error count ≤611 | `npx tsc --noEmit \| grep -c "error TS"` | **611** | ✅ |
| 2 | AVI preserved | `bash scripts/verify_avi_preserved.sh` | exit 0, "no Avi-preserved-edit regressions" | ✅ |
| 3 | Airwallex/partnerFee | 3 fee/gateway test files | **45 passed / 45** | ✅ |
| 4 | Tier-6 v25.47 | `vitest run server/__tests__/v25_47_*` | **18 files / 63 tests passed** | ✅ |
| 5 | vite build | `npx vite build` | exit 0, built in 16.4s | ✅ |
| 6 | npm build | `npm run build` | exit 0, dist/index.cjs emitted | ✅ |
| 7 | Sacred SHA256 | `sha256sum -c SACRED_SHA256.txt` | **20/20 OK, 0 FAILED** (3 MISSING lines expected/ignored) | ✅ |
| 8 | Migration on live-DB copy | `cp data.db /tmp/verify_gemini.db; DATABASE_URL=... npm run db:migrate` | exit 0, 10 applied (0068–0077) | ✅ |

### Gate 7 detail
20 Tier-1 + Rule-76 files hash-MATCH the baseline. The 3 baseline-"MISSING" entries (cap-table-engine.ts, math-fns.ts, the alt-path collectiveRenewalWorker.ts) remain absent as recorded — not failures. **Rule-76 subscription path (paymentGatewayAdapter, canonicalPlanResolver, profileStore, founder/Billing.tsx, subscriptionStore) byte-identical.** No sacred violations.

### Gate 8 detail (copy of production data.db, live DB never touched)
- Migrations **0068–0077 all applied**, exit 0.
- `platform_fees` has `billing_period` + `deleted_at`.
- New tables present: audit_chain_health, collective_admin_settings, spv_deployments, pulse_index_symbols, moderation_log (all = 1).
- Consortium 5-tier seeded: catalyst 49900 / builder 99900 / amplifier 149900 / nexus 499900 / founding_member 0 — **legacy partner_basic/pro/enterprise PRESERVED (no silent drops).**
- Collective `member_subscription.standard` = 24900 ($249/mo) — **legacy basic/pro/enterprise PRESERVED.**

## Audits

- **Lazy `require(` in new server TS:** none. All 13 new/edited server modules clean (tsx-ESM safe). ✅
- **DB-driven (zero in-memory canonical state):** spvDeploymentStore, pulseSymbolStore, postModerationStore, postAttachmentsStore, collectiveAdminSettingsStore all read/write the DB (7–11 db refs each). The two resolvers (collectiveMemberSubscriptionResolver, partnerTiers) carry no canonical state — amounts are DB-resolved via subscriptionTierStore/platform_fees; literal `fallbackMinor` values are explicitly seed fallbacks with "DB row is authoritative," not canonical source. Survives process restart. ✅
- **Migrations additive-only:** no DROP/DELETE/TRUNCATE/destructive ALTER/RENAME in 0069–0077. ✅
- **APD coverage spot-check:** routes present — `/api/collective/member-tier` (APD-019), `/api/consortium/pricing` public (APD-020), `/api/admin/consortium/spv-deployments` (APD-021), pulse/moderation/attachment/collective-settings routes registered in routes.ts (APD-022/023/024/031), `/api/admin/audit-chain-health` (APD-029). Client pages all present: ConsortiumPricing, PulseSymbols, PostsModeration, CollectiveSettings, MembershipPage, AuditChainP0Banner. ✅
- **APD-025 email rebrand:** .env SMTP_USER/FROM/REPLY_TO = scale@capavate.com; **0** scale@blueprintcatalyst.com leftovers; 6 new templates in emailStore.ts. ✅
- **APD-038 S3 fail-fast:** assertProductionStorageConfigured() requires AWS_S3_BUCKET + AWS_KMS_KEY_ID + AWS_REGION + cred mode; throws BEFORE any FS write in production. ✅
- **Version bump:** package.json = 25.47.0, .env APP_VERSION = 25.47.0. ✅

## Findings / deploy-readiness notes (non-blocking)

1. **DEFERRED reason — no live-site verification.** No live credentials in-session; cannot confirm `https://capavate.com/api/healthz` returns version 25.47.0 or run the authenticated SPA pass. This is the sole reason for DEFERRED vs READY.
2. **`INSTALL_v25.47.md` is ABSENT from the tree** (latest present is INSTALL_v25.45.md). The rebuild spec names it as authoritative APD wording and the live deploy doc. The APDs are nonetheless implemented and gate-verified. Recommend authoring/shipping INSTALL_v25.47.md before deploy so Avi has the live runbook (esp. the S3 `AWS_S3_BUCKET`+`AWS_KMS_KEY_ID` divergence vs live `.env`'s `AWS_BUCKET`, per LIVE_SERVER_TRUTH §6).
3. **S3 env divergence reminder (from LIVE_SERVER_TRUTH §6):** live `.env` uses `AWS_BUCKET` and has no `AWS_KMS_KEY_ID`; APD-038 now fail-fasts in production without `AWS_S3_BUCKET`+`AWS_KMS_KEY_ID`. Avi MUST set these on the live box or post-upload routes will throw. Must be called out in the deploy doc.
4. **Deploy-script divergences (LIVE_SERVER_TRUTH §40) are documentation/runtime concerns, not code:** APP_DIR `/var/www/html/backend`, `pm2 restart backend`, `/api/healthz`, refresh `/var/www/html/frontend` with fresh dist/public, never overwrite `.env`/`data.db*`. Verify these in the deploy script before shipping.

## Bottom line
Code is sound: 8/8 gates pass, sacred files intact, no lazy require, DB-driven stores, additive migrations, full APD coverage. **DEFERRED-PENDING-LIVE-CHECK** solely because the authenticated live-site pass cannot be done in this session. Clear the live check (and ship INSTALL_v25.47.md + confirm S3 env on live) → READY.
