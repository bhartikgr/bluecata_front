# Capavate LIVE Server — Source of Truth (for v25.47 deploy + verify)

Sourced from Ozan's saved production notes (2026-06-15) + Avi's live `.env` in this zip. This is the ground truth the deploy script, INSTALL doc, and triple-verify must respect. Live correctness > sandbox-green.

## Host / runtime
- GoDaddy WHM VPS, AlmaLinux 9.8
- Node.js v20.20.2, npm 10.8.2, **npm-only** (no yarn/pnpm)
- nginx 1.20.1 over HTTPS/HTTP2, `client_max_body_size 200M` (15MB post uploads OK)
- **PM2 process name = `backend`** (fork mode). Restart = `pm2 restart backend`. NOT systemctl, NOT "capavate".
- **Production runs TS source directly via `tsx`** at `/var/www/html/backend/node_modules/.bin/tsx server/index.ts` — NOT dist/index.cjs.
  → Server-side TS must use STATIC imports (or dynamic `import()`), never lazy `require()` (tsx runs ESM, package.json type=module).

## Paths
- Backend: `/var/www/html/backend`  (entry referenced as index.cjs but PM2 runs tsx on server/index.ts)
- Frontend: `/var/www/html/frontend`  ← deploy MUST refresh this with fresh `dist/public` or nginx serves stale SPA via error_page fallback
- Env: `/var/www/html/backend/.env`
- DB: `/var/www/html/backend/data.db` (+ -shm, -wal). **NEVER touch data.db / -shm / -wal / .env during deploy.**

## nginx routing
- `/api/` → `127.0.0.1:5000` (forwarded headers, 600s timeouts)
- `/socket.io/` → localhost:5000
- SPA fallback try_files + error_page 403 404 /index.html
- No CDN, no edge cache, no reverse proxy in front — curl probes hit nginx directly.

## Verify sequence after deploy
1. `curl 127.0.0.1:5000/api/healthz`
2. `curl https://capavate.com/api/healthz`  (confirm version == 25.47.0)
3. `pm2 logs backend` + `/var/log/nginx/capavate-error.log`

## Live .env (production truth — non-secret shape)
- NODE_ENV=production, PORT=5000
- DATABASE_URL=file:/var/www/html/backend/data.db
- SMTP gmail:465 secure; **currently scale@blueprintcatalyst.com → v25.47 APD-025 rebrands to scale@capavate.com**
- Airwallex LIVE (AIRWALLEX_MODE=live, real network, live API base + webhook secret), PAYMENT_GATEWAY_DEFAULT=airwallex
- Storage: STORAGE_PROVIDER=s3, AWS_REGION=ap-south-1, **AWS_BUCKET=capavate-uploads** (live uses AWS_BUCKET; AWS creds are placeholders)
- Cookies: COOKIE_DOMAIN=capavate.com, COOKIE_SECURE=true, COOKIE_SAME_SITE=lax
- COLLECTIVE_ENABLED=1 (x2 harmless drift), CONSORTIUM_AUTO_APPROVE=1, dev flags disabled
- APP_VERSION=25.46.1 → bump to 25.47.0

## ⚠️ Divergences to FIX in the rebuilt deploy script / INSTALL (vs attached deploy_v25_47_LIVE.sh)
1. APP_DIR must be `/var/www/html/backend` (script default `/var/www/capavate` is WRONG for live).
2. Restart must be `pm2 restart backend` (script tries systemctl/`pm2 restart capavate` — WRONG name).
3. Health endpoint: live uses `/api/healthz` (script hits `/api/health`). Confirm which the app actually serves; smoke-check the one that exists (ideally both).
4. Frontend: after build, copy fresh `dist/public` → `/var/www/html/frontend` (script doesn't).
5. Must NOT overwrite live `.env` / `data.db*`. Only bump APP_VERSION in place (sed), never rsync over them.
6. S3 env-var naming: v25.47 objectStorage expects `AWS_S3_BUCKET` + `AWS_KMS_KEY_ID`; live .env has `AWS_BUCKET` (no KMS key). Document this in INSTALL so Avi sets AWS_S3_BUCKET + AWS_KMS_KEY_ID (or post uploads fail-fast in production). Flag prominently.

## ⚠️ ESM/tsx note for any new server code
No lazy `require(...)` in server TS. Use `import`. Dynamic `await import(...)` is fine.
