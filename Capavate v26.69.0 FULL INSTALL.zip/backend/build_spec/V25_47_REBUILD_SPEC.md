# v25.47 Rebuild Spec (authoritative work order)

Base tree: `/home/user/workspace/capavate_v25_47` (currently v25.46.1, TSC=611 clean, AVI exit 0, Airwallex 45/45, deps installed).
Goal: re-implement the FULL v25.47 delta so the tree matches INSTALL_v25.47.md + CAPAVATE_SACRED_FILES.md (APD-019 → APD-038), pass all 8 build gates, then triple-verify.

## ABSOLUTE SACRED CONSTRAINTS (do not violate — DO-NOT-SHIP if broken)
- Tier 1 byte-identity: NEVER edit any of these (verify unchanged vs build_spec/v25_47_baseline_snapshot/SACRED_SHA256.txt):
  server/captableCommitStore.ts, server/roundCarryForwardEngine.ts, server/lib/rateLimit.ts, server/lib/sseHub.ts,
  server/lib/userContext.ts, server/companyProfileStore.ts, server/investorCrmStore.ts, server/messagingStore.ts,
  server/notificationsStore.ts, server/lib/collectiveRenewalWorker.ts, server/lib/bridgeRuntime.ts,
  server/lib/migrationRunner.ts, server/lib/driftDetector.ts, server/welcomeStore.ts, server/lib/userPrivacyResolver.ts,
  server/lib/capTableMembership.ts (comment-only changes already exist; do NOT change logic).
  Any file matching glob *captable*/*cap-table*/*math-fns*/*roundCarryForward* is sacred. COMMISSION_RATE literal frozen.
- Rule 76 byte-identity (founder/investor subscription path FROZEN):
  server/paymentGatewayAdapter.ts, server/lib/canonicalPlanResolver.ts, server/profileStore.ts,
  client/src/pages/founder/Billing.tsx, server/subscriptionStore.ts. NEW subscription structures must be SEPARATE/PARALLEL.
- home3compo/ byte-identical to v25.43 (verify_avi_preserved.sh must stay exit 0).
- Migrations ADDITIVE ONLY (ADD COLUMN nullable/default, CREATE TABLE IF NOT EXISTS). Never DROP/destructive ALTER.
- "Private Investor" terminology locked. Zero in-memory canonical state (DB-driven). No silent drops (wrapper pattern).
- Brand: red #cc0001 / navy #041e41 / Montserrat + Instrument Serif. Canonical primitives only on Collective/Consortium surfaces.
- All new tests must hit REAL Express routes via supertest (no React Query mock fixtures). Save→Restart→Load round-trip for persistence.

## DELIVERABLE: implement these APDs (all ADDITIVE). Migrations live in server/db/migrations/.

### Migrations to create (additive only)
- 0069_v25_47_high1_founder_crm_invite.sql — founder_crm contacts: add nullable invite_status, invited_round_id, invited_at
- 0070_v25_47_audit_chain_health.sql — CREATE TABLE audit_chain_health (key/status/detail/updated_at); seed incident row tenant_admin_capavate
- 0071_v25_47_collective_admin_settings.sql — CREATE TABLE collective_admin_settings (key TEXT PK, value_json TEXT, updated_at)
- 0072_v25_47_consortium_5tier.sql — expand platform_fees consortium.subscription.* from 3 → 5 tiers (catalyst 499/builder 999/amplifier 1499/nexus 4999/founding_member 0)
- 0073_v25_47_collective_member_single_tier.sql — seed collective.member_subscription.standard = 24900 minor ($249/mo); preserve legacy basic/pro/enterprise rows
- 0074_v25_47_spv_deployments.sql — CREATE TABLE spv_deployments (spv_id UNIQUE, fee_minor, recorded_at, ...)
- 0075_v25_47_pulse_index_symbols.sql — CREATE TABLE pulse_index_symbols; seed 10 (SPY,QQQ,DIA,IWM,XLK,XLF,BTC-USD,ETH-USD,VIX,USD/EUR), enabled, refresh 3600s
- 0076_v25_47_moderation_log.sql — CREATE TABLE moderation_log (post_id, action, actor, reason, created_at) immutable audit
- 0077_v25_47_posts_attachments.sql — ALTER network_posts ADD COLUMN attachments TEXT (nullable JSON); also base CREATE in server/db/connection.ts
Also add base CREATE TABLE IF NOT EXISTS + seed equivalents in server/db/connection.ts so fresh DB has them.

### Server APDs
- APD-019: server/lib/collectiveMemberSubscriptionResolver.ts — resolveCanonicalMemberTier maps legacy→standard; GET /api/collective/member-tier in server/collectiveRoutes.ts. Test v25_47_apd019_member_single_tier.test.ts (3).
- APD-020: public GET /api/consortium/pricing (collectiveRoutes.ts) projects 5 DB-resolved tiers. Test v25_47_apd020_consortium_pricing.test.ts (3).
- APD-021: server/spvDeploymentStore.ts recordSpvDeployment idempotent on spv_id, fee DB-resolved from consortium.spv_deployment_fee. Admin GET|POST /api/admin/consortium/spv-deployments in server/adminFeeTierRoutes.ts. Test v25_47_apd021_spv_deployments.test.ts (4).
- APD-022: server/pulseSymbolStore.ts + server/pulseSymbolRoutes.ts (GET|POST /api/admin/pulse-symbols, PATCH /api/admin/pulse-symbols/:symbol/enabled, authed GET /api/pulse/symbols). DB-driven watchlist, no hardcoded list. Test v25_47_apd022_pulse_symbols.test.ts (4).
- APD-023: server/postModerationStore.ts (flag/hide/unhide via network_posts.deleted_at soft-delete + moderation_log). Routes GET /api/admin/posts, GET /api/admin/posts/:id/moderation-log, POST /api/admin/posts/:id/moderate. Test v25_47_apd023_posts_moderation.test.ts (5).
- APD-024: server/postAttachmentsStore.ts validates MIME(png/jpeg/gif/webp/mp4/pdf)+size(≤15MB), stores via server/lib/objectStorage.ts, persists metadata to network_posts.attachments. Routes GET|POST /api/posts/:id/attachments. Test v25_47_apd024_posts_attachments.test.ts (3).
- APD-025: email rebrand. .env SMTP_USER/SMTP_FROM/SMTP_REPLY_TO → scale@capavate.com (display "Capavate"); remove scale@blueprintcatalyst.com. 6 new templates in server/emailStore.ts: collective_member_subscribed, consortium_partner_subscribed, spv_deployed, post_flagged, post_hidden, pulse_digest (21 total). Test v25_47_apd025_email_rebrand.test.ts (3).
- APD-026/027/028: BLOCKER-1/5 invitation token email+single-use redeem (round_invitations sha256 tokens, 14-day expiry); BLOCKER-2/3 new rounds Active immediately + apply-gate passes; BLOCKER-4 collective_application_fee canonical $300=30000 TRUE minor units, source /admin/platform-fees Tab2 §A, legacy /admin/application-fee deprecated to redirect, front-end dynamic. Tests: blocker1(6), blocker3(3), blocker4(4).
- APD-029: BLOCKER-6 audit_chain_health table + GET /api/admin/audit-chain-health (server/adminPlatformStore.ts); findings report build_spec or v25_47_work/findings/blocker6_audit_chain_investigation.md. Test v25_47_blocker6_audit_chain_health.test.ts (2).
- APD-030: HIGH-11 server/lib/partnerTiers.ts 5-tier taxonomy: catalyst 499/builder 999/amplifier 1499/nexus 4999/founding_member 0 (invite-only). resolvePartnerTierSlug maps legacy partner_basic/pro/enterprise→canonical. Test v25_47_high11_consortium_5tier.test.ts (4).
- APD-031: HIGH-3 collective_admin_settings table + server/collectiveAdminSettingsStore.ts + server/collectiveAdminSettingsRoutes.ts (GET|PUT /api/admin/collective-settings, public GET /api/collective/public-settings). Test v25_47_high3_collective_settings.test.ts (5).
- APD-033: HIGH-1 crmUpsertInvitedContact on round-invitation create + crmMarkInvitedRegistered on redemption in server/routes.ts; path in server/founderCrmStore.ts. Test v25_47_high1_crm_invited_tag.test.ts.
- APD-034: HIGH-2 terminal-state idempotency guards on Collective approve/reject in server/adminCollectiveRoutes.ts. Test v25_47_high2_reapprove_idempotency.test.ts.
- APD-035: HIGH-6 client/src/App.tsx add /investor/inbox → InvestorMessages wrapped in RequireAuth redirectTo="/investor/login". Test v25_47_high6_investor_inbox_route.test.ts.
- APD-036: HIGH-10 GET /api/admin/partners returns total:list.length (server/partnerRoutes.ts); client/src/pages/admin/Partners.tsx renders total. Test v25_47_high10_partner_count.test.ts.
- APD-038: server/lib/objectStorage.ts assertProductionStorageConfigured requires AWS_S3_BUCKET+AWS_KMS_KEY_ID+AWS_REGION AND a cred mode (explicit keys OR AWS_USE_INSTANCE_PROFILE/AWS_USE_IAM_ROLE/AWS_PROFILE); putObject re-throws in production (no FS fallback). Test v25_47_apd038_s3_failfast.test.ts (2). Add @aws-sdk/client-s3 to package.json deps.

### Client APDs
- APD-020 client: client/src/pages/consortium/ConsortiumPricing.tsx at /consortium/pricing (App.tsx), PUBLIC no-auth, 5 tier cards DB-driven from GET /api/consortium/pricing. Canonical primitives.
- APD-022 client: client/src/pages/admin/PulseSymbols.tsx at /admin/pulse-symbols (CRUD).
- APD-023 client: client/src/pages/admin/PostsModeration.tsx at /admin/posts.
- APD-031 client: client/src/pages/admin/CollectiveSettings.tsx real DB-driven form (data-testid="collective-settings-form") at /admin/collective/settings AND /admin/collective-settings.
- APD-032(B)/APD-019 client: client/src/pages/collective/MembershipPage.tsx → SINGLE canonical tier card consuming GET /api/collective/member-tier ($249/mo). Preserve data-testids: collective-membership-page, current-membership-card, manage-subscription-btn, tier-card-standard, subscribe-btn-standard. CTA → existing POST /api/collective/membership/checkout (unchanged). Legacy /api/collective/membership/tiers endpoint UNTOUCHED (wrapper).
- APD-029 client: client/src/components/AuditChainP0Banner.tsx mounted in AppShell for /admin routes, DB-flag-driven from GET /api/admin/audit-chain-health.

### Version bump (do LAST, after gates pass once)
- package.json "version": "25.47.0"; .env APP_VERSION=25.47.0.

## ROUTE REGISTRATION
Every new route module must be registered in server/routes.ts (or wherever registerRoutes wires modules). Grep how adminFeeTierRoutes/collectiveRoutes/pulseStream are registered and follow the same pattern. Mount BEFORE catch-alls.

## BUILD GATES (must all pass; run from tree root)
1. TSC ≤ 611:  npx tsc --noEmit 2>&1 | grep -c "error TS"
2. AVI:  bash scripts/verify_avi_preserved.sh  (exit 0)
3. Airwallex:  npx vitest run server/__tests__/partnerFeeResolver.test.ts server/__tests__/airwallexGateway.test.ts server/__tests__/v24_2_airwallex_billing.test.ts  (45 pass)
4. Full e2e:  npx vitest run --config vitest.e2e.v2534.config.ts  (837 passed / 1 skipped / 0 failed — update any stale fee assertions to APD-028 $300=30000 per the "fix tests to match LOCKED spec" precedent, production code NOT weakened; see APD-032(A))
5. vite build:  npx vite build  (exit 0)
6. npm build:  npm run build  (exit 0)
7. Tier-6 supertests:  npx vitest run server/__tests__/v25_47_*  (all pass)
8. Subscription byte-identity:  the 5 Rule-76 files unchanged vs SACRED_SHA256.txt; Tier-1 files unchanged too.

## NOTES
- Read INSTALL_v25.47.md and CAPAVATE_SACRED_FILES.md (in tree root) for exact APD wording.
- Reuse existing stores where they already exist (consortiumFeesStore, subscriptionTierStore, adminFeeTierRoutes, collectiveRoutes, emailStore, founderCrmStore, objectStorage, spvDeploymentFee, pulseStream). EXTEND, don't duplicate.
- After each store/route, add its REAL-Express supertest before moving on.
- Keep a running log at build_spec/v25_47_rebuild_log.md.
