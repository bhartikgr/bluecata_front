# CAPAVATE v25.48 OVERRIDE Verification (GPT-5.5)

Project root verified: `/home/user/workspace/capavate_build/capavateAIzip`  
Verification time: 2026-07-02 EDT  
Instructions followed from: `/home/user/workspace/v25_48_verifier_brief.md`  
Logs saved in: `/home/user/workspace/v25_48_gpt55_verification_logs/`

## Gate results (re-run independently)

1. **TSC count** — PASS  
   Command: `npx tsc --noEmit 2>&1 | grep -c "error TS"` equivalent rerun.  
   Result: `611` exactly.  
   Log: `01_tsc_full_rerun.log`, `01_tsc_count_rerun.log`.

2. **Avi preservation** — PASS  
   Command: `bash scripts/verify_avi_preserved.sh`  
   Result: exit 0; `PASS: no Avi-preserved-edit regressions`.  
   Log: `02_avi_preserved.log`.

3. **Airwallex regression tests** — PASS  
   Command: `npx vitest run server/__tests__/partnerFeeResolver.test.ts server/__tests__/airwallexGateway.test.ts server/__tests__/v24_2_airwallex_billing.test.ts`  
   Result: 3 test files passed, 45 tests passed.  
   Log: `03_airwallex_vitest.log`.

4. **v25.48 supertests** — PASS  
   Command A: `ENABLE_DEMO_SEED=1 NODE_ENV=test npx vitest run --config vitest.e2e.v2534.config.ts server/__tests__/v25_48_*_e2e.mjs`  
   Result: 8 test files passed, 26 tests passed.  
   Command B: `ENABLE_DEMO_SEED=1 NODE_ENV=test npx vitest run server/__tests__/v25_48_data1_email_templates.test.ts`  
   Result: 1 test file passed, 4 tests passed.  
   Logs: `04_v2548_e2e_mjs.log`, `04_v2548_data1_email_templates.log`.

5. **Vite build** — PASS  
   Command: `npx vite build`  
   Result: exit 0; build completed. Warnings only: PostCSS `from` warning and large chunk warning.  
   Log: `05_vite_build.log`.

6. **Sacred byte identity** — PASS  
   Command: `sha256sum -c /home/user/workspace/sacred_baseline/SACRED_SHA256.txt`  
   Result: 39 `OK`, 0 `FAILED`.  
   Log: `06_sacred_sha256.log`.

7. **Full e2e** — PASS  
   Command: `timeout 560 env ENABLE_DEMO_SEED=1 NODE_ENV=test npx vitest run --config vitest.e2e.v2534.config.ts`  
   Result: exit 0; 150 test files passed, 1 skipped; 862 tests passed, 2 skipped. No timeout.  
   Logs: `07_full_e2e.log`, `07_full_e2e_exit.log`.

8. **Migration idempotency on DB copy** — PASS  
   Command: copied `data.db` to `/tmp/verif.db`, ran migration twice with `DATABASE_URL=file:/tmp/verif.db MIGRATIONS_DIR=./migrations`.  
   Result: first run exit 0 with 14 applied / 69 skipped; second run exit 0 with 0 applied / 83 skipped.  
   Required tables confirmed present: `subscription_docs_sent`, `investor_wired_signals`, `commit_attestations`, `email_templates`.  
   Log: `08_migration_idempotency.log`.

## Code audit findings

### Sacred integrity

- PASS: Sacred SHA check proves all 39 sacred files are byte-identical.
- Spot-check confirmed v25.48 logic is primarily in parallel route/module layers; sacred files such as `server/captableCommitStore.ts`, `server/roundCarryForwardEngine.ts`, `server/lib/bridgeRuntime.ts`, `server/lib/migrationRunner.ts`, `server/subscriptionStore.ts`, and `client/src/pages/founder/Billing.tsx` remained hash-preserved.

### Lazy `require()` audit

- PASS for the exact v25.48 new-module grep required by the brief: no `require(` found in:
  - `server/lib/bridgeEnabled.ts`
  - `server/lib/captableCommitV2548.ts`
  - `server/lib/investmentSignalsV2548.ts`
  - `server/lib/investorCrmInvitationSeed.ts`
  - `server/lib/dscPitchDeckV2548.ts`
- Additional note: the repository still contains many older lazy `require()` sites. I did not classify those as v25.48 blockers without a VCS baseline. One notable pre-existing site is `server/index.ts:337-340`, inside a v25.21-commented durable-map hydration block.

### Locked item audit

- NEW-1 founder/company gate — PASS: `server/founderCollectiveApplyStore.ts:53-68` reads canonical `subscriptionStore` read-only and fail-closes. Both founder apply paths return `403 not_active_subscriber` at `server/founderCollectiveApplyStore.ts:568-575` and `server/founderCollectiveApplyStore.ts:696-703`.
- NEW-1 investor join gate — PASS: `server/collectiveWaitlistRoutes.ts:48-67` rejects non-admin investor membership joins with `403 no_cap_table_position` unless `isOnCapTable(userId)` is true. Promote gate remains per-company at `server/collectiveWaitlistRoutes.ts:160-170`.
- DSC-1a — PASS: `server/collectiveRoutes.ts:1271-1281` accepts `isDscMember(ctx.userId)` in addition to admin/committee context for DSC compute.
- DSC-1c — PASS: `server/lib/dscPitchDeckV2548.ts:64-91` requires authenticated DSC/admin and returns an expiring signed pitch-deck link; download is also gated at `server/lib/dscPitchDeckV2548.ts:95-105`.
- CP-2a — PASS: `server/lib/partnerTiers.ts:106-164` iterates `listTiers(CONSORTIUM_SUBSCRIPTION_PREFIX)`, omits soft-deleted/absent canonical rows, and appends DB-added tiers.
- CP-2b — **FAIL / BLOCKER**: see blocker #1 below.
- DATA-1 — PASS: `server/db/connection.ts:303+` creates `email_templates`; `server/emailStore.ts:110-127` seed-loads DB rows; `server/emailStore.ts:138-169` persists admin PUTs; `server/emailStore.ts:447-467` exposes admin list/get/put routes.
- DATA-2 — **FAIL / BLOCKER**: see blocker #2 below.
- HIGH-8 — PASS: `server/lib/bridgeEnabled.ts:30-35` defaults bridge disabled in production unless explicitly enabled; `server/index.ts:322-346` gates `startBridgeWorker()`. `server/lib/bridgeRuntime.ts` is sacred and byte-preserved.
- HIGH-9 — PASS: `server/routes.ts:690-701` blocks `POST /api/admin/migration/commit` in production unless `MOCK_MIGRATION_ALLOWED=1`, before `registerMigrationRoutes(app)`. `server/lib/migrationRunner.ts` is sacred and byte-preserved.
- PF-1 — PASS: `server/routes.ts:633-663` adds read-only `GET /api/founder/captable` via exported `captableMembersForCompany`, returning a safe empty view when no company/cap-table exists.
- B1/B3/B4/B5 — PASS for DB persistence in parallel modules:
  - B1 writes `investor_crm_contacts` in `server/lib/investorCrmInvitationSeed.ts:49-80`.
  - B3 writes `subscription_docs_sent` in `server/lib/investmentSignalsV2548.ts:44-61`.
  - B4 writes `investor_wired_signals` in `server/lib/investmentSignalsV2548.ts:88-113`.
  - B5 writes `commit_attestations` before calling sacred `commitFunded` in `server/lib/captableCommitV2548.ts:76-101` and `server/lib/captableCommitV2548.ts:176-203`.

### Migration audit

- PASS: v25.48 migrations are mirrored byte-for-byte between `./migrations` and `server/db/migrations`.
- PASS: destructive-operation search found no `DROP`, destructive `ALTER`, `TRUNCATE`, or `DELETE` in v25.48 migration files.
- PASS: base CREATE statements exist in `server/db/connection.ts:262-303+` via `applyV2548Schema(db)`.

## Blockers

- **BLOCKER 1 — CP-2b advertised price is not strictly the charged price.**  
  Rule violated: verifier brief Part B CP-2b: `partnerSelfServiceRoutes subscribe uses resolveChargeTier (same advertised row)`; master spec CP-2b says advertised price must equal charged price from a single source of truth.  
  Evidence: `server/lib/partnerSelfServiceRoutes.ts:314-318` correctly uses `resolveChargeTier(tier)` when an advertised row exists, but `server/lib/partnerSelfServiceRoutes.ts:318-324` falls back to `resolvePartnerFee(pid, tier, feeKind, {})` when no advertised/live pricing row exists. That means a soft-deleted/non-advertised tier can still be charged from the legacy fee schedule instead of failing closed, violating “same advertised row” and undermining CP-2a soft-delete semantics.  
  Required fix: remove the legacy charge fallback for partner subscription tiers; if `resolveChargeTier(tier)` returns null, return a 409/not-available response.

- **BLOCKER 2 — DATA-2 `/api/companies` is not unconditionally DB-backed.**  
  Rule violated: verifier brief Part B DATA-2: `/api/companies serves DB rows not mock; empty DB → []`; master spec DATA-2 says no mock data and no in-memory canonical state.  
  Evidence: `server/routes.ts:16-24` imports `companies` from `server/mockData.ts`, and `server/routes.ts:1326-1340` uses that in-memory/mock `companies` array as the primary source, only reading `getAllCompaniesFromDb()` if the array is empty. With `ENABLE_DEMO_SEED=1` outside production, this serves mock fixture rows; even in production it relies on an in-memory array check before DB. The implementation is not DB-first/DB-only as locked.  
  Required fix: make `GET /api/companies` always read `getAllCompaniesFromDb()` for served rows; on DB read error or empty DB, return `[]` (or fail according to established API policy), never mock/in-memory fixture rows.

VERDICT: DO-NOT-SHIP
- Blocker: `server/lib/partnerSelfServiceRoutes.ts:318-324` violates CP-2b single advertised/charged source of truth by falling back to legacy fee schedule.
- Blocker: `server/routes.ts:16-24` and `server/routes.ts:1326-1340` violate DATA-2 because `/api/companies` is not unconditionally DB-backed and can serve `mockData`/in-memory rows.
