# v25.48 Build Gate Results (parent-run, post-fix)

| Gate | Required | Actual | Status |
|------|----------|--------|--------|
| 1 TSC error count | ≤ 611 (zero net-new) | 611 (identical code + per-file histogram to baseline) | ✅ |
| 2 verify_avi_preserved.sh | exit 0 | exit 0 (no home3compo hash-link regressions) | ✅ |
| 3 Airwallex + partnerFee | 45/45 | 45/45 | ✅ |
| 4 v25_48_* supertests | all pass | 9 files / 30 passed (26 e2e.mjs + 4 .test.ts) | ✅ |
| 5 vite build | exit 0 | exit 0 (built in ~12s) | ✅ |
| 6 npm run build | exit 0 | exit 0 (client + server bundle) | ✅ |
| 7 Full canonical e2e (vitest.e2e.v2534.config.ts) | 0 failed | 150 files passed / 1 skipped · 862 tests passed / 2 skipped / 0 failed | ✅ |
| 8 Sacred + Rule-76 byte-identity | 39/39 | 39/39 OK, 0 FAILED | ✅ |
| 9 Migration vs live data.db copy | applies + idempotent | 0068–0081 apply exit 0; re-apply exit 0 (0 applied); 4 new tables exist; email_templates seeds 21 rows on boot (prod) | ✅ |

## Pre-existing tests fixed for the NEW-1 gate (production code NOT weakened)
Per the locked spec: the NEW-1 active-paid-subscriber gate on the founder apply
routes broke two pre-existing suites whose founder personas were not subscribers.
Both were fixed to SEED an active paid subscription (subscriptionStore
recordPendingSubscription + activateByPaymentIntent), never by weakening the gate:
1. `v25_41_founder_apply_chapter_resolution_e2e.mjs` — seed active sub per company in beforeAll.
2. `v25_35_persistence_integrity_e2e.mjs` — seed active sub inside seedFounderCompany().

## New v25.48 test files
- server/__tests__/v25_48_helpers.mjs (shared harness)
- server/__tests__/v25_48_new1_collective_eligibility_e2e.mjs (5)
- server/__tests__/v25_48_dsc1a_compute_gate_e2e.mjs (3)
- server/__tests__/v25_48_cp2a_dynamic_pricing_e2e.mjs (4)
- server/__tests__/v25_48_data1_email_templates.test.ts (4)
- server/__tests__/v25_48_data2_no_mock_e2e.mjs (2)
- server/__tests__/v25_48_high9_migration_lockdown_e2e.mjs (3)
- server/__tests__/v25_48_pf1_founder_captable_e2e.mjs (3)
- server/__tests__/v25_48_b1_investor_crm_seed_e2e.mjs (2)
- server/__tests__/v25_48_b3_b4_b5_investment_e2e.mjs (4)
