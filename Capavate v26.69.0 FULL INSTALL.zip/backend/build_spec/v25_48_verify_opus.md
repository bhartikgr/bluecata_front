# v25.48 Independent Verification Report (Opus 4.8)

**Verifier:** Independent Opus 4.8 subagent — re-ran every gate and audited the actual code. No prior claims trusted.
**Project root:** `/home/user/workspace/capavate_build/capavateAIzip`
**Baseline:** v25.47.0 · Baseline TSC error count: 611 · Sacred set: 39 files
**Date of verification:** 2026-07-01/02
**Deps:** already installed (npm install NOT run, per instructions)

---

## Part A — Gates (all re-run from project root)

| # | Gate | Requirement | Result | Status |
|---|------|-------------|--------|--------|
| 1 | TSC `npx tsc --noEmit \| grep -c "error TS"` | exactly 611 | **611** | ✅ PASS |
| 2 | `bash scripts/verify_avi_preserved.sh` | exit 0 | `PASS: no Avi-preserved-edit regressions`, exit 0 | ✅ PASS |
| 3 | Airwallex tests (partnerFeeResolver + airwallexGateway + v24_2_airwallex_billing) | 45 passed | **3 files, 45 tests passed**, exit 0 | ✅ PASS |
| 4 | v25.48 supertests (`v25_48_*_e2e.mjs`) + `v25_48_data1_email_templates.test.ts` | all pass | **8 e2e files / 26 tests** + **1 file / 4 tests** = 30 tests, all pass | ✅ PASS |
| 5 | `npx vite build` | exit 0 | `✓ built in 26.25s`, exit 0 | ✅ PASS |
| 6 | `sha256sum -c SACRED_SHA256.txt` | 39 OK, 0 FAILED | **39 OK, 0 FAILED** | ✅ PASS |
| 7 | Full e2e (`vitest.e2e.v2534.config.ts`) | 0 failed | **150 files passed / 1 skipped; 862 tests passed / 2 skipped; 0 failed**, exit 0 | ✅ PASS |
| 8 | Migration idempotency on COPY of live DB + tables exist | run1 exit 0; run2 exit 0 & 0 applied; 4 tables exist | Run1: 14 applied exit 0. Run2: **0 applied, 83 skipped, exit 0**. All 4 tables present. | ✅ PASS |

### Gate detail notes
- **TSC (611):** Total error count equals baseline exactly → **zero net-new errors**. The 5 NEW v25.48 modules (`bridgeEnabled.ts`, `captableCommitV2548.ts`, `investmentSignalsV2548.ts`, `investorCrmInvitationSeed.ts`, `dscPitchDeckV2548.ts`) contribute **0** TSC errors. Pre-existing-pattern errors in `collectiveRoutes.ts` / `emailStore.ts` / `founderCollectiveApplyStore.ts` (`string | string[]`, `req.session` on Express Request) are of the same class as the codebase-wide baseline and are subsumed by the 611 total. Since total == 611, net-new == 0.
- **Full e2e:** Every string matching `failed`/`FAIL` in the log was either a deliberate fail-closed *test name* (e.g. "returns 500 … exposes NO token") or an *injected-failure* error log inside a passing test. The vitest summary line confirms **0 failed**.
- **Migration idempotency:** Second run reported `All migrations already applied (0 applied, 83 skipped)`, exit 0. Tables `subscription_docs_sent`, `investor_wired_signals`, `commit_attestations`, `email_templates` all confirmed present in `/tmp/verif.db`.

---

## Part B — Code Audit (read the actual code)

### SACRED INTEGRITY ✅
- `sha256sum -c` = **39 OK / 0 FAILED**. All Tier-1 sacred files byte-identical, including the B1/B2/B5-relevant ones: `captableCommitStore.ts`, `roundCarryForwardEngine.ts`, `investorCrmStore.ts`, `bridgeRuntime.ts`, `migrationRunner.ts`, `userContext.ts`, `subscriptionStore.ts`, `capTableMembership.ts`, `Billing.tsx`, all `home3compo/*`.
- Spot-checked: all v25.48 changes live in **parallel modules** (`server/lib/*V2548.ts`, `bridgeEnabled.ts`) or **route/store layers** (`routes.ts`, `founderCollectiveApplyStore.ts`, `collectiveWaitlistRoutes.ts`, `collectiveRoutes.ts`, `emailStore.ts`, `partnerTiers.ts`, `partnerSelfServiceRoutes.ts`, `index.ts`) — never inside a sacred file. Sacred functions are **called** (e.g. `commitFunded()`, `listMembersForCompany()`), never edited.

### LIVE-CORRECTNESS — no NEW lazy `require()` ✅
- Grepped the 5 new modules: **zero** `require()`.
- `partnerSelfServiceRoutes.ts:31` — the only `require`-related line is a **comment** documenting that a prior lazy require was replaced by a static ESM import.
- All other `require()` occurrences in changed files (`routes.ts` lines 2101/2123/2186/2188/3374/4162/4169/4263; `index.ts:339`) carry pre-existing version markers (v25.11, v25.21, Patch v8, etc.) — **none are net-new in v25.48**. The v25.48 route hooks (PF-1, DATA-2, HIGH-9, B1, module registrations) all use **static imports** (`import { listMembersForCompany as captableMembersForCompany }`, `import { seedInvestorCrmFromInvitation }`, etc.).
- Dynamic `await import()` (allowed) is used in `dscPitchDeckV2548.ts` and DATA-2's `/api/companies/:id` — permitted per rules.

### DB-DRIVEN / NO IN-MEMORY CANONICAL ✅
- **Email templates:** `findTemplate` is DB-first (reads hydrated `templateCache` sourced from `email_templates`); `upsertTemplate` persists via `INSERT … ON CONFLICT(slug) DO UPDATE` to `email_templates`; `seedAndLoadTemplatesFromDb()` runs in `hydrateEmailStore()` on boot (INSERT OR IGNORE — never clobbers admin edits). `templateCache` is an explicitly-documented **DB-first read cache, not canonical state**.
- **B3/B4/B5/B1** all write to their DB tables (`subscription_docs_sent`, `investor_wired_signals`, `commit_attestations`, `investor_crm_contacts`) via `rawDb()`.
- No new module holds canonical state in memory. The only arrays in the new modules (`committed`/`failed`/`entries` in `captableCommitV2548.ts`) are **request-scoped locals** inside a route handler. No module-level `new Map`/`new Set` canonical stores.

### LOCKED ITEMS — implemented + SERVER-ENFORCED ✅

- **NEW-1 (company gate):** `founderCollectiveApplyStore.ts` — `isActivePaidCapavateSubscriber()` reads sacred `subscriptionStore.listForCompany` READ-ONLY, fail-closed (any error/absence → false). Enforced on **both** apply routes: `POST /api/founder/collective/nominations` (line ~567) and `POST /api/founder/collective/applications` (line ~694), each returning **403 `not_active_subscriber`**. ✅
- **NEW-1 (investor gate):** `collectiveWaitlistRoutes.ts` — `POST /api/collective/waitlist/investor-membership` requires `isOnCapTable(userId)` (any active position, ledger-derived via `mergedMembership`), fail-closed **403 `no_cap_table_position`**, admin bypass. ✅
- **NEW-1 (promote gate unchanged):** `POST /api/collective/waitlist/cap-table-promote` keeps per-company `isOnCapTable(userId, companyId)` → 403 `not_on_cap_table`. Matches spec (keep as-is). ✅
- **DSC-1a:** `collectiveRoutes.ts` `POST /api/collective/dsc/compute/:companyId` now accepts `isGrantedDscMember = isDscMember(ctx.userId)` (from `adminDscRoutes`) in addition to admin/committee; 401 if no ctx, 403 if none of admin/committee/DSC. `userContext.ts` unchanged (sacred). ✅
- **DSC-1c:** `dscPitchDeckV2548.ts` `GET /api/collective/dsc/pitch-deck/:companyId` gated by `isDscOrAdmin` (`isDscMember` or admin), returns a short-lived (10-min) HMAC-**signed** download link; download endpoint re-verifies session + constant-time HMAC + expiry before streaming via `objectStorage.getObject`. Registered in `routes.ts:852`. ✅
- **CP-2a:** `partnerTiers.ts` `resolveConsortiumPricing()` iterates `listTiers()` (DB) — canonical soft-deleted tiers omitted (`if (!row) continue`), admin-added tiers appended; falls back to seed only when DB has zero live tiers. ✅
- **CP-2b:** `partnerSelfServiceRoutes.ts` `POST /api/partner/me/subscribe` charges via `resolveChargeTier(tier)` = the SAME row `resolveConsortiumPricing()` advertises; fails closed (409) when tier not live, with a legacy fee-schedule fallback for configured-but-unadvertised tiers. ✅
- **DATA-1:** `email_templates` table (migration 0081 + connection.ts) + admin `GET /api/admin/email/templates` (list), `GET …/:slug`, `PUT …/:slug` (persist) — all under the blanket `app.use("/api/admin", requireAdmin)` guard (routes.ts:410/830, before `registerEmailRoutes` at 703). Seed-on-boot via `hydrateEmailStore`. ✅
- **DATA-2:** `/api/companies` reads `getAllCompaniesFromDb()`; empty DB → `[]` (never mock). Verified by `v25_48_data2_no_mock_e2e.mjs` (passing). ✅
- **HIGH-8:** `bridgeEnabled.ts` `isBridgeEnabled()` defaults **OFF in production** (unset → `NODE_ENV !== 'production'`); `index.ts:322/344` gates `startBridgeWorker()` behind `isBridgeEnabled()`. `bridgeRuntime.ts` NOT edited (sacred, byte-identical). `.env`/`.env.example` set `BRIDGE_ENABLED=false`. ✅
- **HIGH-9:** `routes.ts:691` — `app.post("/api/admin/migration/commit", …)` guard mounted **before** `registerMigrationRoutes(app)` (line 701); in production returns **403 `mock_migration_disabled_in_production`** unless `MOCK_MIGRATION_ALLOWED=1`. Path matches the runner's exact route. `migrationRunner.ts` NOT edited (sacred). ✅
- **PF-1:** `routes.ts:633` `GET /api/founder/captable` — read-only via exported `captableMembersForCompany` (`listMembersForCompany` from `captableCommitStore`); ownership-checked (401/403); empty company → safe empty view (never undefined). Sacred store not modified. ✅
- **B1–B5:** All in parallel modules (`captableCommitV2548.ts`, `investmentSignalsV2548.ts`, `investorCrmInvitationSeed.ts`); `captableCommitStore.ts` and `roundCarryForwardEngine.ts` NOT edited (byte-identical). B5 attestation is fail-closed (422 if `attested !== true`; attestation row written BEFORE the sacred `commitFunded()` call; entry skipped if attestation write fails). B4 explicitly advisory (does not move the cap table). ✅

### MIGRATIONS ✅
- **Additive-only:** all 4 files use `CREATE TABLE/INDEX IF NOT EXISTS`; destructive-statement scan (DROP/DELETE/TRUNCATE/ALTER-drop/rename) = **none found**.
- **Mirrored:** `diff` of `./migrations/007[89]*,008[01]*` vs `server/db/migrations/…` = **IDENTICAL** for all 4.
- **Base CREATE present:** `connection.ts` `applyV2548Schema(db)` (called line 248, defined line 262) contains all 4 `CREATE TABLE IF NOT EXISTS` + indexes matching the migration column definitions exactly.

### Test-fix integrity ✅
- `v25_41_founder_apply_chapter_resolution_e2e.mjs` and `v25_35_persistence_integrity_e2e.mjs` were fixed by **seeding an active paid subscription** through the canonical `subscriptionStore` (`recordPendingSubscription` + `activateByPaymentIntent`) — NOT by weakening the NEW-1 gate code.

---

## Blockers
None.

## Summary
All 8 gates pass (TSC exactly 611 / zero net-new; sacred 39 OK / 0 FAILED; Airwallex 45; v25.48 30 tests; vite build clean; full e2e 862 passed / 0 failed; migrations idempotent + all tables present). No sacred-file edit, no net-new TSC error, no new lazy `require()`, no in-memory canonical state, and every locked item is server-enforced and DB-driven. Migrations are additive-only, mirrored in both directories, and mirrored in `connection.ts`.

VERDICT: SHIP
