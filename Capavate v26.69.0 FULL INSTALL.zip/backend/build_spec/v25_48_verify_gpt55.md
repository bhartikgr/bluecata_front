# CAPAVATE v25.48 Re-verification (GPT-5.5 override)

Project root: `/home/user/workspace/capavate_build/capavateAIzip`
Run time: 2026-07-02 03:00-03:04 UTC

## Direct code audit

### Prior blocker 1: CP-2b partner subscribe advertised == charged

Reviewed `server/lib/partnerSelfServiceRoutes.ts` around the partner subscribe route.

Findings:
- The import at line 31 imports only `resolveChargeTier` from `./partnerTiers`; there is no executable `resolvePartnerFee` import.
- `POST /api/partner/me/subscribe` reads `tier` from `req.partnerContext`, computes `cycle`, then calls `resolveChargeTier(tier)` at line 311.
- If `resolveChargeTier(tier)` returns null/undefined, the route returns HTTP 409 with `error: "PARTNER_SUBSCRIPTION_NOT_AVAILABLE"` at lines 312-316.
- The charged amount is derived only from the advertised tier row: monthly uses `advertised.amountMinor`; annual uses `advertised.amountMinor * 12` at line 318.
- The response reports `computedVia: "consortium_pricing_advertised"` at line 319.
- After stripping comments, `server/lib/partnerSelfServiceRoutes.ts` contains 0 `resolvePartnerFee` references and 0 `partner_fee_schedules` references.

Conclusion: CP-2b is resolved. The legacy partner fee schedule is not an executable fallback for partner subscription charges; the route fails closed when the advertised charge tier is unavailable.

Evidence saved:
- `/home/user/workspace/verify_gpt55_round2_partnerSelfServiceRoutes_snippet.txt`

### Prior blocker 2: DATA-2 GET /api/companies no mock primary source

Reviewed `server/routes.ts` around `GET /api/companies`.

Findings:
- The route initializes `source` as `[]` at line 1324.
- The route unconditionally calls `getAllCompaniesFromDb()` at line 1326.
- It maps DB rows to the served shape at lines 1327-1333.
- On DB read error, it sets `source = []` at lines 1334-1335.
- Admin responses return only `source`; non-admin responses filter only `source` by allowed company IDs at lines 1337-1341.
- The route does not reference the in-memory/mock `companies` array or `getAllCompanies()`.

Conclusion: DATA-2 is resolved. `GET /api/companies` no longer serves the mock/in-memory company list as a source; empty DB and DB errors both return an empty source.

Evidence saved:
- `/home/user/workspace/verify_gpt55_round2_routes_companies_snippet.txt`

## Required regression gates

1. `npx tsc --noEmit 2>&1 | grep -c "error TS"`
   - Result: `611`
   - Status: PASS

2. `sha256sum -c /home/user/workspace/sacred_baseline/SACRED_SHA256.txt`
   - Result: 39 `OK`, 0 `FAILED`
   - Status: PASS

3. `bash scripts/verify_avi_preserved.sh`
   - Result: `PASS: no Avi-preserved-edit regressions`
   - Status: PASS

4. Targeted v25.48 tests:
   - Command: `ENABLE_DEMO_SEED=1 NODE_ENV=test npx vitest run --config vitest.e2e.v2534.config.ts server/__tests__/v25_48_cp2a_dynamic_pricing_e2e.mjs server/__tests__/v25_48_data2_no_mock_e2e.mjs`
   - Result: 2 test files passed; 6 tests passed; 0 failed
   - Status: PASS

5. Full e2e:
   - Command: `timeout 560 env ENABLE_DEMO_SEED=1 NODE_ENV=test npx vitest run --config vitest.e2e.v2534.config.ts`
   - Result: 150 test files passed, 1 skipped; 862 tests passed, 2 skipped; 0 failed; exit status 0
   - Status: PASS
   - Full log saved to `/home/user/workspace/verify_gpt55_round2_full_e2e.log`

## Remaining blockers

None.

VERDICT: SHIP
