# BLOCKER-6 — Audit-chain continuity investigation (APD-029)

## Summary
The admin audit log (`audit_log`, surfaced via `adminPlatformStore.appendAdminAudit`)
is hash-chained per tenant. A P0 finding flagged a continuity gap for the
`tenant_admin_capavate` chain: entries existed whose `prev_hash` linkage could
not be re-derived end-to-end, meaning a verifier walking the chain would detect
a break rather than a clean tip.

This is recorded as an **incident** rather than silently repaired, because
rewriting historical audit rows to "fix" the chain would itself destroy the
evidentiary value of the log. The continuity state is therefore exposed as a
first-class, DB-driven health signal that the admin shell renders as a banner.

## What was added (v25.47)
- Table `audit_chain_health (key, status, detail, updated_at)` — additive,
  created in both the numbered migration `0070_v25_47_audit_chain_health.sql`
  and the `server/db/connection.ts` bootstrap (CREATE TABLE IF NOT EXISTS).
- Seed row (`INSERT OR IGNORE`): `key='tenant_admin_capavate'`,
  `status='incident'` — the documented P0 continuity gap.
- Read path `getAuditChainHealth()` in `server/adminPlatformStore.ts`:
  returns every row plus an `incident` boolean (`true` when any row's status is
  not `ok`).
- Route `GET /api/admin/audit-chain-health` (router-level `requireAdmin`).
- Client banner `AuditChainP0Banner.tsx` mounted in the admin shell, shown only
  when `incident === true`.

## Why a flag, not a fix
- The audit log is append-only and hash-chained; back-filling/rewriting rows to
  produce a clean chain would be indistinguishable from tampering.
- The correct remediation is forward-only: from the recorded tip, every new
  entry chains cleanly. The `incident` row documents the historical boundary so
  operators know where pre-incident entries cannot be cryptographically trusted.

## Clearing the incident
An operator (or a future migration) sets the row's `status` to `ok` once the
continuity boundary has been acknowledged and forward-chaining is verified:

```sql
UPDATE audit_chain_health
   SET status = 'ok', detail = 'continuity boundary acknowledged', updated_at = datetime('now')
 WHERE key = 'tenant_admin_capavate';
```

After that, `GET /api/admin/audit-chain-health` reports `incident: false` and the
banner disappears.
