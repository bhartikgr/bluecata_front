import Database from "better-sqlite3";
import {
  computeManifestHash,
  deriveCurrency,
  generateTableManifest,
  isValidCurrencyCode,
  LEGACY_MONEY_COLUMNS,
  LEGACY_PARENT_SPV_FK,
  LEGACY_SOURCE_TABLES,
  type DryRunManifest,
} from "./server/lib/wave0Migration";

function clone<T>(v: T): T {
  return structuredClone(v);
}

const base: DryRunManifest = {
  generatedAtIso: "2026-08-02T00:00:00.000Z",
  wave0Version: "0-4-v4",
  manifestHash: "",
  tables: [
    {
      table: "spvs",
      rowCount: 1,
      perCurrencyMinorSum: { USD: "1", EUR: "2" },
      missingCurrencyRowCount: 0,
      unmigrated: null,
    },
  ],
  missingCurrency: {
    legacy: [],
    canonical: [
      { spvId: "same", legacyId: "legacy-a", defaultSite: "spvEngineStore.ts:1649" },
      { spvId: "same", legacyId: "legacy-b", defaultSite: "spvEngineStore.ts:1684" },
    ],
  },
  ambiguousMatches: [
    {
      sourceTable: "spvs",
      sourceRowId: "l1",
      candidateCanonicalIds: ["c1", "c2"],
      reason: "r",
    },
  ],
  duplicates: [
    {
      table: "spv_positions",
      key: { spv_id: "s", security_id: "x" },
      rowIds: ["r1", "r2"],
      count: 2,
    },
  ],
  orphanChildRows: [],
  deferrals: ["D1", "D2"],
};

function sameHash(label: string, mutate: (m: DryRunManifest) => void) {
  const other = clone(base);
  mutate(other);
  return {
    label,
    equal: computeManifestHash(base) === computeManifestHash(other),
    left: computeManifestHash(base),
    right: computeManifestHash(other),
  };
}

const hashResults = [
  sameHash("nested object key order", (m) => {
    m.tables[0].perCurrencyMinorSum = { EUR: "2", USD: "1" };
  }),
  sameHash("candidateCanonicalIds order", (m) => {
    m.ambiguousMatches[0].candidateCanonicalIds.reverse();
  }),
  sameHash("duplicate rowIds order", (m) => {
    m.duplicates[0].rowIds.reverse();
  }),
  sameHash("top-level tie order", (m) => {
    m.missingCurrency.canonical.reverse();
  }),
  sameHash("deferrals order", (m) => {
    (m.deferrals as string[]).reverse();
  }),
];

const invalidCurrencyDb = new Database(":memory:");
invalidCurrencyDb.exec(`
  CREATE TABLE spvs (
    id TEXT PRIMARY KEY,
    currency TEXT,
    target_minor INTEGER,
    committed_minor INTEGER,
    called_minor INTEGER,
    distributed_minor INTEGER
  );
  CREATE TABLE currency_ref (code TEXT PRIMARY KEY, is_active INTEGER);
  INSERT INTO currency_ref VALUES ('USD', 1);
  INSERT INTO spvs VALUES ('bad-currency', 'Dollars', 1, 0, 0, 0);
`);
const invalidCurrencyManifest = generateTableManifest(invalidCurrencyDb, "spvs");
const invalidCurrencyProbe = {
  manifest: invalidCurrencyManifest,
  helperSaysValid: isValidCurrencyCode(invalidCurrencyDb, "Dollars"),
};

const db = new Database(":memory:");
db.exec(`
  CREATE TABLE secrets (id TEXT PRIMARY KEY, currency TEXT);
  INSERT INTO secrets VALUES ('secret-row', 'ZZZ');
`);

const mutableTables = LEGACY_SOURCE_TABLES as unknown as string[];
mutableTables.push("secrets");
(LEGACY_PARENT_SPV_FK as unknown as Record<string, string | null>).secrets = null;
(LEGACY_MONEY_COLUMNS as unknown as Record<string, readonly string[]>).secrets = [];

let injectedRead: unknown;
try {
  injectedRead = deriveCurrency(
    db,
    "secrets" as unknown as (typeof LEGACY_SOURCE_TABLES)[number],
    "secret-row",
  );
} catch (error) {
  injectedRead = { error: String(error) };
}

console.log(JSON.stringify({ hashResults, invalidCurrencyProbe, injectedRead }, null, 2));
