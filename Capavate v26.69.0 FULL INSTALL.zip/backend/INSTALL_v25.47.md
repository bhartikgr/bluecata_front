# Capavate v25.47 Install — for Avi

**Release:** 25.47.0
**Date:** Mon Jun 29, 2026
**Triple-verified:** Opus 4.8 ✅ · Gemini 3 Pro ✅ · GPT-5.5 ✅ (after blocker-fix pass)

---

## v25.47 Scope — 6 Blockers Fixed + 12 Tracks Landed

### 🔴 Blockers (all fixed, all live-verifiable)
- **BLOCKER-1/5** — Workspace invitation email now includes the token in CTA. Server-reflected expiry. Redeem flow works end-to-end. (APD-026)
- **BLOCKER-2/3** — Newly-created rounds become Active immediately on wizard completion. Apply-to-Collective gate now passes when a round exists. (APD-027)
- **BLOCKER-4** — Collective Application Fee source-of-truth = `/admin/platform-fees` Tab 2 §A. Canonical $300 (30000 minor units), 100% DB-driven. Legacy `/admin/application-fee` page deprecated to read-only redirect. Front-end renders dynamic value (zero hardcoded strings). (APD-028)
- **BLOCKER-6** — Audit hash-chain investigation report saved (`v25_47_work/findings/blocker6_audit_chain_investigation.md`). Global P0 banner across all admin pages, DB-flag-driven. (APD-029)

### Primary tracks
- **P1 Collective Member Subscription** — `/collective/membership` SINGLE-tier card (per locked simplification). DB-driven price from `platform_fees.collective.member_subscription.standard`. Schema future-proofed with `region`/`chapter` columns (additive, NULL = global). Legacy basic/pro/enterprise rows deprecated in code but preserved in DB (backward compat). (APD-019, APD-019.1)
- **P2 Consortium Partner Subscription** — `/consortium/pricing` PUBLIC page (no auth redirect). 5 tier cards: catalyst / builder / amplifier / nexus / founding_member. All DB-driven from `platform_fees.consortium.subscription.*`. (APD-020)
- **P3 SPV Deployment Fee** — Wired into SPV creation flow. Flat fee from `platform_fees.consortium.spv_deployment_fee` ($5,000 admin-editable). New `spv_deployments` table. (APD-021)

### Secondary
- **Pulse + Market Ticker** — `/api/pulse/stream` SSE multiplexes milestone events + market quotes (3600s refresh per locked spec). 10-symbol institutional set seeded (SPY/QQQ/DIA/IWM/XLK/XLF/BTC-USD/ETH-USD/VIX/USD-EUR). `/admin/pulse-symbols` CRUD page. Ticker UI on dashboard. (APD-022)

### Tertiary
- **T1 Posts Moderation** — `/admin/posts` page with flag/hide/remove/restore. `moderation_log` table. Audit-log integration. (APD-023)
- **T2 Posts Media Uploads** — Image (JPG/PNG/WebP up to 10MB) + PDF (up to 25MB) via S3+KMS. `network_posts.attachments` JSONB column. (APD-024)
- **T3 Collective UX** — HIGH-3 Collective Settings page built with all 8 categories (eligibility, SLA, cohort timing, DSC quorum, tie-break, status vocabulary, decision options, fee copy). (APD-031)
- **T4 Email Rebrand** — Sender changed from `scale@blueprintcatalyst.com` → `scale@capavate.com`. All templates refreshed to canonical LookFeel. 6 new templates added (collective_member_subscribed, consortium_partner_subscribed, spv_deployed, post_flagged, post_hidden, pulse_digest). (APD-025)

### Structural
- **HIGH-11 Tier Taxonomy** — Canonical 5-tier set: catalyst / builder / amplifier / nexus / founding_member. `server/lib/partnerTiers.ts` exports `ConsortiumPartnerTier` enum. Migration 0071 expands `platform_fees` consortium subscription rows from 3 → 5. (APD-030)

### Verifier-found blocker fixes
- 3 stale e2e tests updated to assert LOCKED APD-028 spec values (production code NOT weakened). Single-tier UI wired to client `MembershipPage.tsx`. (APD-032)

### HIGH-track fixes that ARE shipping in v25.47 (re-classified from deferred)
A GPT-5.5 live-deploy verification found these four HIGH items already have live v25.47 code; release docs are corrected to list them as shipped, with APDs registered.
- **HIGH-1 CRM auto-tag invited investors** — server-side persistence: `crmUpsertInvitedContact(...)` on round-invitation create (`server/routes.ts:2503-2517`) + `crmMarkInvitedRegistered(...)` on redemption (`server/routes.ts:2324-2331, 2367-2372`); auto-tag path in `server/founderCrmStore.ts:637-725`. Migration `0069_v25_47_high1_founder_crm_invite.sql`. (APD-033)
- **HIGH-2 Re-approve idempotency** — terminal-state guards on Collective application approve/reject (`server/adminCollectiveRoutes.ts:293-315, 378-392, 464-480, 555-565`). Re-approving an already-terminal app is now idempotent (no double side-effects). (APD-034)
- **HIGH-6 /investor/inbox portal guard** — additive route in `client/src/App.tsx:648-655`; previously fell through to the founder login (wrong portal). Now guarded with the investor `redirectTo`. (APD-035)
- **HIGH-10 /admin/partners count bug** — `server/partnerRoutes.ts:86` now returns `total`, and `client/src/pages/admin/Partners.tsx:104` renders it, fixing the "Partners (0)" header. (APD-036)

---

## Deferred to v25.48 (no blockers in v25.47)
- HIGH-4 DSC review modal completeness
- HIGH-5 Pitch deck clickable + safe links
- HIGH-7 Campaign create 404s
- HIGH-8 Bridge/Sync 501 dead letters
- HIGH-9 Mock migration mode lockdown
- 20 mock-data → DB migrations (Section E of master bug list)
- 17 remaining broken links / 404s (1 of 18 fixed in v25.47)
- 15 admin↔front-end reflection gaps

_(HIGH-1, HIGH-2, HIGH-6, HIGH-10 were moved OUT of this list — they ship in v25.47; see APD-033–036 above.)_

---

## Sacred Files — now 10 tiers, 77 rules, APD-001…036

17 new APDs registered in this release: APD-019 through APD-036 (APD-019 + APD-019.1 cover the single-tier Collective decision; APD-033–036 cover the four HIGH-track fixes re-classified from deferred to shipped after the GPT-5.5 live-deploy verification).

---

## Build Gates — all 8 GREEN (post blocker-fix)

| Gate | Required | Actual |
|------|----------|--------|
| TSC error count | ≤ 611 | **611** |
| AVI Tier-2 byte-identity | exit 0 | **exit 0** (12 Tier-2 files IDENTICAL) |
| Airwallex+partnerFee guard | 45/45 | **45/45** |
| Full canonical e2e (143-file) | 837 passed / 0 failed | **837 passed / 1 skipped / 0 failed** |
| vite build | exit 0 | **exit 0** |
| npm build | exit 0 | **exit 0** |
| Tier 6 supertest (v25.47 routes) | full coverage | **59/59 across 15 v25.47 files** |
| Founder/investor subscription byte-identity | 5/5 match v25.45.4 | **5/5 match** (Sacred Rule 76) |

---

## Migrations (additive only)
- `0069_v25_47_*` through `0077_v25_47_*` — 9 new migrations covering: HIGH-1 founder CRM invite, audit_chain_health flag, Collective Settings, partner tier expansion (3→5), member subscription region/chapter columns, SPV deployments, pulse_index_symbols, moderation_log, post attachments.
- All forward-compatible.
- The deploy script runs `npm run db:migrate` (the real script — `tsx server/db/migrate.ts`) and **aborts the deploy (non-zero exit) if any migration fails** — there is no silent `|| true` fallback. After migrating it verifies that `0069`–`0077` are all present in the applied set and fails the deploy if any are missing. The runner scans both `./migrations` and `server/db/migrations` so the v25.47 files are picked up automatically.

---

## Required Production Environment Variables (NEW in v25.47)
For T2 Posts Media Uploads (S3+KMS).

**Always required (both credential modes):**
- `AWS_S3_BUCKET` — name of the S3 bucket for post attachments
- `AWS_KMS_KEY_ID` — KMS key ID for encryption-at-rest
- `AWS_REGION` — AWS region (e.g. us-east-1)

**PLUS exactly one AWS credential mode:**

- **Mode 1 — Explicit keys (simpler):**
  - `AWS_ACCESS_KEY_ID` — IAM access key with `s3:PutObject` + `kms:Encrypt` permissions
  - `AWS_SECRET_ACCESS_KEY` — corresponding secret key
- **Mode 2 — IAM role / instance profile (recommended for EC2/ECS/EKS):**
  - `AWS_USE_INSTANCE_PROFILE=true` — opt in to the AWS SDK's default credential-provider chain (instance/task role). No explicit keys needed. (Legacy `AWS_USE_IAM_ROLE=true` or a non-empty `AWS_PROFILE` are also accepted as Mode 2 opt-ins.)

Either mode is acceptable. Summary of required vars: `AWS_S3_BUCKET`, `AWS_KMS_KEY_ID`, `AWS_REGION` **AND EITHER** (`AWS_ACCESS_KEY_ID` + `AWS_SECRET_ACCESS_KEY`) **OR** `AWS_USE_INSTANCE_PROFILE=true`.

If these are NOT set, post media uploads fall back to the local filesystem (DEV ONLY, NOT production-safe).

**Production fail-fast (v25.47, tightened APD-038):** when `NODE_ENV=production`, the posts media-upload path:
1. Throws a clear startup-time error if any of `AWS_S3_BUCKET` / `AWS_KMS_KEY_ID` / `AWS_REGION` is missing **OR if NEITHER credential mode is configured** (no explicit keys and no instance-profile opt-in). The error lists exactly which requirement(s) are missing.
2. If an S3 `putObject` still fails at runtime (e.g. credentials the SDK cannot resolve), it **re-throws and refuses to fall back to the local filesystem** — production never silently writes unencrypted bytes to disk.

The `@aws-sdk/client-s3` dependency is declared in `package.json` (installed by `npm ci`).

---

## Deploy

```bash
# Option A — full install (recommended)
unzip CAPAVATE_v25.47_FULL_INSTALL_for_Avi.zip
cd capavate_v25_45_src
bash deploy_v25_47_LIVE.sh

# Option B — patch on top of v25.46.1 tree
cd /var/www/capavate
unzip -o CAPAVATE_v25.47_PATCH_for_Avi.zip
bash deploy_v25_47_LIVE.sh
```

Script backs up `${APP_DIR}.prev`, bumps `.env APP_VERSION=25.47.0`, runs `npm ci`, runs migrations 0064–0077 (all additive), builds, restarts, smoke-checks `https://capavate.com/api/health` reports `25.47.0`. Hard sign-off:

```
✓✓✓ v25.47.0 IS LIVE — deploy verified ✓✓✓
```

---

## Live Re-Verification Plan (Ozan drives after deploy)

Per Sacred Tier 4 #39 + Tier 6 #49:

1. **Sacred Rule 76 verification** — Founder login `ozan.isinak@gmail.com` → confirm Capavate founder subscription path still works exactly as before (byte-identical to v25.45.4)
2. **Path B Collective application** — `/founder/apply-to-collective` → confirm round-detection works, dynamic $300 fee renders correctly
3. **BLOCKER-1 invitation flow** — Send invitation to `ozan@capavate.com` from Investor CRM → confirm email contains token → click → redeem succeeds → land on investor dashboard
4. **End-to-end commit** — As investor `ozan@capavate.com`, submit a **$25,000 soft-circle commitment** → confirm investor-side commit flow works
5. **Admin verifications** — `/admin/platform-fees` 3-tab UI / `/admin/collective-settings` (new) / `/admin/pulse-symbols` (new) / `/admin/posts` (new)
6. **New user surfaces** — `/collective/membership` (single tier) / `/consortium/pricing` (5 tiers)

---

## Files in this bundle

| File | Purpose |
|------|---------|
| `CAPAVATE_v25.47_FULL_INSTALL_for_Avi.zip` | Full tree — 7.5 MB |
| `CAPAVATE_v25.47_PATCH_for_Avi.zip` | Delta vs v25.43 — 2.3 MB / 332 files |
| `deploy_v25_47_LIVE.sh` | Single-command deploy + smoke check |
| `CAPAVATE_SACRED_FILES.md` | 10 tiers / 77 rules / 36 APDs — current truth |
| `INSTALL_v25.47.md` | This document |
| `email_to_avi_v25_47.md` | Paste-ready Avi email |
| `whatsapp_v25_47.txt` | Paste-ready WhatsApp drop |

Ping me when deploy reports `✓✓✓ v25.47.0 IS LIVE`. I'll drive the 6-step live walkthrough immediately after.

— Capavate platform team

---

## v25.47 REBUILD ADDENDUM (2026-06-30) — live-server alignment + caught blockers

This rebuild was reconstructed from Avi's v25.46.1 live-site zip. During the rebuild, triple-verify (Opus 4.8 + Gemini 3.1 Pro + GPT-5.5) caught and fixed several issues that would have broken Avi's install. All 8 gates pass; migrations verified against a copy of the real production `data.db`.

### Deploy script is now aligned to the REAL live host
The included `deploy_v25_47_LIVE.sh` was corrected to match production truth:
- `APP_DIR=/var/www/html/backend` (not `/var/www/capavate`)
- Restart via **`pm2 restart backend`** (live PM2 process is `backend`, fork mode, runs TS via `tsx` — not `dist/index.cjs`, not systemctl)
- Refreshes **`/var/www/html/frontend`** from `dist/public` after build (nginx serves the SPA from there; stale assets otherwise persist via error_page fallback)
- **Never overwrites** `.env` or `data.db`/`-shm`/`-wal` — only sed-bumps `APP_VERSION=25.47.0` in place
- Smoke-checks **both** `/api/healthz` and `/api/health` for `25.47.0`
- Does **not** grep for a `MIGRATIONS_PRESENT:` line (the sacred migration runner never emits one); the fail-closed `npm run db:migrate` is the real gate

### Migration safety (caught + fixed)
- Migration **0068** (adds `platform_fees.billing_period` + `deleted_at`) was mirrored into `./migrations` so the runner picks it up; the live applied-set stopped at 0067, so 0068–0077 now apply in order.
- `server/db/connection.ts` bootstrap now runs **guarded additive ALTERs** to add `billing_period`/`deleted_at` to a pre-existing `platform_fees` table (the live table predates those columns, so the `CREATE TABLE IF NOT EXISTS` was a no-op and the seed INSERTs would have crashed). Verified: full chain 0068–0077 applies cleanly **and idempotently** against a copy of the production `data.db`.

### ⚠️ ACTION REQUIRED before T2 Posts Media Uploads work on prod (APD-024/APD-038)
The live `.env` currently has `AWS_BUCKET=capavate-uploads` (region `ap-south-1`) and **no KMS key**. The v25.47 S3 path expects:
- `AWS_S3_BUCKET` (the v25.47 code reads this name, not `AWS_BUCKET`)
- `AWS_KMS_KEY_ID`
- `AWS_REGION`
- PLUS one credential mode: explicit `AWS_ACCESS_KEY_ID`+`AWS_SECRET_ACCESS_KEY`, OR `AWS_USE_INSTANCE_PROFILE=true`

In `NODE_ENV=production` the posts-upload path **fail-fasts** (throws, no silent local-FS fallback) if these are missing. All other v25.47 features are unaffected. Set these before exercising post attachments live.

### Final live re-verification (Ozan drives, per Sacred Tier 4 #39 / Tier 6 #49)
Sandbox triple-verify returned **READY (code) / DEFERRED-pending-live-check** — the only reason it isn't an unconditional READY is that authenticated live-site testing requires Avi's deploy + Ozan's founder credentials, which can't run in-sandbox. Run the 6-step live walkthrough above immediately after `✓✓✓ v25.47.0 IS LIVE`.
