# Independent verification brief — Capavate Wave C4 (projection tab crash)

You are an INDEPENDENT verifier. Return APPROVE or REVISE with concrete file:line
defects + fixes. Read the real files. Be adversarial; flag only REAL issues. Work
committed at HEAD — use `git diff HEAD~1`. Do NOT run `git checkout -- .` /
`git reset` / any broad checkout that discards the tree.

Build tree: `/home/user/workspace/capavate_work` (deps installed). Diff:
`WAVE_C4_SOURCE.diff`. Report: `FIX_REPORT_WAVE_C4.md`.

## Bug
On a freshly-created round (no pre-money, target $0), the "Pre / post-close
projection" tab crashed with `Cannot read properties of null (reading
'toString')` (then `Cannot convert NaN to a BigInt` once that was coerced).

## Fix (client-only, non-sacred)
1. `client/src/pages/founder/RoundDetail.tsx` `ProjectionPanel` now GATES the
   projection: `canProject = preMoney>0 && target>0` (finite). Only then calls
   `projectPostClose`; otherwise renders the pre-close cap table + a guidance
   empty-state (testids `projection-needs-terms` / `projection-gated-note`).
2. `client/src/lib/engineDemo.ts` `projectPostClose` widened its param type to
   `number | null | undefined` and coerces to a finite number before
   `.toString()` (defense in depth; the raw null.toString crash can't recur).

## HARD RULES (any violation = REVISE)
1. Sacred 40/40 byte-identical (confirm none in `git diff HEAD~1 --name-only`;
   note the cap-table-engine PACKAGE must NOT be modified — the fix is in the
   demo wrapper + the panel).
2. Money `server/captableCommitStore.ts` sha16 `01cd36130ee1c0cb`.
3. tsc net-new = 0 → exactly **598**.
4. Guard exit 0, counts UNCHANGED (929 / 194 / 92).
5. No new migration. Payments/Airwallex untouched.

## Correctness to verify (adversarial)
- **No crash for the fresh-round case:** with preMoney null/0 and target 0, the
  projection tab must render (pre-close table + guidance) and must NOT call the
  engine with degenerate inputs (which would BigInt(NaN)-crash). RUN
  `client/src/lib/engineDemo.waveC4.test.ts` (4 tests).
- **Gate correctness:** `canProject` must be true ONLY when BOTH pre-money and
  target are positive finite numbers; false for null/undefined/0/NaN/partial.
- **Valid rounds still project:** a round WITH positive pre-money + target must
  still show the full pre/post-close comparison (no behavioral regression for
  real rounds).
- **Engine null-safety:** `projectPostClose` must not throw a
  `reading 'toString' of null` for null inputs (coercion applied first).
- **No engine-package edit:** confirm `packages/cap-table-engine/**` is NOT in
  the diff (the fix must be in the wrapper/panel only).

Run:
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # exit 0, 929/194/92
npx vitest run client/src/lib/engineDemo.waveC4.test.ts      # 4 pass
git diff HEAD~1 --name-only    # only the 3 C4 files + docs; no sacred/engine-pkg
```
If you run `npm run build`, restore ONLY: `git checkout -- server/public && git clean -fdq server/public/assets dist`. Do NOT commit.

## Output
Write to `/home/user/workspace/capavate_work/VERDICT_C4_<model>.md`:
1. VERDICT: APPROVE / REVISE
2. Gate results (actual numbers)
3. Per-check confirmation or defect (file:line + fix)
