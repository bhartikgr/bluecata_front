import { runAuditChainBootVerifier, hydrateAllStores } from "./server/lib/hydrateStores";
import { rawDb } from "./server/db/connection";
import { resolveAuditChainHealth } from "./server/adminPlatformStore";

async function setup() {
  const db = rawDb();
  
  // Create tables if they don't exist
  db.exec(`
    CREATE TABLE IF NOT EXISTS audit_log (
      tenant_id TEXT,
      id TEXT,
      action TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS audit_chain_health (
      key TEXT UNIQUE,
      status TEXT,
      detail TEXT,
      updated_at TEXT
    );
  `);
  
  // Clean up
  db.exec("DELETE FROM audit_log; DELETE FROM audit_chain_health;");
  
  console.log("Setting up 200 tenants with 100 audit_log rows each...");
  const stmt = db.prepare("INSERT INTO audit_log (tenant_id, id, action, created_at, hash) VALUES (?, ?, ?, ?, ?)");
  
  db.transaction(() => {
    for (let i = 0; i < 200; i++) {
      const tenantId = `tenant_${i}`;
      for (let j = 0; j < 100; j++) {
        stmt.run(tenantId, `log_${i}_${j}`, "test_action", new Date().toISOString(), "dummy_hash");
      }
    }
  })();
  console.log("Setup complete.");
}

async function runTests() {
  await setup();
  
  // 1. Cold-boot behavior (hydrateAllStores <1s)
  const startBoot = performance.now();
  console.log("Calling hydrateAllStores...");
  await hydrateAllStores();
  const endBoot = performance.now();
  const bootDuration = endBoot - startBoot;
  console.log(`Cold-boot duration: ${bootDuration.toFixed(2)}ms`);
  
  // 2. Event loop responsiveness and Memory Peak
  console.log("Testing event loop responsiveness and memory...");
  
  // Setup memory tracking
  const memBefore = process.memoryUsage().heapUsed;
  
  let loopDelayed = false;
  let maxDelay = 0;
  
  // Interval to measure event loop lag
  const interval = setInterval(() => {
    const start = performance.now();
    setTimeout(() => {
      const delay = performance.now() - start;
      if (delay > maxDelay) maxDelay = delay;
    }, 5);
  }, 10);
  
  // Run verifier
  const startTick = performance.now();
  const res = await runAuditChainBootVerifier({ maxTenants: 64 });
  const tickDuration = performance.now() - startTick;
  
  clearInterval(interval);
  
  const memAfter = process.memoryUsage().heapUsed;
  const memDiff = memAfter - memBefore;
  
  console.log(`Tick duration: ${tickDuration.toFixed(2)}ms`);
  console.log(`Max event loop delay for 5ms setTimeout: ${maxDelay.toFixed(2)}ms`);
  console.log(`Memory diff: ${(memDiff / 1024 / 1024).toFixed(2)} MB`);
  console.log("Verifier result:", res);
  
  // Check that the queue processing is running
  await new Promise(r => setTimeout(r, 100)); // wait for queued to start/finish
  
  if (bootDuration > 1000) {
    console.error("Boot duration > 1s!");
    process.exit(1);
  }
  
  if (maxDelay > 20) {
    console.error("Event loop delay > 20ms!");
    process.exit(1);
  }
  
  console.log("All performance tests passed.");
}

runTests().catch(console.error);
