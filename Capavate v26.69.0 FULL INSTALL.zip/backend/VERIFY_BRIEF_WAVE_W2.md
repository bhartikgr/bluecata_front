# VERIFIER BRIEF — Wave 2 (Gate + Accreditation) — v26.2.0-w2

Verify Wave 2 in `/home/user/workspace/capavate_work` (HEAD `ee68afb`). READ-ONLY: no
file edits, no app run. You MAY run read-only git/tsc/vitest/grep.

## Read
- `FIX_REPORT_WAVE_W2.md` (claims) · `WAVE_W2_SOURCE.diff` (or `git diff HEAD~1`).
- `ROADMAP_SPEC_GATE_MESSAGING.md` PART A (A1–A7) — the spec.
- Avi #2: `release_v26.1.2/AVI_FINDINGS_REPORT_v1.md` §2.

## Rules to confirm
- Sacred 47/47 byte-identical (`npm run sacred`, exit 0); Use `npm run sacred` (waiver-aware; `SACRED OK: 47/47`, exit 0). The raw `sha256sum -c sacred_baseline/SACRED_SHA256.txt` reader is **waiver-blind** and reports the five owner-waived files as `FAILED` (35 OK of 40, exit 1) on a healthy tree — by design, not corruption.
  money `server/captableCommitStore.ts` sha16 = `01cd36130ee1c0cb`.
- NO Airwallex/payment code edited. NO sacred file edited (esp. profileStore.ts —
  Avi#2 must READ its table `profilestore_investor_profile` directly, never import/mutate
  the store).
- tsc net-new 0 (total 598); `npm run guard` exit 0 (expect 931 routes = W1's 929 + 2 new
  endpoints, NO drops); ESM only (no new bare require); migration **0110** additive +
  idempotent + MIRRORED + self-healed in connection.ts.
- Build artifact restore if you build: `git checkout -- server/public && git clean -fdq server/public/assets dist`. Do NOT `git checkout -- .`.

## Per-item correctness
1. A2 `getAccreditationGateStatus`: verified never downgraded; none/self_certified/verified
   correct; legacy-grace preserved + logged; reads same store path as hasAccreditedDeclaration.
2. A3 capTableExempt: round-trips through activate/get/hydrate; bootstrap defaults true +
   audits reason; re-activate without flag preserves existing exemption.
3. A1 gate 4-step tree: capTableExempt bypasses ONLY the cap-table sub-check (NOT
   accreditation, NOT auth, NOT active, NOT admin/partner redirect); genuine `none` member
   blocked with ACCREDITATION_DECLARATION_REQUIRED; read error ⇒ fail-closed
   ACCREDITATION_STATUS_UNAVAILABLE; W1 H6 fail-closed block + admin bypass retained.
4. A5 gate-state: 401 unauth; correct shape; requiresAccreditationDeclaration only for
   genuine members with none; NEVER consults KYC; fail-closed on accreditation read error.
5. A7 legal-copy: placeholder NON_LEGAL_ADVICE; malformed supplied JSON degrades
   (degraded:true) without throwing; supplied copy returned verbatim.
6. Avi#2 reconciliation: resolves `derived_inv_<id>` via redeemed_by_user_id; reads the
   real profile + KYC docs + accreditation; fail-soft (never throws / blocks the page);
   profileStore.ts NOT imported/edited. Confirm no NEW IDOR (admin-only route already
   requires admin — verify the route registration/guard).
7. Client: CollectiveMemberGate decision order matches A5; fail-closed default never mounts
   children on a bad response; blocker/KYC-card/AccreditationDeclaration correct; KYC card
   NOT mounted inside the gate.

## Also verify
- `npx tsc --noEmit 2>&1 | grep -c "error TS"` = 598.
- `npx vitest run server/__tests__/waveW2_gate_accreditation.test.ts` = 12/12;
  `waveSEC_collective_gating.test.ts` still 16/16.
- Pre-existing failures unchanged: `sprint21_invitations` 2, `spvEngine` 30 (git stash if unsure).

## Verdict
Write `/home/user/workspace/VERDICT_W2_<model>.md`: APPROVE or REVISE with file:line issues.
Reply 6 lines ending in `VERDICT: APPROVE` or `VERDICT: REVISE`. GPT-5.5 DECIDES; never ship on REVISE.
