# Capavate v25.48.3 — Changelog

Base: v25.48.2 (live on capavate.com as of 2026-07-03).
Runtime: Node 20 + tsx (ESM). Triple-verified (Opus 4.8 + Gemini 3.1 Pro + GPT-5.5; GPT-5.5 overriding).

Sacred: 39/39 byte-identical (before + after). tsc: 601 errors = baseline, zero net-new.
Tests: v25.48.2 suites + storage + new v25.48.3 suites = 47 passed (12 files). Build: clean.

## Fixes implemented (per Ozan's decisions)

- **Q-J1 — Team invites now work.** Team-invitation emails point at the working
  `/auth/redeem?token=…` flow (was the dead `/team/invite/:token`). A new
  parallel interceptor (`server/lib/teamInviteRedeem.ts`) recognises team tokens,
  registers the redeemer as a **founder-capable** user, grants them real
  workspace access to the company (durable `company_members` row), tags them in
  `founder_team_members`, and redirects to `/founder/dashboard`. Investor/round
  tokens fall through unchanged; team-token lookup fails **closed** on a real DB
  error (503, never silently falls through).

  **Durability (single atomic transaction).** The guarded invite claim
  (`pending → accepted`, exactly one row), the `founder_team_members` tag, and
  the `company_members` grant + post-write verification all run inside ONE raw
  SQLite transaction on the shared connection (`writeCompanyMembershipRowRaw`
  runs on the caller's handle with no nested tx). If any step fails — a
  concurrent revoke/accept/expire (0 rows), or a membership-verify failure — the
  entire transaction rolls back, so there is **no state where the invite is
  consumed without durable access, and none where access exists without an
  accepted invite**. The in-memory read cache is mirrored and the session cookie
  set **only after** the transaction commits (no phantom access on rollback; the
  DB stays authoritative and restart-safe). The `company_members` write is an
  idempotent UPSERT that reactivates/re-roles a stale or soft-deleted row, so a
  retry is always safe. (Triple-verified across 4 rounds; final: GPT-5.5 SHIP,
  Opus SHIP, Gemini SHIP — 0 blockers.)

- **Q-K1 — CRM stages.** Invited-but-unregistered investors now show a distinct
  **"Invited – not registered"** stage; on registration they become a
  **"Prospect"** (the term "Lead" was renamed to avoid confusion with "lead
  investor"). Legacy `lead`/`engaged` rows still render (mapped to Prospect).

- **Q-K2 — Reciprocal investor CRM.** When an investor redeems an invitation,
  their CRM now shows the inviting founder/company with real name, email, and
  company name (was a blank "Founder").

- **Q-F1 — Cap Table is view-only.** "Add security" now routes to Rounds; equity
  originates only through the round/ledger flow (cleaner audit trail).

- **Q-F2 — Confirm / mark-funded is easy to find.** The soft-circle review row's
  Confirm and "Confirm / mark funded" buttons are highlighted (solid), and the
  Soft-circle book tab shows an amber indicator when confirmations are pending.

- **Q-D3 — Currency picker** offers the full ISO 4217 list with the 10 preferred
  currencies pinned on top.

- **Q-C3 — Founder billing** reads a new founder-scoped `/api/founder/pricing-tiers`
  endpoint instead of the admin route (no more 403 noise).

- **Q-A1 — Login portal tabs** are more highlighted (bold active tab, distinct
  inactive pills).

- **Q-I1 — Collective apply** now includes an "open to Collective refinement"
  checkbox, persisted (new `open_to_refinement` DB column, migration 0082) and
  relayed to the Collective.

- **Q-C6 — Region tab** shows a full-country dropdown pre-selected to the
  profile's country of incorporation.

- **Q-D2 — Wizard prefill** now reads jurisdiction fields from the canonical
  nested `legalEntity` sub-object (fixes previously blank fields).

## Verified on live (no code change needed)

- Q-B2 investor "replace" crash: gone on live 25.48.2 (clean empty state).
- Q-G1 rounds 404 / Q-C2 team-invite 400: not reproducible on live 25.48.2.
- Q-D1 dashboard search (AppShell) + PRO badge (CompanySwitcher): present in the
  build — deploy will NOT regress them.
- Q-C7 M&A Step 4: all fields persist in the company profile JSON and are read by
  Collective/DSC.
- Q-C8 8-year retention metadata: already implemented (archived_at +
  archive_retention_until).
- Q-A2 signup → company → plan → Airwallex handoff: verified end-to-end on live
  ($840 USD hosted checkout opens; stopped before payment).

## Needs Ozan's decision (not applied)

- **Q2 audit-chain banner** is a seeded `audit_chain_health` incident flag
  (historical continuity boundary), NOT a live data corruption — all real tenant
  audit chains verify clean. Clear it with an additive SQL acknowledgement
  (see Q2_AUDIT_CHAIN_RESOLUTION.md) whenever you're ready. Not auto-applied.
- **V2-S1 marketing sentence** on the Add-Company dialog: the current line has no
  pricing; a punchier draft is offered for your approval in the handoff notes.

## Migrations

- `0082_v25_48_3_open_to_refinement.sql` — additive `open_to_refinement` column
  on `founder_collective_applications` (idempotent; verified against a copy of
  the live data.db). Mirrored in `./migrations` and `server/db/migrations`, plus
  the `connection.ts` bootstrap CREATE/ALTER.
