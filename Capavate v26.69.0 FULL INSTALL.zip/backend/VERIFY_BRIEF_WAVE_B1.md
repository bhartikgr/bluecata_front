# Independent verification brief — Capavate Wave B1 (Add Portfolio Company, 3a)

You are an INDEPENDENT verifier. Review the B1 change set against the standing
rules and return APPROVE or REVISE (with concrete file:line defects + fixes).
Be adversarial; flag only REAL issues. Read the actual files, not just the diff.

Build tree: `/home/user/workspace/capavate_work` (deps installed). Diff:
`WAVE_B1_SOURCE.diff`. Report: `FIX_REPORT_WAVE_B1.md`.

## What B1 changed
- **NEW** `server/partnerPortfolioCompanyRoutes.ts` — `POST /api/partner/me/portfolio-companies`.
  Creates a net-new INDEPENDENT company (canonical `addCompanyForFounder`),
  owned by `u_pending_founder_<hash(email)>` (NEVER the partner), provisions a
  free subscription, links partner attribution (`linkConsortiumPartner`),
  adds a pipeline row, and issues a founder OWNER `founder_team_invitations`
  row + `/auth/redeem` claim link.
- `server/routes.ts` registers it after the SPV engine.
- Client: new nav "Add Portfolio Company" under Pipeline (CollectiveShell);
  new route + page `PartnerAddPortfolioCompany.tsx`.
- `server/collectiveRoutes.ts` company-detail now returns
  `profile.attributedPartner`; `CollectiveDealRoomDetail.tsx` renders a
  "Led by <partner>" badge.
- NEW test `server/__tests__/waveB1_add_portfolio_company.test.ts`.

## HARD RULES (any violation = REVISE)
1. **Sacred 40/40 byte-identical** — confirm NONE of the 40 sacred files were
   edited. In particular B1 imports from sacred `companyProfileStore.ts` and
   sacred `subscriptionStore.ts` must NOT exist — verify B1 only imports the
   NON-sacred `subscriptionsStore.ts` (plural) and does not touch any sacred file.
2. **Money core** `server/captableCommitStore.ts` sha16 `01cd36130ee1c0cb`,
   commitment path not forked.
3. **tsc net-new = 0** → exactly **598**.
4. **Guard exit 0** — new route/page/nav are informational adds only (925/194/92).
5. **No new `require()` in server TS** (ESM only).
6. **Payments/Airwallex untouched**; no referral payout wired (attribution only).
7. **No new migration** — all tables (companies, consortium_links,
   founder_team_invitations, partner pipeline) already exist; B1 must not add a
   migration.

## Correctness / security checks to actually run + reason about
- **Founder-owner isolation:** confirm the created company's owner is the
  pending-founder id, NEVER the partner acting user (the partner must not gain
  founder access; the founder must not gain partner access). The route uses
  `pendingFounderUserId(email)` for `addCompanyForFounder`.
- **Attribution fail-closed:** `linkConsortiumPartner` throws on durable-write
  failure; confirm the route returns 500 (does not silently drop attribution).
- **Company persist fail-closed:** confirm a persist failure returns 500 (no
  false success).
- **Founder invite:** role must be `owner`, status `pending`; the claim link
  uses the real `/auth/redeem?token=` flow; identity of the inviter is the
  session partner user (`ctx.userId`), never a client value.
- **Validation:** missing companyName → 400 COMPANY_NAME_REQUIRED; invalid/absent
  founder email → 400 FOUNDER_EMAIL_REQUIRED.
- **Attribution badge:** `attributedPartner` resolved read-only; null when not
  attributed; the client badge renders only when present.

Run:
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # exit 0
npx vitest run server/__tests__/waveB1_add_portfolio_company.test.ts server/__tests__/waveA_consortium_qa.test.ts server/__tests__/spvUnifiedCanonical.test.ts   # 16 pass
grep -nE "\brequire\(" server/partnerPortfolioCompanyRoutes.ts   # none
grep -nE "companyProfileStore|subscriptionStore\b" server/partnerPortfolioCompanyRoutes.ts   # must NOT import sacred singular stores
```

## Output
Write to `/home/user/workspace/capavate_work/VERDICT_B1_<model>.md`:
1. VERDICT: APPROVE / REVISE
2. Gate results (actual numbers)
3. Per-check confirmation or defect (file:line + fix)
