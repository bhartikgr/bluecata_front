import express from "express";
import request from "supertest";
import { registerPartnerRoutes } from "./server/partnerRoutes";
import { registerPartnerPortfolioCompanyRoutes } from "./server/partnerPortfolioCompanyRoutes";
import { registerCompanyAttributionRoutes } from "./server/companyAttributionRoutes";
import { seedTestPartnerSandbox } from "./server/partnerWorkspaceStore";

process.env.VITEST = "true";
process.env.NODE_ENV = "test";
const app = express();
app.use(express.json());
registerPartnerRoutes(app);
registerPartnerPortfolioCompanyRoutes(app);
registerCompanyAttributionRoutes(app);
seedTestPartnerSandbox({ force: true });

const create = await request(app)
  .post("/api/partner/me/portfolio-companies")
  .set("x-user-id", "u_avi_managing")
  .send({ companyName: "Private IDOR Co", founderEmail: "private-idor-founder@example.com" });
console.log("CREATE", create.status, { companyId: create.body.companyId, collectiveStatus: create.body.company?.collective?.status, attributedPartnerId: create.body.attributedPartnerId });
const companyId = create.body.companyId;
const cross = await request(app)
  .get(`/api/companies/${companyId}/attribution`)
  .set("x-user-id", "u_aisha_patel");
console.log("CROSS_USER_ATTRIBUTION", cross.status, cross.body);
