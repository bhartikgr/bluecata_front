# W-MFCRM — Final Decider Verification (GPT-5.5 role, independent)

I am the final decider in a triple-verification. I did **not** defer to the two prior
SHIP reviews (Opus, Gemini); I re-read the actual code — the engine, both route
files, all three persona stores, `requirePartnerAuth`, and the `createSpv` /
`commitFunded` reference signatures — and re-derived each judgment. In the design
phase I (GPT-5.5) caught the D-9 defect (SPV-on-behalf conflating global capability
with per-engagement Mode-A authority); my first duty is to confirm the CODE closes
it. node_modules is not installed, so no tsc/vitest was run; findings are by reading.

---

## 1. D-9 and every delegated-write path — CLOSED (independently confirmed)

`createSpvOnBehalf` (managedFounderStore.ts L730) calls
`assertDelegatedWriteAuthority(pid, e, { requireSpvWrite: true })` at L742 **before**
`spvEngineStore.createSpv`. The helper (L325–334) throws, in order:
`delegatedAgency` → `spvWriteAuthority` → `status==='ACTIVE'` → `mode==='A'` →
present `authorityArtifactRef` → non-expired `authorityExpiresAt`. Therefore an
**ACTIVE Mode-B engagement whose partner has the global delegated_agency +
spv_write_authority toggles ON is denied `ENGAGEMENT_MODE_NOT_A`** — global toggles
alone are provably insufficient. The gate reads authority from the **per-engagement
row**, not the profile, so the escalation I flagged in design cannot occur.

All other privileged surfaces enforce the same discipline:
- **Mode-A entry** (`assertModeAEntry`, L309) is called at ALL THREE entry points —
  create-in-A (L364), setMode B→A (L444), handover-confirm-into-A (L511) — requiring
  delegated_agency + present + non-expired artifact. No default-open branch.
- **Graduation** (`softCircleGraduate`, L686) asserts GATE 5 (ACTIVE + sources_capital
  OR delegated_agency).
- **Collective push** asserts GATE 4 (collective_fronting + ACTIVE) at the STORE and
  is re-asserted at the route (managedFounderRoutes L370) before durable state moves.
- **Lapsed/handed-over** engagements: gates 3/4/5 each check `status==='ACTIVE'`
  first; `expireStaleTrials` (L567) flips expired Mode-A trials to LAPSED, after which
  every money/authority gate denies `ENGAGEMENT_NOT_ACTIVE`. `setMode`/`handover`
  also guard ACTIVE, so a lapsed engagement cannot be flipped back to A.
- **Unclassified** partners get the most-restrictive `unclassifiedProfile` (L110–127,
  every flag false) by default — fail-closed by construction, not by omission.

**Persona paths do not weaken any of this.** The angel/acct/law stores NEVER write
`mf_engagement` directly; they call the engine's `setEngagementScope` (L464), which
only mutates `chapterId`/`matterId` (no mode/status/authority field is reachable) and
is partner-scoped via `getEngagement` (null on cross-partner). No persona helper
performs a delegated write, SPV, graduation, or Mode-A entry — those live only in the
gated engine methods.

## 2. Money — single sacred ledger; SPV sync-tx correct

- `commitFunded` is the ONLY money entry point. `softCircleGraduate` calls it (L689)
  and, on `{ok:false}`, returns early writing nothing (L698); the Founder-CRM copy-in
  is try/catch best-effort and cannot roll back the sacred commit (L701–712).
- I verified the call site against the real signature (captableCommitStore L675–689):
  the passed keys (invitationId, roundId, companyId, investorId, amount, currency,
  shares) match exactly, and the code consumes `result.entry.seq` on the ok branch —
  no type/shape mismatch that the no-tsc caveat could be hiding.
- `createSpvOnBehalf` runs a single **synchronous** `db.transaction(()=>…)()`
  (L767–785): chain-tip read + `sha256(prevHash|payload)` + INSERT `mf_spv_on_behalf`
  + INSERT `mf_collective_push` 'queued'. **No async/await/network inside the tx**
  (better-sqlite3 would throw); the real push is emitted OUTSIDE via
  `markCollectivePush`. Tip-read and INSERT share one serialized sync tx → **no
  hash-chain TOCTOU**; first row seeds `prevHash="GENESIS"`.
- I confirmed the `spvEngineStore.createSpv` signature (L260–270): the call site's
  keys are all valid; it returns `SpvDTO` and the code uses `.id`. No parallel money
  ledger anywhere (grep: `commitFunded` appears only at the import + the one call).

## 3. Isolation — session-only partnerId; attribution 404

`requirePartnerAuth` resolves `partnerId` from the SESSION team-member record and
NEVER from the URL/body (verified in source, L44–70; the file's own contract states
this is the §9.2 data-isolation guarantee). Every partner + persona handler derives
`pid = req.partnerContext!.partnerId`; no handler reads a body/query `partnerId`.
Every company-scoped route (engine AND persona) calls `isAttributed(pid, companyId)`
and returns **404 COMPANY_NOT_FOUND_OR_NOT_ATTRIBUTED** before the store is touched —
no existence leak. Engagement/handover-scoped routes need no companyId check because
the store filters `WHERE partner_id = ?` / `getEngagement` returns null on mismatch →
404. Admin routes take a URL `:partnerId` by design (platform operator) behind the
`/api/admin` requireAdmin mount PLUS an in-handler `isAdmin` re-check. Store reads are
uniformly `WHERE partner_id = ?`.

## 4. RF-1 sacred edit — additive, behavior-preserving

The diff shows exactly three additive hunks in `userContext.ts`: the union member
`"INVITED_PRIVATE_ROUND"`, an optional `hasPrivateRoundInvite?: boolean` arg, and the
one branch `if (!hasCapTable) return args.hasPrivateRoundInvite ?
"INVITED_PRIVATE_ROUND" : "INVITED_ONLY"`. Absent/false ⇒ byte-identical to prior
behavior for the existing 5 states and every existing caller. `buildInvitedRounds` is
NOT in the diff (untouched). SHA re-baselined `3a6d325c…` → `d75d1321…` in
`SACRED_SHA256.txt` L16 with `CAPAVATE_SACRED_FILES.md` documenting old→new.
`commitFunded`/captableCommitStore, spvEngineStore, and the other money-core files are
untouched (not in the diff). This is the ONLY sacred edit — the 40/40 gate holds with
one line re-baselined.

## 5. Additive-only; schema idempotent

Diff = additions only (imports, HYDRATE_ORDER entries, two `registerMfcrm*` calls, one
nav entry, two client routes with detail-before-list ordering). Nothing renamed,
moved, or removed; new route prefixes are distinct (no Express shadowing).
`applyMfcrmSchema` uses `CREATE TABLE IF NOT EXISTS` for all 12 tables with partner_id
+ indexes + the required UNIQUE constraints; persona tables are created lazily via
idempotent `ensureXTables()`. No destructive ALTER/DROP.

## 6. Findings the two reviewers did not surface

None are ship-blocking, but I record them for completeness and honesty:

1. **`isExpired(null) === false`** (L102–107): an engagement/artifact with a NULL
   `authorityExpiresAt` is treated as perpetual (never-expiring) at the artifact
   check. This is acceptable — the design requires "present + non-expired", and null
   is not "expired"; independent time-boxing is enforced by the 90-day trial
   (`trialExpiresAt` → `expireStaleTrials` → LAPSED → ENGAGEMENT_NOT_ACTIVE). Worth a
   design note, not a defect.
2. **GATE 2 is a routing gate, not a hard deny.** `stampAttribution` (L587) forces
   `first_touch` only when `sourcesCapital=true`, else structurally downgrades to
   `firm_of_record`/`matter_of_record`/`counsel_of_record` and writes
   `sources_capital=0` with no tail. This matches design ("else firm-of-record path")
   and means a non-capital partner can NEVER emit investor first-touch. Correct.
3. **Acct persona has no `INVESTOR_SPINE_FORBIDDEN` analogue.** The law store guards
   `stampCounselOfRecord` with `assertInvestorSpineDisabled` (throws if
   sources_capital=true); the acct store's `stampFirmOfRecord` has no equivalent, so a
   mis-seeded accounting partner with sources_capital=true would receive `first_touch`
   from `stampAttribution`. This requires an admin mis-seed (capability profiles are
   admin-seeded from partner_type, which sets accounting → sources_capital=false), and
   if the flag genuinely were true the attribution would be honest — no money or
   isolation boundary is crossed. Defense-in-depth suggestion, non-blocking: mirror
   the law guard on acct, or document that acct relies on correct seeding.
4. **Invalid SPV jurisdiction/carryBasis on SPV-on-behalf → 403, not 400.**
   `spvEngineStore.createSpv` throws a plain `Error("INVALID_JURISDICTION")` etc.,
   which `sendError`'s fail-closed default maps to 403. Cosmetic status-code nit; no
   security impact.

## 7. Ship risk of un-run tests

Acceptable. The code is additive (no existing behavior mutated beyond the audited RF-1
hunk), every privileged path is gated fail-closed at both store and route layers, and
I independently confirmed the two cross-module signatures (`commitFunded`,
`createSpv`) that a missing type-check might otherwise hide. The tests reference real
exported symbols (`clearLedger`/`getLedger`/`verifyChain`, `_registerSeedPartner`,
`partnerAttributionStore.create`) and assert behavior including the mandated D-9
negative. **Recommendation (non-blocking): run `vitest` once on a machine with deps
before or immediately after ship as belt-and-suspenders.**

---

## Decision

The D-9 defect I caught in design is closed in code: SPV-on-behalf and every
delegated-write / graduation / Mode-A / Collective-push path binds per-engagement
`mode==='A'` + `status==='ACTIVE'` + present non-expired artifact + the required
capability flags, asserted before any durable/money effect. Money flows solely through
the sacred `commitFunded` ledger; the SPV audit tx is synchronous, orphan-safe on the
denial path, and TOCTOU-free. Isolation is session-only with attribution-gated 404 on
every partner and persona route, and the sole sacred edit (RF-1) is additive and
correctly re-baselined. The four observations above are defense-in-depth / cosmetic /
design-notes, none reachable as an escalation or isolation break in normal operation.

FINAL VERDICT: SHIP
