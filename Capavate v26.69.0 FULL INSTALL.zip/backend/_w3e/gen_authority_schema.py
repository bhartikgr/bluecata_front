#!/usr/bin/env python3
"""WAVE 3E — generate server/lib/feeSettlementAuthoritySchema.ts from the
canonical migration, so the inline bootstrap text is byte-identical to
migrations/0151_wave3e_fee_settlement_authorization.sql.

DO NOT hand-edit the generated file. Re-run this after changing the migration.
server/__tests__/wave3e_settlement_authority_db.test.ts asserts the equality.
"""
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
MIG = ROOT / "migrations" / "0151_wave3e_fee_settlement_authorization.sql"
OUT = ROOT / "server" / "lib" / "feeSettlementAuthoritySchema.ts"

sql = MIG.read_text(encoding="utf-8")
esc = sql.replace("\\", "\\\\").replace("`", "\\`").replace("${", "\\${")

HEADER = '''/**
 * server/lib/feeSettlementAuthoritySchema.ts — WAVE 3E.
 *
 * GENERATED FILE. DO NOT HAND-EDIT.
 * Source: migrations/0151_wave3e_fee_settlement_authorization.sql
 * Generator: _w3e/gen_authority_schema.py
 *
 * WHY THIS EXISTS
 * ---------------
 * The durable settlement-authority tables must exist on the `:memory:` test
 * path and on any database that has not yet run the migration runner. The
 * project's normal third home for that bootstrap is `applyInlineMigrations()`
 * in `server/db/connection.ts`, which is SACRED and must not be edited by this
 * wave. The bootstrap therefore lives with the module that owns the table, and
 * it executes the CANONICAL MIGRATION TEXT VERBATIM rather than a hand-copied
 * paraphrase that could drift.
 *
 * The text below is a byte-for-byte copy of the migration.
 * `server/__tests__/wave3e_settlement_authority_db.test.ts` asserts that
 * equality against the file on disk, so drift fails the suite loudly.
 *
 * NOTE: this SQL creates EMPTY tables and seeds NOTHING. Bootstrapping can
 * never manufacture an authorization; a fresh database settles nothing.
 */
export const FEE_SETTLEMENT_AUTHORITY_SQL = `'''

OUT.write_text(HEADER + esc + "`;\n", encoding="utf-8")
print(f"wrote {OUT} ({len(sql)} bytes of SQL)")
