# W-SHADIE — Fix Wave Result (v26.2.0-wshadie, stacked on W-AVI65)

Verification: careful inspection + ~75-assertion Python simulation (node_modules absent; npm/tsc/vitest NOT run). Sacred gate re-run with sha256sum: **40/40 OK**. No sacred file edited.

## Owner decisions (locked & applied)
- 5a: icon-then-label. 3a: 7-day default across ALL surfaces (7 first, keep Never, keep 90). Bulk CSV aligned to 7 + copy fixed. Scope: stacked on W-AVI65 (one package).

## Files NEW (6)
- client/src/lib/inviteExpiry.ts — INVITE_EXPIRY_OPTIONS=[7,14,30,60,90], DEFAULT_INVITE_EXPIRY_DAYS=7.
- client/src/pages/founder/__tests__/wshadie_2a_checkbox_visibility.test.ts
- client/src/pages/founder/__tests__/wshadie_3a_invite_expiry_default.test.ts
- client/src/pages/founder/__tests__/wshadie_4a_resent_column.test.ts
- client/src/pages/founder/__tests__/wshadie_5a_action_labels.test.ts
- client/src/pages/founder/__tests__/wshadie_bulk_expiry_alignment.test.ts

## Files EDITED (5, all non-sacred)
- client/src/pages/founder/ApplyToCollective.tsx — 2a: both required <Checkbox> get `h-5 w-5 border-2 border-slate-500 bg-white data-[state=checked]:border-primary` (shared primitive untouched; checked-red preserved). data-testids unchanged.
- client/src/pages/founder/RoundNew.tsx — 3a: 6 sites → 7 / shared const (state, post-add reset, option map, hint, payload fallback, comment). Zero residual 14 expiry literals.
- client/src/pages/founder/RoundDetail.tsx — 3a (invite state "30"→"7", post-send reset →"7", option list 7-first keeping 90+Never, bulk copy "30-day"→"7-day"); 4a (Resent <th> + <td data-testid inv-resent-> between Sent & Viewed, Viewed cell gains inv-viewed-, empty colSpan 6→7, teal resent chip kept); 5a (icon-then-label Resend/Extend/Revoke + aria-label; disabled logic + testids byte-identical). Extend increment :250 (expiryDays:30) deliberately UNCHANGED.
- server/lib/bulkInvitationsRoutes.ts — 3a: bulk expiry 14→7 (calc + both email copies). Non-sacred.
- client/src/pages/founder/__tests__/v2413_groupA_fixes.test.ts — reconciled 3 assertions: L63 (→ full useState("7") decl), L84 (setInviteExpiry "30"→"7"), L68 (PRE-EXISTING baseline red — fixed the test to match the real multi-statement onChange handler; source NOT changed to satisfy it).

## Deliberately NOT changed (documented decisions)
- Shared client/src/components/ui/checkbox.tsx (20 consumers) — guarded by a test.
- Extend increment RoundDetail.tsx:250 {expiryDays:30} — extend-by feature, not the invite default.
- Server `?? 14` omission fallback in roundInvitationsStore.ts — both dialogs always send an explicit value; unreached from client. CONSEQUENCE: RoundDetail "Never" still resolves to 14 server-side (pre-existing, known-imperfect, out of scope — NOT claimed fixed).

## Tests that must stay green (verified untouched)
waveC3_invite_preview_and_round_name.test.ts:45 (renderer ?? 14 default), v25_55_shadie_v6, v15_invitation_flow, sprint14_stores (staleness constant). Swept all 18 __tests__ dirs + e2e for the 16 removed strings — only hit outside v2413 is the intended renderer-default test, which we don't touch. NO unexpected breaks.

## Anti-vacuity test design (per Opus correction #7)
- 2a: extract each checkbox element by testid; assert override INSIDE each (exactly twice); assert checked-red survives; assert shared primitive still has h-4 w-4/border-primary and NO slate.
- 3a: assert ABSENCE of every old literal; import-AND-use regex (no orphan const); 7-first ordinal chain i7<i14<i30<i60<i90<iNever; Extend increment asserted unchanged.
- 4a: ordinal position in BOTH header and cell row + rank-equality (header order == cell order); colSpan={7} scoped to empty cell; `<th ` count (trailing space).
- 5a: assert visible text node via `/>\s*Label\s*</Button>$` (icon-only revert => `/></Button>` fails); icon-before-label; disabled + testids pinned.
- bulk: exact 7-day arithmetic + both copies; not.toMatch(/\b14\b/) across route; guardrail that server ?? 14 omission fallback is intact.

## Sacred gate
sha256sum -c sacred_baseline/SACRED_SHA256.txt → 40/40 OK, 0 FAILED. None of the 11 touched files is in the manifest.

## POST-REVIEW: F-1 fixed + documentation notes (both reviewers = SHIP, 0 blocking)
Both Opus and Gemini returned SHIP (0 blocking) and independently found the SAME non-blocking finding F-1. Per owner "build it all" + 3a's consistency goal, F-1 is FIXED (not merely disclosed):
- **F-1 FIX (RoundNew.tsx:438):** CRM-picked Step-4 contacts carried no per-row expiryDays → sent null → server ?? 14 → CRM invites got 14 days while manual invites got the new 7. Changed `expiryDays: s.expiryDays ?? null` → `?? DEFAULT_INVITE_EXPIRY_DAYS`. Now ALL Step-4 picks (manual + CRM) default to 7. Manual picks already set s.expiryDays so only the CRM path changes. Sacred still 40/40.

### Handover disclosures (carry into the handover doc)
1. **2a scope limit:** fixes ONLY the two reported apply-to-collective checkboxes; the same low-contrast unchecked box remains on the other ~20 shared-Checkbox consumers BY DESIGN (editing the shared primitive = global blast radius).
2. **Inherited W-AVI65 deploy conditions** (this package stacks on W-AVI65): (a) a genuinely green `npm test` on the server; (b) `BRIDGE_INBOUND_HMAC_SECRET == COLLECTIVE_WEBHOOK_SECRET`; (c) pm2 fork mode (not cluster).
3. **"Never" = 14 today** (pre-existing, out of scope): RoundDetail "Never" → omitted expiryDays → server ?? 14. Known-imperfect, NOT claimed fixed.
4. **KNOWN-RED-ON-ARRIVAL pre-existing tests** (unrelated to W-SHADIE; the widened full-suite gate will show them — do NOT misattribute or revert): 
   - v25_53_round_mgmt_client.test.ts:54 (`const dayInPast` absent on baseline too)
   - v2413_groupB_fixes.test.ts:164 (`L-005 fix v23.4.13` absent on baseline too)
   - v23411_phase1_round_upgrade_interstitial.test.ts:111 (`navigate('/founder/subscribe` absent on baseline too)
   These fail on the untouched baseline; W-SHADIE causes 0 regressions (Opus 175-assertion sweep).
5. **tsconfig excludes **/*.test.ts** → contract tests are not typechecked by `tsc --noEmit`; they are verified only at `vitest run`. The widened gate's actual execution is the real verification.

## POST-DECIDER: preview follow-up fixed (unanimous SHIP: Opus + Gemini + GPT-5.6 decider)
Decider verdict SHIP (0 blocking). It found one more non-blocking item: the manual-invite PREVIEW (RoundNew.tsx ~:1324) omitted expiryDays → preview always said "expires in 14 days" regardless of the dropdown (pre-existing; was already wrong for 30/60/90). FIXED: the preview POST now sends `expiryDays: Number(manualDraft.expiryDays) || DEFAULT_INVITE_EXPIRY_DAYS`, so the preview matches the real email. The /invitation-preview endpoint already accepts expiryDays (server unchanged). Sacred still 40/40.

RESULT: all four Shadie items (2a/3a/4a/5a) fixed; F-1 (CRM-pick 7d) fixed; preview consistency fixed. Unanimous triple-SHIP. No sacred edits (40/40). Change surface: 6 new + 5 edited files (all non-sacred).
