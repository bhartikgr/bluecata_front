import re

files = [
    "client/src/pages/investor/__tests__/w221_benchmarking_sharing_dom.test.tsx",
    "client/src/components/partner/__tests__/w216_esign_rendered_bytes_are_signed_bytes.test.tsx",
    "server/__tests__/w226_attestation_stored_bytes.test.ts"
]
for f in files:
    with open(f, 'r') as file:
        lines = file.readlines()
        for i, line in enumerate(lines):
            if ".toLowerCase" in line:
                print(f"=== {f} LINE {i} (toLowerCase) ===")
                print("".join(lines[max(0, i-2):min(len(lines), i+3)]))
