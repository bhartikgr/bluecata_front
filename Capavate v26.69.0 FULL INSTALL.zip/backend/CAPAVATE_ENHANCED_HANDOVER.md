# CAPAVATE — ENHANCED MASTER HANDOVER (read this first)

**Generated: 2026-07-23 · Current build: LIVE ai64 / v26.2.0 + W-AVI64 fix wave (this package) · Owner: Ozan Isinak · Maintained by: Perplexity Computer**

This is the single-source-of-truth handover for the Capavate platform. If a sandbox fails, a new agent can resume entirely from THIS document. It embeds the full sacred manifest and governance data verbatim (Section 9), the live environment (Section 8), the fix lineage, the open-items ledger, and the exact deploy/verify runbook.

---

## 1. What Capavate is
Full-stack fintech platform for managing investment rounds & cap tables: founders run rounds and invite investors; investors soft-circle/fund; consortium partners manage portfolios; a Collective network + a Managed Founder CRM (MFCRM) layer sit on top. React/wouter FE, Node/Express BE, **SQLite (better-sqlite3, synchronous)**, Airwallex payments (LIVE), SMTP email (live), a Capavate↔Collective event bridge. Server on GoDaddy at `/var/www/html/backend/`.

## 2. Current state (as of this package)
- **LIVE deployed:** ai64 / v26.2.0 (confirmed via healthz buildTime 2026-07-23T05:05:09Z).
- **This package (W-AVI64)** fixes Avi's ai64 feedback + live-audit bugs, built ON TOP of the live ai64 tree.
- **MFCRM (W-MFCRM, 4 personas)** is already present in the ai64 tree (dark-shipped, capability-flag gated — nothing active until a partner profile is seeded).
- Sacred gate: **40/40 OK**. Money core untouched.

## 3. Fix lineage (oldest → newest)
- W-FIX1 (Avi A1–A8/O1–O8: cap-table raw-id resolution, round category, warrants/ESOP, DM founder↔investor, Radix/first-click)
- W-FIX2 (Avi F1–F6: investor companyId backfill, allowDms toggle, auto share price, sign-out, SPV-BUG-1 ×100 + migration)
- W-FIX3 (403→200 invited-investor /securities fix: userContext Option B + companyId backfill)
- W-FIX4 (build/version marker, SPV migration dry-run safety, cap-table observability N1, button-in-Link cleanup)
- W-MFCRM (Managed Founder CRM, all 4 personas — bank/angel/accounting/law; dark-shipped, capability-gated)
- **W-AVI64 (THIS wave)** — Avi ai64 feedback + live-audit fixes (see Section 5)

## 4. Avi's ai64 feedback — verified on LIVE + classification
1. Round not shown to invited investor → **REAL BUG, FIXED** (wizard CRM-pick didn't create an invitation). 
2. Warrant shares → **NOT A BUG** (shares issued on exercise, not creation — explanation sent to Avi).
3 & 4. Founder↔Investor DM not working → **REAL BUG, FIXED** (investor's DM candidate list wasn't relationship-scoped; the "Allow DM" toggle only gates inbound, unrelated to initiating).

## 5. W-AVI64 fixes (this package) — all additive, non-sacred, triple-verified SHIP
- **FIX 1** — round-creation CRM pick now resolves the contact's email and creates the invitation; founder sees an invite summary (no silent drops).
- **FIX 2** — /api/messages/recipients candidate list relationship-scoped (invitations + cap-table + CRM + company membership + inviter); every candidate still gated by fail-closed canDM (no isolation change).
- **FIX 3** — bridge made LIVE: env alias fallback in bridgeOutboundGuard (canonical names still win); deploy must set BRIDGE_ENABLED=1 + COLLECTIVE_WEBHOOK_URL + COLLECTIVE_WEBHOOK_SECRET (Section 8). Sacred bridgeRuntime.ts untouched.
- **FIX 4** — admin global search reads the real data source (finds live companies/investors).
- **FIX 5** — admin Telemetry Explorer sources real recent events.
- **FIX 6** — portal login routes no longer bounce to the admin dashboard when a different-portal session is active.
- **FIX 7** — funnel % clamped; buildSha/AWS/dev-reset documented for deploy.

## 6. OPEN ITEMS LEDGER (as of this package)
### Blocking / deploy
- Install W-AVI64 (this FULL_INSTALL) on live; run the Gate Runbook (Section 7) on the server.
- Set the bridge env block + BUILD_SHA (Section 8); back up data.db before restart.
- SPV-BUG-1 ��100 migration EXECUTION on live still pending (safety built in W-FIX4; dry-run + backup, then commit). ⚠️ Airwallex LIVE.
- W-FIX3 companyId migration on live (dry-run review first).
### Pending owner decision / ops
- Bridge chain "broken@0" + P0 audit-chain incident banner — safe admin-gated re-verify (non-destructive; bridge outbox is NOT the money ledger).
- RF-13 back-classify partners into partner_type to activate MFCRM personas (fail-closed until seeded); RF-4/RF-9 legal/compliance sign-off gates law/accounting activation.
- Founder pending_payment paywall gating (new companies) — UX decision.
- dev-reset URL enabled on live — recommend RETURN_DEV_RESET_URL=0.
- Admin funnel impossible % (clamped this wave) — verify metrics source.

## 7. GATE RUNBOOK (run on the server after install)
```
npm install && npm run build                       # exit 0
npx tsc --noEmit 2>&1 | grep -c 'error TS'          # no NEW errors vs baseline
npm run guard                                       # no DISAPPEARED routes/pages/nav
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
npx vitest run server/__tests__/wavi64_*.test.ts    # pass
```
Known pre-existing failure to ignore: sprint28_billing/hash-chain-replay under pglite (42703) — reproduces on baseline, unrelated to changed files.

## 8. LIVE ENVIRONMENT (canonical — see also embedded CAPAVATE_LIVE_ENVIRONMENT.md in this package)
- Host: capavate.com, NODE_ENV=production, PORT=5000, server path /var/www/html/backend/
- DB: SQLite file:/var/www/html/backend/data.db (better-sqlite3 SYNCHRONOUS — no async inside db.transaction). Back up before any migration.
- Email: SMTP live (smtp.gmail.com:465, scale@blueprintcatalyst.com).
- Payments: **Airwallex LIVE, AIRWALLEX_REAL_NETWORK=1 — REAL MONEY. Never exercise payment/funding/SPV-commit flows on live.**
- Bridge (make live this wave):
  ```
  BRIDGE_ENABLED=1
  COLLECTIVE_WEBHOOK_URL=https://collective.capavate.com/api/bridge/inbox
  COLLECTIVE_WEBHOOK_SECRET=<real shared secret with Collective>
  # keep existing BRIDGE_OUTBOUND_URL / BRIDGE_INBOUND_HMAC_SECRET
  ```
- Set BUILD_SHA (or GIT_SHA) at deploy so healthz stops reporting "unknown".
- S3: STORAGE_PROVIDER=s3, AWS_BUCKET=capavate-uploads, ap-south-1; AWS_ACCESS_KEY_ID/SECRET currently EMPTY — set for uploads.
- Recommend RETURN_DEV_RESET_URL=0 in prod.
- Login portals: /user/login (founder), /investor/login, /partner/login, /admin/login.

## 9. SACRED FILES & DATA (embedded verbatim — DO NOT EDIT without owner authorization + re-baseline)
The 40 sacred files must stay byte-identical unless the owner authorizes an additive edit, in which case: edit, recompute that ONE file's SHA, update the manifest line, document old→new in CAPAVATE_SACRED_FILES.md, and verify 40/40 before AND after. Money core (captableCommitStore, messagingStore, paymentGatewayAdapter, bridgeRuntime, userContext, capTableMembership, canonicalPlanResolver) is especially protected.

### 9.1 SACRED_SHA256.txt (canonical manifest — 40 files, verbatim)
```
e5045ecbe77b06ea9879fae53e58e21ee2002b5b820a5ef066ecdf086c41cb06  server/captableCommitStore.ts
d7fa53f0fb8c41d0acba5ee7184ec11e169aa23530b90d49860533f27c786119  server/roundCarryForwardEngine.ts
83757c546b41bce996cd55cdaf42c046bc8bc3cd3c0e457389ac0738b2911660  server/paymentGatewayAdapter.ts
75ae10080c377a1ddbfa3ed767b485c44f56963580170157c2140dfc932e7848  server/subscriptionStore.ts
1719e274cb795fb9dafd98d2e01b1cfa5afaaed8492a65ccbf6d37a22b014067  server/profileStore.ts
74a7824011ebcef9610638ea07dbcd87a0ab8bb4728b3a698c1cba59408282cc  server/companyProfileStore.ts
95c6e8ad1b2e26b9a7a3ba24a7f6d31a65da1bde3c5339e46d902100a9b53043  server/investorCrmStore.ts
17bd56080b6af4a71ea0ac1f7e4023e1fc8ef64c8d00b9670d5d90ae19b3c392  server/messagingStore.ts
7b5ec3d8e547e7d30be5216ae0cb047c8f579890cbe66afc6fe28ab3fdb58126  server/notificationsStore.ts
b25acc5cf025b19bd9ac41a39558ce234b0eabc42dc9192e6545ed0382f87290  server/welcomeStore.ts
280b636b0479577750f96fab86fe5482b0f4e3a60067b138af36dd538dce2421  server/lib/bridgeRuntime.ts
de13fd13aa7ab0a7b7feea1d4336c2d0713b6633fb58fedfdb4e0bbfeae5f08a  server/lib/migrationRunner.ts
0d9247fd62a5cad1692ca0e577e9d9251d888a4321071a80a50ca52db9758038  server/lib/driftDetector.ts
50abd00004a5f09722a5a75bf4152ee0fa2ab37f6706450601d8f444d8460124  server/lib/rateLimit.ts
57fee03876859cdf705a86ac8ad64440b09bf754685432ace1141694deb45605  server/lib/sseHub.ts
d75d1321b66f1e6ce767c2517eedbbcaceb3b584370438f7507dc27320a8f6b4  server/lib/userContext.ts
e6e8b224b5782b22f1623c9e94f2a306f13aa42ccf51b4ad64577558059a532f  server/lib/userPrivacyResolver.ts
35d313025ca6651562dbb96e3928c0c976ca610238f05d3a8f7fe50f442b2718  server/lib/capTableMembership.ts
d51d77c6e4200a869f566cff2d6f8f3336a0ea4277c295f9b38b845b5372c679  server/lib/canonicalPlanResolver.ts
813de79077e1e0f73ee6572091826cb6e2bec7aa520dee31df588640cf66d692  client/src/pages/founder/Billing.tsx
c938a43dd895a8482b93e65d89d0c7e625461bd8d01244adcedf6ebb89583a8b  client/src/components/home3compo/AudiencesSection.jsx
8038be8ec4771a10c829e877144e58dd33d663911bed5e5bef98296661b27489  client/src/components/home3compo/ContactUsPopup.jsx
475d47802f91c837cd65dd8fdff755c0ed7f29e7e2fd80a2a5a4f7aa8c215022  client/src/components/home3compo/CredibilitySection.jsx
2d99d12591717d0e650126305edd3d3f96b57b22c2b8776a83b9f1eb2f045a87  client/src/components/home3compo/DynamicCRM.jsx
76bbacdbdc662e015fdd2ad047a52ad1eb8c6d9aff9121b6076dcb6c715c410d  client/src/components/home3compo/EducationData.jsx
d143955c9eb3ce30ce1fbf411b71da41da6a9448891d3d41e7ba13bd621fbbda  client/src/components/home3compo/FinalCTA.jsx
64937e08cc4abaf8205909240c485aff779031f5afb8ee43f63b8458a70bb350  client/src/components/home3compo/Footer3.jsx
9bd5fadf4c2fb4c0614b8c7565f8a9b08449f8c487f529636943387f36355e11  client/src/components/home3compo/Header3.jsx
906830852afcb558d923ed4f65d0137addc466242065ce8dbb43a646c85aca6a  client/src/components/home3compo/Hero.jsx
b4ad812a450525809221d61aed6d8667c4f6bb54b6c6a674619852238e799bf7  client/src/components/home3compo/HowItWorks.jsx
13ed3d64d16694aac64c3de6732b15ad58426fba301b7cfa37bf192b9e03b3bf  client/src/components/home3compo/LearnSection.jsx
d4f7d97c50084476d84ec0d79bfe60aa8028359ebbf440ce59eac00c58b84a2a  client/src/components/home3compo/MultiplierSection.jsx
daf12cc265217434f88cb0a3179009e763f487eb309b02f3b59571a68222a249  client/src/components/home3compo/NewFooter.jsx
049cac8f7d92d8c6bcecd3a4eda26b6f8220eb76741cab626a7cf13a5dea4653  client/src/components/home3compo/NewHeader.jsx
01c530772f31a23f2eeba0cb94bdcaee222414dd70e3c224d6b1b56e702cd987  client/src/components/home3compo/PlatformSection.jsx
2184064be1f0336e4d0c94ecdb26753dd275614bea5c9a7e29a979c8a800b865  client/src/components/home3compo/PricingSection.jsx
7c9c5c7a0696c3eb462a12d98f516c39bc8ee51a57298e4d1033a759f3a7bed6  client/src/components/home3compo/RevealAnimation.jsx
373646314de6180c87fe6c204df0d96111285fde67514f813a37962ab3d0c8e5  client/src/components/home3compo/TrustSignals.jsx
8691c0002cd977e13465769aab0da77e76d5b88870b17510231071222bb5e420  client/src/components/home3compo/useScrollReveal.js
b4346f5a81be40fbd2791e43c8b671f6ab713265f024459d0be278766a88c766  client/src/styles/capavate-tokens.css
```

### 9.2 Governance docs shipped in this package (full text included as files)
- `CAPAVATE_SACRED_FILES.md` — sacred tier list + full re-baseline history (old→new SHAs across all waves).
- `AVI_HAND_EDITS_INVENTORY.md` — Avi's manual fixes to preserve across every wave (home3compo hash-router href fix + reapply command).
- `CAPAVATE_LIVE_ENVIRONMENT.md` — full live-server env reference (Section 8 is the summary).
- `sacred_baseline/SACRED_SHA256.txt` — the machine-checkable manifest (Section 9.1 is a verbatim copy).

## 10. Verification discipline (always)
Every wave: build against the live baseline tree; additive + behavior-preserving; DB-driven (no in-memory/mock on prod paths); per-partner/tenant isolation is a fail-closed SECURITY boundary; single sacred money ledger (commitFunded) only; sacred 40/40 before+after; **triple-verify with Opus 4.8 + Gemini 3.1 Pro + GPT-5.5 (decider), NEVER ship on REVISE.** node_modules can't install in-sandbox → gates asserted by inspection here, executed on the server via the Gate Runbook.

---
*End of enhanced handover. Package contents: FULL_INSTALL + PATCH + RELEASE_BUNDLE + SHA256SUMS + this handover + fix report (md/pdf) + source diff + sacred docs + verifier reports.*
