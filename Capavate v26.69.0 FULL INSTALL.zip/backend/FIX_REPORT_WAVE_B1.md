# FIX REPORT — Wave B1 (Consortium Partner QA slide 3a: "Add Portfolio Company")

Builds on Wave A. Composes EXISTING non-sacred engines (no new engine, per Ozan's
note). All gates green (bottom). No new migration (all tables already exist).

## What B1 does
A Consortium Partner creates a genuinely net-new, INDEPENDENT Capavate company
from inside their own workspace:
- **Independent entity** — own `co_…` id + own subscription (Founder Free,
  auto-activated), created via the canonical `addCompanyForFounder` engine.
- **Founder-owned, not partner-owned** — the company owner is a deterministic
  `u_pending_founder_<hash(email)>` id, NEVER the partner user. The founder
  claims the account by email and only ever accesses their own company
  workspace, never the partner section (answers 3a-1 = b).
- **Tagged to the originating partner** — `linkConsortiumPartner(companyId,
  partnerId)` (durable `consortium_links`), fail-closed (500 on link failure).
- **In the partner Pipeline** — added at the `invited` stage, linked by
  companyId (non-fatal on failure).
- **Founder OWNER invite** — a `founder_team_invitations` row (role `owner`,
  pending) + a one-time `/auth/redeem?token=…` claim link returned to the
  partner. The founder redeems to claim ownership and finish the FULL company
  profile in Capavate's own builder (answers 3a-2 = same engine).
- **Native, no iframe** (3a-4 = native) — the create page renders inside the
  partner shell and inherits the reskin/session.
- **Attribution / referral** — attribution recorded; NO referral payout wired
  (3a-3 = a; payments stay untouched, rule #14).

## Files
- **New** `server/partnerPortfolioCompanyRoutes.ts` — `POST /api/partner/me/portfolio-companies`
  (managing_partner|associate|bd; requireSignedAgreement). Validates
  companyName + founder email; creates company (fail-closed 500 on persist);
  provisions subscription; links attribution (fail-closed 500); adds pipeline
  row; issues founder owner-invite (defensively ensures the invitations table).
- **New** `client/src/pages/partner/PartnerAddPortfolioCompany.tsx` — partner-shell
  create form + success panel with the copyable founder claim link.
- `server/routes.ts` — registers the new route after the SPV engine.
- `client/src/components/CollectiveShell.tsx` — new nav "Add Portfolio Company"
  directly under Pipeline.
- `client/src/App.tsx` — new route `/collective/partner/add-portfolio-company`
  (RequireAuth + CollectiveShell).
- `server/collectiveRoutes.ts` — the Collective company-detail endpoint now
  returns `profile.attributedPartner` ({ partnerId, name }) resolved read-only
  from `consortium_links` + `getConsortiumPartnerDisplayName`.
- `client/src/pages/collective/CollectiveDealRoomDetail.tsx` — renders a navy
  **"Led by <partner>"** badge on the company header when attributed
  (`badge-led-by-partner`). This is the primary, investor-visible attribution
  surface (answer 9 = all; cap-table/round + founder-dashboard placements are a
  small follow-up in B2 so each is verified separately).
- **New** `server/__tests__/waveB1_add_portfolio_company.test.ts` — 3 tests
  (validation, create+attribute+owner-invite, founder-owner isolation).
- **New** `server/__tests__/waveB1_adversarial_attribution_orphan.test.ts` — 1
  test (attribution failure rolls back the company, no orphan).
- `server/multiCompanyStore.ts` — new exported `rollbackFounderCompany` helper
  (compensating soft-delete + cache eviction; net-new tsc 0).

## Round 2 — fixes for GPT-5.5 (deciding) REVISE
Three data-integrity defects were found and fixed (Opus + Gemini APPROVED; GPT-5.5
decides per rule #7):
1. **Attribution failure left an orphan company.** Now REQUIRED + fail-closed
   WITH ROLLBACK — on `linkConsortiumPartner` failure the just-created company is
   compensating-soft-deleted (new `rollbackFounderCompany` in
   `multiCompanyStore.ts`: soft-deletes companies + company_members inside one tx
   and evicts the in-memory mirror) and the route returns 500. Proven by
   `waveB1_adversarial_attribution_orphan.test.ts` (forces attribution write to
   fail via a trigger; asserts 500 + company soft-deleted + no live membership).
2. **Defensive invitation-table ensure missing `sent_at`.** Now mirrors the real
   founderTeamStore schema (idempotent `ALTER TABLE … ADD COLUMN sent_at`).
3. **Owner-invite failure downgraded to a 201 with null invite.** The owner
   invite is now REQUIRED + fail-closed WITH ROLLBACK (undoes attribution +
   company, returns 500 FOUNDER_INVITE_FAILED). A 201 now ALWAYS carries a
   `founderInvite` claim link, so the client success toast is always accurate.

Order of operations is now: create company (fail-closed) → provision free sub
(non-fatal, derivable) → attribution (required, rollback) → owner-invite
(required, rollback) → pipeline (non-fatal, recoverable).

## Security / isolation
- Company ownership is the pending-founder id, never the partner (asserted in
  the test: owner id matches `u_pending_founder_*`, never the partner user).
- The founder claims via the existing `/auth/redeem` team-invite flow (account +
  password created on claim); the partner never sees the founder's credentials.
- Route is partner-auth + sub-role gated + requireSignedAgreement, same as other
  partner writes.

## Gates (end of B1)
| Gate | Result |
|---|---|
| Sacred files | **40/40** byte-identical (companyProfileStore.ts, subscriptionStore.ts etc. untouched) |
| Money core sha16 | **01cd36130ee1c0cb** (unchanged) |
| tsc `--noEmit` | **598** (net-new **0**) |
| Guard | **exit 0** — 925 routes / 194 pages / 92 nav (new route + page + nav are informational adds) |
| Build | **OK** |
| New `require()` in server TS | none (ESM only) |
| Payments / Airwallex | untouched |
| Migrations | none (all tables pre-exist) |
| Tests | B1 4/4 (incl. adversarial rollback), Wave A 4/4, SPV canonical 9/9 (17/17) |

## Addendum — "Led by [Partner]" on ALL surfaces (answer 9 = all)
Completed at Ozan's request ("finish now"). The badge now renders on all four
surfaces. Because the founder company-profile endpoint (`profileStore.ts`) is
SACRED and cannot be edited, the founder surfaces read attribution from a NEW
additive, read-only endpoint instead of that sacred payload.
- **New** `server/companyAttributionRoutes.ts` — `GET /api/companies/:id/attribution`
  (`requireAuth`), returns `{ attributedPartner: { partnerId, name } | null }`
  resolved read-only from `consortium_links` + `getConsortiumPartnerDisplayName`.
  Never fails the page (returns null on error). Registered in `routes.ts`.
  **IDOR hardened (GPT-5.5 deciding REVISE, round 2):** attribution for a
  PRIVATE (unpublished) company is returned ONLY to (a) admins, (b) the
  company's founder/team, (c) members of the LINKED Consortium Partner, or
  (d) when the company is actually listed in the Collective (public). Any other
  authenticated user gets `attributedPartner: null` — no leak of who leads a
  private company. Proven by the IDOR test below.
- `client/src/pages/founder/Dashboard.tsx` — "Led by" badge on the founder hero.
- `client/src/pages/founder/CapTable.tsx` — badge in the cap-table header.
- `client/src/pages/founder/RoundDetail.tsx` — badge in the round header.
- (Collective company profile badge was already done in the main B1 pass.)
- **New** `server/__tests__/waveB1_company_attribution.test.ts` — 4 tests
  (auth-guarded with dev-bypass disabled; null when unattributed; resolves the
  partner for the LINKED partner member; does NOT leak a private company's
  attribution to an unrelated user). Full suite now 21/21.

Gates after addendum: sacred **40/40**, money **01cd36130ee1c0cb**, tsc **598**
(net-new 0), guard **exit 0** (926 routes / 194 pages / 92 nav — new GET is an
informational add), build OK.

## Open (for B2, not built here)
- B2 proper: two parallel process-box rows (companies + SPVs), Make-Private /
  Publish-to-Collective toggles, Following-from-Collective card restyle.
