# VERDICT: APPROVE

The C3 wave accurately implements Shadie 2a (exact-HTML invite preview) and 7a (round-name per-company uniqueness) per the verify brief.

## Gates
* tsc count: 598 (exact match)
* sacred checksum: 40/40 OK
* money captableCommitStore sha16: 01cd36130ee1c0cb
* guard script: exit 0 (929 routes, 194 pages, 92 nav)
* vitest tests: 7 tests for C3 passed, no regressions in existing round tests
* no sacred file changes confirmed via diff --name-only

## Review Confirmation
### 2a - Exact-HTML Preview
* `renderInvitationEmail` is correctly created and used by both the actual sending logic (`createInvitation`) and the new preview routes.
* Both endpoints (`/api/rounds/:id/invitations/preview` and `/api/companies/:companyId/invitation-preview`) are ownership-gated.
* Both endpoints are READ-ONLY: they do not send an email, create rows, or mint tokens. They only return the exact HTML and a placeholder link.
* The company-scoped preview accurately takes `roundName` from the request body (client-provided) but `renderInvitationEmail` escapes it via `e()`.
* Note escaping and inclusion confirmed via the template interpolations and test coverage.
* Client-side accurately collects the optional `note` and previews via the endpoints in both `RoundDetail.tsx` and `RoundNew.tsx`.
* Note persistence round-trips via existing columns.

### 7a - Per-Company Scope Round Uniqueness
* `roundNameExistsForCompany` accurately checks same-company only by comparing using `getRoundsForCompany` and case-insensitivity.
* `suggestUniqueRoundName` correctly handles collision generation.
* The store `createRound` is fail-closed, throwing `ROUND_NAME_REQUIRED` and `ROUND_NAME_DUPLICATE` errors prior to generating an ID or DB commit.
* Route handler catches the duplicate and correctly surfaces 409 + suggestion.
* `GET /api/rounds/name-availability` added to help client auto-fill.
* Confirmed cross-company test works.
* No DB migrations detected.
