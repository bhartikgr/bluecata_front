# Verdict for Wave C1

1. VERDICT: REVISE

2. Gate results:
- tsc net-new = 0 -> exactly 598
- Sacred 40/40 byte-identical
- Money `server/captableCommitStore.ts` sha16 `01cd36130ee1c0cb`
- Guard exit 0, counts UNCHANGED (926 / 194 / 92)
- Server tests run cleanly.

3. Per-check confirmation or defect:
- **No re-notification of a revoked investor:** CONFIRMED. `revokeInvitation` in `server/roundInvitationsStore.ts:840` throws `ALREADY_REVOKED` before DB operations. Tests confirm no re-emailing.
- **Fail-closed ordering:** CONFIRMED. Guards run at the very top of `revokeInvitation`, `extendInvitation`, and `resendInvitation` in `server/roundInvitationsStore.ts`, prior to persistence or token mutation.
- **Persist-first semantics preserved:** CONFIRMED. DB changes are applied before emitting cache updates in `roundInvitationsStore.ts`.
- **6a sort:** CONFIRMED. `client/src/pages/founder/Rounds.tsx:159-165` sorts a copy using `[...(rounds.data ?? [])].sort(...)`, falls back to 0 if missing, and uses id tiebreak. The `Round` type in `Rounds.tsx` includes `createdAt?: string | null`.
- **No behavioral regression:** CONFIRMED. Normal paths function.

- **DEFECT 1 (3a/4a/5a client guards):** `client/src/pages/founder/RoundDetail.tsx` failed to disable buttons for terminal states as explicitly required by the brief ("resend disabled for accepted|revoked; extend disabled for revoked|accepted; revoke disabled for revoked."):
  - **client/src/pages/founder/RoundDetail.tsx:528:** Resend is missing revoked guard.
    - *Current:* `disabled={resendMut.isPending || i.state === "accepted"}`
    - *Fix:* `disabled={resendMut.isPending || i.state === "accepted" || i.state === "revoked"}`
  - **client/src/pages/founder/RoundDetail.tsx:529:** Extend is missing accepted and revoked guards.
    - *Current:* `disabled={extendExpiryMut.isPending}`
    - *Fix:* `disabled={extendExpiryMut.isPending || i.state === "accepted" || i.state === "revoked"}`
  - **client/src/pages/founder/RoundDetail.tsx:530:** Revoke is missing revoked guard.
    - *Current:* `<Button size="sm" variant="ghost" onClick={() => setRevokeId(i.id)} ...>`
    - *Fix:* add `disabled={i.state === "revoked"}` to the Button.
  
- **DEFECT 2 (6a Client Round type consistency):** While `Rounds.tsx` was correctly updated, `client/src/pages/founder/RoundDetail.tsx` (lines 38-53) defines its own `Round` type without `createdAt`. 
  - **client/src/pages/founder/RoundDetail.tsx:50:** 
    - *Fix:* Add `createdAt?: string | null;` to the `Round` type.
