# W-AVI65 — Fix Wave Result

Tree: `/home/user/workspace/capavate_avi65_build` (live ai65 / v26.2.0 / wavi64 base).
Verification method: careful code inspection against in-tree conventions
(`node_modules` is not installed in this environment, so `npm` / `tsc` / `vitest`
were deliberately NOT run — as instructed). `sha256sum` WAS run.

**SACRED BASELINE: 40/40 OK.** `sha256sum -c sacred_baseline/SACRED_SHA256.txt` →
40 lines, all `: OK`, zero failures. No sacred file was opened for writing.
**Avi hand-edits: PRESERVED.** `scripts/verify_avi_preserved.sh` → `PASS: no
Avi-preserved-edit regressions`; `grep 'href="#/'` and
`grep '"https://capavate.com/#/'` in `client/src/components/home3compo/` → 0 hits.

---

## Files changed

### New files (5)

| File | Purpose |
|---|---|
| `server/lib/dmCoMembership.ts` | FIX 2 — caller-side DM co-membership predicate (founder↔investor), wrapping the SACRED investor↔investor helper unchanged. |
| `server/__tests__/wavi65_round_owner.test.ts` | FIX 1 — owned-round PATCH succeeds; cross-tenant PATCH/GET denied. |
| `server/__tests__/wavi65_admin_search.test.ts` | FIX 3 — founder finds own company; cross-tenant search denied; client + server shape contracts. |
| `server/__tests__/wavi65_dm_comember.test.ts` | FIX 2 — co-member name resolves; non-co-member and opted-out mask. |
| `server/__tests__/wavi65_bridge_env.test.ts` | FIX 4 — self-loop URL + equal-secrets contract. |

### Edited files (9) — all NON-sacred

| File | Change |
|---|---|
| `server/lib/roundInitialShareholdersStore.ts` | FIX 1 — DB-direct round→company resolution + fail-closed ownership gate on PATCH **and** GET. |
| `server/founderSearchStore.ts` | FIX 3 — added a tenant-scoped `company` search surface + `company` count. |
| `server/adminV25Store.ts` | FIX 3 — `/api/admin/search` now also emits the flat `results[]` shape the header box renders (additive). |
| `client/src/components/AppShell.tsx` | FIX 3 — `GlobalSearch` is role-aware: admin → `/api/admin/search`, else `/api/founder/search`. |
| `server/commsStore.ts` | FIX 2 — DM-aware `isCoMember` + DB-resolved `legalName`. |
| `server/index.ts` | FIX 4 — hoisted `hydrateBridgeStore()` + `hydrateDurableMaps()` out of the outbound gate. |
| `.env.example` | FIX 4 — corrected bridge block + equal-secrets rule. |
| `CAPAVATE_LIVE_ENVIRONMENT.md` | FIX 4 — §1 corrected (dead host → self-loop) + hydrate note. |
| `DEPLOY_FOR_AVI.md` | FIX 4 — corrected live block + equal-secrets warning. |
| `server/__tests__/wavi64_bridge_env.test.ts` | Removed the stale `collective.capavate.com` fixtures (3 sites). |

---

## FIX 1 — Round wizard PATCH returned 403 `not_round_owner`

**LIVE ENDPOINT TARGETED:** `PATCH /api/founder/rounds/:roundId/initial-shareholders`
— the exact request captured failing on the live site (403
`{"ok":false,"error":"not_round_owner"}`) while `POST /api/rounds/:id/invitations`
returned 200 for the *same* founder + round + company. **Not a dead path:** this
is the round wizard's own save call; the 403 body in the capture is emitted by
exactly one line in the tree (`roundInitialShareholdersStore.ts`), which is the
file changed.

**Root cause.** `callerOwnsRound()` resolved the round through a LAZY
`require("../roundsStore")` (the `createRequire(import.meta.url)` shim at the top
of the file). In the production CJS bundle (`dist/index.cjs`) that specifier does
not resolve → `round = null` → `companyId` undefined → ownership `false` → 403 on
**every** call. The working POST path uses a STATIC import
(`routes.ts:220`, `getRoundById as roundsStoreGetById`) and therefore succeeded.
Independent corroboration already in-tree:
`server/__tests__/v2348_round_initial_shareholders.test.ts:34-40` documents that
this same require throws `Unexpected token ':'` in an isolated harness, which is
why that suite had to use `u_admin` to bypass the gate entirely.

A **second** latent failure mode existed: `roundsStore.getRoundById` reads the
in-memory `ROUNDS_BY_ID` map, so under PM2 cluster mode a round created by one
worker is invisible to another → the same spurious 403.

**Change.** Ownership no longer depends on the fragile require. The round's
company is read DB-direct through the `rawDb` handle this file already imports
**statically** (so it cannot fail to resolve in the bundle), using the exact
convention already used inside `roundsStore.ts:375/418`:

```sql
SELECT company_id FROM rounds WHERE id = ? AND deleted_at IS NULL LIMIT 1
```

The lookup is **tri-state** (`{ok:true, companyId}` / `{ok:true, companyId:null}` /
`{ok:false}`) so "no such round" and "the read failed" are distinguishable — that
distinction is what makes the gate fail-closed. `resolveRoundOwnership()` then:

- **round's company resolved** → ownership is EXACTLY
  `resolvedCompanyId ∈ ctx.founder.companies`. A client-supplied `body.companyId`
  can never override or widen this.
- **no row anywhere AND the DB read succeeded** → accept `body.companyId` only if
  the founder owns that company (a brand-new wizard round belongs to no tenant,
  so this cannot reach another tenant's data).
- **the DB read FAILED** → deny. `body.companyId` is not trusted, because the
  round might really belong to another tenant and we have no proof either way.

The lazy require is retained only as a **non-authoritative secondary**
(`roundCompanyIdFromStoreCache`) for seed rounds present in the store cache but
not in the `rounds` table — it is consulted after the DB and can only ever add a
*resolved* company id, which is then subjected to the same `∈ ctx.founder.companies`
test. Admin still bypasses. `effectiveCompanyId` (always an owned id) is threaded
into the CRM upsert, the existing invitation loop, and the audit row.

**Also hardened:** the GET twin (`GET /api/founder/rounds/:roundId/initial-shareholders`)
had **no ownership gate at all** — any authenticated user could read any round's
shareholder names and emails. It now uses the same `resolveRoundOwnership()`. A
grep confirmed zero client callers, so no live surface is dropped.

**Zero in-memory canonical state:** the authority is now the `rounds` table.

**SECONDARY (read path) — noted, NOT changed.** The investor's round visibility is
served by `buildInvitedRounds` in SACRED `server/lib/userContext.ts`, which
hydrates `RUNTIME_INVITATIONS` only when the map is **empty** (L342) — a
stale-cache bug: an invitation created after the map was first populated is not
picked up until a fresh context/login. `createInvitation` already DB-persists the
invitation, so a fresh context does hydrate it. See the STOP list.

---

## FIX 3 — Admin/global header search returned nothing

**LIVE ENDPOINT TARGETED:** the header box fires `GET /api/founder/search?q=…`
(confirmed in the capture, returning `{"results":[],"counts":{round:0,contact:0,file:0}}`).
`GET /api/admin/search` had **zero** client callers — the previous wave fixed a
dead endpoint. Both ends are addressed here, and the client is now wired to the
admin endpoint so it stops being dead.

**Root causes (two).**
1. `/api/founder/search` scopes to `getCompaniesForFounder(userId)`, which is
   **empty for an admin** → `searchFounderWorkspace([], q)` short-circuits to `[]`.
2. It never searched `companies` at all (only rounds / investor CRM contacts /
   dataroom files), so even a real **founder** typing their own company or
   workspace name got "No matches".

**Changes.**

*Client* (`AppShell.tsx` `GlobalSearch`): the endpoint is now chosen by role —
`isAdmin` → `/api/admin/search`, else `/api/founder/search`. `isAdmin` comes from
`useEntitlement()` (fed by `/api/auth/me`), which is the **authoritative** signal;
`useRole()` was deliberately *not* used because it is local UI state that defaults
to `"founder"` and would mis-route admins. The chosen path is part of the
react-query key, so a role change refetches instead of serving a stale cache. The
render loop is unchanged — both endpoints now return
`results[] { kind, id, title, subtitle, href }`.

*Server, founder path* (`founderSearchStore.ts`): added a 4th surface over
`companies`, matching **both** `name` and `legal_name` — the live workspace label
("`<Founder>'s Workspace`") is persisted into both columns by
`paymentGatewayAdapter.ts:623-624`, and that is exactly the string users type.
Scoping is unchanged and strict: `id IN (${placeholders})` where the placeholders
are bound from `getCompaniesForFounder(userId)`, plus `deleted_at IS NULL`. The
existing `likeTerm()` wildcard escaping and `ESCAPE '\\'` parameterized SQL are
reused verbatim. `SearchHit.kind` gained `"company"`; `counts` gained `company`
in both the empty-state and the real branch. href is `/founder/companies/:id`
(verified against `client/src/App.tsx:636`).

*Server, admin path* (`adminV25Store.ts`): `/api/admin/search` is `requireAdmin`
(unchanged) but only ever returned the four typed buckets
`{founders, investors, partners, collective_members}` — not a shape the header box
can render. It now **additionally** emits a flat `results[]` projection with kinds
`company` / `investor` / `partner` / `member`, plus `ok`, `query` and `counts`.
Purely additive: all four original keys are still returned untouched, so no
existing consumer breaks. Company hits already match `legal_name` via the
W-AVI64 `getAllCompaniesFromDb()` union. hrefs verified against `App.tsx`:
`/admin/companies/:id` (708), `/admin/investors` (720), `/admin/partners` (735),
`/admin/collective/members` (891 — note `/admin/collective` is *not* a route).

**No cross-tenant leak:** the founder surface never drops the `companyIds` scope;
the admin surface is behind `requireAdmin`.

---

## FIX 2 — Founder↔Investor DM showed "Private Investor"

**LIVE ENDPOINT TARGETED:** `GET /api/comms/channels` → `displayTitle`, which the
Messages UI renders. That value is produced by `commsStore.projectChannel` →
`resolveIdentity` — the functions changed.

**Root cause.** The masking happens at SACRED
`server/lib/userPrivacyResolver.ts:222-224`: for the `message` context it returns
`"Private Investor"` whenever `opts.isCoMember !== true`. `commsStore` computed
that flag with SACRED `areCoMembersOnAnyCapTable()`, which self-joins
`captable_commits` requiring **both** sides to be an `investor_id` — an
investor↔investor-only rule. A founder is never an `investor_id` row on their own
cap table, so a founder **never** qualified. Compounded: `COMMS_USERS` is `{}` in
production (`commsStore.ts:250`), so the `legalName` handed to the resolver
degraded to a raw `u_…` id.

**Change.** New NON-sacred `server/lib/dmCoMembership.ts` exporting
`areDmCoMembers(a, b)`, true when ANY of:

1. `a` is an **active** `company_members` row with role `founder`/`co_founder`
   (`is_active = 1 AND deleted_at IS NULL`) for a company on whose
   `captable_commits` `b` holds a `state='committed'`, non-deleted row;
2. the reverse;
3. `areCoMembersOnAnyCapTable(a, b)` — the SACRED helper, **called unchanged**.

Parameterized SQL, read-only, fail-closed `false` on self-pairs, malformed ids,
missing tables, or any error. Because the sacred rule is one of the disjuncts,
this can only ever *add* true cases.

In `commsStore.resolveIdentity` an optional `opts { dm?: boolean }` selects the
predicate: `dm === true` → `areDmCoMembers`, otherwise the exact legacy call. `dm`
is passed from the DM channel projection (`projectChannel`), the channel's
`lastMessage` (`dm: channel.kind === "dm"`) and `projectMessage`
(`dm: channel?.kind === "dm"`). Every non-DM surface is byte-for-byte unchanged in
behavior.

Real names: a new `dbLegalNameFor()` resolves `legalName` through
`server/lib/displayNameResolver.ts` (users → credentials → userContext) when
`COMMS_USERS` lacks the user, and only when the resolver reports `resolved` and
the value is not a raw `u_…`. It is passed **only** into the `resolveDisplayName`
call; the fallback `UserRef` is not mutated, so `resolveDisplayIdentity`'s other
branches are untouched. If nothing resolves, the raw id is kept as before so the
existing `sanitizeCommsName` / resolver fallbacks ("Invited contact") still apply
— a raw id is never surfaced.

**Leak guarantees (all hold, all covered by negative tests).**
- The `visibleToCoMembers` opt-out is evaluated at resolver L222, **before** the
  `isCoMember` check at L223. Widening `isCoMember` therefore cannot unmask an
  opted-out subject. Not bypassed.
- Non-co-members (founder↔founder cold DM, cold outreach, a founder of a
  different company) still get `"Private Investor"`.
- Co-membership is **never** derived from "a DM channel exists" or from
  `canDM` / privacyMode — only from durable `company_members` + `captable_commits`
  rows.
- Resolved per `(viewer, counterparty)` per request. Nothing is cached on the
  thread or channel row.
- Non-committed holdings, inactive members, soft-deleted members and non-founder
  roles all fail the predicate.

---

## FIX 4 (BRIDGE) — config + hydrate hoist

**LIVE STATE TARGETED:** 568 queued / 0 delivered / audit chain broken.

**Root causes.**
- (a) The documented receiver was `https://collective.capavate.com/api/bridge/inbox`
  — **that host does not exist.** The Collective is the same app on the same
  domain (`capavate.com/collective`); the inbound route is `/api/bridge/inbound`.
  So the bridge is a **self-loop** back to capavate.com.
- (b) **HMAC mismatch.** Outbound signs with `COLLECTIVE_WEBHOOK_SECRET`
  (SACRED `server/lib/bridgeRuntime.ts:90`); inbound verifies with
  `BRIDGE_INBOUND_HMAC_SECRET ?? BRIDGE_HMAC_SECRET ?? <hardcoded default>`
  (`server/bridgeStore.ts:295-301`) and **never** consults
  `COLLECTIVE_WEBHOOK_SECRET`. For a self-loop the two must be equal, or every
  self-POST 401s and dead-letters.
- (c) `hydrateBridgeStore()` and `hydrateDurableMaps()` were nested **inside** the
  `maySendOutboundBridge()` outbound gate (`server/index.ts:431-452`), so with
  outbound disabled or misconfigured — the actual live state — the durable maps
  and the outbox were never rehydrated on boot, even though
  `/api/bridge/inbound` dispatches into those maps regardless of send permission.

**Changes.**
- `server/index.ts`: both hydrators are hoisted out of the gate and now run
  unconditionally at boot (read-only, idempotent, each already wrapped in its own
  non-fatal try/catch). Only `startBridgeWorker()` remains behind the outbound
  gate, so the HIGH-8 "no 501 storm / no DLQ pileup" contract is preserved
  verbatim. SACRED `bridgeRuntime.ts` untouched.
- `.env.example`, `CAPAVATE_LIVE_ENVIRONMENT.md` §1, `DEPLOY_FOR_AVI.md`: the
  corrected block below, with the equal-secrets requirement stated explicitly and
  the reason (which file reads which name) cited inline.
- The `chain broken @0` condition is **not** auto-rewritten. Recorded as a
  follow-up requiring an admin-gated, non-destructive re-verify.

### The exact `.env` block for the live box

```dotenv
BRIDGE_ENABLED=1
COLLECTIVE_WEBHOOK_URL=https://capavate.com/api/bridge/inbound
COLLECTIVE_WEBHOOK_SECRET=<secret>
BRIDGE_INBOUND_HMAC_SECRET=<SAME secret as COLLECTIVE_WEBHOOK_SECRET>
COLLECTIVE_APP_URL=https://capavate.com/collective
```

> ⚠ `BRIDGE_INBOUND_HMAC_SECRET` **must equal** `COLLECTIVE_WEBHOOK_SECRET`.
> This is not optional for the self-loop topology: outbound signs with the former
> name, inbound verifies with the latter. Different values → every event 401s and
> dead-letters. Generate with `openssl rand -hex 32`; placeholder values
> (`YOUR_STRONG_SECRET`, `changeme`, …) are rejected by `isPlaceholderSecret()`.

---

## New tests

All four use in-tree conventions (`vitest`, `express()` + the store's own
`registerXRoutes(app)`, `supertest`, `x-user-id`, `registerFounderUser` +
`addCompanyForFounder`, `rawDb()` for DB-direct seeding). They were written by
inspection and **not executed** (`node_modules` unavailable, per instructions).

**`server/__tests__/wavi65_round_owner.test.ts`**
- A REAL (non-admin) founder PATCHing a round their company owns → 200, row
  persisted, and explicitly `not.toBe(403)`.
- The DB is asserted to be the authoritative resolver even though the lazy
  `require("../roundsStore")` may fail in this runtime — the simulation of the
  bundle failure that the spec asked for.
- NEGATIVE: founder B (different tenant) → 403 `not_round_owner`, and nothing
  written.
- NEGATIVE: a lying `body.companyId` (a company the caller *does* own) cannot
  override the round's real owner → still 403.
- NEGATIVE: unknown round + an unowned `companyId` → 403.
- NEGATIVE: the GET twin is ownership-gated — owner 200, other tenant 403.

**`server/__tests__/wavi65_admin_search.test.ts`**
- A founder finds their own company by `name` and by `legal_name`; href points at
  a route that exists.
- NEGATIVE: founder B cannot match founder A's company and vice-versa.
- NEGATIVE: an empty company scope (an admin on the founder endpoint) matches
  nothing — the precise reason the admin box had to move.
- NEGATIVE: user-typed `%` / `_` are escaped, not honoured as wildcards.
- Client contract: `GlobalSearch` references both paths, uses `useEntitlement()`
  and **not** `useRole()`, and keys the query on the chosen path.
- Server contract: `/api/admin/search` is `requireAdmin`, emits `results` with a
  `company` kind, and still returns `collective_members` (additive).

**`server/__tests__/wavi65_dm_comember.test.ts`**
- Founder ↔ committed holder is a co-member, symmetrically; the investor↔investor
  sacred rule still holds and is one of the disjuncts.
- Regression anchor: `areCoMembersOnAnyCapTable(founder, holder)` is still
  `false` — proving the sacred helper was not changed.
- A co-member founder resolves the investor's real name in the `message` context.
- NEGATIVE: stranger → `"Private Investor"`; founder↔founder cold DM → not a
  co-member; a founder of a different company gets nothing.
- NEGATIVE: an **opted-out** investor stays `"Private Investor"` even when
  `isCoMember` is genuinely true.
- NEGATIVE: self-pairs, empty/whitespace/undefined ids, `state='pending'`
  holdings, `is_active = 0`, `deleted_at` set, and a non-founder role all → false.
- Wiring contract: `areDmCoMembers` is used only for `opts?.dm === true`, the DM
  projection passes `{ dm: true }`, and `dbLegalNameFor` is used for the name.

**`server/__tests__/wavi65_bridge_env.test.ts`**
- `https://capavate.com/api/bridge/inbound` + a real secret → `hasRealReceiver()`
  true; the full prescribed block → `maySendOutboundBridge()` true.
- Asserts the URL's host/path and that it does not contain
  `collective.capavate.com`.
- The equal-secrets contract: the outbound-signing secret equals the inbound
  verifying secret under the prescribed block. The inbound resolution is
  **duplicated, not imported**, so the test pins the contract and cannot be
  silently satisfied by a change to the outbound guard.
- NEGATIVE: setting only `COLLECTIVE_WEBHOOK_SECRET` leaves inbound on the
  hardcoded default → mismatch → the confirmed live 401 failure.

**Updated:** `server/__tests__/wavi64_bridge_env.test.ts` — the three
`https://collective.capavate.com/api/bridge/inbox` fixtures (L53, L55, L104) now
use the real self-loop URL, so no test enshrines the dead hostname. The
assertions themselves (canonical-wins, alias fallback, placeholder rejection) are
unchanged.

---

## STOP list — wanted sacred edits, NOT made

1. **`server/lib/userContext.ts` (SACRED) — `buildInvitedRounds` stale-cache
   union.** `RUNTIME_INVITATIONS` is hydrated from the DB **only when the map is
   empty** (L342). Once any invitation is in the map, a *newly* DB-persisted
   invitation is not picked up until the process restarts or a fresh context is
   built, so an investor may not see a round they were just invited to. The
   correct fix is a **union** (always merge DB rows into the map instead of
   gating on emptiness). This requires editing a sacred file, so it was **not**
   done. Requested as a future owner-authorized sacred edit. Current mitigation:
   `createInvitation` DB-persists the invitation, so a fresh context/login does
   hydrate it, and FIX 1 ensures the invitation is actually created.

2. **Bridge audit chain `broken @0`.** Not auto-repaired — the chain math lives in
   SACRED `bridgeRuntime.ts`. Recommend an admin-gated, **non-destructive**
   re-verify endpoint rather than any rewrite of the ledger.

Nothing else required a sacred edit; no sacred file was hacked around.

---

## Rule compliance

| Rule | Status |
|---|---|
| SACRED files byte-identical | ✅ `sha256sum -c` → 40/40 OK |
| Additive + behavior-preserving | ✅ new surfaces/params are additive; every non-DM identity path and all four admin-search buckets unchanged |
| DB-driven, zero in-memory canonical state | ✅ FIX 1 authority is the `rounds` table; FIX 2 predicate reads `company_members` + `captable_commits`; FIX 3 reads `companies`; FIX 4 restores durable hydration |
| Fail-closed isolation (no cross-tenant, no identity leak) | ✅ FIX 1 denies on a failed read and never lets `body.companyId` override; FIX 3 keeps the `companyIds` scope; FIX 2 fails closed and cannot bypass the opt-out |
| Money only via `commitFunded` | ✅ untouched — `captable_commits` is only ever READ |
| Never silent-drop routes/pages/nav | ✅ no route removed; the previously ungated GET is kept (now gated) and has zero client callers |
| Preserve Avi hand-edits | ✅ `verify_avi_preserved.sh` PASS; `home3compo/` not touched |
| Every fix targets a live-confirmed endpoint | ✅ FIX 1 `PATCH /api/founder/rounds/:id/initial-shareholders`; FIX 3 `GET /api/founder/search` (+ the admin endpoint the client now actually calls); FIX 2 `GET /api/comms/channels` → `displayTitle`; FIX 4 the live bridge config + boot path |

---

## AUTHORIZED SACRED EDITS (owner-approved, applied AFTER the subagent wave)

### `server/lib/userContext.ts` — buildInvitedRounds stale-cache UNION (STOP item #1, now DONE)
Owner explicitly authorized this sacred edit ("Include the sacred userContext.ts edit now"). Two sites changed, both additive + behavior-preserving:
- **Block A `buildInvitedRounds` (~L334):** dropped the `(!runtimeInvs || runtimeInvs.length===0)` "hydrate only when empty" gate; now UNIONs durable `listInvitationsByEmail(persona.email)` rows into RUNTIME_INVITATIONS on EVERY call, deduped by invitationId (existing cache entries win on collision → nothing already-shown mutates).
- **Block B persona-synthesis (~L888):** dropped the `existingInvs.length===0 && isInvestor` gate; same UNION-by-invitationId. `isInvestor` remains used downstream (persona build L935-936) so no orphaned var.
- **Isolation:** invitations are keyed by the user's OWN email; unresolved/other-state rows still dropped (no over-inclusion, no cross-tenant). Fail-closed: any DB error falls through to the existing cache (legacy behavior).
- **Why:** fixes Avi's "already on the platform → new round invisible until restart" — the DB is the source of truth; the cache is a write-through projection (honors the zero-in-memory-canonical-state rule).

**Sacred re-baseline (owner-authorized):**
- file: `server/lib/userContext.ts`
- OLD sha256: `d75d1321b66f1e6ce767c2517eedbbcaceb3b584370438f7507dc27320a8f6b4`
- NEW sha256: `51fa56b6b1758bda5cc95402fb216b7aa2e031981557a28eeb277dc26ca9e7ed`
- `sacred_baseline/SACRED_SHA256.txt` updated in place; gate re-verified **40/40 OK** (only userContext.ts hash changed; 39 others byte-identical).

STOP item #2 (bridge chain `broken @0` re-verify) remains deferred — needs an admin-gated non-destructive re-verify endpoint, not a ledger rewrite.

---

## REVISE ROUND 1 — triple-review blockers fixed (both non-sacred)

The mandatory triple-review returned **REVISE** from BOTH Opus and Gemini (no ship-on-REVISE). Two distinct blockers, both fixed:

### BLOCKER A (Opus) — FIX 1 soft-deleted-round isolation gap [server/lib/roundInitialShareholdersStore.ts]
`roundCompanyIdFromDb` filtered `deleted_at IS NULL`, so a SOFT-DELETED round of tenant A returned no row → indistinguishable from a nonexistent round → the `body.companyId` branch let tenant B write shareholder rows against tenant A's round id. FIX: the round→company query no longer filters `deleted_at` and returns an `exists` flag; `resolveRoundOwnership` now trusts `body.companyId` ONLY when the round id is GENUINELY absent (`db.exists === false && cached === null`). A soft-deleted foreign round now resolves its real owner → ownership denied (403). Regression test added (founder B blocked from tenant A's soft-deleted round).

### BLOCKER B (Gemini) — FIX 2 email-as-display-name identity leak [server/commsStore.ts]
`dbLegalNameFor` rejected only `/^u_/`, but `displayNameResolver` returns the user's EMAIL as `.name` (resolved:true) when no legal name exists → the email became the DM `displayTitle` (a NEW leak; the pre-fix raw `u_` id was masked). FIX: `dbLegalNameFor` now rejects any value containing `@` or a raw-id prefix — matching the sibling `resolveCommsDisplayName`'s "NEVER returns an email" contract. Regression assertion added.

**Sacred gate after REVISE: 40/40 OK** (both revised files are non-sacred; no new sacred edit). Correction to an earlier line in this doc: this wave DOES change exactly one sacred file — `server/lib/userContext.ts` — under explicit owner authorization (see AUTHORIZED SACRED EDITS above); all other 39 sacred files remain byte-identical.

New/updated tests this round: `server/__tests__/wavi65_revise_blockers.test.ts` (both blockers), `server/__tests__/wavi65_invited_rounds_union.test.ts` (the authorized union edit).
