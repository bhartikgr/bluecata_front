# Capavate v25.48.3 — SANDBOX RECOVERY / CONTINUATION PROMPT
### (Copy this ENTIRE document as the first message into a new task if this sandbox fails or is lost.)

> **You are resuming a production fintech fix wave for Capavate (founder/CEO: Ozan Isinak).**
> Read this document start-to-finish before doing anything. It is written so that a fresh
> session with ZERO prior context can reproduce or finish the v25.48.3 fix wave correctly.
> Do not guess. When a business/logic question is genuinely ambiguous, ASK Ozan — he has
> explicitly said: "IF YOU HAVE TO, ASK LOGIC/BUSINESS QUESTIONS AS I DO NOT WANT YOU TO MAKE
> ASSUMPTIONS THAT MAY LEAD TO A WRONG BUILD."

---

## 0. THE ONE-PARAGRAPH SUMMARY
v25.48.3 is a fix wave on top of the live v25.48.2 build (live at https://capavate.com). All
Q-code fixes are IMPLEMENTED, all gates pass, and the wave was TRIPLE-VERIFIED to a unanimous
SHIP (GPT-5.5 SHIP + Opus 4.8 SHIP + Gemini 3.1 Pro SHIP, 0 blockers; GPT-5.5's verdict
OVERRIDES). It has been PACKAGED (FULL + PATCH zips, SHA256SUMS, CHANGELOG, README for Avi,
Sacred Files manifest, Q2 audit doc). What remains are three items that require OZAN'S EXPLICIT
SIGN-OFF and were intentionally NOT done: (1) approve the V2-S1 marketing sentence; (2) live QA
data cleanup; (3) clear the Q2 audit banner. If you are recovering because the sandbox died mid-way,
re-establish the build tree and re-run the gates FIRST (Section 5), then continue from Section 8.

---

## 1. WHO / CONTEXT
- **User:** Ozan Isinak — founder/CEO of Capavate (fintech platform: cap table, funding rounds,
  founder/investor CRM, the "Collective", "Consortium Partners", SPV admin). Timezone
  America/Toronto. Advanced dev; runs multi-timezone (Canada / India / Hong Kong).
- **Avi:** the deploy engineer who installs releases on the live GoDaddy server. Packages go to
  Avi via WhatsApp (Gmail strips zips). Avi authored some Tier-2 "sacred" code.
- **Runtime:** Node 20 (v20.20.1) + tsx (ESM). pm2 runs the TypeScript SOURCE directly on live
  (`pm2 restart backend`); there is no separate compiled-JS deploy step for the patch path.
- **Live site:** https://capavate.com. It was updated the night before 2026-07-03 and is now on
  v25.48.2. Ozan's standing rule: "IF IT WORKS ON THE LIVE SITE, ALL GOOD" and "VERIFY THE LIVE
  SITE AGAIN BEFORE MOVING FORWARD." Sandbox-green is necessary but NEVER sufficient.

---

## 2. NON-NEGOTIABLE STANDING RULES (violating any = DO-NOT-SHIP)
These come from the handoff docs and the canonical `CAPAVATE_SACRED_FILES.md` manifest.
1. **39 sacred files must stay BYTE-IDENTICAL.** Never edit them. Verify before AND after every
   change against `sacred_baseline/SACRED_SHA256.txt` (see Section 5 for the exact command).
2. **No new `require()` in server TS.** Use static `import` or `await import(...)` only. (Four
   pre-existing lazy `require()` shims already exist in `server/multiCompanyStore.ts` — leave them;
   add ZERO new ones.)
3. **Migrations additive + idempotent** vs a COPY of the live `data.db`. Never destructive ALTER,
   never DROP. New columns nullable or defaulted. `CREATE TABLE IF NOT EXISTS`.
4. **Fail-closed** on money / auth / cap-table / durability. **Zero in-memory canonical state** —
   Maps may be a cache, but the DB is authoritative and must survive a restart. Mirror caches to
   memory ONLY after the DB write commits.
5. **tsc error budget ≤ 611, ZERO net-new.** Baseline is exactly **601**. If tsc reports anything
   other than 601, you introduced errors — fix them (all 601 baseline errors are pre-existing and
   NOT in the files this wave touched).
6. **Tests must hit REAL Express routes** via supertest — no React-Query mock fixtures. If a
   pre-existing test encodes OLD behavior that this wave intentionally changed, **FIX THE TEST,
   not production code.**
7. **Sacred-adjacent files edited ONLY at the route/parallel layer** (never edit the sacred file
   itself; register a parallel module and mount it in the non-sacred `server/routes.ts`).
8. **Triple-verify mandatory** before ship: Opus 4.8 + Gemini 3.1 Pro + GPT-5.5 in parallel.
   **GPT-5.5's verdict OVERRIDES** Opus + Gemini. **Do NOT ship on a REVISE / DO-NOT-SHIP from
   GPT-5.5**, even if the other two say SHIP.
9. **Sacred Rule #78 (added 2026-07-03):** "Never silently drop, delete, or forget widgets and/or
   functionality." Omission through inattention counts the same as deliberate deletion. Every
   triple-verify must affirmatively confirm NOTHING was dropped/deleted/forgotten.
10. **CAPAVATE_SACRED_FILES.md must ALWAYS be included in the release package**, plus this recovery
    prompt (Ozan directives, 2026-07-03).

---

## 3. WORKSPACE FILE MAP (exact paths)
> If the sandbox was lost, these paths must be re-created from the attachments (Section 4 + 5).

- **Build tree (v25.48.3, where all edits live):**
  `/home/user/workspace/capavate_build/capavateAIzip/`
  - Deps installed under `node_modules`; tsc at `node_modules/.bin/tsc`; tsx at `node_modules/.bin/tsx`.
  - Sacred manifest (authoritative, 39 lines `"<sha256>  <path>"`):
    `capavate_build/capavateAIzip/sacred_baseline/SACRED_SHA256.txt`
  - Version file: `capavate_build/capavateAIzip/package.json` → `"version": "25.48.3"`.
- **Live install copy (real `.env` + real `data.db` from ~Jul 1):**
  `/home/user/workspace/live_server_july3/capavateAIzip/`
- **Live DB copy for Q2 diagnostics (read-only):** `/home/user/workspace/q2_diag/live_copy.db`
- **Original v25.48.2 tree for diffing (FLAT layout — `/tmp/orig/server/...` NOT
  `/tmp/orig/capavateAIzip/server/...`):** `/tmp/orig/` (unzip of the FULL_INSTALL attachment).
- **Review artifacts:** `/home/user/workspace/review/`
  - `changed_files_final.txt` — the 29 files this wave changed (28 source + the sacred doc).
  - `V25_48_3_REVIEW_BRIEF.md`, `v25_48_3_all_diffs.txt` (round 1/2 full context)
  - `V25_48_3_R3_REVIEW_BRIEF.md`, `v25_48_3_r3_diffs.txt` (round 3)
  - `V25_48_3_R4_REVIEW_BRIEF.md`, `v25_48_3_r4_diffs.txt` (round 4 — the final atomic fix)
  - Verdicts: `verify_{gpt55,opus,gemini}.md` (r1), `_r2.md`, `_r3.md`, `_r4.md`.
    Final round-4 verdicts are all SHIP / 0 blockers.
- **Q2 audit resolution + SQL:** `/home/user/workspace/q2_diag/Q2_AUDIT_CHAIN_RESOLUTION.md`
- **Final package (deliverables):** `/home/user/workspace/dist_pkg/`
  - `capavate_v25.48.3_FULL_INSTALL.zip`, `capavate_v25.48.3_PATCH.zip`,
    `SHA256SUMS_v25.48.3.txt`, `README_FOR_AVI_v25.48.3.md`, `CHANGELOG_v25.48.3.md`,
    `Q2_AUDIT_CHAIN_RESOLUTION.md`, `CAPAVATE_SACRED_FILES.md`, and THIS file.

---

## 4. USER-UPLOADED ATTACHMENTS (source of truth if the sandbox is empty)
Folder: `/home/user/workspace/uploaded_attachments/bc2a9c9023e24a31aa68f43597ed353b/`
- `capavate_v25.48.2_FULL_INSTALL.zip`  ← unzip this to rebuild the base tree.
- `capavate_v25.48.2_PATCH.zip`
- `capavateAIzip-50-Avi-s-Install-on-Live-Server-July-3-2026.zip`  ← Avi's live install; contains
  the real `.env` and `data.db`. Use for live-shape parity + Q2 diagnostics (READ-ONLY copies).
- `CHANGELOG_v25.48.2.md`, `FIX_WAVE_REPORT_v25.48.2.md`, `README_FOR_AVI_v25.48.2.md`,
  `SACRED_AND_ENV_REPORT_v25.48.md` (← the 39 sacred file list originates here),
  `Q2_AUDIT_CHAIN_DIAGNOSTIC.md`, `SHA256SUMS_v25.48.2.txt`.

---

## 5. RECOVERY PROCEDURE (if the sandbox died — rebuild + re-gate)
Run these in order. Do NOT skip the sacred check.
```bash
# 5.1 Rebuild the build tree from the v25.48.2 FULL attachment (only if capavate_build is gone)
mkdir -p /home/user/workspace/capavate_build && cd /home/user/workspace/capavate_build
unzip -q /home/user/workspace/uploaded_attachments/bc2a9c9023e24a31aa68f43597ed353b/capavate_v25.48.2_FULL_INSTALL.zip -d capavateAIzip
cd capavateAIzip && npm ci     # Node 20; installs tsc/tsx/vitest into node_modules/.bin

# 5.2 Recreate the ORIGINAL diff baseline (FLAT layout at /tmp/orig)
rm -rf /tmp/orig && mkdir -p /tmp/orig
unzip -q /home/user/workspace/uploaded_attachments/bc2a9c9023e24a31aa68f43597ed353b/capavate_v25.48.2_FULL_INSTALL.zip -d /tmp/orig
# NOTE: files land at /tmp/orig/server/... (flat), NOT /tmp/orig/capavateAIzip/server/...

# 5.3 Recreate the sacred baseline manifest if missing (from SACRED_AND_ENV_REPORT_v25.48.md).
#     If sacred_baseline/SACRED_SHA256.txt already exists, SKIP. Otherwise extract the 39
#     "<sha256>  <path>" lines from that report into sacred_baseline/SACRED_SHA256.txt.

# 5.4 THEN re-apply the v25.48.3 changes. Easiest: unzip the finished PATCH over the tree:
unzip -o /home/user/workspace/dist_pkg/capavate_v25.48.3_PATCH.zip -d /tmp/cap_patch
rsync -a /tmp/cap_patch/capavate_v25.48.3_PATCH/ /home/user/workspace/capavate_build/capavateAIzip/
#     (This overlays the 28 changed source files + migration 0082 + docs. If dist_pkg is also
#      gone, re-implement from Section 7 by hand.)
```
### THE FOUR GATES (must all pass — run from the build tree)
```bash
cd /home/user/workspace/capavate_build/capavateAIzip

# GATE 1 — SACRED 39/39 byte-identical
MISMATCH=0; while read h p; do [ -z "$p" ] && continue; \
  if [ -f "$p" ]; then a=$(sha256sum "$p"|awk '{print $1}'); [ "$a" != "$h" ] && { echo "MISMATCH $p"; MISMATCH=1; }; \
  else echo "MISSING $p"; MISMATCH=1; fi; done < sacred_baseline/SACRED_SHA256.txt; \
  [ "$MISMATCH" = "0" ] && echo "SACRED CLEAN 39/39" || echo "SACRED DIRTY"

# GATE 2 — tsc MUST be exactly 601 (zero net-new; budget ceiling 611)
./node_modules/.bin/tsc --noEmit 2>&1 | grep -c 'error TS'   # expect: 601

# GATE 3 — wave-relevant tests (Q-J1 + Q-C5 must PASS)
ENABLE_DEMO_SEED=1 NODE_ENV=test ./node_modules/.bin/vitest run \
  server/__tests__/v25_48_3_qj1_team_invite_redeem.test.ts \
  server/__tests__/v25_48_3_qc5_privacy_propagation_three_surfaces.test.ts \
  server/__tests__/v25_47_high1_crm_invited_tag.test.ts \
  server/__tests__/sprint14_stores.test.ts
# expect: 44 passed / 3 failed. The ONLY acceptable failures are the 3 PRE-EXISTING
# sprint14 "Milestone broadcast segmentation" tests (demo-fixture dependency;
# milestoneBroadcastStore.ts is byte-identical to original; NOT caused by this wave;
# NOT part of the v25.48.2 gate suite). Q-J1 (3) and Q-C5 (2) MUST pass.

# GATE 4 — production build
./node_modules/.bin/tsx script/build.ts ; echo "BUILD_EXIT=$?"   # expect 0

# BONUS — confirm zero new require() in changed server files
grep -cE '\brequire\(' server/multiCompanyStore.ts   # expect 4 (pre-existing shims only)
grep -cE '\brequire\(' server/lib/teamInviteRedeem.ts # expect 0
```

---

## 6. THE Q-CODE DECISIONS (verbatim intent — what each fix must do)
> These are Ozan's decisions. Do not reinterpret. Status: ALL implemented (Section 7).
- **Q-J1** — Team-invite emails must use the working `/auth/redeem?token=…` flow (the dead
  `/team/invite/:token` route was the bug). The redeemer becomes a FOUNDER-capable user (NOT an
  investor), gets REAL workspace access to the invited company, is tagged in `founder_team_members`,
  lands on `/founder/dashboard`. Investor/round tokens must fall through unchanged.
- **Q-K1** — CRM: rename stage "Lead" → "Prospect" (avoid confusion with "lead investor"); add a
  distinct "Invited – not registered" stage. Lifecycle: `invited_unregistered` → `prospect` on
  registration. Legacy `lead`/`engaged` rows still render (mapped to Prospect).
- **Q-K2** — Reciprocal investor CRM: when an investor redeems an invite, their CRM shows the
  inviting founder/company with real name/email/company (was a blank "Founder").
- **Q-F1** — Cap Table is VIEW-ONLY; "Add security" redirects to Rounds (equity originates only
  via the round/ledger flow).
- **Q-F2** — On the soft-circle review page, highlight BOTH the Confirm and "Confirm / mark funded"
  buttons; amber indicator on the soft-circle book tab when confirmations pending.
- **Q-D3** — Currency dropdown = full ISO 4217, with 10 preferred currencies pinned on top.
- **Q-C3** — Founder Billing/Plan tab must read a founder-scoped `/api/founder/pricing-tiers`
  (was hitting admin `/api/admin/pricing-tiers` → 403).
- **Q-A1** — Make the login/signup portal tab more highlighted.
- **Q-I1** — Collective apply requires a live round + an "open to refinement" checkbox in the
  application (persisted; relayed to the Collective).
- **Q-C6** — Region tab = full COUNTRY dropdown, pre-selected to the profile's country of
  incorporation. (Ozan clarified: full ISO country list for the Region tab ONLY — NOT the
  cap-table 9-jurisdiction matrix.)
- **Q-D2 (prefill)** — Pre-fill wizard fields already captured in Company Profile (read from the
  canonical nested `legalEntity` sub-object).
- **VERIFY-ONLY (no code needed, confirmed on live 25.48.2):** Q-B2 (investor "replace" crash gone),
  Q-G1 (rounds 404 not reproducible), Q-C2 (team-invite 400 not reproducible), Q-D1 (dashboard
  search in `AppShell.tsx`, PRO badge in `CompanySwitcher.tsx` — deploy-safe), Q-C7 (M&A Step-4
  fields persist via companyProfileStore profileJson), Q-C8 (retention metadata already in
  workspaceArchiveStore.ts), Q-A2 (signup→company→plan→Airwallex handoff works; $840 hosted
  checkout opens; STOP before payment).

---

## 7. EXACTLY WHAT WAS CHANGED (the 28 source files + migration + tests)
Full authoritative list: `/home/user/workspace/review/changed_files_final.txt`.
Key modules and the crux of each change:
- **NEW `server/lib/teamInviteRedeem.ts`** (Q-J1 parallel module). Mounted in `server/routes.ts`
  BEFORE `registerAuthShellRoutes` (~line 1173). Handles team tokens on `/api/auth/redeem` +
  `/api/auth/redeem/preview`; hashes the raw token (sha256) to match `token_hash`; fails CLOSED on
  a real DB error (503, never `next()`); non-team tokens `next()` through unchanged.
  **FINAL DESIGN (after 4 review rounds — this is the important part):** the POST redeem does ALL
  durable writes in ONE `rawDb().transaction()`:
    (a) guarded claim `UPDATE founder_team_invitations SET status='accepted',accepted_at=? WHERE
        id=? AND status='pending' AND accepted_at IS NULL AND deleted_at IS NULL AND (expires_at
        IS NULL OR expires_at>?)` requiring `changes===1` (else rollback → 409);
    (b) `founder_team_members` upsert tag;
    (c) `writeCompanyMembershipRowRaw(db,…)` — the `company_members` grant + post-write verify on
        the SAME handle.
  Any failure rolls back ALL of (a)(b)(c). Cache mirror + session cookie happen ONLY after commit.
  `registerFounderUser` (persona/auth creds) runs BEFORE the tx; on rollback it leaves only an
  inert company-less founder shell (no access) — this was reviewed and accepted (equivalent to an
  abandoned fresh signup).
- **`server/multiCompanyStore.ts`** — added THREE exports (all NEW functions, so no sacred/require
  concerns): `addExistingCompanyMembership` (standalone entry: own tx → raw writer → cache mirror),
  `writeCompanyMembershipRowRaw(db, {userId,companyId,tenantId,dbRole,now,isFirstCompany})` (the
  atomic primitive — raw UPSERT `ON CONFLICT(id) DO UPDATE` reactivating role/tenant_id/is_active=1/
  deleted_at=NULL/last_active_at, then a post-write SELECT verifying a LIVE row with the expected
  `dbRole` exists, THROW if not), and `mirrorExistingCompanyMembershipToCache(...)` (post-commit
  cache mirror only). KEY FACT: `getDb()` wraps the SAME better-sqlite3 handle `rawDb()` returns
  (`server/db/connection.ts`), so a raw write inside `rawDb().transaction()` is atomic with the rest.
  Role map: owner→co_founder, admin→admin, viewer→viewer, member→editor.
- `server/founderCrmStore.ts`, `shared/crmStages.ts` (FOUNDER_CRM_STAGES now 9),
  `client/src/pages/founder/CRM.tsx`, `client/src/pages/founder/CRMNew.tsx` — Q-K1 stages.
- `server/lib/investorCrmInvitationSeed.ts` (+ wiring in `server/routes.ts`) — Q-K2 reciprocal CRM.
- `server/lib/founderTeamStore.ts`, `client/src/pages/auth/Redeem.tsx` — Q-J1 supporting.
- `client/src/pages/founder/CapTable.tsx` (Q-F1), `client/src/pages/founder/RoundDetail.tsx` (Q-F2).
- **NEW `client/src/lib/currencyOptions.ts`** + `client/src/pages/founder/ProfileWizard.tsx`
  (Q-D3 + Q-D2 prefill).
- `server/adminPricingStore.ts` (new founder-scoped GET `/api/founder/pricing-tiers`) +
  `client/src/pages/founder/Settings.tsx` (Q-C3 + Q-C6 CountryPicker pre-selected).
- `client/src/pages/auth/Login.tsx` (Q-A1).
- `client/src/pages/founder/ApplyToCollective.tsx` + `server/founderCollectiveApplyStore.ts`
  (Q-I1; `mapAppRow` now includes `openToRefinement` for DB-first read parity).
- `shared/schema.ts` + `server/db/connection.ts` — added `open_to_refinement` column to
  `founder_collective_applications` (bootstrap CREATE + idempotent ALTER; hydrate + INSERT include it).
- `package.json` → version bumped to `25.48.3`.
- **Tests:** NEW `server/__tests__/v25_48_3_qj1_team_invite_redeem.test.ts` (3),
  `server/__tests__/v25_48_3_qc5_privacy_propagation_three_surfaces.test.ts` (2); UPDATED
  `server/__tests__/v25_47_high1_crm_invited_tag.test.ts`,
  `server/__tests__/sprint14_stores.test.ts` (CRM-stage assertions updated to new behavior).
- **Migration `0082_v25_48_3_open_to_refinement.sql`** in BOTH `migrations/` and
  `server/db/migrations/` (additive + idempotent; verified against a copy of live `data.db`).

---

## 8. WHAT REMAINS — needs OZAN'S EXPLICIT SIGN-OFF (do NOT do without it)
### 8.1 V2-S1 — Add-Company dialog marketing sentence (proposed draft, awaiting approval)
Proposed replacement copy:
> "Add another company to your account — each one gets its own cap table, rounds, data room, and
> investor CRM, billed separately from your first. Free to set up; you only pay when you upgrade a
> company's plan."
Action once approved: it's a one-line client copy change in the Add-Company dialog; re-run all
four gates + a quick GPT-5.5 re-verify, then re-package (Section 9).

### 8.2 LIVE QA DATA CLEANUP (these are LIVE writes — confirm each before doing)
- Revert BluePrint Catalyst Ltd headline (currently set to "QA-TEST one sentence 2026-07-02") to
  its original value.
- Hard-delete the probe founder account `avinayquicktech@gmail.com`
  (user id `u_founder_1783004327037_ag5wzv`).
- Remove the two QA artifacts created during this session:
  `qa-handoff-2026-07-03@example.com` and its "QA Handoff Co".
Do these on the LIVE server. Use `browser_task` with the live logins (Section 10) or the admin UI.
Ask/confirm before each destructive action.

### 8.3 Q2 AUDIT BANNER (informational; additive clear only, on Ozan's word)
The admin "Audit chain integrity incident — tenant_admin_capavate" banner is a SEEDED
`audit_chain_health` incident FLAG (added v25.47, APD-029), NOT real corruption — every real tenant
audit chain verifies clean (tenant_platform 92 OK, tenant_co_novapay 90 OK, tenant_co_helia 18 OK,
tenant_admin_capavate has 0 audit_log rows). Full analysis + the exact additive SQL is in
`q2_diag/Q2_AUDIT_CHAIN_RESOLUTION.md`. The additive clear (NOT auto-applied):
```sql
UPDATE audit_chain_health
   SET status='ok',
       detail='continuity boundary acknowledged 2026-07-03; forward-chaining verified',
       updated_at=datetime('now')
 WHERE key='tenant_admin_capavate';
```

### 8.4 FLAG TO AVI/OZAN — live `.env` deploy gaps (in the README for Avi)
STORAGE_PROVIDER=s3 but no DATAROOM_STORAGE_DIR; BRIDGE_OUTBOUND_URL set with a placeholder HMAC
('YOUR_STRONG_SECRET') → set BRIDGE_ENABLED=0 until a real secret exists; COLLECTIVE_ENABLED appears
twice (dedupe); AIRWALLEX_MODE=live but PAYMENT_GATEWAY_MODE=test (pick one).

---

## 9. RE-PACKAGING PROCEDURE (rebuild the deliverables after ANY further change)
```bash
cd /home/user/workspace/capavate_build/capavateAIzip && OUT=/home/user/workspace/dist_pkg; V=25.48.3
# Ensure the changed-files list includes CAPAVATE_SACRED_FILES.md (Rule #78 — always ship the manifest)
mkdir -p "$OUT"
# PATCH (changed files + migration + docs)
PATCHROOT=$(mktemp -d)/capavate_v${V}_PATCH && mkdir -p "$PATCHROOT"
while IFS= read -r f; do [ -z "$f" ] && continue; mkdir -p "$PATCHROOT/$(dirname "$f")"; cp "$f" "$PATCHROOT/$f"; done < /home/user/workspace/review/changed_files_final.txt
cp CHANGELOG_v25.48.3.md "$PATCHROOT/"; cp /home/user/workspace/q2_diag/Q2_AUDIT_CHAIN_RESOLUTION.md "$PATCHROOT/"
rm -f "$OUT/capavate_v${V}_PATCH.zip"; ( cd "$(dirname "$PATCHROOT")" && zip -rq "$OUT/capavate_v${V}_PATCH.zip" "capavate_v${V}_PATCH" )
# FULL (source tree, NO node_modules/dist/live-data/backups)
rm -f "$OUT/capavate_v${V}_FULL_INSTALL.zip"
zip -rq "$OUT/capavate_v${V}_FULL_INSTALL.zip" . -x 'node_modules/*' -x '.git/*' -x 'dist/*' -x '.vite/*' -x 'coverage/*' -x '*/.DS_Store' -x 'data/*.db' -x 'data.db' -x '*.log' -x '*.prev' -x '*.bak' -x '*.orig'
# Copy standalone docs into the package + regenerate checksums
cp CAPAVATE_SACRED_FILES.md "$OUT/"
cd "$OUT" && sha256sum capavate_v${V}_FULL_INSTALL.zip capavate_v${V}_PATCH.zip > SHA256SUMS_v${V}.txt && sha256sum -c SHA256SUMS_v${V}.txt
```
**The package MUST contain (share each with the user):** FULL zip, PATCH zip, SHA256SUMS,
README_FOR_AVI_v25.48.3.md, CHANGELOG_v25.48.3.md, Q2_AUDIT_CHAIN_RESOLUTION.md,
**CAPAVATE_SACRED_FILES.md**, and **this RECOVERY_PROMPT_v25.48.3.md**.

---

## 10. LIVE LOGINS (for live verification / cleanup — handle as secrets)
- **Admin:** https://capavate.com/admin/login — `ozan@capavate.io` / `placeholder_removed_use_approved_recovery`
- **Founder:** https://capavate.com/user/login — `Ozan.isinak@gmail.com` / `placeholder_removed_use_approved_recovery`
- **Investor:** https://capavate.com/investor/login — `ozan@capavate.com` / `placeholder_removed_use_approved_recovery`
- **Partner:** `ozan@blueprintcatalyst.com` / `placeholder_removed_use_approved_recovery`
Health checks: `curl -fsS https://capavate.com/api/healthz` (→ `{"ok":true,…,"dbConnected":true}`)
and `curl -fsS https://capavate.com/api/health` (→ `"version":"25.48.x"`).

---

## 11. TRIPLE-VERIFY PROCEDURE (how the SHIP verdict was reached — repeat for any new change)
Spawn THREE independent reviewer subagents IN PARALLEL, each writing a verdict file:
- GPT-5.5 (`model=gpt_5_5`) → `review/verify_gpt55_rN.md` — **OVERRIDING verdict.**
- Opus 4.8 (`model=claude_opus_4_8`) → `review/verify_opus_rN.md`.
- Gemini 3.1 Pro (`model=gemini_3_1_pro`) → `review/verify_gemini_rN.md`.
Give each: a review brief (see `review/V25_48_3_R4_REVIEW_BRIEF.md` as the template), the diff file,
the prior-round verdicts, and instructions to read the ACTUAL current source. Verdict format:
`VERDICT: SHIP|REVISE`, `Blocker count: N`, `## Summary`, `## Remaining blockers`, `## Non-blocking notes`.
**Rule: if GPT-5.5 says REVISE, you FIX its blockers and re-verify — do NOT ship.** History of this
wave: r1 GPT-5.5 4 blockers → r2 2 blockers → r3 1 blocker (atomicity race) → r4 SHIP (single-tx fix).
Every verify MUST also affirmatively confirm Sacred Rule #78 (nothing dropped/deleted/forgotten).

---

## 12. FIRST ACTIONS FOR THE RECOVERING AGENT (do these, in order)
1. Read this whole doc. Load the `coding` skill if you'll touch code.
2. If the build tree is gone → Section 5 (rebuild + re-apply patch).
3. Run the FOUR GATES (Section 5). Confirm: SACRED CLEAN 39/39, tsc 601, tests 44 pass (only the 3
   pre-existing sprint14 failures allowed), build exit 0. If anything else fails, STOP and diagnose —
   do not proceed to ship.
4. If gates are green and nothing else was requested → the wave is already SHIP-ready and packaged;
   confirm the package in `dist_pkg/` is intact (Section 9 check) and tell Ozan it's ready for Avi.
5. Then handle the three open items (Section 8) ONLY with Ozan's explicit sign-off, confirming each
   live/destructive action first.
6. After any code change: re-run the four gates, re-triple-verify (Section 11, need GPT-5.5 SHIP),
   re-package (Section 9), and re-share ALL deliverables including this doc + the Sacred manifest.

*Generated 2026-07-03 as part of the v25.48.3 handoff, per Ozan's directive that a recovery prompt
always be included in the package.*
