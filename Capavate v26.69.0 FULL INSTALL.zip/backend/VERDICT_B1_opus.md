# VERDICT — Wave B1 (Add Portfolio Company, 3a) — Independent Verification (Opus)

## 1. VERDICT: **APPROVE**

Wave B1 is correct, fail-closed, and touches no sacred surface. All hard gates
and correctness/security checks pass. No defects found.

## 2. Gate results (actual)

| Gate | Expected | Actual | Result |
|------|----------|--------|--------|
| `npx tsc --noEmit` net-new errors | 598 | **598** | PASS |
| `sacred_baseline/SACRED_SHA256.txt` OK count | 40 | **40** | PASS (0 failures) |
| `captableCommitStore.ts` sha16 | `01cd36130ee1c0cb` | **`01cd36130ee1c0cb`** | PASS |
| `npm run guard` | exit 0, 925/194/92 | **exit 0, 925 routes / 194 pages / 92 nav** | PASS |
| vitest (waveB1 + waveA_consortium_qa + spvUnifiedCanonical) | 16 pass | **16 passed (3 files)** | PASS |
| `grep require(` in partnerPortfolioCompanyRoutes.ts | none | **none** | PASS |
| `grep companyProfileStore\|subscriptionStore\b` (sacred singular) | none | **none** | PASS |

B1 diff (`WAVE_B1_SOURCE.diff`) touches exactly 8 files: `server/partnerPortfolioCompanyRoutes.ts` (new),
`server/routes.ts`, `server/collectiveRoutes.ts`, `server/__tests__/waveB1_add_portfolio_company.test.ts` (new),
`client/src/App.tsx`, `client/src/components/CollectiveShell.tsx`,
`client/src/pages/collective/CollectiveDealRoomDetail.tsx`,
`client/src/pages/partner/PartnerAddPortfolioCompany.tsx` (new). None is a sacred file.

Note: the working tree also carries prior Wave A changes (e.g. `adminContactsStore.ts`,
`0108_1c_spv_launch_signoffs.sql`). These are NOT part of the B1 diff and were excluded from
scope — the B1 migration rule is about B1 not adding a migration, which it does not.

## 3. Per-check confirmations

### HARD RULES
1. **Sacred 40/40 byte-identical** — CONFIRMED. All 40 sacred files verify OK. B1 imports only the
   NON-sacred `subscriptionsStore.ts` (plural) at `partnerPortfolioCompanyRoutes.ts:31`; the sacred
   singular `subscriptionStore.ts` and `companyProfileStore.ts` are never imported. No sacred file edited.
2. **Money core** — CONFIRMED. `captableCommitStore.ts` sha16 unchanged; commitment path not forked
   (B1 never imports/touches it).
3. **tsc net-new = 598** — CONFIRMED.
4. **Guard exit 0** — CONFIRMED. New route/page/nav are informational adds only; 925/194/92 intact.
5. **No new `require()`** — CONFIRMED. ESM-only (`import` of `node:crypto`, etc.); no `require(` in the new server TS.
6. **Payments/Airwallex untouched; no payout wired** — CONFIRMED. Only "Airwallex" reference is a
   comment. Attribution only (`linkConsortiumPartner`); no referral payout.
7. **No new migration** — CONFIRMED. B1 diff adds no `.sql` migration; relies on existing tables
   (companies via multiCompanyStore, consortium_links, founder_team_invitations, partner pipeline).
   The route defensively `CREATE TABLE IF NOT EXISTS founder_team_invitations` (no-op on real DB) — not a migration.

### CORRECTNESS / SECURITY
- **Founder-owner isolation** — CONFIRMED. Owner id is `pendingFounderUserId(founderEmail)`
  (`partnerPortfolioCompanyRoutes.ts:110`), passed as the userId to `addCompanyForFounder(ownerUserId, company)`
  (`:130`). The `company_members` row uses this pending-founder id (`multiCompanyStore.ts:624`), NEVER
  `ctx.userId` (the partner). Format `u_pending_founder_<sha256(email)[:16]>` (`:51-54`). Partner never
  gains founder membership; founder never enters the partner section. Test asserts membership user_id
  `!= MANAGING` and matches `/^u_pending_founder_/` (test:90-91).
- **Attribution fail-closed** — CONFIRMED. `linkConsortiumPartner` writes DB first and THROWS
  `CONSORTIUM_LINK_PERSIST_FAILED` on durable-write failure (`consortiumLinkStore.ts:53-58`);
  the route catches and returns **500 ATTRIBUTION_LINK_FAILED** (`partnerPortfolioCompanyRoutes.ts:152-157`).
  No silent drop.
- **Company persist fail-closed** — CONFIRMED. `addCompanyForFounder` wraps a DB transaction and
  re-throws `COMPANY_PERSIST_FAILED` on failure (`multiCompanyStore.ts:648-664`), mirroring the cache
  only after commit. The route returns **500 COMPANY_PERSIST_FAILED** (`partnerPortfolioCompanyRoutes.ts:129-134`).
  No false 201.
- **Founder invite** — CONFIRMED. INSERT hard-codes `role='owner'`, `status='pending'`
  (`partnerPortfolioCompanyRoutes.ts:188`). Inviter `invited_by_user_id = ctx.userId` (session partner,
  `:190`), never a client value. Token is `randomBytes(32)`; only the sha256 `token_hash` is stored (`:179-180`),
  and the raw token is returned once in a real `/auth/redeem?token=` claim URL (`:204`). Test verifies
  role=owner, status=pending, invited_email, and claimUrl contains `/auth/redeem?token=`.
- **Validation** — CONFIRMED. Missing companyName → **400 COMPANY_NAME_REQUIRED** (`:104`);
  invalid/absent founder email → **400 FOUNDER_EMAIL_REQUIRED** via `isEmail()` (`:107`). Both covered by tests.
- **Session-derived identity** — CONFIRMED. `requirePartnerAuth`/`assertSubRole` resolve
  `req.partnerContext` from the session (`getUserContext()`), and `partnerId` is ALWAYS the
  session-resolved team member, NEVER read from the client (`requirePartnerAuth.ts:4-5,86-92`).
  Write gated to sub-roles `managing_partner|associate|bd` plus `requireSignedAgreement`.
- **Attribution badge** — CONFIRMED. Server resolves `attributedPartner` read-only via
  `getConsortiumPartnerId` + `getConsortiumPartnerDisplayName`, wrapped in try/catch returning `null`
  when unattributed or on error (`collectiveRoutes.ts` B1 hunk). `getConsortiumPartnerDisplayName`
  pre-exists (added in Wave A); B1 only composes it — no adminContactsStore edit. Client badge renders
  only when `profile.attributedPartner?.name` is truthy (`CollectiveDealRoomDetail.tsx` B1 hunk).

## Notes
- Subscription provisioning (`createSubscriptionForNewCompany` → auto-activate free) and pipeline row
  are intentionally non-fatal (logged, continues) — acceptable since company + attribution are the
  durable/fail-closed steps and the invite/subscription are re-issuable. Not a defect.
- `npm run build` was NOT run; no restore was necessary. Nothing committed. `server/public`/`dist` clean.
