files=(
"server/__tests__/wave207_fee_basis_fence.test.ts"
"server/__tests__/w227_accreditation_jurisdiction_scope.test.ts"
"server/__tests__/w221_benchmarking_opt_out.test.ts"
"client/src/lib/__tests__/w226_attestation_rendered.test.tsx"
"client/src/pages/investor/__tests__/w221_benchmarking_sharing_dom.test.tsx"
"server/__tests__/w223_audit_chain_verification.test.ts"
"client/src/components/partner/__tests__/w216_esign_rendered_bytes_are_signed_bytes.test.tsx"
"server/__tests__/w216_esignature_intent_and_hash.test.ts"
"server/__tests__/w226_attestation_stored_bytes.test.ts"
"server/__tests__/w219_r206_collective_sharing_honoured_in_benchmark.test.ts"
"client/src/pages/founder/__tests__/w228_collective_false_claims.test.tsx"
"client/src/pages/partner/__tests__/w219_retention_link_reaches_a_real_page.test.tsx"
"client/src/pages/public/__tests__/w217_partner_compliance_gate_dom.test.tsx"
"server/__tests__/w217_login_and_ordinary_work_unaffected.test.ts"
"server/__tests__/w217_partner_compliance_gate_http.test.ts"
"server/__tests__/w218_cookie_consent_store_and_no_second_path.test.ts"
"client/src/pages/home/__tests__/w218_cookie_disclosure_and_terms_link_dom.test.tsx"
)

for f in "${files[@]}"; do
  if [ -f "$f" ]; then
    echo "=================================="
    echo "FILE: $f"
    cat "$f"
  fi
done
