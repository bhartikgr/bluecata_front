# Capavate v26.4.0 — Wave B (SPV canonicalization) HANDOVER

## Status

- **Wave 0** (all): v5.2 SHIPPED (v26.3.2 baseline)
- **Wave A-1** (ADR-3 audit chain): v2.3 SHIPPED (v26.3.4)
- **Wave C** (SPV UI unblock): v3.1 SHIPPED (v26.3.5 — current live baseline)
- **Wave B** (SPV canonicalization + adapter retirement): **v26.4.0 — READY FOR TRIPLE-REVIEW**

## What Wave B does

Wave B canonicalizes the SPV data path by:

1. **Retiring the `routes.ts → spvFundStore` coupling** via engine-backed adapter methods on `spvEngineStore` (Stage 2). The 10 legacy child routes now register through `registerSpvLegacyAdapterRoutes` (from the new `server/spvLegacyAdapters.ts`), which calls the engine's new `engine*` methods. `spvFundStore.ts` becomes an internal implementation module (still resident, no longer surfaced in the route registration path).
2. **Data-preserving backup migration** (0125). Nine legacy source tables get full-row snapshots into `wave_b_backup_*` tables with PK-idempotent copies. Byte-identical mirror in `server/db/connection.ts` so `:memory:` boots hit the same self-heal.
3. **Shadow-persist to the canonical engine table** on every new SPV / commitment. The two `require("./spvFundStore")` dynamic requires in `partnerWorkspaceStore.ts:2337,2454` are rewired to `require("./spvEngineStore")` — new partnerSpvStore creates now project onto the engine `spv` / `spv_subscription` tables using an idempotent `spv_mig_<sha256(legacyId)[:24]>` id convention.
4. **New DB-backed SPV KPI functions** (`dbTotalSpvCommittedMinor`, `dbTotalSpvWiredMinor`, `dbTotalActiveSpvs`) — pure `rawDb().prepare()` reads with per-currency maps. Additive; no in-memory state.
5. **Semver bump** 26.3.5 → 26.4.0 (minor bump — contract-compatible adapter preserves the wire API).

## What Wave B does NOT do (deferred)

- **In-memory read-cache elimination in `spvEngineStore`** — deferred to **Wave B.5**. The engine still uses `spvById`, `subsBySpv`, etc., Maps for reads. Wave B kept the adapter thin (delegates to `spvFundStore`) so Wave B.5 can retire the caches cleanly in one dedicated wave without touching route contracts.
- **Deletion of `spvFundStore.ts`** — deferred to **Wave B.5**. Currently only imported by `spvEngineStore.ts` (lazy `require` for delegation) and `server/lib/hydrateStores.ts` (still hydrates RAM caches the engine's own reads depend on).
- **New SPV Launch Fee (Airwallex-backed billing)** — deferred to **Wave F**. Legacy `chargeSpvDeploymentFee` was retired in this wave; billing pause window between Wave B and Wave F is by design.

## Ground-truth code delta

**Added:**
- `server/spvLegacyAdapters.ts` — 441 lines. 10 route handlers, 5 Zod schemas, feature-flag gate, ownership-check helper. Byte-identical wire contract to legacy `registerSpvFundRoutes`.
- `migrations/0125_wave_b_backups.sql` — 9-table backup DDL (both plural relational + kv_* sources). PK-idempotent, `_migrations_applied` marker.
- `server/db/migrations/0125_wave_b_backups.sql` — byte-identical mirror.
- `server/__tests__/waveB_stage2_canonicalization.test.ts` — 14 tests, engine adapter deep-equality + shadow-persist idempotency + KPI reads.
- `server/__tests__/waveB_stage2_adapter_routes.test.ts` — 31 tests, all 10 routes × happy path + all failure modes (400/403/404/422/503).
- `server/__tests__/waveB_retirement_guard.test.ts` — 13 tests, retirement-artifact assertions (G-1 through G-8).

**Modified:**
- `server/spvEngineStore.ts` — +315 lines. 2 shadow-persist helpers (Stage 1) + 11 legacy adapter methods (Stage 2). Preserves engine invariants; delegates to `spvFundStore` internals via a lazy `require`.
- `server/db/connection.ts` — +42 lines. Inline mirror of migration 0125.
- `server/lib/adminKpiDbReads.ts` — +67 lines. 3 new SPV KPI functions.
- `server/lib/hydrateStores.ts` — comments only (Stage 1 tried to retire the `spvFundStore` hydrator; Stage 2 restored it since engine reads still depend on the RAM caches until Wave B.5).
- `server/lib/seedDemoData.ts` — repointed from `spvFundStore.createSpv` to `spvEngineStore.createSpv`. Includes structureType and status mapping to engine enum vocabulary.
- `server/partnerWorkspaceStore.ts` — 2 dynamic requires rewired from `spvFundStore` to `spvEngineStore`.
- `server/routes.ts` — replaced `registerSpvFundRoutes(app)` → `registerSpvLegacyAdapterRoutes(app)`. Import site swapped.
- `package.json`, `package-lock.json` — 26.3.5 → 26.4.0.

**Unchanged (Q5 zero-tolerance):**
- Every `airwallex*` file — SHA-pinned, byte-identical.
- Every sacred file — 40/40 baseline still passes.
- `partnerConsortiumRoutes.ts` — byte-identical (`b88a0fcf55a389ea78908b9efd0196b668e010aa487f01655eb13ee227d1cbee`) per owner Q4.

## Gate values

- **Sacred SHA gate:** ✅ 40/40 (verified against `sacred_baseline/SACRED_SHA256.txt`)
- **`partnerConsortiumRoutes.ts` byte-identity:** ✅ `b88a0fcf55a389ea78908b9efd0196b668e010aa487f01655eb13ee227d1cbee`
- **Airwallex files untouched:** ✅ (grep confirmed — no touch of `server/airwallex*` or `server/lib/airwallex*`)
- **Migration mirror byte-identity:** ✅ (0125 SHA in `migrations/` == `server/db/migrations/`)
- **Semver bump:** ✅ 26.4.0 (contract-preserving minor bump — adapter maintains wire compatibility)
- **Retirement-guard whitelist:** ✅ (only `server/lib/hydrateStores.ts` + `server/spvEngineStore.ts` import from `spvFundStore` outside test files)
- **Static syntax parity:** ✅ (all modified files pass brace/paren/backtick balance)
- **tsc baseline (to be verified by Avi):** target = 598 errors (unchanged since Wave A-1 v2.3)

## Install procedure for Avi

### Step 1 — Backup
```bash
# In your working directory that mirrors capavate.com:
cp -r . ../capavate-v26.3.5-backup-$(date +%Y%m%d)
```

### Step 2 — Apply the patch
Extract `v26.4.0_PATCH.zip` at the repo root:
```bash
unzip -o v26.4.0_PATCH.zip
```
The patch contains 15 files (12 modified + 3 new test files).

### Step 3 — Install & typecheck
```bash
npm install                      # picks up any lockfile drift (none expected)
npx tsc --noEmit 2>&1 | tail -5  # target: 598 errors (baseline unchanged)
```

### Step 4 — Run the Wave B test suite
```bash
npm test -- waveB_stage2 waveB_retirement
```
Expected: 58 tests pass.

If any test fails, the most likely category is **test-setup drift** (my sandbox couldn't run vitest to validate the fixture layout). Real code defects would be in **the canonicalization tests** (Section 1) — those exercise the engine adapter methods directly.

### Step 5 — Boot & health check
```bash
npm run build && npm start
curl -s http://localhost:3000/api/health | jq
# Expected:
# { "version": "26.4.0", "airwallexMode": "live", ... }
```

### Step 6 — Live smoke test
Log in as Partner (ozan@trendwellventures.com / placeholder_removed_use_approved_recovery) and walk the SPV Engine page. Every existing SPV should list, every existing commitment/capital-call/distribution/position should show, and reconciliation math should match pre-deploy values. Any create/patch action should succeed.

**Rollback trigger:** if reconciliation math changes for any existing SPV, or if any of the 10 routes returns unexpected status codes, roll back immediately (Step 7).

### Step 7 — Rollback (if needed)
```bash
cd ..
mv capavate capavate-v26.4.0-failed-$(date +%Y%m%d)
mv capavate-v26.3.5-backup-$(date +%Y%m%d) capavate
cd capavate && npm install && npm start
```
The 0125 backup tables remain in the DB but are inert (no code reads from them). They can be dropped later or kept as extra insurance.

## Post-install verification checklist

- [ ] `/api/health` reports `version: 26.4.0`
- [ ] `npx tsc --noEmit` returns 598 errors (unchanged baseline)
- [ ] `npm test -- waveB_stage2 waveB_retirement` → 58/58 pass
- [ ] Partner login → Deployments tab → existing test SPVs (Test SPV, QUantum SPV, Asian Biotech, Live Test SPV Jul20, TEST2 SPV) all render with correct amounts and currencies
- [ ] Create new commitment on Test SPV → 201 response, DB row present in `spv_commitments`
- [ ] Reconcile math on Test SPV matches pre-Wave-B values (committedMinor, calledMinor, distributedMinor)
- [ ] `SELECT COUNT(*) FROM wave_b_backup_spvs` returns the same count as `SELECT COUNT(*) FROM spvs` (backup was full-row snapshot)

## Known limitations of Wave B v26.4.0

1. **Engine reads still use RAM caches.** The 11 new `engine*` adapter methods on `spvEngineStore` delegate to `spvFundStore` internals, which read from `spvsCache`, `commitmentsCache`, etc. Wave B.5 replaces these delegations with direct DB SELECT statements.
2. **`spvFundStore.ts` still resident.** 1,576-line file, no longer imported by `routes.ts` but still hydrated at boot and still used by 2 test files (`spvFundDb.test.ts`, `harmonyE2E.test.ts`, `w2_consortium.test.ts`). All three continue to pass as regression coverage.
3. **`registerSpvFundRoutes` export still available.** For test-only usage in `w2_consortium.test.ts`. Wave B.5 removes it.

## Follow-up waves

- **Wave B.5** (next) — Retire `spvFundStore.ts` entirely. Replace the 11 engine adapter method delegations with direct DB queries. Drop `hydrateSpvFundStore` and the RAM caches. Delete `spvFundStore.ts`. Update `w2_consortium.test.ts` to use `registerSpvLegacyAdapterRoutes`. Semver bump 26.5.0.
- **Wave F** — New SPV Launch Fee (Airwallex-backed billing per owner Q6). Wave B leaves a billing pause window; Wave F re-enables charge-on-launch.
- **Wave L** — Currency exponents, money-field UX, client tombstone deletion, `partnerFundsStore` full impl retirement.

## Cited artifacts (previous session)

- **Strategy Spec v4** (executable-backed, all 6 v3 defects fixed): `wave_b/WAVE_B_STRATEGY_SPEC_v4.md`
- **Prototype (Python, run against real data.db):** `wave_b/prototype/wave_b_prototype.py` + `V4_RUN_OUTPUT.txt`
- **Reviews (12 total across 4 rounds):** `wave_b/reviews/REVIEW_WAVE_B_V{1..4}_{OPUS,GEMINI,GPT5}.md`
- **Owner decisions locked:** Q1 port fee to Wave F (new billing), Q2 keep capital-calls table, Q3 both KPI tiles, Q4 v26.4.0 with contract-preserving adapters + partnerConsortiumRoutes byte-pin, Q5 no Airwallex touch, Q6 offline capital wires + SPV LPs treated like cap-table members, Q13 Wave B.5 split (canonicalization now, in-memory elimination later)

## Semver bump justification (26.3.5 → 26.4.0)

Minor bump (not patch, not major) because:
- **Additive migrations** (0125 backups) — additive-only, non-destructive.
- **Adapter routes wire-compatible** — all 10 route paths + status codes + response DTO shapes preserved byte-identically.
- **New engine methods on `spvEngineStore`** — additive to the engine's public surface.
- **No breaking removal** — `registerSpvFundRoutes` still exported from `spvFundStore.ts` for backward compat in the test surface.

Wave B is a minor bump not a patch because the internal architecture materially changes (canonicalization of route → engine → legacy-table path). Wave B.5 will be another minor bump (26.5.0) when `spvFundStore.ts` is fully retired.
