# VERIFIER BRIEF — Wave 2M (Messaging + Posting) — v26.2.0-w2m

Verify Wave 2M in `/home/user/workspace/capavate_work` (HEAD `2653286`; source diff
`WAVE_W2M_SOURCE.diff` or `git diff 2653286~2 2653286`). READ-ONLY: no file edits, no app
run. You MAY run read-only git/tsc/vitest/grep. **Do NOT write scratch .txt files into the
repo tree** — keep any notes in /home/user/workspace (outside capavate_work) or in your
verdict file only.

## Read
- `FIX_REPORT_WAVE_W2M.md` (claims) · `WAVE_W2M_SOURCE.diff`.
- `ROADMAP_SPEC_GATE_MESSAGING.md` PART B (B1–B6).

## Hard rules to confirm
- **SACRED `server/messagingStore.ts` BYTE-IDENTICAL**: sha256 must be
  `17bd56080b6af4a71ea0ac1f7e4023e1fc8ef64c8d00b9670d5d90ae19b3c392`. Confirm the diff does
  NOT touch it.
- Sacred 47/47 (`npm run sacred`, exit 0; Use `npm run sacred` (waiver-aware; `SACRED OK: 47/47`, exit 0). The raw `sha256sum -c sacred_baseline/SACRED_SHA256.txt` reader is **waiver-blind** and reports the five owner-waived files as `FAILED` (35 OK of 40, exit 1) on a healthy tree — by design, not corruption.); money
  `01cd36130ee1c0cb`.
- NO Airwallex/payment code edited. tsc net-new 0 (total 598). `npm run guard` exit 0 (931
  routes, no drops). ESM only (no new bare `require`). Migration ledger untouched (W2M adds
  no migration).
- Build restore if you build: `git checkout -- server/public && git clean -fdq server/public/assets dist`. Do NOT `git checkout -- .`.

## Per-item correctness
1. B5: DM CRM email-only fallback yields "Invited contact" NOT the email; DM + post
   notification titles route through `resolveCommsDisplayName` (never email / `u_` id);
   the helper's fallback order + `looksUnsafe` guard are correct.
2. B3 no-silent-drop: `persistNetworkPost` returns `{ok|error}`; `POST /api/comms/posts`
   returns 500 on primary write failure AND on collective dual-write failure; the
   in-memory post is removed on failure. Confirm the persist call is a STATIC import
   (cycle-safe — networkPostsStore has NO static commsStore import; it uses
   `await import()`), not the old swallow-everything lazy require.
3. B3 scheduler: `publishDueScheduledPosts` publishes due posts once (idempotent), leaves
   future scheduled, notifies once, updates content_json; wired into GET /api/comms/posts.
4. B3 moderation: `applyPostModerationToComms` hide/unhide reflects in-memory + emits
   mutation; wired into postModerationRoutes after moderatePost; `listPostsForModeration`
   THROWS on read failure (no silent empty).
5. Client: partner New-DM handles 403/422 visibly; PostsFeed sends companyId for
   followers/cap_table + shows failure (no false success); comment/admin author display
   never raw email/id.

## Also verify (per-suite, NOT full `vitest run server/`)
- `npx tsc --noEmit 2>&1 | grep -c "error TS"` = 598.
- `wave2M_messaging_posting.test.ts` 5/5; `sprint19_comms` 36/36; `sprint21_messages`
  16/16; `v13_network_posts_persistence` 3/3; `promotionModeration` 7/7; `waveSEC` 16/16;
  `waveW2` 13/13.
- Pre-existing failures unchanged per-suite: `sprint21_invitations` 2, `spvEngine` 30.
  NOTE: the FULL-suite `vitest run server/` shows ~381 failures on BOTH pristine and this
  tree (cross-suite pollution) — do NOT treat that as a W2M regression; verify PER-SUITE.

## Verdict
Write `/home/user/workspace/VERDICT_W2M_<model>.md`: APPROVE or REVISE with file:line.
Reply 6 lines ending `VERDICT: APPROVE` or `VERDICT: REVISE`. GPT-5.5 DECIDES; never ship on REVISE.
