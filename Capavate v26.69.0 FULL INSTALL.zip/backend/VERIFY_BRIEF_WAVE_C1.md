# Independent verification brief — Capavate Wave C1 (Shadie QA: Rounds)

You are an INDEPENDENT verifier. Return APPROVE or REVISE with concrete file:line
defects + fixes. Read the real files, not just the diff. Be adversarial; flag
only REAL issues.

Build tree: `/home/user/workspace/capavate_work` (deps installed). Diff:
`WAVE_C1_SOURCE.diff`. Report: `FIX_REPORT_WAVE_C1.md`. Source QA:
`SHADIE_QA_ANALYSIS.md` (items 3a/4a/5a/6a).

## What C1 does
Founder → Rounds fixes. NON-sacred files only, no new route/nav, no migration.

- **3a/4a/5a — a REVOKED invitation is terminal, fail-closed at BOTH layers:**
  - `server/roundInvitationsStore.ts`: `revokeInvitation` throws `ALREADY_REVOKED`
    if already revoked; `extendInvitation` throws `INVITATION_REVOKED` /
    `INVITATION_ACCEPTED`; `resendInvitation` throws `INVITATION_REVOKED` — all
    BEFORE any DB write / token re-mint / email.
  - `server/routes.ts`: the resend (POST), extend (PATCH), revoke (DELETE)
    invitation routes return typed 409s for terminal states and, for revoke,
    SKIP the revoked-notification when already revoked (no second email).
  - `client/src/pages/founder/RoundDetail.tsx`: resend disabled for
    accepted|revoked; extend disabled for revoked|accepted; revoke disabled for
    revoked.
- **6a — Rounds list newest-created on TOP:** `client/src/pages/founder/Rounds.tsx`
  sorts a COPY of the list by `createdAt` DESC with a stable id tiebreak.
  `createdAt` is already returned by `/api/rounds`.

## HARD RULES (any violation = REVISE)
1. Sacred 40/40 byte-identical (confirm none of the 40 sacred files are in the diff).
2. Money `server/captableCommitStore.ts` sha16 `01cd36130ee1c0cb`.
3. tsc net-new = 0 → exactly **598**.
4. Guard exit 0, counts UNCHANGED (926 / 194 / 92).
5. No new `require()` in server TS. No new migration. Payments/Airwallex untouched.

## Correctness to verify (adversarial)
- **No re-notification of a revoked investor:** confirm that revoking an
  already-revoked invite does NOT call the revoked-notification again, and that
  resending a revoked invite sends NO email and does NOT re-mint the token.
  RUN `server/__tests__/waveC1_invitation_terminal_guards.test.ts` (4 tests) and
  confirm it genuinely proves: revoke-again throws, extend-on-revoked throws +
  expiry unchanged, resend-on-revoked throws + token hash unchanged,
  extend-on-accepted throws.
- **Fail-closed ordering:** the guards must run BEFORE any mutation/email (not
  after). Confirm by reading the functions.
- **Persist-first semantics preserved:** confirm the existing persist-first +
  zero-row-guard logic (v25.35) is intact and the new guards sit above it.
- **6a sort:** confirm it sorts a COPY (does not mutate the react-query cache),
  newest createdAt first, stable tiebreak; confirm no crash when createdAt is
  missing (falls back to 0). Confirm the client Round type has createdAt.
- **No behavioral regression:** the legitimate flows (revoke a still-pending
  invite once + its single notification; extend a pending invite; resend a
  pending/sent invite) must still work.

## Known pre-existing (NOT a regression — do not fail C1 for this)
`server/__tests__/sprint21_invitations.test.ts` has 2 failing co-soft-circle
visibility tests (403 vs 200) — fail identically on pristine HEAD (verify via
`git stash` if you wish). Unrelated to C1 (invitation actions / rounds sort).

Run:
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # exit 0, 926/194/92
npx vitest run server/__tests__/waveC1_invitation_terminal_guards.test.ts server/__tests__/v25_55_shadie_v6.test.ts server/__tests__/v15_invitation_flow.test.ts   # C1 4/4 + no new fails
```
If you run `npm run build`, restore: `git checkout -- server/public && git clean -fdq server/public/assets dist`. Do NOT commit.

## Output
Write to `/home/user/workspace/capavate_work/VERDICT_C1_<model>.md`:
1. VERDICT: APPROVE / REVISE
2. Gate results (actual numbers)
3. Per-check confirmation or defect (file:line + fix)
