import path from 'node:path';
import express from 'express';
import http from 'node:http';
import request from 'supertest';

process.env.NODE_ENV = 'test';
process.env.ENABLE_DEMO_SEED = '1';
process.env.VITEST = 'true';
process.env.DATABASE_URL = `file:${path.resolve('/home/user/workspace/build_spec/v25_46_1_verify_gpt55_endpoint_probe.sqlite')}`;

async function main() {
const { registerRoutes } = await import('./server/routes');
const { getDb, closeDb } = await import('./server/db/connection');
const { seedDemoData } = await import('./server/lib/seedDemoData');

const ADMIN = (r: request.Test) => r.query({ as: 'admin' });
const FOUNDER = (r: request.Test) => r.query({ as: 'founder' });
const INVESTOR = (r: request.Test) => r.query({ as: 'investor' });

async function makeApp(seed = false) {
  const app = express();
  app.use(express.json());
  const server = http.createServer(app);
  if (seed) await seedDemoData(getDb());
  await registerRoutes(server, app);
  return { app, server };
}
function assert(cond: unknown, msg: string): asserts cond {
  if (!cond) throw new Error(msg);
}
function bodySummary(r: request.Response) { return JSON.stringify(r.body).slice(0, 700); }

const results: any[] = [];
let { app, server } = await makeApp(true);

const families = [
  { name: 'collective_member_subscription', base: '/api/admin/collective/member-subscription-tiers', seeded: ['basic','pro','enterprise'], slug: 'gpt55_persist_collective', amount: 43210, updated: 54321 },
  { name: 'consortium_partner_subscription', base: '/api/admin/consortium/subscription-tiers', seeded: ['partner_basic','partner_pro','partner_enterprise'], slug: 'gpt55_persist_consortium', amount: 87654, updated: 98765 },
];

for (const fam of families) {
  let r = await INVESTOR(request(app).get(fam.base));
  results.push({ endpoint: `GET ${fam.base}`, actor: 'investor', status: r.status });
  assert([401,403].includes(r.status), `${fam.name} non-admin GET expected 401/403 got ${r.status} ${bodySummary(r)}`);
  r = await FOUNDER(request(app).post(fam.base).send({ slug: 'blocked_probe', amountMinor: 1 }));
  results.push({ endpoint: `POST ${fam.base}`, actor: 'founder', status: r.status });
  assert([401,403].includes(r.status), `${fam.name} non-admin POST expected 401/403 got ${r.status} ${bodySummary(r)}`);
  r = await ADMIN(request(app).get(fam.base));
  results.push({ endpoint: `GET ${fam.base}`, actor: 'admin', status: r.status, body: r.body });
  assert(r.status === 200, `${fam.name} admin GET expected 200 got ${r.status} ${bodySummary(r)}`);
  for (const s of fam.seeded) assert(r.body.tiers.some((t:any) => t.slug === s), `${fam.name} missing seeded ${s}`);
  r = await ADMIN(request(app).post(fam.base).send({ slug: fam.slug, amountMinor: fam.amount, billingPeriod: 'monthly' }));
  results.push({ endpoint: `POST ${fam.base}`, actor: 'admin', status: r.status, body: r.body });
  assert(r.status === 201, `${fam.name} admin POST expected 201 got ${r.status} ${bodySummary(r)}`);
  r = await ADMIN(request(app).put(`${fam.base}/${fam.slug}`).send({ amountMinor: fam.updated, billingPeriod: 'annual' }));
  results.push({ endpoint: `PUT ${fam.base}/:slug`, actor: 'admin', status: r.status, body: r.body });
  assert(r.status === 200 && r.body.tiers.amountMinor === fam.updated, `${fam.name} admin PUT failed got ${r.status} ${bodySummary(r)}`);
  r = await ADMIN(request(app).delete(`${fam.base}/${fam.slug}`));
  results.push({ endpoint: `DELETE ${fam.base}/:slug`, actor: 'admin', status: r.status, body: r.body });
  assert(r.status === 200 && r.body.deleted === true, `${fam.name} admin DELETE failed got ${r.status} ${bodySummary(r)}`);
  // recreate for durability probe after DELETE soft-deleted it
  r = await ADMIN(request(app).post(fam.base).send({ slug: fam.slug, amountMinor: fam.updated, billingPeriod: 'quarterly' }));
  assert(r.status === 201, `${fam.name} recreate after delete failed got ${r.status} ${bodySummary(r)}`);
}

// Tier isolation both directions.
let r = await ADMIN(request(app).post(families[0].base).send({ slug: 'gpt55_iso_collective_only', amountMinor: 11111 }));
assert(r.status === 201, `isolation setup collective failed ${r.status} ${bodySummary(r)}`);
r = await ADMIN(request(app).put(`${families[1].base}/gpt55_iso_collective_only`).send({ amountMinor: 22222 }));
results.push({ endpoint: `PUT ${families[1].base}/gpt55_iso_collective_only`, actor: 'admin cross-family', status: r.status, body: r.body });
assert(r.status === 404, `collective row writable through consortium endpoint; got ${r.status} ${bodySummary(r)}`);
r = await ADMIN(request(app).post(families[1].base).send({ slug: 'gpt55_iso_consortium_only', amountMinor: 33333 }));
assert(r.status === 201, `isolation setup consortium failed ${r.status} ${bodySummary(r)}`);
r = await ADMIN(request(app).put(`${families[0].base}/gpt55_iso_consortium_only`).send({ amountMinor: 44444 }));
results.push({ endpoint: `PUT ${families[0].base}/gpt55_iso_consortium_only`, actor: 'admin cross-family', status: r.status, body: r.body });
assert(r.status === 404, `consortium row writable through collective endpoint; got ${r.status} ${bodySummary(r)}`);

const SPV = '/api/admin/consortium/spv-deployment-fee';
r = await INVESTOR(request(app).get(SPV));
results.push({ endpoint: `GET ${SPV}`, actor: 'investor', status: r.status });
assert([401,403].includes(r.status), `SPV non-admin GET expected 401/403 got ${r.status} ${bodySummary(r)}`);
r = await FOUNDER(request(app).put(SPV).send({ amountMinor: 1 }));
results.push({ endpoint: `PUT ${SPV}`, actor: 'founder', status: r.status });
assert([401,403].includes(r.status), `SPV non-admin PUT expected 401/403 got ${r.status} ${bodySummary(r)}`);
r = await ADMIN(request(app).get(SPV));
results.push({ endpoint: `GET ${SPV}`, actor: 'admin', status: r.status, body: r.body });
assert(r.status === 200 && r.body.spvDeploymentFee.amountMinor === 500000, `SPV seeded expected 500000 got ${r.status} ${bodySummary(r)}`);
r = await ADMIN(request(app).put(SPV).send({ amountMinor: 654321, currency: 'USD' }));
results.push({ endpoint: `PUT ${SPV}`, actor: 'admin', status: r.status, body: r.body });
assert(r.status === 200 && r.body.spvDeploymentFee.amountMinor === 654321, `SPV PUT failed got ${r.status} ${bodySummary(r)}`);

await new Promise<void>((resolve) => server.close(() => resolve()));
await closeDb();

// Simulated restart: close DB + HTTP server, create a new Express server over same file DB, GET values.
({ app, server } = await makeApp(false));
for (const fam of families) {
  r = await ADMIN(request(app).get(fam.base));
  const row = r.body.tiers.find((t:any) => t.slug === fam.slug);
  results.push({ endpoint: `RESTART GET ${fam.base}`, actor: 'admin', status: r.status, persistedRow: row });
  assert(r.status === 200 && row?.amountMinor === fam.updated && row?.billingPeriod === 'quarterly', `${fam.name} restart persistence failed ${r.status} row=${JSON.stringify(row)}`);
}
r = await ADMIN(request(app).get(SPV));
results.push({ endpoint: `RESTART GET ${SPV}`, actor: 'admin', status: r.status, body: r.body });
assert(r.status === 200 && r.body.spvDeploymentFee.amountMinor === 654321, `SPV restart persistence failed ${r.status} ${bodySummary(r)}`);

await new Promise<void>((resolve) => server.close(() => resolve()));
await closeDb();
console.log(JSON.stringify({ ok: true, databaseUrl: process.env.DATABASE_URL, results }, null, 2));
}
main().catch((e) => { console.error(e); process.exit(1); });
