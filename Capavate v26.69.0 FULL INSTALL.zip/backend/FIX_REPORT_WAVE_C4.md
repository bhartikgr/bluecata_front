# FIX REPORT — Wave C4 (Pre/post-close projection tab crash)

Founder → Round detail → "Pre / post-close projection" tab. Client-only.
Non-sacred files. No new route/nav, no migration. All gates green (bottom).

## Bug (found during the C2 live repro)
On a freshly-created round (no pre-money valuation, target $0 — shown as
"Unknown"/$0), opening the projection tab threw
`Cannot read properties of null (reading 'toString')` and the tab failed to
render.

## Root cause
`ProjectionPanel` (client/src/pages/founder/RoundDetail.tsx) called
`projectPostClose(securities, { preMoneyValuation: round.preMoney,
investmentAmount: round.targetAmount, ... })`. `round.preMoney` is
`number | null`, but `projectPostClose` (client/src/lib/engineDemo.ts) was typed
`number` and did `round.preMoneyValuation.toString()` directly → `null.toString()`
crash. Even with that coerced, a **0/0 priced round** yields a NaN
price-per-share the cap-table engine cannot represent → a second crash
`Cannot convert NaN to a BigInt` inside `computeCapTable`. A post-close
projection is simply not meaningful without a positive pre-money + target.

## Fix (two layers)
1. **Caller GATES the projection (primary fix)** —
   `client/src/pages/founder/RoundDetail.tsx` `ProjectionPanel` now computes
   `canProject = preMoney > 0 && target > 0` (finite). Only then does it call
   the engine. Otherwise it renders the **pre-close cap table** plus a clear
   guidance state ("Add a pre-money valuation and a target amount in Edit terms
   to see the post-close projection") instead of feeding degenerate 0/0 inputs
   into the engine. No crash, informative UX.
2. **Engine is null-safe (defense in depth)** — `client/src/lib/engineDemo.ts`
   `projectPostClose` widened its param type to `number | null | undefined` and
   coerces each to a finite number before `.toString()`, so the raw
   `null.toString()` crash can never recur even if called directly.

The sacred-adjacent cap-table engine package was NOT modified; the fix lives in
the demo wrapper + the panel.

## Files
- `client/src/pages/founder/RoundDetail.tsx` (ProjectionPanel gate + guidance state)
- `client/src/lib/engineDemo.ts` (null-safe `projectPostClose`)
- **New** `client/src/lib/engineDemo.waveC4.test.ts` — 4 tests (gate is false for
  null/0/partial inputs; true only for positive pre-money+target; engine
  computes for positive inputs; the null.toString() crash is gone).

## Gates (end of C4)
| Gate | Result |
|---|---|
| Sacred files | **40/40** byte-identical |
| Money core sha16 | **01cd36130ee1c0cb** (unchanged) |
| tsc `--noEmit` | **598** (net-new **0**) |
| Guard | **exit 0** — 929 / 194 / 92 (no route/nav/page change) |
| Build | **OK** |
| Migrations | none |
| Payments / Airwallex | untouched |
| Tests | C4 4/4 |

## Note
The projection now renders for ANY round: a priced round with a positive
pre-money + target shows the full pre/post-close comparison; a round without
those shows the current (pre-close) cap table + guidance. This is the last item
in Shadie's QA follow-ups. After C4 approval, the full v26.1.0 deployment bundle
for Avinay will be packaged (per Ozan — package once ALL fixes are complete).
