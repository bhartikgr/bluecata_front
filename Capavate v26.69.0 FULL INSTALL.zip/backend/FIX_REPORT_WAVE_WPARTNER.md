# Capavate — Fix Report: Wave W-PARTNER
**Version:** v26.2.0-wpartner · **Date:** 2026-07-25 · **For:** Avinay (deploy) / Ozan (owner)
**Base:** live wavi64 baseline (as carried in `capavate_avi65_build`, on top of the pending W-SHADIE package)

This wave makes the **Consortium Partner** flow work end-to-end. It fixes all confirmed defects from the live 5-stream audit, was triple-tested at both the STRATEGY and CODE stages (Claude Opus + Gemini + GPT-5.6 decider) to a unanimous SHIP, and adds 7 anti-vacuity regression test files.

## The two flow-breakers (now fixed)
- **F1 — Stream 4 unblocked.** A partner-created portfolio company now becomes a CRM "client." The Add-Portfolio-Company flow previously wrote only the sponsor tag (`consortium_links`) but never the revenue-bearing attribution the Clients CRM reads. It now creates a `partner_attributions` attribution (fail-closed with rollback), and attributions are promoted from a schemaless kv blob to a **typed `partner_attributions` table** (+ `partner_attribution_revisions` history) with an `attribution_source` CHECK, a safe TypeScript backfill, and a typed-first/kv-fallback hydrator.
- **F9-B — Stream 5 unblocked.** Approving a Collective promotion now grants Collective directory visibility. Nothing previously inserted a `collective_directory_listings` row on approval, so an approved deal stayed invisible to every non-admin member. A new `ensurePromotionDirectoryListing` (no-overwrite guard) is called non-fatally on approval, filed under the promotion's own chapter.

## All items in this wave
| ID | Fix | Files (primary) |
|---|---|---|
| **F1** | Attribution write on Add (fail-closed) + typed `partner_attributions`/`_revisions` tables + backfill + hydrator cutover + admin `source` validation; Clients GET returns `companyName` | `partnerWorkspaceStore.ts`, `partnerPortfolioCompanyRoutes.ts`, `partnerRoutes.ts`, `lib/hydrateStores.ts`, `db/connection.ts`, `migrations/0114_*` |
| **F1-b** | Partner-created company now appears in the Portfolio list (seed `partner_portfolio_company` row, companyName only, non-fatal) | `partnerPortfolioCompanyRoutes.ts` |
| **F9-B** | Directory visibility on promotion approval (chapter-scoped, no-overwrite guard, non-fatal) | `collectiveInterestStore.ts`, `promotionModerationRoutes.ts` |
| **F2-b** | Portfolio profile Save no longer 400s the whole patch: Industry is now a Select over `INDUSTRY_OPTIONS` (clears to null); field-level 400 details; scheme-less website URL normalized; fixed a latent `ma.transactionStatus` nesting drop | `PartnerPortfolioProfileDialog.tsx`, `partnerPortfolioStore.ts`, `partnerRoutes.ts` |
| **F3** | Designated partner-member lead on the client CRM (`lead_user_id` column, `setLead` endpoint, active-member validation); `setStage` carries the lead forward; hydrator clear-after-successful-read | `partnerClientCrmStore.ts`, `partnerClientCrmRoutes.ts`, `migrations/0115_*`, `db/connection.ts` |
| **F6** | Contact editing wired (PATCH), required fields blocked from clearing with named errors | `PartnerContacts.tsx` |
| **F7** | Partner display-name change mirrored to `contacts.display_name` (non-fatal; `legal_name` untouched) | `partnerRoutes.ts` |
| **F8** | "Promote to Collective" shows a pending/under-review badge to the managing partner; "Make Private" withdraw affordance kept | `PartnerPipeline.tsx` |
| **F10** | Company-scoped notes (scope + scopeId selector + list filter) | `PartnerNotes.tsx` |
| **F5-real** | Bio + Contact fields on partner settings | `PartnerSettings.tsx` |
| **F-new1** | Portfolio profile editor reachable from the Portfolio page | `PartnerPortfolio.tsx` |
| **F-new2** | `bd` sub-role can edit a portfolio profile (single shared role constant; DELETE stays stricter) | `shared/partnerRoles.ts`, `partnerRoutes.ts` |
| **F-new3** | Team seat banner shows "X of N seats" (limit from the same resolver the invite gate uses) | `PartnerTeam.tsx` |

## Migrations (apply in order)
- **`0114_partner_attributions.sql`** — creates `partner_attributions` (with `attribution_source` CHECK IN `admin_manual`,`referral_code`,`partner_claim`,`partner_portfolio`) + `partner_attribution_revisions` + indexes. DDL-only; the kv→typed backfill runs as a guarded TypeScript boot step (before `partnerWorkspaceShimStore` in `HYDRATE_ORDER`), coercing any unrecognized historical `attribution_source` to `admin_manual` so it can never abort.
- **`0115_partner_client_crm_lead.sql`** — `ALTER TABLE partner_client_crm ADD COLUMN lead_user_id TEXT`.

Both are additive, idempotent, mirrored byte-identically into `server/db/migrations/`, and self-healed in `server/db/connection.ts` (CREATE-literal for fresh DBs + guarded ADD COLUMN for upgraded DBs). **`migrations-pg/` is intentionally untouched** (drizzle-generated; hand-editing breaks the PGlite harness). The migration-id pin in `server/__tests__/w9_migration_mirror_drift.test.ts` was moved to `115` in the same change set.

## Sacred / safety posture
- **Sacred gate: clean** — no sacred file touched (`npm run sacred` → `SACRED OK: 47/47`, exit 0).
  Use `npm run sacred` (waiver-aware; `SACRED OK: 47/47`, exit 0). The raw `sha256sum -c sacred_baseline/SACRED_SHA256.txt` reader is **waiver-blind** and reports the five owner-waived files as `FAILED` (35 OK of 40, exit 1) on a healthy tree — by design, not corruption.
- **DB-canonical** — attributions moved from a schemaless blob to a typed table; RAM remains a write-through projection.
- **No silent drops** — every change is additive or corrected wiring. A latent pre-existing drop (`ma.transactionStatus` nesting) was fixed, not introduced.
- **No money path** — Airwallex / funding / soft-circle untouched. F9-B writes only `collective_directory_listings` rows (display-only).
- **F9-B visibility** — owner-accepted full chapter visibility (Deal Room + Companies list + graph + M&A chapter-of-record + the other `listedIds`-gated surfaces incl. soft-circle display), confirmed 2026-07-25.

## Release notes (behavioral)
- **Authorization widening (intended):** `partnerAttributionStore.listByPartner` backs three authorization gates (`partnerClientCrmRoutes.ts`, `managedFounderRoutes.ts`, `managedFounderPersonaRoutes.ts`); partner-created companies now unlock the managed-founder surfaces for the creating partner.
- **Dashboard client count** rises to include partner-created companies.
- **PGlite coverage gap:** `partner_client_crm` and `collective_directory_listings` are absent from the PG baseline, so the PGlite harness does not exercise F3/F9-B tables; their coverage is the SQLite path + the new tests.

## Triple-test summary
- **Strategy:** Opus + Gemini → REVISE (10 blockers incl. migration-pin, migrations-pg, F3 self-heal/hydrator wipe, F3 ON-CONFLICT logic, F9-B enumeration, F1 backfill portability, CHECK-abort, revoke rollback, kv dual-write lock) → all fixed → GPT-5.6 decider **SHIP**.
- **Code:** Opus + Gemini → REVISE (3 convergent blockers: empty-typed-table shadows kv ×2, `setLead` cold-projection lead loss) + test-hardening found B2's second half (stage reset) → all fixed → GPT-5.6 decider found 1 test-isolation blocker → fixed → **SHIP**.

## Gate runbook for the server (Avi)
1. `npm ci` (or `npm install`).
2. Apply migrations (runner picks up `migrations/0114`, `0115`; self-heal covers fresh + upgraded DBs).
3. `npm test` — full vitest suite. Expected green except the documented known-red baseline (`sprint28_billing` / `hash-chain-replay` under pglite, Postgres `42703`), which is pre-existing and unrelated to this wave.
4. New wave tests to confirm pass: `wpartner_f1_attribution_typed`, `wpartner_f2b_portfolio_patch`, `wpartner_f3_client_lead`, `wpartner_f3_crm_hydrator_guard`, `wpartner_f7_display_name_mirror`, `wpartner_f9b_promotion_directory`, and `PartnerPipeline.underReviewBadge`.
5. Confirm `w9_migration_mirror_drift` is green (pin now 115).
