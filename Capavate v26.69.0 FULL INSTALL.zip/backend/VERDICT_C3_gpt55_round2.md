# VERDICT_C3_gpt55_round2 — Wave C3 Round 2

VERDICT: APPROVE

## Round-2 fix verification

- `server/routes.ts` now threads `expiryDays` through both preview routes:
  - Company-scoped Step-4 preview body includes `expiryDays?: unknown` and forwards numeric values to `renderInvitationEmail` at `server/routes.ts:2714-2725`.
  - Round-scoped preview body includes `expiryDays?: unknown` and forwards numeric values to `renderInvitationEmail` at `server/routes.ts:2733-2750`.
- `client/src/pages/founder/RoundDetail.tsx` send and preview both compute expiry with `inviteExpiry === "never" ? null : parseInt(inviteExpiry, 10)`:
  - Send includes `expiryDays` only when the computed value is non-null at `RoundDetail.tsx:148-166`.
  - Preview includes the same selected numeric expiry for 14/30/60 and omits it for `never` at `RoundDetail.tsx:211-216`.
  - The expiry dropdown clears stale preview HTML on change at `RoundDetail.tsx:917-920`.
  - The personal-note helper no longer says expiry/duration is unchanged; it only says terms/name are unchanged at `RoundDetail.tsx:898-902`.
- The renderer defaults omitted/null expiry to 14 days at `server/roundInvitationsStore.ts:161-184`, and actual send uses the same shared renderer at `server/roundInvitationsStore.ts:530-545`.
- The new expiry regression is present and passed: `renderInvitationEmail` now asserts `expiryDays: 30`, `expiryDays: 60`, and omitted-default `14` behavior at `server/__tests__/waveC3_invite_preview_and_round_name.test.ts:35-46`.

## Preview == send assessment

- Round-detail path: subject, greeting, round/company facts, note, and expiry all come from the same `renderInvitationEmail` function. The selected 30/60-day expiry is passed by preview and send, so a founder previewing 30 days sees “expires in 30 days” and the investor receives the same expiry line. `never` omits `expiryDays` in both preview and send, so both consistently fall through to the renderer’s 14-day default.
- Step-4 company-scoped path: there is no expiry control. Preview omits `expiryDays`; initial-shareholder invitation creation also omits `expiryDays`, so both use the renderer default of 14 days.
- The preview routes remain read-only: they call only the renderer and return `{ ok, preview }`; they do not create an invitation, mint a real token, or send email. The link is the intentional preview placeholder.

## Prior approved aspects reconfirmed

- Single shared renderer preserved: `renderInvitationEmail` is the sole email subject/html/text composition path for preview and send.
- Personal note is HTML-escaped via `escapeHtml` in the renderer; raw angle-bracket note injection is covered by the Wave C3 test.
- Preview is ownership-gated: company-scoped preview checks company ownership; round-scoped preview goes through `requireFounderOwnsRound`.
- Round facts in the round-scoped preview are server-resolved from company/round stores, not client-overridable.
- Note persistence uses the existing invitation/shareholder note fields; no migration/schema file is in the C3 diff.
- 7a per-company uniqueness remains fail-closed in `createRound`, and the Wave C3 cross-company reuse test is present.
- Editable auto-suggest remains present via `/api/rounds/name-availability` and the client-side suggested-name update/hint.

## Gates rerun

- TypeScript: `npm run check` exited with the expected pre-existing failure state and exactly `598` TypeScript errors. Net-new count is 0. The server/routes errors that appear in edited-file grep are the same pre-existing baseline errors (line shifts only); no C3 change added errors in the preview/body-type areas. Output: `verify_c3_gpt55_round2_tsc_full.txt`, summary: `verify_c3_gpt55_round2_tsc_summary.txt`, comparison: `verify_c3_gpt55_round2_tsc_edited_compare.txt`.
- Sacred checksum: `40/40` OK, exit 0. Output: `verify_c3_gpt55_round2_sacred_full.txt`.
- Sacred overlap with `git diff HEAD~2..HEAD`: none. Output: `verify_c3_gpt55_round2_sacred_overlap.txt`.
- Money checksum: `01cd36130ee1c0cb`. Output: `verify_c3_gpt55_round2_money_sha16.txt`.
- Silent-drop guard: exit 0 with `OK: 929 routes, 194 pages, 92 nav — no silent drops`. Output: `verify_c3_gpt55_round2_guard_full.txt`.
- Wave C3 test: `server/__tests__/waveC3_invite_preview_and_round_name.test.ts` passed `8/8`. Output: `verify_c3_gpt55_round2_waveC3_vitest_full.txt`.
- Round regressions passed: `roundPersistenceProof`, `roundDetailLoad`, `v2348_round_initial_shareholders`, and `v15_invitation_flow` passed `4 files / 19 tests`. Output: `verify_c3_gpt55_round2_round_regressions_vitest_full.txt`.

No new defect found in the round-2 change.
