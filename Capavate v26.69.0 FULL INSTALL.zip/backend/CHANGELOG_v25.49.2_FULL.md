# Capavate v25.49.0 — CHANGELOG (Consortium Partner rebuild + canonical SPV Engine)

Full v25.49.0 = the v25.49.0-rc1 Consortium Partner rebuild (Phases 1-3) PLUS the canonical SPV Engine
(Phase 4). Installs on top of live v25.48.2; additive; drops nothing. Triple-verified SHIP
(GPT-5.5 + Opus 4.8 + Gemini 3.1 Pro, 0 blockers; GPT-5.5 overriding — it took 3 SPV review rounds to
clear 9 fintech-safety blockers). Sacred 39/39 byte-identical · tsc 601 (zero net-new) · build clean ·
104/104 partner+SPV tests pass · migrations 0083-0087 additive+idempotent.

## PART A — Consortium Partner module rebuild (Phases 1-3; also in v25.49.0-rc1)
- **P0 crash fix.** React #310 crashed the entire partner workspace on every page (a membership hook
  called conditionally in `CollectiveShell.tsx` — hook count changed once data loaded). Now called
  unconditionally; regression test added. The "reload a few times to get in" symptom is gone.
- **Re-skin to capavate.com brand** (red #cc0001, navy #041e41, cream, Montserrat + Instrument Serif)
  reusing existing `--cv-*` tokens; on-brand error boundary; **grouped left-nav** (OVERVIEW /
  DEALS & SPVs / WORKSPACE / NETWORK / ACCOUNT). All nav items preserved.
- **Partner Clients CRM enhanced** (kept as its own engine per decision): durable stages, activity
  timeline, list search/filter; honest read-only cap-table card. Migration 0083 (two additive tables).
- **Messaging + Posts inserted** (partner pages + dashboard cards) reusing the shared comms engine;
  fixed the partner Posts deeplink doubling bug.

## PART B — Canonical SPV Engine (Phase 4) — ONE engine, three contexts
- **One canonical engine** (`server/spvEngineStore.ts` + `spvEngineRoutes.ts`), write-through to SQLite
  and rehydrated on boot (zero in-memory canonical state). Consortium Partner (GP owner) / Collective /
  Capavate are contexts on top of the single store. **Single unified 'SPVs' surface + one nav entry**
  (decision #4) — the old separate "SPVs"/"Funds" pages/routes now redirect into the canonical engine;
  a Fund is just an SPV with `spvType='fund'`. Existing partner SPV + Fund records are migrated in via
  an idempotent boot backfill with `migrated_from` provenance (nothing dropped — Rule #78).
  **No live route can create a non-canonical SPV/fund** — admin fee routes, `/api/partner/me/funds`,
  and legacy SPV update/position routes all write through the canonical engine or are read-only.
- **Migrations 0084-0087** (additive + idempotent, verified against a copy of live data.db): 0084 = the
  9 SPV tables (spv, spv_mandate, spv_fee, spv_subscription, spv_deployment, spv_distribution,
  spv_document, spv_transfer) + `investor_compliance_profile`; 0085 = `spv.lp_visibility`; 0086 =
  `spv_fee_obligation`; 0087 = deployment `wire_payment_ref` + `closing_doc_ref`.
- **GP 5-step setup wizard** — pulls GP identity/org/tier/jurisdiction/team from the partner profile
  (no re-collecting), save-as-draft + clone-previous-SPV. **carry_basis has NO default** — the GP must
  explicitly choose per-deployment vs whole-SPV, in a dead-simple, plain-language wizard step (decision).
- **3 progressive investor compliance gates** — KYC (reusable one-time via `investor_compliance_profile`),
  accreditation self-cert, subscription e-sign; fail-closed-but-forgiving (flag for manual review).
- **Two-layer fee model** — management (GP) + platform (Capavate, read-only to GP). Money-movement-safe:
  fixed/hybrid fixed portions become mandatory **fee obligations wired through the existing Airwallex
  payment flow at funding** (unbypassable — enforced at subscription commit, deployment create/advance,
  and ledger commit; cleared only by pay or admin-waive); carry collected at distribution with recorded
  payment refs, fail-closed on collection failure. Admin controls live in **separate admin tabs**
  (the confirmed Capavate founder/investor fee flow is untouched).
- **Deployment** — fail-closed readiness gates before any money path: requires a mandate, an eligible
  company (active PAID Capavate subscriber w/ valid M&A profile + active round; excluded on any missing
  field), an active round matching the round id, instrument sourced from the round profile, and
  **sufficient COMMITTED/funded LP capital** (a committed-only register, not raw subscriptions).
  Deployment writes a **SINGLE cap-table ledger line through the existing sacred `commitFunded` path**
  (the sacred ledger file is byte-identical, never edited) — and only after `wired` + founder-confirmed +
  docs + a real `wirePaymentRef` + no prior ledger ref.
- **Distribution/waterfall** — return-of-capital first, carry only on realized profit; `per_deployment`
  and `whole_spv` carry bases genuinely diverge; per-LP gross/carry/net persisted; allocates over the
  committed-only register; fails closed with no committed LPs or missing basis.
- **Distribution scopes** — private / collective_only / network / invite_only. `collective_only` is
  first-class and is NOT surfaced on core Capavate investor surfaces. The founder/target always sees the
  SPV as a SINGLE investor of record (the LP roster is never exposed to the founder).
- **LP visibility (decision #5)** — a simple per-SPV toggle: default each LP sees ONLY their own
  position; when the GP turns it on, LPs in that SPV can see co-investors. Enforced FAIL-CLOSED
  server-side (`lpRosterForViewer`): a non-LP (incl. the founder) gets `NOT_AN_LP` in either mode; the GP
  sees the full roster.
- **Audit** — hash-chain + audit-log + bridge event on state changes, recording the compliance pass relied upon.
- Fixes the old audit finding that SPV/Fund "create" buttons returned 400/500 — the client now uses the
  canonical DTOs (`partner_workspace.test.ts` is now 15/15; the 3 pre-existing SPV-creation failures are gone).

## Migrations
- 0083 partner_client_crm · 0084 spv_engine (9 tables + compliance profile) · 0085 spv_lp_visibility ·
  0086 spv_fee_obligation · 0087 spv_deployment wire_payment_ref/closing_doc_ref. All additive +
  idempotent (guarded ADD COLUMN / IF NOT EXISTS), mirrored in ./migrations and server/db/migrations,
  auto-apply on boot. No manual step; no downgrade needed.

## Known / future cleanup (non-blocking, per GPT-5.5 round-3)
- A few stale comments in `partnerFeeAdminRoutes.ts` still mention the old store (the live path uses the
  canonical engine; proven by spy tests).
- Legacy `spvFundStore` CHILD read routes (`/commitments`, `/capital-calls`, `/distributions`, `/detail`,
  `/db-positions`) remain mounted for older DB-backed records; they cannot create new canonical SPVs and
  a new canonical SPV is not written through them. A future pass can reconcile these read surfaces.

## Gates
Sacred 39/39 byte-identical · tsc 601 (zero net-new) · build BUILD_EXIT=0 · no new `require()` in server
TS · 104/104 partner+SPV tests pass · migrations 0083-0087 idempotent. Triple-verified SHIP (GPT-5.5
overriding), 3 SPV review rounds clearing 9 blockers total.

---

# v25.49.1 — HOTFIX appended (Bug 1: investor invitation page crash)
Client-only null-guard fix on top of v25.49.0. No migrations, no new deps.
- Investor Invitation page crashed with "can't access property 'replace', ke.category is undefined"
  because dataroom-file rows / use-of-proceeds entries called `.replace()` on an optional `category`.
  Fixed with render-side null guards (show "Uncategorized" when empty) in
  client/src/pages/investor/InvitationDetail.tsx (lines ~544-546, 600, 603) and CompanyDetail.tsx:379,
  plus a loading guard on the file/UoP lists. Regression test:
  client/src/pages/investor/__tests__/dataroomCategory.regression.test.ts (8 tests).
- Gates: Sacred 39/39 · tsc 601 · build 0 · regression 8/8.

---

# v25.49.2 — Investor left-nav reorganization + audit
Client-only change on top of v25.49.1. No migrations, no new deps, no server changes.
- Full audit of the Investor module (every left-nav item + every reachable page) for business logic,
  broken links / undelivered promises, and in-memory/mock data. Result: no nav 404s, no dead handlers,
  no in-memory canonical state, nothing mock on customer paths. Bug 1 (invitation category crash)
  confirmed guarded. Findings: review/investor_audit_findings.md.
- Reorganized the investor left-nav (client/src/components/AppShell.tsx useInvestorNav) into cleaner
  categorized groups WITH nothing dropped (Sacred Rule #78):
    OVERVIEW → Dashboard
    DEALS    → Invitations (badge), Portfolio, Apply to Collective
    NETWORK  → Messages, Network Posts, CRM
    ACCOUNT  → Investor Profile, Settings, Notifications, Glossary
  8/8 prior items preserved (Invitations badge intact); 3 shipped-but-unlinked pages (Settings,
  Notifications, Glossary) recovered into the left nav while keeping their existing top-bar entry
  points. Investor Profile moved to ACCOUNT (identity), Apply-to-Collective to DEALS (deal action).
  Founder/admin/partner navs untouched.
- Gates: Sacred 39/39 · tsc 601 (zero net-new) · build 0 · 112/112 partner+SPV+investor+Bug1 tests.
