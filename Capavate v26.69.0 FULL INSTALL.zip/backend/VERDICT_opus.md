# Independent Verification Verdict — Capavate Wave A (Opus)

**VERDICT: REVISE**

One concrete defect: a repeated, verifiably-wrong count claim ("20 titles") in
FIX_REPORT + code comments — the delivered `PARTNER_TITLES` list has only **18**
entries. Every hard rule (#1–#9), every gate, and every security-sensitive item
(1c/1d/1e/2a permission tiers) passes. The defect is a spec-completeness /
accuracy issue in 2a, not a security hole, regression, or gate break. It is a
low-effort fix (add the 2 missing titles or correct the count) but it is a
factual claim in the report that does not hold, which the brief asked me to judge.

---

## 1. Gate results (commands actually run)

| Gate | Command | Expected | Actual | Pass |
|---|---|---|---|---|
| tsc net-new = 0 | `npx tsc --noEmit \| grep -c "error TS"` | 598 | **598** | ✅ |
| Sacred 40/40 | `sha256sum -c SACRED_SHA256.txt \| grep -c ": OK"` | 40 | **40** (0 FAILED) | ✅ |
| Money core sha16 | `sha256sum server/captableCommitStore.ts \| cut -c1-16` | 01cd36130ee1c0cb | **01cd36130ee1c0cb** | ✅ |
| Guard | `npm run guard` | exit 0 | **exit 0** (924 routes / 193 pages / 91 nav) | ✅ |
| Migration mirrored | `diff migrations/0108… server/db/migrations/0108…` | identical | **identical (exit 0)** | ✅ |
| No new require() | `grep -nE "\brequire\(" spvLaunchSignoffStore.ts partnerTitles.ts` | none | **none** | ✅ |

Additional independent checks (all pass):
- No new `require()` added in ANY changed server TS (swept all 7 changed server files, not just the 2 new).
- Payments/Airwallex: **no** payment/billing/Airwallex/Stripe/checkout file modified.
- `partner-theme.css`: scoped (`[data-product="partner"]`, 44 occurrences), consumes only `--cv-*` tokens (no non-cv `var(--…)` added). Reskin CSS is not sacred.
- Self-heal `applyC1cSpvLaunchSignoffSchema` table body + both indexes are byte-for-byte equivalent (normalized) to migration 0108. Mirrored SQL files are identical.
- Sacred `server/lib/userPrivacyResolver.ts` and `server/profileStore.ts`: in the sacred 40, `git diff --stat` empty — untouched (READ-only import of existing `readUserPrivacyRaw`).
- Targeted tests: `spvUnifiedCanonical` **9/9 pass**.
- Guard reports `/investor/accreditation` as "new since baseline" — this is **pre-existing** (Wave 1, commit 2a8fbc7), NOT a Wave A change; informational only, guard still exits 0. Not a defect.

---

## 2. Defect (REVISE)

### D1 — 2a: "20 titles" claim does not hold; list has 18 (accuracy / spec completeness)
- **File:line:** `shared/partnerTitles.ts:13-31` (array has 18 items).
- Wrong-claim locations:
  - `FIX_REPORT_WAVE_A_CONSORTIUM_QA.md:76` "the QA list is 20 job titles",
    `:77` "the 20 `PARTNER_TITLES`", `:83` "a **Title** dropdown (20)".
  - `client/src/pages/partner/PartnerTeam.tsx:32` "the 20 professional TITLES",
    `:194` "the 20 professional titles".
  - `shared/partnerTitles.ts:11` comment "Order matches the QA slide (2a) exactly"
    — cannot be exact if the QA slide has 20 and this list has 18.
- **Why it violates a rule:** The brief instructs judging "whether every claim in
  FIX_REPORT holds" and specifically to verify "the 20 titles purely
  presentational." The count claim (20) is repeated 5× across report + code and is
  objectively false — the delivered array is 18 (`Managing Partner … Viewer`). This
  is a wrong claim, which the brief explicitly lists as flag-worthy. It also implies
  the title list is likely incomplete versus the QA-spec 20 (2 titles appear
  dropped), though no QA-source slide is present in the workspace to name the exact
  missing two.
- **Not a security/permission issue:** titles are display-only, `isPartnerTitle`
  fail-softs unknown→null, and the 5 permission tiers are untouched (see §3.2a).
- **Suggested fix:** Reconcile to the QA source — either add the 2 missing titles
  to `PARTNER_TITLES` (restoring 20), or, if 18 is genuinely intended, correct the
  count in FIX_REPORT (`:76,:77,:83`) and the two client comments (`:32,:194`) and
  soften `partnerTitles.ts:11` ("Order matches the QA slide" → the accurate count).

---

## 3. Correctness findings on the sensitive items

### 1c — SPV launch sign-off (security-critical) — CORRECT
- **Identity keyed to session, never client id:** `server/spvEngineRoutes.ts:108-137`
  uses `ctx.userId`/`ctx.partnerId` from `req.partnerContext` only; the store
  (`spvLaunchSignoffStore.recordSignoff`) receives `userId` from the route, not the
  body. ✅ (rule #9)
- **Missing name / unaccepted attestation → 400, no SPV created:**
  `spvEngineRoutes.ts` returns `400 SIGNOFF_LEGAL_NAME_REQUIRED` and
  `400 SIGNOFF_ATTESTATION_REQUIRED` **before** `spvEngineStore.createSpv(...)` is
  called. No SPV is created on either failure. ✅ (rule #9)
- **Durability:** `recordSignoff` INSERTs into `spv_launch_signoffs` after the SPV
  exists (links real `spv.id`); DB failure is logged, never blocks the created SPV
  (acceptable telemetry-tolerance for a post-create audit record).
- **Migration additive/idempotent/mirrored + self-heal:** `CREATE TABLE/INDEX IF
  NOT EXISTS`, no FKs to money-core; `migrations/0108…` and `server/db/migrations/0108…`
  byte-identical; `applyC1cSpvLaunchSignoffSchema` in `connection.ts` matches the
  migration schema exactly (verified column-for-column + both indexes). ✅ (rule #7)
- **GET signoffs route partner-scoped:** `/api/partner/me/spv/:spvId/signoffs`
  resolves via `spvEngineStore.getSpv(pid, spvId)` (partner-scoped) → 404 on
  cross-partner; `listSignoffsForSpv` additionally filters `partner_id = ?`. ✅
- **Rule #13 (name captured):** typed full legal name is required and stored
  (`signer_legal_name NOT NULL`). ✅
- **Client gating:** `PartnerSpvEngine.tsx` Launch button disabled unless
  `signoffLegalName.trim()` AND `signoffAccepted`; client `ATTESTATION_TEXT_V1`
  matches server `ATTESTATION_TEXT_V1` verbatim. ✅

### 1d — Partner post-author label — CORRECT
- **Precedence:** `resolvePartnerPostAuthorLabel` (`server/commsStore.ts`) →
  (1) chosen screen name wins; (2) anonymous (`visibleToCoMembers === false`) →
  "Consortium Partner"; (3) `getConsortiumPartnerDisplayName` (displayName →
  legalName) else "Consortium Partner". Matches the QA precedence and the
  brief's screen-name → company-name → "Consortium Partner". ✅
- **Never leaks raw `u_…` id:** for a partner author the label is always a real
  name or the generic "Consortium Partner"; the raw id is never returned. For
  non-partners the helper returns null and the pre-existing resolver label is kept
  (unchanged behavior). ✅ (rule #9)
- **Honors privacy setting:** reads privacy via existing `readUserPrivacyRaw`;
  anonymity masks the org name to the generic label. ✅
- **Sacred untouched:** `userPrivacyResolver.ts` / `profileStore.ts` are READ-only
  imports; both remain in the sacred 40 and byte-identical. `getConsortiumPartnerDisplayName`
  is a new, additive, `consortium_partner`-only lookup in `adminContactsStore.ts`. ✅
- **Rule #13:** falls back to legalName then a safe generic label; no name is
  silently dropped into a raw id. ✅

### 1e — Auto-derived engine enum matches server fallback — CORRECT
- Server enum: `shared/spvEngine.ts:39` `SPV_JURISDICTIONS = ["delaware","cayman","bvi","canadian_lp"]`.
- Server fallback: `server/spvEngineStore.ts:1423` `normJur = isSpvJurisdiction(j) ? j : "delaware"`.
- Client `deriveEngineJurisdiction` (`PartnerSpvEngine.tsx`): US→delaware,
  Cayman→cayman, BVI→bvi, Canada→canadian_lp, **default→delaware**. Every returned
  value is a valid enum member, so `normJur` passes it through unchanged; every
  unmapped country → `delaware`, exactly mirroring the server fallback. Hidden input
  preserves `spv-w-jurisdiction` testid + submitted value. No enum change, no
  migration. ✅ (rule #8)

### 2a — Permission tiers intact, titles presentational — CORRECT (aside from D1 count)
- **5 tiers unchanged + server-enforced:** invite endpoint (`partnerRoutes.ts`)
  still validates `subRole` against exactly `["managing_partner","associate","bd","analyst","viewer"]`
  → `badRequest` on anything else. Titles are validated separately by
  `isPartnerTitle` and fail-soft to `null` ("never a permission"). ✅
- **Titles never grant permission:** title stored in `invitation_json`
  (`opts.title`) / member `positionNote`; purely display in the Team page (separate
  Title vs Access columns/dropdowns). No path maps a title to access. ✅
- Caveat: the title *count* claim is wrong — see **D1** (18 delivered, "20" claimed).

---

## 4. Other report claims verified
- **1f nav rename:** `CollectiveShell.tsx` label "Contacts" → "Contacts (CRM)";
  href `/collective/partner/contacts` + testid `nav-partner-contacts` unchanged.
  Guard allowlist entry present, `approvedBy: "Ozan"`, dated, correct id/reason. ✅
- **1a currency:** `formatShares` / `formatCount` added, additive, no behavior
  change. ✅
- **sprint18 failures PRE-EXISTING:** confirmed — 2 failures in
  `sprint18_phase3.test.ts` (`/api/comms/dev/outbox` returns non-array under the
  test's admin path) reproduce **identically on a pristine HEAD (6f7a17f)**
  worktree; Wave A's commsStore diff does not touch the outbox route. ✅

## 5. Hygiene
- Did NOT run `npm run build`; no `server/public`/`dist` changes to restore.
- Working tree left intact (28 changed/new entries, unchanged from start). Nothing
  committed. Temporary pristine worktree created for the sprint18 check was removed
  and pruned.

---

### Bottom line
Technically the change set is sound and safe: all gates green, no sacred/money/
payments/security violations, 1c/1d/1e/2a behave correctly and rule-compliantly.
The **REVISE** is solely for the inaccurate, repeated "20 titles" claim vs the
18-item list (D1) — reconcile the list to the QA-spec 20 (preferred) or correct the
count across the report + comments. Everything else = APPROVE.
