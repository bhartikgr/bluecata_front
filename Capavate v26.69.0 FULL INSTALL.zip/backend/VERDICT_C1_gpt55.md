# VERDICT_C1_gpt55

VERDICT: REVISE

## Gate results (run independently)
- TypeScript gate: `npx tsc --noEmit | grep -c "error TS"` = 598 (required exactly 598; net-new 0).
- Sacred gate: `sha256sum -c sacred_baseline/SACRED_SHA256.txt | grep -c ': OK'` = 40/40.
- Sacred overlap: Wave C1 diff files vs sacred baseline overlap count = 0.
- Money gate: `server/captableCommitStore.ts` sha16 = `01cd36130ee1c0cb`.
- Guard gate: exit 0; final count line `OK: 926 routes, 194 pages, 92 nav — no silent drops`.
- New require / migration / payments / Airwallex check in `WAVE_C1_SOURCE.diff`: no matches for new `require(`, migration, payments, or Airwallex touches.
- Tests: `npx vitest run server/__tests__/waveC1_invitation_terminal_guards.test.ts server/__tests__/v25_55_shadie_v6.test.ts server/__tests__/v15_invitation_flow.test.ts` exited 0. Result: 3 files passed, 20 tests passed; C1 suite itself passed 4/4.

## Defect requiring revision

1. `client/src/pages/founder/RoundDetail.tsx:528-530` — Wave C1's client-side terminal guards are not present in the actual working tree. The buttons still allow actions on revoked invitations from the UI:
   - resend is disabled only for `i.state === "accepted"`, not `revoked`;
   - extend is disabled only while pending mutation, not for `revoked` or `accepted`;
   - revoke is never disabled for `revoked`.

   This violates the brief requirement that `RoundDetail.tsx` disable resend for `accepted|revoked`, extend for `revoked|accepted`, and revoke for `revoked`. Evidence: the actual file is clean against HEAD for this hunk, while `WAVE_C1_SOURCE.diff` contains the intended hunk. Concrete fix: apply the intended disabled predicates at these lines:
   - resend: `disabled={resendMut.isPending || i.state === "accepted" || i.state === "revoked"}`
   - extend: `disabled={extendExpiryMut.isPending || i.state === "revoked" || i.state === "accepted"}`
   - revoke: add `disabled={i.state === "revoked"}`.

## Other checks
- Revoke route ordering is correct: `DELETE /api/rounds/:id/invitations/:invId` checks `existing.state === "revoked"` and returns 409 before `roundInvitationsRevoke(...)` and before `roundInvitationsNotifyRevoked(...)`, so already-revoked route calls do not re-notify.
- Resend route ordering is correct: it checks `accepted` and `revoked` before calling `roundInvitationsResend(...)`, so route-level revoked resend cannot re-mint a token or email.
- Store ordering is correct for the scoped guards: `revokeInvitation` throws `ALREADY_REVOKED` before DB write/cache mutation/emit; `extendInvitation` throws `INVITATION_REVOKED`/`INVITATION_ACCEPTED` before DB write/emit; `resendInvitation` throws `INVITATION_REVOKED` before token generation, DB write, email, or emit.
- Persist-first and zero-row guard semantics remain in the store mutation paths: DB update occurs before cache mutation/emit for revoke, extend, and resend; zero affected rows clear stale cache and throw.
- Rounds list sorting is implemented on a copy via `[...(rounds.data ?? [])]`, sorts `createdAt` descending, uses id tiebreak, and missing `createdAt` falls back to 0. `createdAt` is included in the client `Round` type and is mapped by `server/roundsStore.ts` `rowToRound`; `/api/rounds` spreads merged round rows into the response.
- Happy-path backend behavior is preserved by regression tests: first revoke + single notification path, pending resend token rotation, pending invitation flows, Shadie-v6 suite, and v15 invitation flow suite all passed.

Because the required `RoundDetail.tsx` client guard hunk is absent from the actual tree, Wave C1 cannot be approved even though the backend gates and tests pass.
