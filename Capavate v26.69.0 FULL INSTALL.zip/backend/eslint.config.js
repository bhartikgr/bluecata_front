// W-FIX4 item 6 — regression guard for button-in-Link nesting.
//
// Additive, opt-in ESLint flat config. It intentionally contains ONLY the one
// rule needed to stop the anti-pattern from returning; it does not lint the
// wider codebase (no existing ESLint setup to preserve). Run with:
//
//   npx eslint --config eslint.config.js "client/src/**/*.tsx"
//
// (or add `"lint": "eslint --config eslint.config.js \"client/src/**/*.tsx\""`
// once eslint + typescript-eslint are installed as devDependencies).
//
// Rationale: a wouter <Link> already renders an <a>. Nesting a <Button> (which
// renders a <button>) or a native <button> inside it produces invalid,
// non-accessible <a><button></a> markup. The correct pattern is
// `<Button asChild><Link/></Button>` (Radix Slot merges the button styling onto
// the anchor) or styling the <Link> directly.

const NEST_MSG =
  "Do not nest a <Button>/<button> inside a wouter <Link> (invalid <a><button></a>). " +
  "Use `<Button asChild><Link/></Button>` or style the <Link> directly.";

export default [
  {
    files: ["client/src/**/*.{tsx,jsx}"],
    rules: {
      "no-restricted-syntax": [
        "error",
        {
          selector:
            "JSXElement[openingElement.name.name='Link'] JSXElement[openingElement.name.name='Button']",
          message: NEST_MSG,
        },
        {
          selector:
            "JSXElement[openingElement.name.name='Link'] JSXElement[openingElement.name.name='button']",
          message: NEST_MSG,
        },
      ],
    },
  },
];
