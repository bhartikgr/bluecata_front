# FIX REPORT — Wave 2M (Messaging + Posting verify-and-repair) — v26.2.0-w2m

**Baseline:** v26.2.0-w2 (HEAD `b624f4f`). **Scope:** Part B of
`ROADMAP_SPEC_GATE_MESSAGING.md` (B1–B6). SACRED `server/messagingStore.ts` byte-identical;
no payments/Airwallex code; no sacred file edited.

## Gates (final)
- Sacred: **40/40** · Money sha16: **01cd36130ee1c0cb** · `messagingStore.ts` sha16
  **17bd56080b6af4a7** (byte-identical, guard test added)
- tsc net-new: **0** (total **598**)
- Guard: **exit 0** — **931** routes (unchanged; W2M repaired existing routes, added none)
- Build: **EXIT 0**
- New suite `wave2M_messaging_posting.test.ts`: **5/5**; client suites **11/11**
  (3 files). Messaging/posting suites pass per-suite (sprint19_comms 36/36,
  sprint21_messages 16/16, v13 persistence 3/3, promotionModeration 7/7, messagingMigration
  14/14). W1 16/16, W2 13/13.
- Pre-existing failing suites UNCHANGED per-suite: `sprint21_invitations` 2, `spvEngine` 30.
  (Full-suite `vitest run server/` shows 381 failures on BOTH pristine and this tree — a
  pre-existing cross-suite pollution artifact, not a W2M regression: pristine 381f/3291p vs
  this tree 381f/3296p = +5 passing new tests, same 381.)

## Server repairs

### B5/B1 — identity never leaks email / raw id  (`commsStore.ts`)
- New `resolveCommsDisplayName(viewerId, subjectUserId, fallback?)` — fallback order:
  privacy-resolver name → supplied full name → company/firm → "Collective member" /
  "Invited contact". Never returns an email or `u_...` id.
- DM-start CRM email-only provisioning now sets `legalName: "Invited contact"` (was
  `crm.email`). DM-start notification + post notifications now route titles through the
  resolver (were `legalName ?? actorId`).

### B3 — posting no-silent-drops + schedule + moderation  (`commsStore.ts`, `networkPostsStore.ts`, `postModerationStore.ts`, `postModerationRoutes.ts`)
- `persistNetworkPost` now returns `{ok} | {ok:false,error}` (was void, swallowed DB
  failures as "non-fatal"). `POST /api/comms/posts` returns **500 POST_PERSIST_FAILED** on
  primary write failure (removes the in-memory entry). The `public_to_collective` dual-write
  failure now returns **500 COLLECTIVE_POST_PERSIST_FAILED** (was memory-only).
- **Root-cause fix (caught in regression):** the post-create persist call used a lazy
  `require("./networkPostsStore")` that fails spuriously under the vitest ESM loader; the
  old code swallowed that error (silent drop) and returned 200. Replaced with a **static
  import** — cycle-safe because networkPostsStore breaks the cycle with a runtime
  `await import("./commsStore")` and has NO static import of commsStore. This both removes
  the silent drop and fixes 20 sprint19_comms failures the naive change had introduced.
- Schedule metadata (`status`/`scheduledFor`/`publishedAt`) persisted in
  `network_posts.content_json`. New `publishDueScheduledPosts(now)` (read-side scheduler,
  idempotent, publishes once + notifies once) wired into `GET /api/comms/posts`.
- New `applyPostModerationToComms(postId, action, moderatorUserId)` bridge in commsStore
  (hide → set in-memory `deletedAt` + emit `post` mutation; unhide → clear + rehydrate from
  DB if missing; flag → emit mutation). Called from `postModerationRoutes` after
  `moderatePost` succeeds, so hide/unhide reflects in `/api/comms/posts` + the Collective
  feed IMMEDIATELY (was DB-only until restart). `listPostsForModeration` now THROWS on read
  failure (was silent `[]`); the route already returns 500 with a visible error.

## Client repairs (client-only; no server/sacred edits)
- `partner/PartnerMessages.tsx` — "New DM" button + picker (from `/api/comms/users`),
  POSTs `/api/comms/dm/start`, visible 403/422 handling (`data-testid="partner-new-dm-button"`).
- `comms/PostsFeed.tsx` — styled schedule datetime field (replaced native
  `datetime-local`); create-post now sends `companyId` for followers/cap_table (audiences
  disabled when no active company); visible partial-failure toast on 500 (no false success);
  comment author display uses `authorLabel || "Collective member"` (no raw id/email).
- `admin/PostsModeration.tsx` — primary author column uses resolved label; raw id moved to
  a secondary muted column.
- `vitest.config.ts` — additive: include `client/src/**/*.test.tsx` + jsdom ONLY for those
  via `environmentMatchGlobs` (default stays `node`; existing suites unaffected — verified).

## Tests + static guards
- `server/__tests__/wave2M_messaging_posting.test.ts` — moderation reflect, scheduler
  (publish-once + future-stays-scheduled + idempotent), identity no-leak, **SACRED
  messagingStore.ts byte-identical hash guard**, **no-new-`require` ESM guard** on the W2M
  files.
- Client: `PartnerMessages.newDm`, `PostsFeed.scheduleAudience`,
  `PostsModeration.reflectIdentity`.

## Rule assurances
- `server/messagingStore.ts` UNCHANGED (sha16 `17bd56080b6af4a7`, guard test enforces it).
- No Airwallex/payment code touched. No new bare `require` added (the one static import is
  cycle-safe; the pre-existing createRequire shim is retained, unused-but-harmless).
  Rule #13 (no email-as-name) enforced across DM + posts + comments + moderation.
