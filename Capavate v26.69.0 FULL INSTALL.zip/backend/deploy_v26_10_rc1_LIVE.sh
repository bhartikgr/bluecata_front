#!/usr/bin/env bash
# Capavate v26.1.0-rc1 LIVE deploy — aligned to the REAL production host.
#
# Live-server truth (Ozan's source-of-truth, 2026-06-15 + Avi's live .env):
#   - GoDaddy WHM VPS / AlmaLinux 9.8, Node v20.20.2, npm 10.8.2, nginx 1.20.1
#   - PM2 process name = "backend" (fork mode). Restart = `pm2 restart backend`.
#   - Production runs the TS SOURCE via tsx (server/index.ts), NOT dist/index.cjs.
#   - Backend dir: /var/www/html/backend ; Frontend dir: /var/www/html/frontend
#   - Env: /var/www/html/backend/.env ; DB: /var/www/html/backend/data.db (+ -shm,-wal)
#   - NEVER overwrite .env or data.db* during deploy. Only sed-bump APP_VERSION.
#   - Health: /api/healthz and /api/health both report {version}. nginx serves SPA
#     fallback from /var/www/html/frontend; stale assets persist unless refreshed.
set -euo pipefail

VERSION="26.1.0-rc1"
APP_DIR="${APP_DIR:-/var/www/html/backend}"
FRONTEND_DIR="${FRONTEND_DIR:-/var/www/html/frontend}"
PM2_NAME="${PM2_NAME:-backend}"
HEALTH_URL="${HEALTH_URL:-https://capavate.com/api/healthz}"
HEALTH_URL_ALT="${HEALTH_URL_ALT:-https://capavate.com/api/health}"
LOCAL_HEALTH="${LOCAL_HEALTH:-http://127.0.0.1:5000/api/healthz}"

echo "==> Capavate v${VERSION} deploy starting (APP_DIR=$APP_DIR, pm2=$PM2_NAME)"
cd "$APP_DIR"

# --- Safety: confirm we are in the backend tree and will NOT clobber live state ---
if [ ! -f package.json ]; then echo "FATAL: no package.json in $APP_DIR"; exit 1; fi

echo "==> Backing up code (EXCLUDING node_modules, uploads, .env, data.db*) to ${APP_DIR}.prev"
rsync -a --delete \
  --exclude=node_modules --exclude=uploads \
  --exclude='.env' --exclude='data.db' --exclude='data.db-shm' --exclude='data.db-wal' \
  "$APP_DIR/" "${APP_DIR}.prev/" 2>/dev/null || true

echo "==> Verifying source version"
SRCVER=$(grep '"version"' package.json | head -1 | sed -E 's/.*"version": "([^"]+)".*/\1/')
if [ "$SRCVER" != "$VERSION" ]; then
  echo "FATAL: package.json reports $SRCVER, expected $VERSION. Aborting."
  exit 1
fi

echo "==> Bumping .env APP_VERSION to $VERSION (in place — never overwrite .env)"
if [ -f .env ]; then
  if grep -q '^APP_VERSION=' .env; then
    sed -i.bak "s/^APP_VERSION=.*/APP_VERSION=$VERSION/" .env
  else
    echo "APP_VERSION=$VERSION" >> .env
  fi
else
  echo "WARN: $APP_DIR/.env not found — leaving env untouched (set APP_VERSION manually)."
fi

echo "==> npm ci"
npm ci --production=false

echo "==> Running DB migrations (additive only; runner scans ./migrations)"
# Uses the REAL script `db:migrate` (tsx server/db/migrate.ts). NO `|| true` mask —
# set -euo pipefail makes a migration failure abort the deploy. The runner applies
# every ./migrations/NNNN_*.sql not already applied. v26.1.0-rc1 ships THREE new
# additive migrations on top of v25.56.0's 0104 (0105/0106 from v26.0.0 + 0107 new here):
#   0105_group_c_contacts_arrangement_json.sql — ADD COLUMN contacts.arrangement_json TEXT (nullable)
#   0106_group_f1_partner_crm_parity.sql        — additive partner_crm_contacts columns
#   0107_enh1_your_decision_durable.sql          — NEW in v26.1.x: durable your_decision_records
#                                                 table (decision state machine, additive+idempotent)
#                                                 (stage, company_id, note_log, tasks, starred,
#                                                  source_kind, source_ref) + partial UNIQUE index
# Both are additive-only and also applied inline in connection.ts so a fresh/live
# DB self-heals on boot. data.db is NOT touched except by these additive migrations.
# Next free migration id after this release: 0108.
MIGRATE_LOG="$(mktemp)"
if ! npm run db:migrate 2>&1 | tee "$MIGRATE_LOG"; then
  echo "FATAL: npm run db:migrate failed. Aborting deploy (no fallback mask)."
  echo "    Migration output saved at: $MIGRATE_LOG"
  exit 1
fi
# Confirm the runner reported success (it prints 'Exit 0' on success). We do NOT
# grep for a 'MIGRATIONS_PRESENT:' line — the runner (migrationRunner, sacred) does
# not emit one. The fail-closed `npm run db:migrate` above is the real gate.
if ! grep -qE 'Exit 0|migrations applied successfully|already applied' "$MIGRATE_LOG"; then
  echo "FATAL: migration runner did not confirm success. See $MIGRATE_LOG"; exit 1
fi
echo "    OK: migrations applied (fail-closed)."
rm -f "$MIGRATE_LOG"

echo "==> Building (server bundle + client dist/public)"
npm run build

echo "==> Publishing fresh client assets to ${FRONTEND_DIR}"
# nginx serves the SPA from FRONTEND_DIR; stale assets persist via error_page
# fallback unless we refresh them. The client build emits to dist/public.
if [ -d dist/public ]; then
  mkdir -p "$FRONTEND_DIR"
  rsync -a --delete dist/public/ "$FRONTEND_DIR/"
  echo "    OK: refreshed $FRONTEND_DIR from dist/public"
else
  echo "WARN: dist/public not found after build — frontend NOT refreshed. Check build output."
fi

echo "==> Restarting PM2 process '${PM2_NAME}'"
if command -v pm2 >/dev/null; then
  pm2 restart "$PM2_NAME" --update-env || { echo "FATAL: pm2 restart $PM2_NAME failed"; exit 1; }
else
  echo "FATAL: pm2 not found; live host runs pm2 process '$PM2_NAME'. Aborting."; exit 1
fi

echo "==> Waiting 8s for service start"
sleep 8

echo "==> Local smoke check ${LOCAL_HEALTH}"
curl -fsS --max-time 10 "$LOCAL_HEALTH" 2>/dev/null | grep -q "$VERSION" \
  && echo "    OK: local backend reports $VERSION" \
  || echo "    (local check did not report $VERSION yet — continuing to public check)"

echo "==> Public smoke check ${HEALTH_URL} (and alt)"
for i in 1 2 3 4 5; do
  RESP=$(curl -fsS --max-time 10 "$HEALTH_URL" 2>/dev/null || echo "FAIL")
  if echo "$RESP" | grep -q "$VERSION"; then
    echo ""; echo "✓✓✓ v${VERSION} IS LIVE — deploy verified (/api/healthz) ✓✓✓"; echo ""
    echo "Health response: $RESP"; exit 0
  fi
  RESP2=$(curl -fsS --max-time 10 "$HEALTH_URL_ALT" 2>/dev/null || echo "FAIL")
  if echo "$RESP2" | grep -q "$VERSION"; then
    echo ""; echo "✓✓✓ v${VERSION} IS LIVE — deploy verified (/api/health) ✓✓✓"; echo ""
    echo "Health response: $RESP2"; exit 0
  fi
  echo "  attempt $i — health did not yet report $VERSION (healthz: $RESP)"
  sleep 4
done

echo "✗✗✗ DEPLOY VERIFY FAILED — service running but health does not report v${VERSION}"
echo "    Rollback hint: rsync -a ${APP_DIR}.prev/ ${APP_DIR}/ (preserves .env/data.db) && pm2 restart ${PM2_NAME}"
exit 1
