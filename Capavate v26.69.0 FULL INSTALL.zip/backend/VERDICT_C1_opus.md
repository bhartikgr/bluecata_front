# VERDICT — Wave C1 (Shadie QA: Rounds) — Independent Verification (Opus)

## 1. VERDICT: **APPROVE**

Wave C1 correctly makes a REVOKED invitation terminal and fail-closed at both the
store and route layers, guarantees a revoked investor is never re-notified or
re-emailed, preserves the existing v25.35 persist-first + zero-row-guard logic,
and sorts the Rounds list newest-created-on-top on a COPY without mutating the
react-query cache. All hard gates pass and no regressions were found.

## 2. Gate results (actual numbers)

| Gate | Required | Actual | Result |
|------|----------|--------|--------|
| tsc `error TS` count | 598 | **598** | PASS |
| Sacred baseline `: OK` | 40 | **40** | PASS |
| Money `captableCommitStore.ts` sha16 | 01cd36130ee1c0cb | **01cd36130ee1c0cb** | PASS |
| Guard exit code | 0 | **0** | PASS |
| Guard counts | 926 / 194 / 92 | **926 / 194 / 92** | PASS |
| C1 terminal-guard test | 4/4 | **4 passed (4)** | PASS |
| v25_55_shadie_v6 | no new fails | **10 passed** | PASS |
| v15_invitation_flow | no new fails | **6 passed** | PASS |

Combined focused run: **20 passed (20)** across 3 files.

## 3. Per-check confirmation

### 3a/4a/5a — Revoked invitation is terminal, fail-closed at BOTH layers

**Store (`server/roundInvitationsStore.ts`) — guards run BEFORE any mutation/email:**
- `revokeInvitation` (L834): after the `if (!row) return` null check, L840
  `if (row.state === "revoked") throw new Error("ALREADY_REVOKED")` — BEFORE the
  `nowIso()` staging, the `UPDATE ... state='revoked'` (L862), the zero-row guard,
  and the cache mutation. CONFIRMED before all writes. No notification is emitted
  from the store; the revoked notification lives only in the route.
- `extendInvitation` (L891): L897 `revoked → INVITATION_REVOKED`, L898
  `accepted → INVITATION_ACCEPTED` — BEFORE the anchor/expiry computation (L908),
  the `UPDATE ... expires_at` (L918), and the cache mutation. Expiry cannot change.
- `resendInvitation` (L989): L995 `revoked → INVITATION_REVOKED` — BEFORE
  `generateToken()`/`sha256Hex()` (L997-998), the `UPDATE ... token_hash` (L1005),
  and `sendMail` (L1028). No token re-mint, no email. CONFIRMED.

**Routes (`server/routes.ts`) — typed 409s + skip notification:**
- Resend POST (L2818): L2843 returns 409 `invitation_revoked` before calling
  `roundInvitationsResend`; catch block L2866 also maps store `INVITATION_REVOKED`
  → 409 (defense in depth). No email path reached.
- Extend PATCH (L2874): L2888 revoked→409, L2891 accepted→409 before mutation;
  try/catch L2896-2903 maps store errors to 409. CONFIRMED.
- Revoke DELETE (L2913): L2927 already-revoked→409 `already_revoked` returns
  BEFORE `roundInvitationsRevoke` AND before `roundInvitationsNotifyRevoked`
  (L2941). The revoked-notification only fires on a FIRST successful revoke.
  **A revoked investor is NEVER re-notified.** CONFIRMED.

**Client (`client/src/pages/founder/RoundDetail.tsx`):**
- L547 resend `disabled ... || i.state === "accepted" || i.state === "revoked"`
- L548 extend `disabled ... || i.state === "revoked" || i.state === "accepted"`
- L549 revoke `disabled={i.state === "revoked"}`
CONFIRMED matches spec (revoked terminal; accepted also blocked for resend/extend).

### 6a — Rounds newest-created on top (`client/src/pages/founder/Rounds.tsx`)
- L160 sorts `[...(rounds.data ?? [])]` — a COPY; the react-query cache is not
  mutated. CONFIRMED.
- L161-162 fall back to `0` when `createdAt` is missing (no crash on undefined).
- L163 `bt - at` = newest createdAt first (DESC). L164 stable id tiebreak.
- L21 `Round` type includes `createdAt?: string | null`. CONFIRMED.
- `/api/rounds` returns `createdAt`: routes.ts L1602 spreads `...r` from
  `mergeLegacyAndDbRounds()`; roundsStore DTO L119 maps `created_at`. CONFIRMED.

### Persist-first semantics preserved
The v25.35 fix-2/fix-3 persist-first-throw + zero-row-guard logic in revoke
(L852-888) and extend (L899-943) is fully intact; the new terminal guards sit
ABOVE it (immediately after the null check). No persist logic altered.

### Test genuinely proves the claims (`waveC1_invitation_terminal_guards.test.ts`)
- Imports (`createInvitation`, `revokeInvitation`, `extendInvitation`,
  `resendInvitation`, `getInvitation`, `_testAccessInvitations`) all exist as real
  exports (store L334/834/891/989/723/1147). `_testAccessInvitations.rows` aliases
  `memInvitations`; `getInvitation` strips `tokenHash`, so the test correctly reads
  the hash via `_testAccessInvitations.rows`.
- T1: revoke-again throws `/ALREADY_REVOKED/` (proves no re-notify path taken).
- T2: extend-on-revoked throws `/INVITATION_REVOKED/` AND `expiresAt` unchanged.
- T3: resend-on-revoked rejects `/INVITATION_REVOKED/` AND `tokenHash` unchanged
  (no re-mint / no email).
- T4: extend-on-accepted throws `/INVITATION_ACCEPTED/`.
All 4 pass. Genuine, not tautological.

### No behavioral regression
- Legitimate revoke of a pending invite + its single notification: verified by
  v25_55_shadie_v6 4a (DELETE→200, accepted→revoked, one email).
- Resend of a live/sent invite (token rotation + resent_at): v25_55_shadie_v6 5a/5b PASS.
- Full invitation flow: v15_invitation_flow 6/6 PASS.

### Hard-rule compliance
- No C1 source file appears in the sacred baseline list.
- No Airwallex/payment references in `WAVE_C1_SOURCE.diff`.
- No new `require()` introduced (the only `require(` matches in
  roundInvitationsStore.ts are in a pre-existing v25.25.2 comment block, L26/30,
  outside the C1 diff hunks).
- No new migration / no new route / no new nav (guard counts unchanged).

## Known pre-existing (NOT a C1 regression)
`server/__tests__/sprint21_invitations.test.ts` → 2 failed / 12 passed. Both
failures are `GET /api/rounds/:roundId/co-soft-circle-members` returning 403 vs
expected 200 (co-soft-circle visibility) — an endpoint C1 does not touch
(C1 changes only invitation resend/extend/revoke actions + rounds sort).
Consistent with the brief; explicitly excluded from the C1 verdict.

## Notes
- I did NOT run `npm run build`; working tree `server/public`/`dist` remain clean
  (nothing to restore). No commit made.
