import hashlib

def get_hash(filename):
    try:
        with open(filename, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception as e:
        return "MISSING_OR_ERROR"

with open('sacred_baseline/SACRED_SHA256.txt', 'r') as f:
    lines = f.read().splitlines()

drift = False
for line in lines:
    if not line.strip(): continue
    expected_hash, filename = line.split(None, 1)
    actual_hash = get_hash(filename)
    if actual_hash != expected_hash:
        print(f"DRIFT FOUND: {filename}")
        print(f"  Expected: {expected_hash}")
        print(f"  Actual:   {actual_hash}")
        drift = True

if not drift:
    print("NO DRIFT FOUND in sacred files.")
