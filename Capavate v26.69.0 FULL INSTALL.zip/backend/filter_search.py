import os

for root, dirs, files in os.walk('.'):
    if "node_modules" in root: continue
    for f in files:
        if ".test." in f and f.startswith('wave2'):
            pass # just a check
        if ".test.ts" in f or ".test.tsx" in f:
            path = os.path.join(root, f)
            with open(path, 'r', encoding='utf-8', errors='ignore') as file:
                lines = file.readlines()
                for i, line in enumerate(lines):
                    if ".filter(" in line:
                        if "=>" in line and "===" in line:
                            # Let's extract the property being checked
                            print(f"{path}:{i} {line.strip()}")
