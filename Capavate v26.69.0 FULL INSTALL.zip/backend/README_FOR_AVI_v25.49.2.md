# Capavate v25.49.2 — Deploy README for Avi (FULL, live-safe)

Net build over live v25.48.2. Cumulative contents: Consortium Partner rebuild + canonical SPV Engine
(v25.49.0) + Bug 1 investor-invitation crash hotfix (v25.49.1) + Investor left-nav reorganization
(v25.49.2). Sacred 39/39 byte-identical · tsc 601 (baseline, zero net-new) · build clean ·
112/112 partner+SPV+investor+Bug1 tests pass. Runtime Node 20 + tsx; pm2 runs the TS source, so no
`npm run build` step. ZIPs via WhatsApp (Gmail strips them).

## INSTALL — pick ONE (both preserve .env + data.db)
0. BACK UP THE DB FIRST (on the server):
   cp /var/www/html/backend/data.db /var/www/html/backend/data.db.$(date +%F_%H%M).bak
1. (Optional) verify: sha256sum -c SHA256SUMS_v25.49.2.txt   (both must print OK)

OPTION A — FULL:
  unzip capavate_v25.49.2_FULL_INSTALL.zip -d capavate_v492
  rsync -a --exclude='.env' --exclude='data.db' --exclude='data.db-shm' --exclude='data.db-wal' --exclude='node_modules' capavate_v492/ /var/www/html/backend/
  cd /var/www/html/backend && npm ci
  pm2 restart backend         # migrations 0083-0087 auto-apply on boot (additive + idempotent)

OPTION B — PATCH (faster; no new deps):
  cd /var/www/html/backend
  unzip -o capavate_v25.49.2_PATCH.zip -d /tmp/cap_v492 && rsync -a /tmp/cap_v492/capavate_v25.49.2_PATCH/ /var/www/html/backend/
  pm2 restart backend

## WILL IT WORK ON LIVE? (pre-flight — all satisfied by this build)
- Additive only: migrations 0083-0087 use IF NOT EXISTS / guarded ADD COLUMN and were verified
  idempotent against a copy of the live data.db (safe to re-run; existing rows untouched).
- No new npm dependencies vs v25.48.2 → PATCH path needs no `npm ci`.
- .env unchanged/compatible: no NEW required env var. Confirm the existing ones still hold (below).
- Existing partner SPV/Fund rows are migrated into the canonical `spv` engine by an idempotent boot
  backfill (INSERT OR IGNORE) — nothing dropped.
- v25.49.2 itself is a client-only nav change; server behavior identical to v25.49.1.

## .env — confirm on live before/after deploy (carried from v25.48.x; nothing new REQUIRED)
- If SPV document storage is on local disk: STORAGE_BACKEND=fs (SPV files under uploads/spv/, DB stores
  relative keys). If S3, keep the AWS_* creds valid.
- Make AIRWALLEX_MODE and PAYMENT_GATEWAY_MODE consistent (both live for real charges, both test to test).
- Keep BRIDGE_ENABLED=0 until a real bridge HMAC secret is set (placeholder still present).
- Dedupe the duplicated COLLECTIVE_ENABLED line if it's still there.
- Prod safety (should already hold): DISABLE_DEV_BYPASS=true, ENABLE_SEED_DATA=false, COOKIE_SECURE=true.

## MIGRATIONS (auto-apply on boot; additive + idempotent)
0083 partner_client_crm · 0084 spv_engine (+ investor_compliance_profile) · 0085 spv_lp_visibility ·
0086 spv_fee_obligation · 0087 spv_deployment wire_payment_ref/closing_doc_ref. No manual step, no downgrade.

## VERIFY AFTER DEPLOY
  curl -fsS https://capavate.com/api/health  →  "version":"25.49.2", "db":"connected"
  Partner portal (/partner/login): loads (no #310 crash), on-brand, grouped nav, Clients CRM,
    Messages/Posts, SPVs wizard (create → no 400/500), fee breakdown shows GP + platform separately.
  Investor portal (/investor/login): left nav shows OVERVIEW/DEALS/NETWORK/ACCOUNT with Settings,
    Notifications, Glossary now in the sidebar; Invitations badge shows pending count; invitation page
    opens without the "category is undefined" crash (missing categories show "Uncategorized").

## STILL OPEN (from Avi's report) — NOT in this build
- Bug 2 (investor profile checkboxes reset on refresh) and Bug 3 (investor lands on wrong platform
  after logout/login): awaiting a clean live reproduction / Ozan confirmation.

## ROLLBACK
Restore the pre-deploy backup dir + data.db.<date>.bak and `pm2 restart backend`. Migrations 0083-0087
are additive-only; the previous build ignores the new tables/columns.
