# VERDICT: APPROVE — Wave B1 Addendum Round 2

I independently verified the round-2 authorization change in `server/companyAttributionRoutes.ts`. The previous IDOR is closed.

## Authorization review

- `GET /api/companies/:id/attribution` remains behind `requireAuth` at `server/companyAttributionRoutes.ts:30`.
- After resolving `partnerId`, the route now authorizes only these allow paths:
  - admin: `ctx.isAdmin` (`server/companyAttributionRoutes.ts:46-47`)
  - founder/team member of the same company: `founderOwnedCompanyIds(ctx).has(id)` (`server/companyAttributionRoutes.ts:48`)
  - member of the linked partner only: `partnerTeamStore.findByUserId(ctx.userId).partnerId === partnerId` (`server/companyAttributionRoutes.ts:49-54`)
  - actually public/listed company: `getListedCompanyIds().has(id)` (`server/companyAttributionRoutes.ts:56-59`)
- If none of those is true, the route returns `{ attributedPartner: null }` without leaking attribution (`server/companyAttributionRoutes.ts:61-64`).
- Fail-open was not introduced: listing-store errors are treated as private (`server/companyAttributionRoutes.ts:56-59`), and the outer catch returns `{ attributedPartner: null }` instead of 500ing the page (`server/companyAttributionRoutes.ts:70-73`).

## IDOR closure and legitimate access

- The new IDOR test is genuine: it creates a private B1 company through `POST /api/partner/me/portfolio-companies`, then requests its attribution as `u_aisha_patel`, an unrelated authenticated investor, and asserts `attributedPartner === null` (`server/__tests__/waveB1_company_attribution.test.ts:77-92`).
- I also ran an independent probe saved at `idor_probe_b1addendum_gpt55_round2.txt`; it confirmed:
  - freshly-created B1 company: `freshListed: false`
  - unrelated private user: `unrelatedPrivate: null`
  - linked partner member, founder-owned company caller, admin, and public/listed access all return the linked partner name
  - after explicit directory listing upsert, unrelated public access returns the partner
- `getListedCompanyIds()` is based on `collective_directory_listings WHERE status = 'listed'`, not mere company existence (`server/collectiveInterestStore.ts:289-305`). The probe confirmed a fresh B1 company is not listed until explicitly listed.

## Client/route safety checks

- Founder-side queries remain gated with `enabled: Boolean(companyId)` / `enabled: Boolean(activeCompanyId)` in `Dashboard.tsx`, `CapTable.tsx`, and `RoundDetail.tsx`.
- No `require()` exists in `server/companyAttributionRoutes.ts`.
- The addendum diff contains only founder UI files, the new attribution test, `server/companyAttributionRoutes.ts`, and `server/routes.ts`; no addendum migration or payment file changes.
- Payments/money core untouched: `server/captableCommitStore.ts` sha16 is `01cd36130ee1c0cb`.

## Gates re-run

- Full B1 test set: PASS — `3 passed`, `8 passed`, `EXIT:0` (`tests_b1addendum_gpt55_round2.txt`).
- TypeScript: baseline preserved — exactly `598` TS errors, `0` in `server/companyAttributionRoutes.ts` (`tsc_b1addendum_gpt55_round2.txt`).
- Sacred files: `40/40` OK, zero failures (`sacred_b1addendum_gpt55_round2.txt`).
- Money core: `01cd36130ee1c0cb`.
- Silent-drop guard: `GUARD_EXIT:0` (`guard_b1addendum_gpt55_round2.txt`).

No new round-2 defect found.
