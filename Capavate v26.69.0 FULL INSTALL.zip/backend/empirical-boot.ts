import { runAuditChainBootVerifier } from "./server/lib/hydrateStores";
import { rawDb } from "./server/db/connection";
import crypto from "crypto";

function sha256(data: string) {
  return crypto.createHash("sha256").update(data).digest("hex");
}

async function setup() {
  const db = rawDb();
  
  db.exec("DELETE FROM audit_log; DELETE FROM audit_chain_health;");
  
  console.log("Setting up 200 tenants with 1 audit_log row each...");
  const stmt = db.prepare(`
    INSERT INTO audit_log (id, tenant_id, actor_id, action, target, payload_json, prev_hash, hash, created_at) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  db.transaction(() => {
    for (let i = 0; i < 200; i++) {
      const tenantId = `tenant_${i.toString().padStart(3, '0')}`;
      
      const id = `log_${i}`;
      const action = "test_action";
      const target = "test_target";
      const ts = "2024-01-01T00:00:00.000Z";
      const payloadJson = "{}";
      const priorHash = "0".repeat(64);
      
      const hash = sha256(`${priorHash}|${id}|${action}|${target}|${ts}|${payloadJson}`);
      
      stmt.run(id, tenantId, "admin", action, target, payloadJson, priorHash, hash, ts);
    }
  })();
  console.log("Setup complete.");
}

async function runTests() {
  await setup();
  console.log("Running verifier...");
  
  const origLog = console.log;
  const origInfo = console.info;
  const loggedMessages: string[] = [];
  
  console.log = (...args) => {
    loggedMessages.push(args.join(" "));
    origLog(...args);
  };
  console.info = (...args) => {
    loggedMessages.push(args.join(" "));
    origInfo(...args);
  };
  
  await runAuditChainBootVerifier({ maxTenants: 64 });
  
  await new Promise(resolve => setTimeout(resolve, 4000));
  
  console.log = origLog;
  console.info = origInfo;
  
  const db = rawDb();
  const rows = db.prepare("SELECT * FROM audit_chain_health WHERE status = 'ok'").all();
  console.log(`Found ${rows.length} rows with status='ok'`);
  
  const multiLogs = loggedMessages.filter(m => m.includes("boot tick:"));
  for (const m of multiLogs) {
    origLog(m);
  }
  
  if (rows.length !== 200) {
    console.error(`Expected 200 healthy tenants, but got ${rows.length}`);
    process.exit(1);
  }
  
  // Verify no infinite loop / duplicate log messages
  // We can just check that sum of tenants processed across all ticks == 200
  let totalProcessed = 0;
  for (const m of multiLogs) {
    const match = m.match(/(\d+) processed/);
    if (match) {
      totalProcessed += parseInt(match[1]);
    }
  }
  origLog(`Total processed across all ticks: ${totalProcessed}`);
  
  if (totalProcessed > 200) {
    console.error("Infinite loop detected! Processed more than 200 tenants.");
    process.exit(1);
  }
  
  console.log("Success! 200 tenants verified successfully.");
}

runTests().catch(err => {
    console.error(err);
    process.exit(1);
});
