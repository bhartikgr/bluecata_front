#!/usr/bin/env python3
"""
WAVE 170 — FAIL-BEFORE HARNESS.

Modelled on scratch_w169_failbefore.py: snapshot the files, REVERT one wave-170
mechanism at a time to its pre-wave BEHAVIOUR, run the two new test files, record
the real output, restore, and verify the restore was byte-exact by hash. If any
restore does not match, this script says so loudly and exits non-zero rather than
leaving the tree half-reverted.

Each revert below removes exactly one mechanism, so a test that still passes with
it removed is reported as VACUOUS.
"""
import hashlib, io, os, subprocess, sys, json, time

REPO = os.path.dirname(os.path.abspath(__file__))
os.chdir(REPO)

SERVER_TEST = "server/__tests__/wave170_unmapped_refusal_reference.test.ts"
DOM_TEST = "client/src/pages/partner/__tests__/wave170_raw_error_dom.test.tsx"
UNIT_TEST = "client/src/lib/__tests__/wave170_partner_action_refusal_text.test.ts"
ART = "build_log/wave170/artefacts"
os.makedirs(ART, exist_ok=True)

FILES = [
    "client/src/pages/partner/PartnerSpvDetail.tsx",
    "client/src/lib/serverRefusalMessage.ts",
    "server/spvEngineRoutes.ts",
    "server/lib/esignatureRoutes.ts",
]


def sha(p):
    return hashlib.sha256(io.open(p, "rb").read()).hexdigest()


def read(p):
    return io.open(p, encoding="utf-8").read()


def write(p, s):
    io.open(p, "w", encoding="utf-8").write(s)


SNAP = {p: read(p) for p in FILES if os.path.exists(p)}
HASH = {p: sha(p) for p in SNAP}
print("snapshot taken:")
for p, h in HASH.items():
    print(f"  {h}  {p}")


def run_tests(tag, tests):
    cmd = ["npx", "vitest", "run", "--reporter=verbose", "--no-coverage", *tests]
    env = dict(os.environ, ENABLE_DEMO_SEED="1", NODE_ENV="test")
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=1800)
    out = (r.stdout or "") + "\n----- stderr -----\n" + (r.stderr or "")
    path = os.path.join(ART, f"failbefore_{tag}.txt")
    write(path, f"$ {' '.join(cmd)}\nEXIT={r.returncode}  ({time.time()-t0:.1f}s)\n\n{out}")
    print(f"[{tag}] EXIT={r.returncode} -> {path}")
    return r.returncode


REVERTS = {
    # 170-1 — the five onError handlers render `e.message` again, which is the
    # shipped pre-wave line at :276/:323/:342/:407/:430. This is the revert that
    # puts an internal string back on screen.
    "1701_five_onerror_render_raw_message": ([
        ("client/src/pages/partner/PartnerSpvDetail.tsx",
         'title: "Invite failed", description: partnerActionRefusalText(e) }),',
         'title: "Invite failed", description: e.message }),'),
        ("client/src/pages/partner/PartnerSpvDetail.tsx",
         'title: "LP commit failed", description: partnerActionRefusalText(e) }),',
         'title: "LP commit failed", description: e.message }),'),
        ("client/src/pages/partner/PartnerSpvDetail.tsx",
         'title: "Capital call failed", description: partnerActionRefusalText(e) }),',
         'title: "Capital call failed", description: e.message }),'),
        ("client/src/pages/partner/PartnerSpvDetail.tsx",
         'title: "Distribution failed", description: partnerActionRefusalText(e) }),',
         'title: "Distribution failed", description: e.message }),'),
    ], [DOM_TEST]),
    # 170-2 — err()'s unmapped tail returns the bare code again, with no
    # reference minted and no log line joining it to anything.
    "1702_err_tail_has_no_reference": ([
        ("server/spvEngineRoutes.ts",
         "return res.status(map[msg] ?? 500).json({ error: msg, incidentCode: mintUnexplainedRefusalReference(msg) });",
         "return res.status(map[msg] ?? 500).json({ error: msg });"),
        ("server/spvEngineRoutes.ts",
         "      incidentCode: mintUnexplainedRefusalReference(msg),\n",
         ""),
    ], [SERVER_TEST]),
    # 170-3 — the resolver trusts whatever it is handed, which is the naive fix
    # every previous wave reached for: it renders codes and stack text again.
    "1703_resolver_trusts_any_message": ([
        ("client/src/lib/serverRefusalMessage.ts",
         "export function partnerActionRefusalText(err: unknown): string {",
         "export function partnerActionRefusalText(err: unknown): string {\n"
         "  if (err instanceof Error && err.message) return err.message; /* PRE-WAVE naive fix */"),
    ], [UNIT_TEST, DOM_TEST]),
    # 170-4 — the sentence test loses its R77 clause, so prose carrying an
    # internal identifier reaches the screen again.
    "1704_sentence_test_drops_r77_clause": ([
        ("client/src/lib/serverRefusalMessage.ts",
         "  if (/\\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+\\b/.test(t)) return false;  // R77 — embedded code",
         "  /* PRE-WAVE: no R77 clause */"),
    ], [UNIT_TEST]),
    # 170-5 — wave 148's ESG minter keeps its own copy of the format, so there
    # are two authorities for one token shape again.
    "1705_esign_minter_duplicates_format": ([
        ("server/lib/esignatureRoutes.ts",
         '  return mintRefusalIncidentCode("ESG");',
         '  return `ESG-${randomBytes(4).toString("hex").toUpperCase()}`;'),
    ], [SERVER_TEST]),
}

def apply(pairs):
    for p, new, old in pairs:
        s = read(p)
        if s.count(new) != 1:
            restore()
            sys.exit(f"REFUSING: revert anchor not unique in {p} ({s.count(new)} hits): {new[:60]!r}")
        write(p, s.replace(new, old))


def restore():
    for p, s in SNAP.items():
        write(p, s)
    bad = [p for p in SNAP if sha(p) != HASH[p]]
    if bad:
        print("RESTORE MISMATCH:", bad)
        return False
    print("restore verified byte-exact for all files")
    return True


results = {}
for tag, (pairs, tests) in REVERTS.items():
    apply(pairs)
    results[tag] = run_tests(tag, tests)
    if not restore():
        sys.exit(1)

results["AFTER_full_wave170"] = run_tests(
    "AFTER_full_wave170",
    [SERVER_TEST, DOM_TEST, UNIT_TEST,
     "client/src/pages/partner/__tests__/wave164_itemC_cap_split_dom.test.tsx",
     "server/__tests__/w82_spv_launch_atomicity.test.ts"],
)

write(os.path.join(ART, "failbefore_summary.json"), json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
if results["AFTER_full_wave170"] != 0:
    sys.exit("AFTER run did not pass")
for tag, c in results.items():
    if tag != "AFTER_full_wave170" and c == 0:
        sys.exit(f"VACUOUS: {tag} passed with the mechanism reverted")
print("FAIL-BEFORE / PASS-AFTER established for every reverted mechanism")
