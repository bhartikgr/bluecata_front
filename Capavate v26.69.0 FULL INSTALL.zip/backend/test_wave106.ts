import { recordLpCommitIdentity, listLpInvites } from "./server/spvLpInviteStore";
import { rawDb } from "./server/db/connection";
import { resolveDisplayName } from "./server/lib/displayNameResolver";
import { lpInvestorIdForEmail } from "./server/lib/lpIdentity";

const partnerId = "p_test106";
const spvId = "spv_test106";
const partnerUserId = "u_partner106";

function run() {
  console.log("--- Initial setup ---");
  rawDb().prepare(`DELETE FROM spv_lp_invite WHERE spv_id = ?`).run(spvId);

  console.log("--- Inserting an initial invite ---");
  rawDb().prepare(`
    INSERT INTO spv_lp_invite (id, partner_id, spv_id, email, first_name, last_name, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
  `).run("inv_1", partnerId, spvId, "Ozan@capavate.com", "Ozan", "Isinak", "invited");
  
  console.log("Before commit:", listLpInvites(partnerId, spvId));
  
  const res1 = recordLpCommitIdentity(partnerId, spvId, {
    email: "ozan@capavate.com",
    firstName: "Ozan",
    lastName: "Isinak"
  }, partnerUserId);
  
  console.log("After commit matching email:", res1);
  console.log("State:", listLpInvites(partnerId, spvId));

  const res2 = recordLpCommitIdentity(partnerId, spvId, {
    email: "newguy@example.com",
    firstName: "New",
    lastName: "Guy"
  }, partnerUserId);
  
  console.log("After commit non-matching email:", res2);
  console.log("State:", listLpInvites(partnerId, spvId));

  try {
    recordLpCommitIdentity(partnerId, spvId, { email: "", firstName: "", lastName: "" }, partnerUserId);
  } catch (e) {
    console.log("Empty identity error:", e.message);
  }
}

run();