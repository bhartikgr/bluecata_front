import os
import re

files = [
    "server/__tests__/wave207_fee_basis_fence.test.ts",
    "server/__tests__/w227_accreditation_jurisdiction_scope.test.ts",
    "server/__tests__/w221_benchmarking_opt_out.test.ts",
    "client/src/lib/__tests__/w226_attestation_rendered.test.tsx",
    "client/src/pages/investor/__tests__/w221_benchmarking_sharing_dom.test.tsx",
    "server/__tests__/w223_audit_chain_verification.test.ts",
    "client/src/components/partner/__tests__/w216_esign_rendered_bytes_are_signed_bytes.test.tsx",
    "server/__tests__/w216_esignature_intent_and_hash.test.ts",
    "server/__tests__/w226_attestation_stored_bytes.test.ts",
    "server/__tests__/w219_r206_collective_sharing_honoured_in_benchmark.test.ts",
    "client/src/pages/founder/__tests__/w228_collective_false_claims.test.tsx",
    "client/src/pages/partner/__tests__/w219_retention_link_reaches_a_real_page.test.tsx"
]

for f in files:
    if os.path.exists(f):
        with open(f, 'r') as file:
            content = file.read()
            print(f"=== {f} ===")
            
            # Check for replica
            # Look for `.toLowerCase()`, `.trim()` inside expect
            if ".toLowerCase()" in content or ".trim(" in content:
                print("FOUND POTENTIAL NORMALISATION: toLowerCase / trim")
                for line in content.split('\n'):
                    if ".toLowerCase()" in line or ".trim(" in line:
                        if "expect(" in line or ".toEqual(" in line or ".toBe(" in line:
                            print("  " + line.strip())

            # Look for empty arrays/sets being compared without length checks
            if "toEqual([])" in content or "toEqual(new Set())" in content:
                print("FOUND POTENTIAL EMPTY FILTER:")
                for line in content.split('\n'):
                    if "toEqual([])" in line or "toEqual(new Set())" in line:
                        print("  " + line.strip())

            # Look for querySelector that is unscoped or just `screen.getBy`
            
            # Look for filter on wrong field
            if "filter(" in content:
                for line in content.split('\n'):
                    if "filter(" in line:
                        print("  " + line.strip())
                        
            # Look for expect(true).toBe(true) or similar vacuous tests
            if "expect(true).toBe(true)" in content:
                print("FOUND VACUOUS TEST")
                
            # Look for `if` statements in tests without assertions inside them or where they might be skipped
