# VERDICT: REVISE

Wave B2 is not approvable. The basic gates mostly pass, but I found real behavioral/security defects in the company Make-Private flow and SPV status integrity. These are not cosmetic.

## Gate results

- TypeScript error count: PASS — `npx tsc --noEmit | grep -c "error TS"` returned `598`.
- Sacred baseline: PASS — `sha256sum -c sacred_baseline/SACRED_SHA256.txt | grep -c ": OK"` returned `40`.
- Money core hash: PASS — `server/captableCommitStore.ts` sha16 is `01cd36130ee1c0cb`.
- Guard: PASS — exit `0`; output `OK: 926 routes, 194 pages, 92 nav — no silent drops`.
- Wave B2 targeted test: PASS — `server/__tests__/waveB2_pipeline_dynamic.test.ts` passed `4/4`.
- B2 source diff scope: PASS for `WAVE_B2_SOURCE.diff` — only `client/src/pages/partner/PartnerPipeline.tsx` and `server/__tests__/waveB2_pipeline_dynamic.test.ts`.
- Raw `git diff --name-only`: FAIL as a literal gate in this workspace — it contains many prior Wave A/B1 files and server source changes, not just B2. This appears cumulative workspace state rather than B2 source diff, but the literal command does not satisfy the brief.
- New `require()` in B2 diff: PASS — none found in `WAVE_B2_SOURCE.diff`.
- B2 diff payments/Airwallex/migrations: PASS — no matches in `WAVE_B2_SOURCE.diff`.

Gate logs saved:
- `/home/user/workspace/capavate_work/gate_b2_tsc_gpt55.txt`
- `/home/user/workspace/capavate_work/gate_b2_sacred_gpt55.txt`
- `/home/user/workspace/capavate_work/gate_b2_money_gpt55.txt`
- `/home/user/workspace/capavate_work/gate_b2_guard_gpt55.txt`
- `/home/user/workspace/capavate_work/gate_b2_vitest_gpt55.txt`
- `/home/user/workspace/capavate_work/gate_b2_diff_names_gpt55.txt`

## Defects requiring revision

### 1. Company Make-Private UI gate does not match the server gate

- Client: `client/src/pages/partner/PartnerPipeline.tsx:95` defines `canPromote` as `managing_partner` OR `associate`.
- Client: `client/src/pages/partner/PartnerPipeline.tsx:383-402` renders the `Make Private` button under `canPromote`, so associates see/click the withdraw action.
- Server: `server/partnerRoutes.ts:973-978` gates `POST /api/partner/me/promotions/:id/withdraw` with `assertSubRole("managing_partner")` only.

Why this fails B2: the brief explicitly requires the withdraw path to be managing-partner gated server-side and the UI gate to match. It currently does not match; associates get a dead/destructive affordance that the server must reject.

Concrete fix: split the gates, e.g. `const canWithdrawPromotion = role.identity?.subRole === "managing_partner";`, and render/call `Make Private` only when `collectivePromo && canWithdrawPromotion`. Keep `Publish to Collective` available to the existing promote roles if desired.

### 2. Pending reviewed collective promotions are not recognized, so Make-Private is missing for the reviewed promote flow

- Server status enum: `server/partnerWorkspaceStore.ts:369-379` includes `pending_collective_review`.
- Server create path: `server/partnerWorkspaceStore.ts:2249-2252` creates `collective_deal_room` promotions with status `pending_collective_review`, not `pending`.
- Client type: `client/src/pages/partner/PartnerPipeline.tsx:62-67` omits `pending_collective_review` from `Promotion.status`.
- Client active-promotion lookup: `client/src/pages/partner/PartnerPipeline.tsx:389-390` treats only `live` or `pending` collective promotions as active.

Why this fails B2: after the reviewed `Publish to Collective` flow creates the pending reviewed promotion, the pipeline card will not detect it as an active collective promotion and will keep showing `Publish to Collective` instead of `Make Private`. That means the required “withdraw the correct live OR pending collective promotion” behavior is broken for the server’s actual pending status.

Concrete fix: add `pending_collective_review` to the client `Promotion.status` union and treat it as active in all collective promotion checks, e.g. `p.status === "live" || p.status === "pending" || p.status === "pending_collective_review"`. Consider showing an “In review” badge for pending reviewed promotions.

### 3. SPV status PATCH accepts arbitrary status values server-side

- Server route: `server/spvEngineRoutes.ts:171-174` passes the request body directly into `spvEngineStore.updateSpv`.
- Store update: `server/spvEngineStore.ts:334-342` validates `distributionScope` and `lpVisibility`, but assigns `if (patch.status) s.status = patch.status` without checking `SPV_STATUSES`.
- Canonical statuses: `shared/spvEngine.ts:42-45` define the allowed six statuses.

Why this fails B2: B2 exposes status mutation from the client. The UI only offers the six valid statuses, but a client-supplied `status` can still persist an invalid lifecycle state. The client fallback prevents a crash/drop in the UI, but it does not preserve server-side integrity.

Concrete fix: add a runtime `isSpvStatus` guard (or equivalent `SPV_STATUSES.includes`) in `spvEngineStore.updateSpv` and reject invalid `patch.status` with `INVALID_SPV_STATUS`; apply the same validation on `createSpv` if arbitrary create payloads can include `status`.

### 4. SPV “Published to Collective” copy/badge overstates discoverability for draft SPVs

- Client: `client/src/pages/partner/PartnerPipeline.tsx:216-221` says a scope flip to `collective_only` means “This SPV is now discoverable in the Collective.”
- Client: `client/src/pages/partner/PartnerPipeline.tsx:456-464` shows `In Collective` solely from `distributionScope === "collective_only"`.
- Server discovery rule: `server/spvEngineStore.ts:320-327` excludes draft SPVs from discovery before applying scope filters; `collective_only` is discoverable in the Collective only when the SPV is not draft and not archived.

Why this fails B2: a default draft SPV can be flipped to `collective_only` and the UI claims it is discoverable/in Collective, but the SPV engine will not return draft SPVs from `/api/collective/spvs`. That fails the requested confirmation that the scope toggle makes the SPV Collective-discoverable per the engine’s own rules.

Concrete fix: either block/disable `Publish to Collective` while `status === "draft"` with explanatory copy, or change the badge/toast to distinguish `Collective scope set` from actual Collective discoverability until the SPV reaches a discoverable status. Ideally also add a test that sets `status: "open"`, flips `distributionScope: "collective_only"`, verifies `/api/collective/spvs` includes it, then flips `private` and verifies removal.

## Confirmed working pieces

- Company bucketing is data-driven by `deal.stage` in `client/src/pages/partner/PartnerPipeline.tsx:231-232` and rendered by stage at `client/src/pages/partner/PartnerPipeline.tsx:334-341`.
- Company stage changes PATCH `/api/partner/me/pipeline/:id` and invalidate `/api/partner/me/pipeline` at `client/src/pages/partner/PartnerPipeline.tsx:101-107`.
- SPV bucketing covers all six requested columns at `client/src/pages/partner/PartnerPipeline.tsx:42` and `client/src/pages/partner/PartnerPipeline.tsx:239-243`; unknown statuses fall back into the draft bucket without dropping the SPV.
- SPV status/scope client mutations invalidate `/api/partner/me/spv` at `client/src/pages/partner/PartnerPipeline.tsx:194-223`.
- SPV partner scoping is session-derived, not client-derived: route uses `req.partnerContext!.partnerId` in `server/spvEngineRoutes.ts:171-174`; store `getSpv` fails closed on partner mismatch in `server/spvEngineStore.ts:304-308`.
- Promotion withdraw isolation is partner-scoped at `server/partnerRoutes.ts:982-989` and `server/partnerWorkspaceStore.ts:2350-2353`.
- B2 source diff does not touch the sacred cap-table ledger path; money hash is unchanged.
