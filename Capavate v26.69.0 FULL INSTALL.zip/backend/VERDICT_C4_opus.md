# VERDICT — Capavate Wave C4 (Pre/post-close projection tab crash) — Opus verifier

## 1. VERDICT: **APPROVE**

Independent adversarial review of the Wave C4 fix (committed at HEAD `d755433`).
The fresh-round crash (`null.toString()` → `BigInt(NaN)`) is correctly resolved by
(a) gating the projection in `ProjectionPanel` and (b) making `projectPostClose`
null-safe. No HARD RULE violations. All gates and correctness tests pass.

## 2. Gate results (actual)

| Gate | Expected | Actual | Result |
|------|----------|--------|--------|
| tsc net-new errors | 598 | **598** | PASS |
| Sacred `: OK` count | 40 | **40** | PASS |
| Money `captableCommitStore.ts` sha16 | 01cd36130ee1c0cb | **01cd36130ee1c0cb** | PASS |
| Guard exit / counts | 0, 929/194/92 | **exit 0, 929 routes / 194 pages / 92 nav** | PASS |
| Wave C4 vitest | 4 pass | **4 passed** | PASS |

## 3. Per-check confirmations

- **Diff scope** — `git diff HEAD~1 --name-only` shows only the 3 C4 code files
  (`client/src/lib/engineDemo.ts`, `client/src/lib/engineDemo.waveC4.test.ts`,
  `client/src/pages/founder/RoundDetail.tsx`) plus non-source docs/backups/verify
  artifacts (C3 leftovers). CONFIRMED.
- **No engine-package edit** — no `packages/cap-table-engine/**` source in the diff
  (`git diff HEAD~1 --stat -- 'packages/cap-table-engine/**'` is empty). The only
  `packages/`-matching entries are C3 `verify_*` text files, not engine source. The
  fix is confined to the demo wrapper + panel. CONFIRMED.
- **Fresh-round: no crash, engine not called with degenerate inputs** —
  `RoundDetail.tsx:1029-1040`: `canProject = Number.isFinite(preMoneyNum) &&
  preMoneyNum > 0 && Number.isFinite(targetNum) && targetNum > 0`; `post` is `null`
  when `!canProject`, so `projectPostClose` is never called for a 0/0 round.
  The gated branch (`RoundDetail.tsx:1066-1078`) renders the pre-close cap table
  (`testid="table-pre"`) plus guidance empty-state (`projection-needs-terms`,
  `projection-gated-note`). CONFIRMED — no BigInt(NaN) path reachable.
- **Gate correctness** — predicate is true ONLY for both-positive-finite; vitest
  test 1 asserts false for `(null,null)`, `(0,0)`, `(1e6,0)`, `(0,5e5)`,
  `(undefined,undefined)`, `(NaN,5e5)`; test 2 asserts true for `(8e6,2e6)`.
  The test's `canProject` mirror is byte-consistent with the real gate. CONFIRMED.
- **Valid rounds still project** — when `canProject`, the original full pre/post
  comparison renders unchanged (`RoundDetail.tsx:1055-1064`: `table-pre`,
  `table-post`, allocation line). vitest test 3 confirms `projectPostClose` returns
  a valid result with Founder row for positive inputs. No regression. CONFIRMED.
- **Engine null-safety (defense in depth)** — `engineDemo.ts:247-249` coerces
  `preMoneyValuation`/`investmentAmount` to a finite number (fallback 0) before
  `.toString()` (`engineDemo.ts:262-263`); param type widened to
  `number | null | undefined`. vitest test 4 confirms no thrown error matches
  `reading 'toString'` or `of null`. CONFIRMED — raw `null.toString()` crash cannot
  recur.
- **No new migration** — no migration/`.sql` files in diff. CONFIRMED.
- **Payments/Airwallex untouched** — no payment/airwallex source in diff. CONFIRMED.

## Notes
- `npm run build` was NOT run; no `server/public`/`dist` restore was needed.
- Working tree has only verify artifacts + one deleted stale backup tgz; no source
  file is dirty. Nothing committed by verifier.

**No defects found.**
