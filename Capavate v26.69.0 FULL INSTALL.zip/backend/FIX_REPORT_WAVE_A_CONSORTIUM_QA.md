# FIX REPORT — Wave A (Consortium Partner QA, v26.1.x)

Low-risk batch from the EDITS-version9 QA deck. Base: v26.1.0 final (HEAD `6f7a17f`).
Client + additive-server only. All gates green (see bottom).

## Items

### 1f — Nav rename "Contacts" → "Contacts (CRM)" ✅
- `client/src/components/CollectiveShell.tsx` — partner nav label only; `href`
  (`/collective/partner/contacts`) and `data-testid` (`nav-partner-contacts`)
  UNCHANGED. Route/page untouched.
- Guard: the rename reads as a label disappearance (guard tracks `href\tlabel`);
  added a logged, Ozan-approved allowlist entry
  (`scripts/silent-drop-guard/allowlist.json`). Not a functional removal.

### 1e — "Engine legal-entity type" field removed (redundant) ✅
- Analysis: `WAVE_A_1e_LEGAL_ENTITY_ANALYSIS.md`. The strict `jurisdiction` enum
  duplicated Jurisdiction (country) + Legal entity structure; the server already
  falls back to `delaware` for any non-enum value.
- `client/src/pages/partner/PartnerSpvEngine.tsx` — removed the standalone field;
  the enum is now AUTO-DERIVED from the country (`deriveEngineJurisdiction`,
  mirroring the server fallback exactly) and carried on a hidden input so the
  `spv-w-jurisdiction` testid + submitted value are preserved. Also removed the
  redundant Review row. No enum change, no migration (rule #8).
- Recommendation included: investor-grade two-field domicile model (country →
  structure), matching Carta/AngelList/Sydecar norms.

### 1a — Thousands separators (currency + shares) ✅
- Audit: `WAVE_A_1a_THOUSANDS_SEPARATOR_AUDIT.md`. Consortium Partner surfaces are
  already separator-compliant for currency (all use `formatMinor` / Intl) and for
  financial share counts (`fmtNum`); the QA "120000/30083" values are editable
  `<input type=number>` fields (a native input cannot show grouping separators).
- Added canonical `formatShares()` / `formatCount()` primitives to
  `client/src/lib/currency.ts` for future share/count renders and the
  platform-wide expansion phase. Additive; no behavior change.

### 1d — Posts author label for Consortium Partners ✅
- Root cause: the generic identity resolver has no partner-org identity, so a
  partner author (synthetic `u_redeemed_…` id) leaked a raw id into the byline.
- `server/adminContactsStore.ts` — new `getConsortiumPartnerDisplayName(partnerId)`
  (displayName → legalName; consortium_partner only).
- `server/commsStore.ts` — new `resolvePartnerPostAuthorLabel()` applying the
  QA precedence, honoring privacy: (1) chosen SCREEN NAME → (2) anonymous ⇒
  "Consortium Partner" → (3) registered/company name, else "Consortium Partner".
  Wired into `projectPost` for user-authored posts only. Sacred
  `userPrivacyResolver.ts` / `profileStore.ts` untouched (READ via
  `readUserPrivacyRaw`).

### 1c — Full sign-off before Launch (verifiable + recorded) ✅
- Migration **0108** (`spv_launch_signoffs`) — additive, idempotent, mirrored in
  `migrations/` + `server/db/migrations/` + inline self-heal
  (`applyC1cSpvLaunchSignoffSchema` in `server/db/connection.ts`). No FKs to
  money-core / Avi tables; never touches payments.
- `server/spvLaunchSignoffStore.ts` (new, non-sacred) — versioned ESIGN/UETA
  attestation text (`ATTESTATION_VERSION` v1), `recordSignoff` (identity from
  session only), `listSignoffsForSpv`.
- `server/spvEngineRoutes.ts` — `POST /api/partner/me/spv` now REQUIRES
  `signoffLegalName` (typed) + `signoffAccepted` (true) or returns 400 (no SPV
  created); records the sign-off durably after create. New GET
  `/api/partner/me/spv/:spvId/signoffs` for verification (partner-scoped, 404 on
  cross-partner).
- `client/src/pages/partner/PartnerSpvEngine.tsx` — Review step now shows an
  "Authorized sign-off (required)" block: typed full legal name + attestation
  checkbox (full versioned text) + audit note; Launch is gated on both.

### 1b — Live info bar (Capavate Pulse) — DIAGNOSIS (no code change needed) ✅
- The bar is the shared `MarketTicker` (already reused by Collective + partner via
  `CollectiveShell`, Q6). The Capavate Pulse segment shows real DB numbers; the
  `— — —` is only the market/crypto/macro tiles, which are `PROVIDER_NOT_CONFIGURED`
  because no provider is set on the LIVE host.
- **Action for Avi (config, not code):** set `FEEDS_PROVIDER=yahoo_coingecko` in
  the live `.env` and `pm2 restart backend --update-env`. No API key required.

### 2a — Team titles (Option 1: Title + Access) ✅
- Constraint: the 5 `subRole` values are server-enforced permission tiers; the QA
  list is 18 job titles. Per Ozan (Option 1), Title and Access are SEPARATE.
- `shared/partnerTitles.ts` (new) — the 18 `PARTNER_TITLES` (exactly the QA slide) + `isPartnerTitle`.
- Invitations carry an optional `title` in `invitation_json` (no migration);
  active-member titles reuse the existing `partner_team_member_contact` override.
  `server/partnerWorkspaceStore.ts` + `server/partnerRoutes.ts` thread `title`
  (validated to the known list; unknown ⇒ null — never a permission).
- `client/src/pages/partner/PartnerTeam.tsx` — invite form now has a **Title**
  dropdown (18) + an **Access level** dropdown (5); members/invitations tables
  show Title and Access columns. Titles never grant permissions.

## Reskin (slide 1) — verified already live; NOT a Wave A code item
- Live DOM inspection confirmed the partner workspace already applies the theme
  (`<main>` bg `rgb(250,250,248)` = `#fafaf8`, `<h1>` Instrument Serif,
  `data-product="partner"` present). It reads subtle because the theme currently
  touches page bg + headings only. Deeper card/section theming (option C, matching
  the sacred `capavate-tokens.css` system) is proposed as its own focused pass.
- Separately: the LIVE backend reports **26.0.0**, so v26.1.0 (incl. Waves 1–5)
  is not deployed yet — a deploy action for Avi, independent of this code.

## Gates (at end of Wave A)
| Gate | Result |
|---|---|
| Sacred files | **40/40** byte-identical (0 failed) |
| Money core `captableCommitStore.ts` sha16 | **01cd36130ee1c0cb** (unchanged) |
| tsc `--noEmit` | **598** (net-new **0**) |
| Anti-silent-drop guard | **exit 0** — 924 routes / 193 pages / 91 nav (new signoffs route + renamed nav are informational adds; rename allow-listed) |
| `npm run build` | **OK** |
| New `require()` in server TS | none (ESM/dynamic import only) |
| Payments / Airwallex | untouched |
| Migrations | 0108 additive + idempotent + mirrored + inline self-heal; SQL validated |
| Targeted tests | spvUnifiedCanonical 9/9; partner_workspace + groupF1 pass; the 2 sprint18 outbox failures are PRE-EXISTING (identical on pristine baseline) |

## Files
Changed: CollectiveShell.tsx, currency.ts, PartnerSpvEngine.tsx, PartnerTeam.tsx,
allowlist.json, adminContactsStore.ts, commsStore.ts, connection.ts,
partnerRoutes.ts, partnerWorkspaceStore.ts, spvEngineRoutes.ts.
New: shared/partnerTitles.ts, server/spvLaunchSignoffStore.ts,
migrations/0108_*.sql (x2 mirrored), WAVE_A_1a/1e docs, WAVE_A_CHANGES.diff.

## Triple-verification (rule #7 — GPT-5.5 decides)
- **Round 1:** Gemini 3.1 Pro APPROVE; Opus 4.8 REVISE (title count); GPT-5.5 REVISE (4 defects: sign-off not fail-closed, wrong signerSubRole field, 18-vs-20 title claim, invitation title not carried on redeem).
- **Round 2:** all 4 fixed; GPT-5.5 REVISE (2 remaining: legacy `/api/partner/me/spvs` create bypassed sign-off; stale "(20)" wording in report).
- **Round 3:** legacy route sign-off-gated (+ canonical-shim test updated, still passes THROUGH the one engine); wording corrected. **GPT-5.5 VERDICT: APPROVE.**
- Final gates: tsc 598, sacred 40/40, money 01cd36130ee1c0cb, guard exit 0, tests 13/13 (spvUnifiedCanonical 9 + waveA 4), no new require().
