# VERDICT — Wave B2 (Consortium Partner QA 3b/3c) — Opus (independent verifier)

## 1. VERDICT: **APPROVE**

Wave B2 is a clean, client-only change plus one new server test. All hard-rule gates
pass at their required values, all correctness behaviours are implemented and verified,
and the change set is provably isolated to exactly the two intended files.

---

## 2. Gate results (actual numbers)

| Gate | Required | Actual | Result |
|------|----------|--------|--------|
| tsc net-new errors | 598 | **598** | PASS |
| Sacred 40/40 byte-identical | 40 OK, 0 fail | **40 OK, 0 fail** | PASS |
| Money `server/captableCommitStore.ts` sha16 | `01cd36130ee1c0cb` | **`01cd36130ee1c0cb`** | PASS |
| Guard exit code | 0 | **0** | PASS |
| Guard route / page / nav counts | 926 / 194 / 92 | **926 / 194 / 92** | PASS |
| Wave B2 test (`waveB2_pipeline_dynamic.test.ts`) | 4 pass | **4 passed / 4** | PASS |
| B2 source footprint | only PartnerPipeline.tsx + new test | **exactly those two** | PASS |

Notes:
- Guard reported "7 new items added since baseline" (3 server routes, 2 client
  routes/pages, 2 nav) — these are from **prior waves A/B1** (add-portfolio-company,
  company attribution, accreditation, contacts CRM), **NOT B2**. B2 adds zero
  routes/nav/pages, which is why the guard counts remain at 926/194/92 and exit 0.
- `npm run build` was **not** run, so no `server/public`/`dist` restore was needed.

---

## 3. Change-set isolation (adversarial footprint check)

Because the working tree carries uncommitted Wave A + B1 changes on top of HEAD
(v26.1.0), `git diff --name-only` vs HEAD is noisy. I isolated B2's *real* footprint
by extracting the pre-B2 baseline (`backups/capavate_tree_waveB1_COMPLETE.tgz`) and
diffing it against the current tree, restricted to source dirs:

```
diff -rq preB2/client  client/   -> only PartnerPipeline.tsx differs
diff -rq preB2/server  server/   -> only NEW server/__tests__/waveB2_pipeline_dynamic.test.ts
diff -rq preB2/shared  shared/   -> (no differences)
diff -rq preB2/migrations ...    -> (no differences)
```

- **No server source file changed** (only the new test file added). Confirmed.
- **No new migration.** WAVE_B2_SOURCE.diff contains zero migration hunks; no new
  `migrations/*.sql` vs baseline.
- **Payments/Airwallex untouched** — 0 references in PartnerPipeline.tsx and the test.
- **No new `require()`** in the new test (ESM imports only); no server TS changed at all.

I also re-applied `WAVE_B2_SOURCE.diff` onto a pristine copy of the baseline
PartnerPipeline.tsx and confirmed the result is **byte-identical** to the applied
working-tree file (and likewise for the new test). The diff and the tree agree.

---

## 4. Per-check correctness confirmation

### Dynamic bucketing — SPVs by status (KEY requirement) — CONFIRMED
- `PartnerPipeline.tsx:42` `SPV_LIFECYCLE_STAGES = ["draft","open","deployed","distributing","closed","wound_down"]`.
- Canonical `shared/spvEngine.ts:42-44 SPV_STATUSES = ["draft","open","closed","deployed","distributing","wound_down"]` — **same 6 values** (order differs, irrelevant for columns). Every real status therefore has a column → **no SPV dropped**.
- Bucketing loop `PartnerPipeline.tsx:110-113`:
  `const st = (s.status ?? "draft"); (bySpvStage[st] ?? bySpvStage.draft).push(s);`
  → **unknown/legacy status falls back to `draft`**, so no SPV is ever dropped.
- Status change persists + re-buckets: `spvStatusMut` PATCHes `/api/partner/me/spv/:id { status }`
  and on success `invalidateQueries(["/api/partner/me/spv"])` (`:64-75`) → card auto-moves on next fetch.

### Dynamic bucketing — companies by stage — CONFIRMED
- Existing 6-stage funnel unchanged (`byStage` at `:101-102`; render `:335-372`); stage
  dropdown (`stage-select-*`) PATCHes and invalidates. B2 preserves this behaviour.

### Company Publish / Make-Private (correct promotion selection) — CONFIRMED
- `PartnerPipeline.tsx:389-391`:
  `promos.find(p => p.promotionType === "collective_deal_room" && (p.status === "live" || p.status === "pending"))`.
  This is exactly "collective_deal_room, live OR pending".
- If found → **Make Private** button withdraws *that exact* promotion id via
  `withdrawMut.mutate({ promotionId: collectivePromo.id })` (`:401`).
- If not found → **Publish to Collective** opens the reviewed Promote flow
  (`setPromoteDeal(d)`, `:409`) — the existing admin-reviewed
  `POST /api/partner/me/pipeline/:id/promote-to-collective`.
- Withdraw is **server-gated to managing_partner** and **cross-partner isolated**:
  `server/partnerRoutes.ts:974-996` — `requirePartnerAuth` + `assertSubRole("managing_partner")`
  + `requireSignedAgreement`, and rejects promotions whose `partnerId !== ctx.partnerId` (404).
- `Promotion.status` union (`:66`) includes `"pending"`, so the `.find` is type-valid; tsc stays 598.

### SPV scope toggle (collective_only <-> private) — CONFIRMED
- Constants `SPV_SCOPE_COLLECTIVE = "collective_only"`, `SPV_SCOPE_PRIVATE = "private"` (`:59-60`).
- `spvScopeMut` PATCHes `/api/partner/me/spv/:id { distributionScope }` and invalidates the SPV query (`:81-98`).
- UI reads current scope: `isCollective = s.distributionScope === "collective_only"` (`:456`):
  shows **"In Collective" badge** + **Make Private** when collective_only; **Publish to Collective** otherwise (`:461-504`).
- Server `updateSpv` validates scope via `isSpvDistributionScope` (`spvEngineStore.ts:337`) and
  touches only SPV metadata — **no cap-table/ledger/money path**.

### Cross-partner isolation — CONFIRMED
- PATCH handler `spvEngineRoutes.ts:171-176` uses `requirePartnerAuth` + `assertSubRole(...WRITE_ROLES)`
  + `requireSignedAgreement`; partnerId is taken from `req.partnerContext!.partnerId` (session-resolved),
  **never from the client body**. `updateSpv(partnerId, spvId, ...)` scopes lookup by partnerId.
- `requirePartnerAuth` (`server/lib/requirePartnerAuth.ts:43-69`) fail-closes: 401 if unauthenticated,
  **403 PARTNER_NOT_FOUND** if the user has no team membership → a stranger (`u_stranger_not_partner`)
  is refused and no mutation occurs.
- Test 3 asserts `[401,403].contains(status)` and status stays `"draft"` — matches server behaviour. PASS.

### Following restyle (3c) — CONFIRMED
- Pills → cards: `flex flex-wrap` → `grid grid-cols-2 md:grid-cols-4`, `rounded-full` chip → `block rounded-lg` card (`:527-542` region), same `data-testid="following-list"` / `following-row-*` and same
  click-through `href="/collective/companies/:id"` (new tab). Behaviour preserved; cosmetic only.

### Role gating (client) — CONFIRMED
- `canWrite` = managing_partner/associate/bd (`:94`); `canPromote` = managing_partner/associate (`:95`).
  SPV status select + scope buttons gate on `canWrite`; company Publish/Make-Private gate on `canPromote`.
  Server remains the source of truth in all cases.

---

## 5. Known pre-existing (NOT a B2 regression)
`server/__tests__/v25_50_group_b_spv.test.ts` → **7 failed / 4 passed** (11 total).
These are the documented B3/B4 LP-commit failures. B2 changed **no server source**
(footprint proven above to be PartnerPipeline.tsx + the new test only), so it cannot
have introduced them. Correctly excluded from the B2 verdict.

---

## 6. Minor observations (non-blocking, not defects vs the brief)
- The SPV inline status `<select value={s.status ?? "draft"}>` would be a "controlled value
  not in options" for a legacy status string not in the 6 lifecycle values. The **bucketing**
  requirement (unknown→draft, no drop) is fully satisfied; this is only a cosmetic select-value
  edge case for non-canonical data and does not violate any brief rule. No action required.

## Restore / hygiene
- `npm run build` was not run; nothing to restore. No commits made.
