# CAPAVATE SACRED FILES — v25.54.0

Sacred baseline: `sacred_baseline/SACRED_SHA256.txt` — **40 entries, 40/40 OK** after re-baseline.

## Authorized sacred edit — W-MFCRM wave (1) — RF-1
ONE additive, behavior-preserving edit to `server/lib/userContext.ts` (the ONLY sacred edit authorized for W-MFCRM). All other 39 sacred files remain BYTE-IDENTICAL. Re-baselined (old→new) below.

| File | Reason | Old SHA256 | New SHA256 |
|---|---|---|---|
| `server/lib/userContext.ts` | W-MFCRM RF-1: (a) added `"INVITED_PRIVATE_ROUND"` to the `InvestorState` union (after `"INVITED_ONLY"`); (b) added an OPTIONAL additive field `hasPrivateRoundInvite?: boolean` to `computeInvestorState` args and, in the existing `if (!hasCapTable)` branch, returns `"INVITED_PRIVATE_ROUND"` when it is true else the prior `"INVITED_ONLY"`. ADDITIVE + behavior-preserving: the field is absent/false for every existing caller so all 5 pre-existing states and every call site behave IDENTICALLY; `buildInvitedRounds` untouched. | `3a6d325c05069eb38abf03060de846bca5ec117f9f34b05998dd75986c496bca` | `d75d1321b66f1e6ce767c2517eedbbcaceb3b584370438f7507dc27320a8f6b4` |

## Authorized sacred edits this wave (2)
Ozan explicitly authorized editing exactly these two sacred files for v25.54.0. All other 38 sacred files remain BYTE-IDENTICAL to the v25.53.0 baseline. The two entries below were re-baselined (old→new) and verified before AND after.

| File | Reason | Old SHA256 | New SHA256 |
|---|---|---|---|
| `server/lib/userContext.ts` | AVI-1 Fix B: `invitedRounds` filter now includes state `"accepted"` (lines 345, 864) — an accepted invite was being dropped, causing spurious 403 `NOT_ON_CAP_TABLE`. | `f338c81140e08d2dee448400f5adcb8a5bb897b172bfe75b93c34819231f6ab0` | `6753005b6a8bb6f00885ebc6810e9364e9b117b4e5b2339b7dc7d4b583d57858` |
| `server/roundCarryForwardEngine.ts` | AVI-2 / G0-3: engine now resolves companies from live `multiCompanyStore` (seed fallback) instead of the empty production mock seed. Pure-read; fixes "Company not found: <id>" for all real companies. | `c1c36c77fdf517a926e7d3aee6e3368096f9528cbace4c911278bf26ebd9faa8` | `d7fa53f0fb8c41d0acba5ee7184ec11e169aa23530b90d49860533f27c786119` |

## Authorized sacred edit — W-FIX3 wave (1)
Ozan explicitly authorized ONE additive, behavior-preserving edit to `server/lib/userContext.ts` this wave (Bug#4 Option B). All other 39 sacred files remain BYTE-IDENTICAL. The entry below was re-baselined (old→new) and verified 40/40 OK before AND after.

| File | Reason | Old SHA256 | New SHA256 |
|---|---|---|---|
| `server/lib/userContext.ts` | Bug#4 Option B: the two `buildInvitedRounds` filter sites (~L345, ~L864) now resolve a null invitation companyId from its round — `const resolvedCompanyId = r.companyId ?? getRoundById(r.roundId)?.companyId;` — filter on `!!resolvedCompanyId`, and map `companyId: resolvedCompanyId`. ADDITIVE + behavior-preserving: a non-null companyId short-circuits (`??` never calls getRoundById → identical to prior behavior); a missing round / null round.companyId resolves falsy so the row is still dropped (no over-inclusion, no isolation change — same round→company chain the DETAIL handler already trusts). `getRoundById` was already imported/used in this file. | `6753005b6a8bb6f00885ebc6810e9364e9b117b4e5b2339b7dc7d4b583d57858` | `3a6d325c05069eb38abf03060de846bca5ec117f9f34b05998dd75986c496bca` |

## Authorized sacred edit — W-FIX4 wave (1) — item 9-N1
Ozan explicitly authorized ONE additive, **observability-only** edit to `server/captableCommitStore.ts` this wave (item 9-N1). The edit adds `log.warn(...)` emission inside two pre-existing best-effort `catch` blocks so silent misses become auditable. It MUST NOT and does NOT re-throw, change control flow, alter the in-memory state, or change any money outcome — the errors are still swallowed exactly as before; only a warning is now logged. All other 39 sacred files remain BYTE-IDENTICAL. The entry below was re-baselined (old→new) and verified 40/40 OK before AND after.

| File | Reason | Old SHA256 | New SHA256 |
|---|---|---|---|
| `server/captableCommitStore.ts` | item 9-N1: two best-effort catches now emit a warning. (1) `hydrateComplianceHolds()` (~L151) — a failed hydrate previously left the compliance-hold cache silently empty; now logs `[captableCommitStore.hydrateComplianceHolds] best-effort hydrate skipped`. (2) wire-funded handler soft-circle status advance (~L1049) — the funded-queue row is already the source of truth, so a failed UI `updateSoftCircleStatus(scId,"wired")` stays non-fatal; now logs `[captableCommitStore.wire-funded] soft-circle status advance to "wired" failed`. Observability-only: control flow, response, cache contents, and every money outcome UNCHANGED (a byte-identical commit body still results). | `32ba97cbcdf977509fdbcab44484761c12adf6f7c2fe3743ea2b8eb9867630f5` | `e5045ecbe77b06ea9879fae53e58e21ee2002b5b820a5ef066ecdf086c41cb06` |

_(Sibling change: `server/captableSnapshotsStore.ts` gained the same observability-only `log.warn` in its best-effort round-name catch (~L192). That file is NOT sacred and needs no re-baseline.)_

## Money core — UNCHANGED (verified byte-identical)
- `server/captableCommitStore.ts` `commitFunded()` / `buildCommitBody()` / `verifyChain()` untouched by W-FIX4 — the item 9-N1 edit adds only two `log.warn` lines inside pre-existing best-effort catch blocks (see the authorized-edit section above); the ledger write path and hash chain are byte-for-byte identical in behavior.

## Verification
- Triple-verified by Opus 4.8 + Gemini 3.1 Pro + GPT-5.5 → unanimous APPROVE, 0 blockers (incl. re-verify after the post-verify revoked-check hardening in non-sacred `routes.ts`).
- Sacred gate after re-baseline: `npm run sacred` → `SACRED OK: 47/47`, exit 0.
  Use `npm run sacred` (waiver-aware; `SACRED OK: 47/47`, exit 0). The raw `sha256sum -c sacred_baseline/SACRED_SHA256.txt` reader is **waiver-blind** and reports the five owner-waived files as `FAILED` (35 OK of 40, exit 1) on a healthy tree — by design, not corruption.
  (The historical `40/40 OK` claim for the raw reader was correct before the waivers existed; it has not been true since WAIVER-1.)
