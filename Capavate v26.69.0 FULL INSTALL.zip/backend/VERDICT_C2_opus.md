# VERDICT — Wave C2 (Shadie 1a/1b) — Independent verification (Opus)

## 1. VERDICT: **APPROVE**

Wave C2 correctly fixes the reproduced bug: a CRM/manual investor picked in
round-creation Step 4 now LANDS on the round (appears in the Invitations table
via the exact source the tab reads) and is EMAILED via the canonical
`roundInvitationsStore.createInvitation` — the same store the round-detail invite
uses. All gates pass with exact expected values, all required tests pass, and no
sacred/money/migration/payment file is touched.

## 2. Gate results (actual)

| Gate | Expected | Actual | Status |
|------|----------|--------|--------|
| tsc `error TS` count | 598 | **598** | PASS |
| sacred `: OK` count | 40 | **40** | PASS |
| money `captableCommitStore.ts` sha16 | 01cd36130ee1c0cb | **01cd36130ee1c0cb** | PASS |
| guard exit code | 0 | **0** | PASS |
| guard counts | 926 / 194 / 92 | **926 / 194 / 92** | PASS |
| waveC2 test | 3 pass | **3 passed** | PASS |
| v2348 test (regression) | pass | **5 passed** | PASS |
| Combined C2 + v2348 | all pass | **8 passed (2 files)** | PASS |

Diff scope (git diff HEAD~1) touches only the three expected source artifacts:
`server/lib/roundInitialShareholdersStore.ts`,
`client/src/pages/founder/RoundNew.tsx`, and the new
`server/__tests__/waveC2_crm_investor_lands_on_round.test.ts` (plus unrelated
C1 residue: VERDICT_C1/gate_c1 logs, WAVE_C1_SOURCE.diff, backups/*.tgz — no
source impact).

## 3. Per-check confirmation

- **Pick LANDS + is emailed** — CONFIRMED. `GET /api/rounds/:id/invitations`
  (routes.ts:1774-1785) serves `roundInvitationsListForRound` = `listForRound`
  (roundInvitationsStore.ts:708-714), which reads the same rows
  `createInvitation` persists (DB + mem mirror, state `"sent"`,
  roundInvitationsStore.ts:361-450). The round-detail invite uses the identical
  function (`createInvitation as roundInvitationsCreate`, routes.ts:103, 2759).
  Handler issues one invite per picked row with an email
  (roundInitialShareholdersStore.ts:258-283). Email is sent on the non-dryRun
  path (roundInvitationsStore.ts:494-522).

- **Idempotent / no double-send** — CONFIRMED. `createInvitation` throws
  `duplicate_invitation` for an already-active invite (preflight
  roundInvitationsStore.ts:346-348 + UNIQUE-index race guard :438-440) BEFORE
  minting a token or sending mail. Handler catches it as a benign skip
  (`skippedDuplicate++`, roundInitialShareholdersStore.ts:278), never surfaced
  as an error, never re-sent. Test 2 proves re-issue rejects and exactly one row
  remains.

- **No-email pick skipped** — CONFIRMED. Handler skips rows without an email
  (`if (!row.email) { skippedNoEmail++; continue; }`,
  roundInitialShareholdersStore.ts:260). The shareholder row is still saved
  (store.set/persist at :221-222, before issuance). Store also defends with
  `invalid_email` (roundInvitationsStore.ts:336). Test 3 proves empty email
  rejects at the store.

- **Fail-closed reporting, not rollback** — CONFIRMED. Shareholder save
  (store.set + persist) happens at :221-222, BEFORE the invite loop (:258+).
  Per-invite failures are pushed to `inviteErrors` and logged
  (roundInitialShareholdersStore.ts:279-280) and returned in the response
  (:302-312); they never throw out of the handler, so the persisted shareholder
  save is not rolled back.

- **Ownership gate intact** — CONFIRMED. `!ctx.isAdmin && !callerOwnsRound`
  returns 403 at roundInitialShareholdersStore.ts:161-163, well before the
  invite-issuance block at :258. Async conversion did not move or weaken it.

- **Guarded require degrades gracefully (no 500)** — CONFIRMED, and observed
  live: the v2348 test runs the real handler in an isolated harness that cannot
  parse the `.ts` store, producing the warn
  `"could not load roundInvitationsStore for invite issuance: Unexpected token
  'export'"` (roundInitialShareholdersStore.ts:253-257). The endpoint still
  succeeds (issuance skipped, `createInvitation` stays null → loop guarded by
  `if (companyId && createInvitation)` at :258). v2348's 5 tests all pass — no
  500, no regression from the async change.

- **No regression** — CONFIRMED. v2348_round_initial_shareholders.test.ts:
  5 passed. Async handler change is transparent to existing behavior.

- **Client toast safe parse** — CONFIRMED. `apiRequest` returns
  `Promise<Response>` (queryClient.ts:119); onSuccess does
  `inviteSummary = await r.json().catch(() => null)` (RoundNew.tsx) — parse
  guarded. The PATCH block is inside `if (selectedShareholders.length > 0)`, so
  when empty `inviteSummary` stays null and `?? 0` defaults apply — never
  throws. Toast `variant: failed > 0 ? "destructive" : undefined` — both are
  valid (`destructive` defined in components/ui/toast.tsx:32).

## HARD RULES
1. Sacred 40/40 byte-identical, roundsStore.ts NOT in diff — PASS.
2. Money sha16 `01cd36130ee1c0cb` — PASS.
3. tsc net-new 0 → exactly 598 — PASS.
4. Guard exit 0, counts 926/194/92 unchanged — PASS.
5. Only one new `require("../roundInvitationsStore")`, using the file's existing
   `createRequire` shim (line 36) and try/catch-guarded — same pattern as the
   sacred roundsStore boundary; no new require idiom. No migration. Payments/
   Airwallex untouched (not in diff). — PASS.

## Known pre-existing (NOT a C2 regression)
`server/__tests__/sprint21_invitations.test.ts` = 2 failed / 12 passed — matches
the brief's documented pre-existing co-soft-circle failures. Not caused by C2.

## No build run
`npm run build` was not executed, so no server/public or dist restore was
needed. Nothing committed.

## Defects
None.
