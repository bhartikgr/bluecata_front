# Capavate v25.49.1 — Deploy README for Avi (FULL, includes Bug 1 hotfix)

Net build over live v25.48.2: the full Consortium Partner rebuild + canonical SPV Engine (v25.49.0)
PLUS the Bug 1 investor-invitation crash hotfix (v25.49.1). Sacred 39/39 byte-identical · tsc 601
(baseline, zero net-new) · build clean · 104/104 partner+SPV tests + Bug-1 regression pass. Runtime is
Node 20 + tsx; pm2 runs the TS source, so no `npm run build` step is required. ZIPs via WhatsApp.

## INSTALL — pick ONE (both preserve .env + data.db)
BEFORE: back up the DB → `cp /var/www/html/backend/data.db /var/www/html/backend/data.db.$(date +%F_%H%M).bak`
(Optional) `sha256sum -c SHA256SUMS_v25.49.1.txt` → both must print OK.

OPTION A — FULL:
  1. `unzip capavate_v25.49.1_FULL_INSTALL.zip -d capavate_v49_1`
  2. `rsync -a --exclude='.env' --exclude='data.db' --exclude='data.db-shm' --exclude='data.db-wal' --exclude='node_modules' capavate_v49_1/ /var/www/html/backend/`
  3. `cd /var/www/html/backend && npm ci`
  4. `pm2 restart backend`   (migrations 0083-0087 auto-apply on boot — additive + idempotent)

OPTION B — PATCH (overlay; faster; no new deps):
  1. `cd /var/www/html/backend`
  2. `unzip -o capavate_v25.49.1_PATCH.zip -d /tmp/cap_v491 && rsync -a /tmp/cap_v491/capavate_v25.49.1_PATCH/ /var/www/html/backend/`
  3. `pm2 restart backend`

## WHAT'S IN IT (full detail in CHANGELOG_v25.49.1_FULL.md)
- Everything in v25.49.0: partner portal #310 crash fix, capavate.com re-skin, grouped nav, enhanced
  Clients CRM, Messaging+Posts, and the canonical SPV Engine (one engine / 3 contexts, GP wizard,
  compliance gates, two-layer Airwallex fees, fail-closed deployment + single ledger line, waterfall,
  distribution scopes, LP-visibility toggle). Migrations 0083-0087.
- v25.49.1 Bug 1 hotfix: the investor Invitation page no longer crashes when a dataroom file or
  use-of-proceeds entry has no category (renders "Uncategorized").

## MIGRATIONS (additive + idempotent; auto-apply on boot)
0083 partner_client_crm · 0084 spv_engine · 0085 spv_lp_visibility · 0086 spv_fee_obligation ·
0087 spv_deployment wire_payment_ref/closing_doc_ref. No manual step; no downgrade needed.

## VERIFY AFTER DEPLOY
  `curl -fsS https://capavate.com/api/health` → `"version":"25.49.1"`, `"db":"connected"`
  Partner portal loads (no #310 crash), on-brand, grouped nav, Clients CRM, Messages/Posts, SPVs wizard.
  Investor invitation page (Path A): create round → invite investor → open invite page → renders (no
  "category is undefined" crash); missing categories show "Uncategorized".

## STILL OPEN (from Avi's report)
- Bug 2 (investor profile checkboxes reset on refresh) and Bug 3 (investor lands on wrong platform after
  logout/login) are NOT in this build — awaiting a clean live reproduction / your confirmation.

## ROLLBACK
Restore the pre-deploy backup dir + `data.db.$(date).bak` and `pm2 restart backend`. Migrations 0083-0087
are additive-only; the previous build ignores the new tables/columns.
