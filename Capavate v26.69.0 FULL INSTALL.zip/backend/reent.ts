import Better from "better-sqlite3";
import { applyInlineMigrationsForFreshDb } from "./server/db/connection.js";
const p = process.argv[2];
const db: any = new (Better as any)(p);
db.pragma("foreign_keys = ON");
for (let i=1;i<=3;i++){
  try { applyInlineMigrationsForFreshDb(db); console.log(`pass ${i}: OK`); }
  catch(e:any){ console.log(`pass ${i}: THREW ${e.message}`); }
  const cols = db.prepare("PRAGMA table_info('_migrations_applied')").all().map((c:any)=>c.name).join(",");
  const leg = db.prepare("SELECT name FROM sqlite_master WHERE name='_migrations_applied_legacy_v26_7_2'").get();
  const n = db.prepare("SELECT count(*) c FROM _migrations_applied").get().c;
  console.log(`   _ma cols=[${cols}] rows=${n} legacyTbl=${!!leg}`);
}
db.close();
