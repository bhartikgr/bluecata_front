# W-MFCRM — Independent Adversarial Verification (Gemini role)

Scope: verify the actual code in `/home/user/workspace/capavate_build`, hunting for
fail-closed / isolation defects. node_modules is not installed in the sandbox, so
`tsc`/`vitest` were not run; every finding below is from reading the actual source
against the in-tree conventions (partnerClientCrmStore / spvEngineStore /
captableCommitStore / kycDocumentStore) and the rev3 design doc.

Method: read the engine (`managedFounderStore.ts`), both route files, the three
persona stores, the schema, the five test files, and the `_MFCRM_EDITED_FILES.diff`
of every touched sacred/host file. Traced each gate at BOTH the store and route
layer, and traced the two money paths end-to-end.

---

## Area 1 — Capability-gating escalation (unclassified / non-capital / lapsed / Mode-B); the D-9 case

FAIL-CLOSED, NO ESCALATION PATH FOUND.

- All six gates are `GateError`-throwing helpers in `managedFounderStore.ts`
  (L302–350) and are re-invoked at the route layer, so a gate cannot be skipped by
  calling a route directly.
- **D-9 (the critical one).** `createSpvOnBehalf` (L730) calls
  `assertDelegatedWriteAuthority(pid, e, { requireSpvWrite: true })` at L742 —
  BEFORE any SPV is created. The helper (L325–334) checks, in order:
  `delegatedAgency` → `spvWriteAuthority` → `status === 'ACTIVE'` →
  `mode === 'A'` → present `authorityArtifactRef` → non-expired
  `authorityExpiresAt`. An ACTIVE **Mode-B** engagement whose partner has the
  global `delegated_agency` + `spv_write_authority` toggles ON is therefore denied
  with `ENGAGEMENT_MODE_NOT_A`. Global toggles alone are NOT sufficient — the
  per-engagement Mode-A + non-expired artifact binding is mandatory. This is
  exactly the escalation hole the design flagged, and it is closed.
- **Unclassified** → `assertClassified` (L302) denies `CAPABILITY_UNCLASSIFIED` on
  engagement create (L361).
- **Non-capital** → attribution stamp requires `assertSourcesCapital` (L317); the
  accounting/law personas route to firm-of-record / counsel-of-record instead
  (never investor first-touch).
- **Lapsed / handed-over** → gates 3/4/5 each assert `status === 'ACTIVE'` first
  (L329, L340, L347). `expireStaleTrials` transitions expired Mode-A trials to
  `LAPSED`, after which every money/authority gate denies `ENGAGEMENT_NOT_ACTIVE`.

## Area 2 — Mode-A entry gated fail-closed

CLEAN. `assertModeAEntry` (L309) requires `delegatedAgency` +
non-empty `authorityArtifactRef` + non-expired `authorityExpiresAt`, and is called
at all three Mode-A entry points: create-in-A (L364), setMode B→A (L444), and
handover-confirm-into-A (L511). Absent artifact → `AUTHORITY_ARTIFACT_REQUIRED`;
expired → `AUTHORITY_ARTIFACT_EXPIRED`; no delegated agency →
`DELEGATED_AGENCY_REQUIRED`. No default-open branch.

## Area 3 — Lapsed engagement denied money / delegated-write

CLEAN. Covered by the ACTIVE assertion in gates 3/4/5 (Area 1). `setMode` (L490)
and `handover` (L441) also guard `status === 'ACTIVE'`, so a lapsed engagement
cannot be flipped back to A to re-enable money.

## Area 4 — Isolation (partnerId session-only; body/URL ignored; attribution; cross-partner → 404)

CLEAN on partner routes.

- Every partner handler derives `pid` from `req.partnerContext!.partnerId`
  (session) — grep of both route files shows no `req.body.partnerId` /
  `req.params.partnerId` read on any `/api/partner/*` route. A body-supplied
  partnerId is simply ignored.
- companyId-scoped handlers call `isAttributed(pid, companyId)` →
  `partnerAttributionStore.listByPartner(pid).some(a => a.companyId === companyId)`
  and return **404 `COMPANY_NOT_FOUND_OR_NOT_ATTRIBUTED`** on miss (never 403 — no
  existence leak). Verified on engagements-create, attribution, layers,
  spv-on-behalf, audit, and all persona companyId endpoints.
- Store methods take a session pid and call `requirePid`; reads are filtered
  `WHERE partner_id = ?`, so a cross-partner id yields empty/`*_NOT_FOUND` → 404.
- Admin routes DO read `:partnerId` from the URL — this is **correct and expected**:
  they sit under the `/api/admin` requireAdmin mount AND re-check
  `getUserContext(req).isAdmin` in-handler (`requireAdminCtx`, L392–394). The
  platform operator legitimately acts cross-partner; a partner session cannot reach
  these paths.
- Note (not a defect): the angel `chapters` and `carry-report` endpoints are
  partner-scoped without a companyId. That is acceptable — they read only the
  session partner's own rows (`WHERE partner_id = ?`); there is nothing to attribute.

## Area 5 — Single sacred ledger; SPV sync-tx correctness

CLEAN.

- **Money path 1 (graduation).** `softCircleGraduate` (L674) is the only place that
  calls `commitFunded` (L689) — the single sacred ledger. On `!result.ok` it
  returns `{ ok:false }` with NO parallel write. The Founder-CRM copy-in is wrapped
  in try/catch (L701–712) and explicitly documented as best-effort; a projection
  failure never rolls back the sacred commit. No second money path exists in the
  tree (grep: `commitFunded` appears only here + the import).
- **Money path 2 (SPV-on-behalf).** `createSpvOnBehalf` gates FIRST (L742), then
  creates the durable SPV via `spvEngineStore.createSpv` (L745), then runs a
  **synchronous** `db.transaction(() => { ... })()` (L767–785) that: reads the
  per-partner chain tip INSIDE the tx (L768), computes
  `sha256(prevHash|JSON.stringify(payload))` (L776), INSERTs the `mf_spv_on_behalf`
  audit row, and INSERTs the `mf_collective_push` row `status='queued'` — all
  atomically. There is **no async/await/network inside the tx** (better-sqlite3
  forbids it), so no silent tx-abort. `recordEvent`/`recordAudit` and the actual
  push run OUTSIDE the tx (L787–789, `markCollectivePush`).
- **No hash-chain TOCTOU:** the tip read and the INSERT are in the same sync tx;
  better-sqlite3 is single-threaded/synchronous, so no interleaving is possible.
  First row correctly seeds `prevHash = "GENESIS"`.
- Minor observation (design-sanctioned, not a defect): because the gate is asserted
  before `createSpv`, a *denied* call leaves no orphan. A DB failure in the
  post-SPV tx could in principle leave a durable SPV with no on-behalf/push row, but
  this ordering is the explicit §3.3 contract (durable SPV first) and the SPV itself
  is a legitimate standalone entity; no money moves in this path (push is queued,
  not committed). Acceptable.

## Area 6 — Additive / behavior-preserving (RF-1, buildInvitedRounds, no dropped route/page/nav)

CLEAN. The full `_MFCRM_EDITED_FILES.diff` shows every touched sacred/host file is
purely additive:

- `userContext.ts`: one union member `"INVITED_PRIVATE_ROUND"`; one optional
  `hasPrivateRoundInvite?: boolean` arg; the `!hasCapTable` return becomes
  `args.hasPrivateRoundInvite ? "INVITED_PRIVATE_ROUND" : "INVITED_ONLY"`. Absent/
  false field ⇒ byte-identical behavior for all existing 5 states and callers.
  `buildInvitedRounds` does NOT appear in the diff → untouched (W-FIX3 region intact).
- `hydrateStores.ts`: 4 additive hydrate entries appended AFTER the SPV engine store.
- `routes.ts`: 2 imports + 2 `registerX(app)` calls; nothing removed/reordered.
- `App.tsx`: 1 import + 2 routes (detail before list so `:id` resolves); no existing
  route dropped.
- `CollectiveShell.tsx`: 1 nav entry appended to PARTNER→OVERVIEW; nothing renamed.

No existing route/page/nav is removed or renamed.

## Area 7 — DB-driven, no in-memory/mock/seed on production paths

CLEAN. All writes go to the additive `mf_*` tables via `rawDb().prepare(...).run()`.
RAM Maps (`profileByPartner`, `engagementById`) are rebuildable projections
hydrated at boot by `hydrateManagedFounderStore()` (applies schema, then
`SELECT *`), exactly the partnerClientCrmStore pattern. Persona stores add their own
tables lazily via `ensureXTables()` (kycDocumentStore pattern). No mock/seed on a
production read/write path.

## Area 8 — Tests actually assert the above (incl. negatives + D-9)

ADEQUATE.

- `mfcrm_gates.test.ts`: one POSITIVE + one NEGATIVE per gate, including the D-9
  negative (ACTIVE **Mode-B** + all global toggles ⇒
  `.toThrowError(/ENGAGEMENT_MODE_NOT_A/)`) and the positive only after setMode→A +
  artifact.
- `mfcrm_moneypath.test.ts`: single-ledger assertion via `commitFunded` +
  `getLedger/verifyChain`; transactional SPV (durable row + queued push); NO orphan
  on a GATE-3 denial; hash-chain prev/curr link with GENESIS first.
- `mfcrm_isolation.test.ts`: route-level (supertest) — own scope 201; cross-partner
  / never-attributed → 404; body-supplied partnerId ignored (session wins);
  unauthenticated 401/403; viewer sub-role 403.
- `mfcrm_persona.test.ts`: angel chapter scoping + `CHAPTER_SCOPING_REQUIRED`
  negative; acct `firm_of_record` + `PAYS_ON_BEHALF_REQUIRED` /
  `DOCUMENT_CUSTODY_REQUIRED` negatives; law conflict-flag-never-blocks
  (`blocked:false`) + `counsel_of_record` + `INVESTOR_SPINE_FORBIDDEN` negative.
- `mfcrm_schema.test.ts`: 12 tables exist, idempotent re-apply, UNIQUE indexes,
  partner_id everywhere.

Caveat: tests were not executed (no node_modules); they are asserted by inspection
to reference real exported symbols and match in-tree test conventions
(clearLedger/getLedger/verifyChain from captableCommitStore; the
`_registerSeedPartner` + `partnerAttributionStore.create` supertest pattern).

---

## Numbered defects

NONE. No fail-closed or isolation defect was found. Two design-sanctioned
observations are noted (Area 4 angel non-companyId endpoints; Area 5 post-gate SPV
ordering) — neither is a security defect.

## Residual risk (non-blocking)

- Tests are un-run in this sandbox; a green `vitest` on a machine with node_modules
  is recommended as belt-and-suspenders before ship, but the logic is verified by
  reading.
- The SPV-on-behalf durable-SPV-before-tx ordering matches §3.3; if a future change
  moves money into that path, the tx boundary must be re-audited.

VERDICT: SHIP
