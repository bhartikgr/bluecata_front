import express from "express";
import request from "supertest";
import { registerRoundInitialShareholdersRoutes } from "./server/lib/roundInitialShareholdersStore";
import { listForRound } from "./server/roundInvitationsStore";

process.env.SMTP_MODE = "dry_run";

const app = express();
app.use(express.json());
registerRoundInitialShareholdersRoutes(app);

const roundId = `rnd_c2_smoke_${Date.now()}`;
const email = `c2_smoke_${Date.now()}@example.com`;
const noEmailName = "No Email Smoke";

const first = await request(app)
  .patch(`/api/founder/rounds/${roundId}/initial-shareholders?as=admin`)
  .set("x-user-id", "u_admin")
  .send({
    companyId: "co_novapay",
    shareholders: [
      { name: "Smoke Investor", email, source: "manual" },
      { name: noEmailName, source: "manual" },
    ],
  });
const afterFirst = listForRound(roundId);
const second = await request(app)
  .patch(`/api/founder/rounds/${roundId}/initial-shareholders?as=admin`)
  .set("x-user-id", "u_admin")
  .send({
    companyId: "co_novapay",
    shareholders: [
      { name: "Smoke Investor", email, source: "manual" },
      { name: noEmailName, source: "manual" },
    ],
  });
const afterSecond = listForRound(roundId);
console.log(JSON.stringify({
  firstStatus: first.status,
  firstBody: first.body,
  afterFirstCount: afterFirst.length,
  afterFirstEmails: afterFirst.map((i) => i.investorEmail),
  secondStatus: second.status,
  secondBody: second.body,
  afterSecondCount: afterSecond.length,
  afterSecondEmails: afterSecond.map((i) => i.investorEmail),
}, null, 2));
