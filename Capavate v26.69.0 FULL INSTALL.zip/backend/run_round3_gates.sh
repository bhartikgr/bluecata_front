#!/usr/bin/env bash
set +e
cd /home/user/workspace/capavate_work || exit 1

echo '== tsc error count =='
npx tsc --noEmit 2>&1 | grep -c "error TS"
echo "tsc_pipeline_exit=${PIPESTATUS[*]}"

echo '== sacred baseline OK count =='
# WAVE 39 (Review 4A N1 / 4B): this line used the WAIVER-BLIND base-manifest reader,
# which prints 5 FAILED and exits 1 on a healthy tree. Replaced with the waiver-aware
# gate. (This script is also currently INERT — it cds into a checkout that no longer
# exists — but it must not be left carrying a command that mis-reports the tree.)
bash scripts/sacred_check.sh   # SACRED OK: 48/48, exit 0 (Wave 50 added server/db/connection.ts)
echo "sha_pipeline_exit=${PIPESTATUS[*]}"

echo '== captableCommitStore hash prefix =='
sha256sum server/captableCommitStore.ts | cut -c1-16
echo "hash_pipeline_exit=${PIPESTATUS[*]}"

echo '== npm guard tail =='
npm run guard 2>&1 | tail -3
echo "guard_pipeline_exit=${PIPESTATUS[*]}"

echo '== targeted vitest =='
npx vitest run server/__tests__/spvUnifiedCanonical.test.ts server/__tests__/waveA_consortium_qa.test.ts
echo "vitest_exit=$?"

echo '== stale wording grep =='
grep -rn "(20)\|20 titles\|20 professional\|the 20 " FIX_REPORT_WAVE_A_CONSORTIUM_QA.md client/src/pages/partner/PartnerTeam.tsx shared/partnerTitles.ts
echo "grep_exit=$?"
