# Capavate v26.7.1 — Full Install Package

## What this is

This is the complete Capavate v26.7.1 source tree with the mf_engagement_event
hotfix already applied. Use this INSTEAD of the delta hotfix zip if you want
to install cleanly from scratch, or if you want to be sure your working copy
matches ours exactly.

## Install (recommended path — auto-recovery script)

```
# 1. Back up your existing backend directory (INCLUDING data.db)
cp -r /var/www/html/backend /var/www/html/backend.backup.$(date +%Y%m%d_%H%M%S)

# 2. Extract this zip to a staging location (NOT directly over the running install yet)
unzip capavate_v26.7.1_FULL_INSTALL.zip -d /var/www/html/backend_v26_7_1_staging/

# 3. Copy your existing data.db, .env, and any local runtime files into the new tree
cp /var/www/html/backend/data.db /var/www/html/backend_v26_7_1_staging/data.db
cp /var/www/html/backend/.env /var/www/html/backend_v26_7_1_staging/.env  # if you have one
# Copy anything else you customize per-server (uploads/, logs/, etc.)

# 4. Stop the current server
# (systemctl stop capavate or pm2 stop capavate — whichever you use)

# 5. Swap the trees
mv /var/www/html/backend /var/www/html/backend.old
mv /var/www/html/backend_v26_7_1_staging /var/www/html/backend

# 6. Install dependencies (may take 5-10 minutes)
cd /var/www/html/backend
npm install --no-audit --prefer-offline

# 7. Run the auto-install script — it detects your DB state and applies the right recovery
bash install_v26_7_1.sh .

# 8. Restart the server
# (systemctl start capavate or pm2 start capavate)

# 9. Verify capavate.com loads
```

## Rollback (if anything goes wrong)

```
# Stop the server
mv /var/www/html/backend /var/www/html/backend.failed
mv /var/www/html/backend.old /var/www/html/backend
# Restart
```

Your data.db backup at Step 1 is your safety net.

## What changed vs. v26.7.0

Only ONE file was modified: `server/db/connection.ts` (added the
`mf_engagement_event` DDL to `buildProductionTableStatements`). Everything else
is byte-identical to the v26.7.0 install that failed.

## Send back to Ozan

- Full output of `bash install_v26_7_1.sh .` (copy-paste)
- Screenshot of capavate.com loading after restart
- Confirmation that rounds can be viewed and created

## Deeper diagnosis

Read `AVI_DEPLOY_FAILURE_DIAGNOSIS.md` in this tree.
