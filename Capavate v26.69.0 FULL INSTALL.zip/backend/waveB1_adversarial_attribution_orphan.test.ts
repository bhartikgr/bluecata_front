import { describe, it, expect, beforeAll } from 'vitest';
import express from 'express';
import request from 'supertest';
import { registerPartnerRoutes } from './server/partnerRoutes';
import { registerPartnerPortfolioCompanyRoutes } from './server/partnerPortfolioCompanyRoutes';
import { seedTestPartnerSandbox } from './server/partnerWorkspaceStore';
import { rawDb } from './server/db/connection';

const MANAGING = 'u_avi_managing';

describe('Wave B1 adversarial attribution failure', () => {
  let app: express.Express;
  beforeAll(() => {
    app = express();
    app.use(express.json());
    registerPartnerRoutes(app);
    registerPartnerPortfolioCompanyRoutes(app);
    seedTestPartnerSandbox({ force: true });
  });

  it('shows whether company persists when attribution write fails', async () => {
    const db: any = rawDb();
    db.exec('DROP TABLE IF EXISTS consortium_links');
    const companyName = `Orphan Probe ${Date.now()}`;
    const res = await request(app)
      .post('/api/partner/me/portfolio-companies')
      .set('x-user-id', MANAGING)
      .send({ companyName, founderEmail: `probe_${Date.now()}@example.com` });
    const co = db.prepare('SELECT id, name FROM companies WHERE name = ?').get(companyName) as any;
    const cm = co ? db.prepare('SELECT user_id FROM company_members WHERE company_id = ?').get(co.id) as any : undefined;
    console.log(JSON.stringify({ status: res.status, error: res.body?.error, companyPersisted: !!co, membershipUserId: cm?.user_id }));
    expect(res.status).toBe(500);
  });
});
