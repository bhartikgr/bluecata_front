# Capavate — W-AVI64 Fix Report (Avi ai64 feedback + live-audit bugs)

**Baseline: LIVE ai64 / v26.2.0 (verified deployed 2026-07-23) · Prepared 2026-07-23 by Perplexity Computer**

## Status: SHIP (triple-verified unanimous)
Fixes Avi's reported items + the additional bugs found during a live-site audit. Verified by three top models reading the actual code: **Opus 4.8 SHIP · Gemini 3.1 Pro SHIP · GPT-5.5 (decider) SHIP** — unanimous, no REVISE. Sacred baseline **40/40 OK** before and after (only non-sacred files changed).

> **Verification note:** the build sandbox cannot install `node_modules` (better-sqlite3 native compile exceeds sandbox limits), so `tsc`/`guard`/`build`/`vitest` were NOT executed here. Correctness verified by close code inspection against in-tree conventions + triple-verify. **Avi must run the Gate Runbook (below) on the server** as the final pre-go-live check.

## Live verification that preceded these fixes
- Confirmed ai64/v26.2.0 is the deployed build (healthz buildTime matches the zip).
- Reproduced Avi's items on live using the real accounts (founder = BluePrint Catalyst PRO; investor = ozan@capavate.com). Platform logic is identical per account, so these repros represent Avi's experience.

## Avi's reported items

### Item 1 — Round not shown to invited investor → FIXED (was a real bug, reproduced live)
- **Reproduced:** founder created a round and added an investor from CRM in the wizard's "Add initial shareholders" step → round created but detail showed **"Investor invitations (0)"** → no `round_invitations` row → investor login never shows the round.
- **Root cause:** the wizard sends `email: s.email || null`; a CRM pick with no on-file email (or an unresolved email) → server `skippedNoEmail` → no invitation. Failures were also swallowed client-side, so the founder never learned the investor wasn't invited.
- **Fix (FIX 1):** server `roundInitialShareholdersStore.ts` now resolves a CRM pick's email from `founder_crm_contacts` (via `crmContactId`) before deciding `skippedNoEmail`, and returns a per-pick `inviteResults[]`. Client `RoundNew.tsx` surfaces the invite summary (invited / skipped-no-email / errors) to the founder instead of swallowing it. Additive + idempotent (a duplicate invite is a benign skip). No money path touched.
- **Workaround (still valid):** the round-header "Invite investor" button always created invitations correctly.

### Item 2 — Warrant shares → NOT A BUG (working as designed; explanation for Avi)
- A warrant is created attached to the round as a priced instrument (strike = price/share). **Shares are issued only on EXERCISE, not at creation:** cash exercise → pay `strike × qty`, receive `qty` shares; cashless/net → receive `floor(qty × (FMV − strike) / FMV)`; unexercised → expire, no shares. The cap table shows the warrant as an instrument; exercised shares post to the cap table via the single sacred ledger on exercise. No code change.

### Items 3 & 4 — Founder↔Investor DM not working → FIXED (real bug; asymmetric)
- **Reproduced:** founder→investor DM works; investor→founder shows **"No eligible contacts"** — the inviting founder never appears, so the investor cannot start the DM.
- **Root cause:** `/api/messages/recipients` built its list from a flat `auth_users` scan (`listDmCandidates`), NOT scoped to the viewer's real relationships, then filtered by `canDM`. `canDM` correctly allows founder↔investor, but the founder wasn't in the candidate list from the investor's side, so it never got evaluated.
- **Fix (FIX 2):** `listDmCandidates` now UNIONS the viewer's real counterparties — companies they're a member of, founders who invited them (`round_invitations` by email + `invited_by_user_id`), cap-table co-parties (`captable_commits`), and `founder_crm_contacts` references — in addition to the existing base set. **Every candidate is still gated by the unmodified fail-closed `canDM`** (no isolation change; only the pool widened). All SQL is parameterized and fail-closed (try/catch → empty). Deduped, capped at 500.
- **Note for Avi:** the "Allow direct messages" toggle gates *inbound* DMs *to* the investor — it never controlled the investor's ability to *start* a DM. That's why enabling it didn't help; the real cause was the candidate-list gap, now fixed.

## Additional bugs found during the live audit (all fixed this wave)

### FIX 3 — Bridge outbox: 561 queued / 0 delivered / chain "broken@0" + P0 audit banner → FIXED to go LIVE
- **Root cause (config):** code reads env `COLLECTIVE_WEBHOOK_URL` + `COLLECTIVE_WEBHOOK_SECRET` + `BRIDGE_ENABLED`; the live `.env` uses different names (`BRIDGE_OUTBOUND_URL`, `BRIDGE_INBOUND_HMAC_SECRET`) and never sets `BRIDGE_ENABLED` → the worker never started.
- **Owner decision (this wave):** bridge should be LIVE in production.
- **Fix:** `bridgeOutboundGuard.ts` `hasRealReceiver()` now accepts the legacy alias env names as fallbacks (canonical names still win) — so the live `.env` works. The sacred `bridgeRuntime.ts` (which reads the canonical names directly) is untouched, so the deploy MUST also export the canonical names. **Set these on the server** (documented in `.env.example` + `DEPLOY_FOR_AVI.md`):
  ```
  BRIDGE_ENABLED=1
  COLLECTIVE_WEBHOOK_URL=https://collective.capavate.com/api/bridge/inbox
  COLLECTIVE_WEBHOOK_SECRET=<the real shared secret agreed with Collective>
  # keep existing BRIDGE_OUTBOUND_URL / BRIDGE_INBOUND_HMAC_SECRET
  ```
  With these, `maySendOutboundBridge()` becomes true → the worker starts → the 561 backlog drains (delivered > 0). The chain "broken@0" is documented for a safe admin-gated re-verify (the bridge outbox is NOT the money ledger; no destructive auto-run).

### FIX 4 — Admin global search returned nothing (even for existing companies) → FIXED
- Search now unions the same DB readers the admin Companies/Investors/Partners pages use, so it finds live entities (e.g. "Neou").

### FIX 5 — Admin Telemetry Event Explorer showed 0-of-0 while the live feed showed events → FIXED
- The Explorer now sources real recent events (`getRecentEvents()`), with the synthetic seed only as an empty-store fallback.

### FIX 6 — `/investor/login` (and other portals) redirected to the admin dashboard when an admin session was active → FIXED
- Portal login routes now show the login form when the active session is for a different portal, instead of bouncing to the current session's dashboard. The normal "already logged in as this portal → dashboard" case is preserved.

### FIX 7 — Config/ops
- **Funnel metrics:** per-step conversion clamped to [0,100] (valuation step-up intentionally not clamped).
- **buildSha "unknown":** documented — set `BUILD_SHA` (or `GIT_SHA`) at deploy. Code already degrades gracefully.
- **AWS S3 creds empty:** documented required `AWS_ACCESS_KEY_ID`/`SECRET`/`AWS_S3_BUCKET`; storage path confirmed fail-safe.
- **Dev-reset URL on live:** flagged — recommend `RETURN_DEV_RESET_URL=0` in production (security).

## Gate results
| Gate | Result |
|------|--------|
| Sacred SHA256 | **40/40 OK** (parent-executed, before + after); no sacred file edited |
| Money-core | `captableCommitStore` / `messagingStore` / `paymentGatewayAdapter` / `bridgeRuntime` untouched |
| Edit surface | 10 source + 3 docs + 4 tests, all additive; no route/page/nav dropped |
| tsc / guard / build / vitest | run on server (Gate Runbook) — inspection-clean |
| Triple-verify | Opus SHIP · Gemini SHIP · GPT-5.5 SHIP |

## Gate Runbook for Avi (run on the server after install)
```
npm install && npm run build            # expect exit 0
npx tsc --noEmit 2>&1 | grep -c 'error TS'   # no NEW errors vs baseline
npm run guard                            # no DISAPPEARED items
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
npx vitest run server/__tests__/wavi64_round_invite.test.ts \
  server/__tests__/wavi64_dm_recipients.test.ts \
  server/__tests__/wavi64_bridge_env.test.ts \
  server/__tests__/wavi64_admin_search.test.ts   # expect pass
```

## Deploy notes
1. `npm install` → `npm run build` → set the bridge env block above (+ `BUILD_SHA`) → restart.
2. Back up `/var/www/html/backend/data.db` before restart (schema is additive; no destructive migration).
3. ⚠️ Airwallex is LIVE on this server — do not exercise payment/funding flows during smoke-testing.
4. Verify: founder invites investor via wizard → investor sees the round; investor can DM the founder; admin search finds "Neou"; healthz shows a real buildSha; bridge outbox begins draining.

## Deliverables
`capavate_v26.2.0-wavi64_FULL_INSTALL.zip` · `_PATCH.zip` · `_RELEASE_BUNDLE.zip` · `SHA256SUMS_v26.2.0-wavi64.txt` · `FIX_REPORT_WAVE_WAVI64.md` (+pdf) · `WAVE_WAVI64_SOURCE.diff` · `CHANGED_FILES_WAVI64.txt` · `CAPAVATE_LIVE_ENVIRONMENT.md` · `CAPAVATE_ENHANCED_HANDOVER.md` · verifier reports.
