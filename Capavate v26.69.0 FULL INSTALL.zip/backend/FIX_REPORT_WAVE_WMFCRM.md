# Capavate — W-MFCRM Fix Report (Managed Founder CRM, all 4 personas)

**Baseline: ai-63 + W-FIX3 + W-FIX4 (build tree: `userContext.ts` 3a6d325c→d75d1321, `captableCommitStore` e5045ecb) · 2026-07-22 · Prepared by Perplexity Computer**

## Status: SHIP (triple-verified unanimous)
Implements Item 5 (MFCRM) from the rev3 engineering build doc — the bank base engine **plus** the angel-network, accounting, and law personas, in one dark-shipped, capability-flag-gated package. Independently verified by three top models, each reading the actual code (not the build summary):
- **Opus 4.8: SHIP · Gemini 3.1 Pro: SHIP · GPT-5.5 (decider): SHIP** — unanimous, no REVISE.
The parent independently re-ran the gates it could execute in-sandbox (sacred SHA, money-core SHAs, edit-surface diff) and inspected the full diff before triple-verify.

> **Verification note (read this):** the build tree's `node_modules` could not be installed in the build sandbox (the `better-sqlite3` native compile exceeds the sandbox process/time limits). Therefore `tsc`, `npm run guard`, `npm run build`, and `vitest` were **NOT executed here** — correctness was verified by close code inspection against the tree's own canonical patterns (`partnerClientCrmStore`, `captableCommitStore.commitFunded`, `spvEngineStore.createSpv`, `spvFundStore` sync-tx, `requirePartnerAuth`, `kycDocumentStore` schema pattern) and by triple-verify. **Avi must run the four automated gates on the server (where the toolchain works) as the final pre-go-live check — see the Gate Runbook below.**

## What shipped (all additive, DB-driven, dark-shipped behind capability flags)
Deploying this changes **nothing** on live until an admin seeds/flips a per-partner capability profile. No persona is active by default (fail-closed).

### Base engine (W-MFCRM)
- **12 additive `mf_*` tables** via `applyMfcrmSchema()` (idempotent, `CREATE TABLE IF NOT EXISTS`, `partner_id` + indexes on every partner-scoped table): `mf_capability_profile`, `mf_engagement` (UNIQUE partner_id+company_id), `mf_engagement_event`, `mf_attribution`, `mf_attribution_tail`, `mf_crossover_flag`, `mf_handover`, `mf_pricing_trial`, `mf_spv_on_behalf` (prev_hash/curr_hash chain), `mf_collective_push`, `mf_layer_membership`, `mf_audit`.
- **`managedFounderStore.ts`** — orchestration engine: capability profile (seeded from `partner_type`), engagement lifecycle (modes A/B), hand-over (initiate/confirm/admin-override), attribution (first-touch + 12-month tail vs firm-of-record), crossover flags C1–C7 (flag, never block), 3 CRM layers (delegating persistence to `partnerClientCrmStore` + `founderCrmStore`; `investorCrmStore` untouched), pricing/trial (90-day Mode-A expiry), and both money paths.
- **`managedFounderRoutes.ts`** — 20 partner + 6 admin endpoints under `/api/partner/me/mfcrm*` and `/api/admin/mfcrm*`.

### Persona waves (same model + capability profile, never forked)
- **W-ANGEL** (`mfcrmAngelStore.ts`): chapter scoping + per-chapter carry; fail-closed when `chapter_scoping=false`.
- **W-ACCT** (`mfcrmAcctStore.ts`): firm-of-record attribution, pays-on-behalf rebill (AR intent), document custody, fund-admin report; gated by `pays_on_behalf`/`document_custody`/`fund_admin`.
- **W-LAW** (`mfcrmLawStore.ts`): matters, conflict-of-interest engine (**flags, never blocks**), counsel-of-record; `sources_capital=true` fails closed (`INVESTOR_SPINE_FORBIDDEN`).
- **`managedFounderPersonaRoutes.ts`** — 17 persona endpoints.

### Money paths (single sacred ledger; §3.3 transactionality)
- **Soft-circle graduation** → `commitFunded(...)` only. No parallel ledger. The Founder-CRM copy-in is best-effort and never rolls back the sacred commit.
- **`createSpvOnBehalf`** → creates the SPV durably via `spvEngineStore.createSpv`, then a **synchronous** `db.transaction` reads the per-partner hash-chain tip, computes the hash, INSERTs the audit row, and queues the `mf_collective_push` row atomically. The async Collective push runs **outside** the tx (`markCollectivePush`). No async inside the tx, no orphan on gate denial, no hash-chain TOCTOU.

### The 6 fail-closed capability gates (store-enforced + re-checked at every route)
1. `assertClassified` — engagement create requires a classified profile.
2. `assertSourcesCapital` — first-touch attribution requires `sources_capital` (else firm-of-record).
3. `assertDelegatedWriteAuthority` (**D-9**) — SPV / any delegated-write-on-behalf requires `status==='ACTIVE'` **AND** `mode==='A'` **AND** present, non-expired `authority_artifact_ref` **AND** `delegated_agency` **AND** `spv_write_authority`. Global toggles alone are insufficient.
4. `assertCollectivePush` — `collective_fronting` **AND** `status==='ACTIVE'`.
5. `assertGraduation` — `status==='ACTIVE'` **AND** (`sources_capital` OR `delegated_agency`).
6. `assertModeAEntry` — Mode-A entry (create-in-A / B→A / hand-over-confirm-into-A) requires `delegated_agency` **AND** valid non-expired artifact.

### RF-1 sacred edit (the ONLY sacred-file change — owner-authorized)
- `server/lib/userContext.ts`: additive `"INVITED_PRIVATE_ROUND"` `InvestorState` + optional `hasPrivateRoundInvite?` arg. Existing 5 states and all existing callers behave identically when the flag is absent/false. `buildInvitedRounds` (the W-FIX3 region) untouched.
- SHA re-baselined `3a6d325c…→d75d1321…`, documented old→new in `CAPAVATE_SACRED_FILES.md`, sacred gate **40/40 OK** before and after.

### Front-end (additive; nothing renamed/removed)
- `client/src/pages/partner/PartnerManagedFounders.tsx` — list + dashboard widget + engagement detail (3 CRM layers as drill-down tabs; SPV-on-behalf entry). DB-driven via the new endpoints.
- One "Managed Founders" nav entry in PARTNER→OVERVIEW (existing `NavGroup` pattern); two client routes (detail before list). No existing nav/route/page dropped.

## Gate results
| Gate | Requirement | Result |
|------|-------------|--------|
| Sacred SHA256 | 40/40 OK; only `userContext.ts` re-baselined | **40/40 OK** (parent-executed); `d75d1321` disk==manifest |
| Money-core SHAs | byte-identical | **captableCommitStore e5045ecb · messagingStore 17bd5608 · paymentGatewayAdapter 83757c54 · investorCrmStore 95c6e8ad — all unchanged** (parent-executed) |
| Edit surface | additive only | **7 new server files, 5 tests, 1 FE page; 5 existing files ADD-only (userContext +6, hydrate +13, routes +9, App +10, nav +3)** (parent-executed diff) |
| tsc `--noEmit` | ≤ 597, no new | **run on server** (Gate Runbook) — inspection-clean |
| `npm run guard` | ≥ baseline, no drops | **run on server** — additions only; nothing dropped |
| `npm run build` | exit 0 | **run on server** |
| Wave tests (vitest) | pass | **run on server** — 5 suites written (schema/gates/moneypath/isolation/persona) |
| Triple-verify | unanimous SHIP | **Opus SHIP · Gemini SHIP · GPT-5.5 SHIP** |

## Gate Runbook for Avi (run on the server after install)
```
npm install            # or npm ci — builds better-sqlite3 native addon on the server
npm run build          # expect exit 0
npx tsc --noEmit 2>&1 | grep -c 'error TS'      # expect <= 597 (no NEW errors)
npm run guard          # expect no DISAPPEARED items (routes/pages/nav only grow)
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
ENABLE_DEMO_SEED=1 DATABASE_URL=file:./x.db npx vitest run --no-file-parallelism \
  server/__tests__/mfcrm_schema.test.ts server/__tests__/mfcrm_gates.test.ts \
  server/__tests__/mfcrm_moneypath.test.ts server/__tests__/mfcrm_isolation.test.ts \
  server/__tests__/mfcrm_persona.test.ts   # expect all pass
```
Known pre-existing failure (NOT this wave): `sprint28_billing`/`hash-chain-replay` under pglite (`42703`) — reproduces on baseline, imports none of the changed files. Ignore as a wave signal.

## Deploy notes
1. Deploy the tree → `npm install` → `npm run build` → restart. `applyMfcrmSchema()` runs at boot (creates the 12 tables idempotently); the 4 hydrate calls rebuild RAM projections from the DB.
2. **Nothing activates until you seed a partner's capability profile** (`POST /api/admin/mfcrm/capability/:partnerId/seed`) — dark-shipped, fail-closed. Unclassified partners get the most-restrictive profile.
3. **RF-13 back-classification** (assigning `partner_type` to existing partners) and **RF-4/RF-9 legal/compliance sign-off** gate *activation* (esp. law/accounting), not the install.
4. Money paths remain the single sacred ledger; SPV-on-behalf is safe-by-gate (Mode-A + artifact + both toggles).

## Absolute-rule compliance
NEVER silent-drop (nothing removed/renamed; routes/pages/nav only grow) · additive + behavior-preserving · DB-driven, no in-memory/mock/seed on prod paths · per-partner isolation session-only + companyId-attribution 404 · single sacred ledger via `commitFunded` (no parallel path; I-1/I-2/I-3 untouched) · sacred 40/40 with only the authorized `userContext.ts` re-baseline · migrations additive/idempotent · triple-verified, never shipped on REVISE.

## Deliverables
`capavate_v26.2.0-wmfcrm_FULL_INSTALL.zip` · `_PATCH.zip` · `_RELEASE_BUNDLE.zip` · `SHA256SUMS_v26.2.0-wmfcrm.txt` · `FIX_REPORT_WAVE_WMFCRM.md` (+pdf) · `WAVE_WMFCRM_SOURCE.diff` · `CHANGED_FILES_WMFCRM.txt` · `_VERIFY_BUILD_{OPUS,GEMINI,GPT55_DECIDER}.md`.
