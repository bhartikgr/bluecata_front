# FIX REPORT — Wave C1 (Shadie QA: Rounds invitation guards + list sort)

Founder → Rounds surface. Fixes Shadie 3a/4a/5a (revoked/accepted invitation
actions) + 6a (Rounds list order). No new route/nav, no migration. All gates
green (bottom). Non-sacred files only.

## 3a / 4a / 5a — a REVOKED invitation is terminal (fail-closed, both layers)
Root cause: the three invitation action buttons + endpoints did not account for
the `revoked` (terminal) state, so a revoked invitation could be revoked again,
have its expiry extended, or be resent — each re-notifying the revoked investor.

- **3a Revoke:** revoking an already-revoked invite is now refused. Client button
  disabled when `state === "revoked"`; route returns 409 `already_revoked` and
  CRUCIALLY skips the revoked-notification (no second email); store
  `revokeInvitation` throws `ALREADY_REVOKED` (no DB write, no cache mutation).
- **4a Extend expiry:** a terminal invite can't be extended. Client button
  disabled for `revoked` AND `accepted` (Ozan). Route returns 409; store
  `extendInvitation` throws `INVITATION_REVOKED` / `INVITATION_ACCEPTED` before
  any expiry change.
- **5a Resend/remind:** a revoked invite can't be resent. Client button disabled
  for `revoked` (and existing `accepted`). Route returns 409 `invitation_revoked`
  and sends nothing; store `resendInvitation` throws `INVITATION_REVOKED` before
  the token re-mint + email.

Defense in depth: the client disables the control, the route returns a typed 409
without side effects, and the store fails closed even if called directly.

## 6a — Rounds list: newest (latest-created) on top
Root cause: `GET /api/rounds` returns rounds in insertion order (no ORDER BY) and
`Rounds.tsx` rendered them unsorted, so the FIRST-created round showed on top.
Fix: `Rounds.tsx` now sorts a COPY of the list by `createdAt` DESCENDING (newest
first), with a stable id tiebreak. Client-only (no API contract change);
`createdAt` is already returned by `/api/rounds` (rowToRound). Answer from Ozan:
newest on top, oldest at bottom, regardless of state.

## Files
- `server/roundInvitationsStore.ts` — terminal-state guards in
  `revokeInvitation` / `extendInvitation` / `resendInvitation`.
- `server/routes.ts` — 409 guards + no-op-on-revoked (no re-notify) in the
  resend / extend (PATCH) / revoke (DELETE) invitation routes.
- `client/src/pages/founder/RoundDetail.tsx` — disable resend/extend/revoke for
  terminal states.
- `client/src/pages/founder/Rounds.tsx` — newest-createdAt-first sort (+ type).
- **New** `server/__tests__/waveC1_invitation_terminal_guards.test.ts` — 4 tests
  (revoke-again refused, extend-on-revoked refused + expiry unchanged,
  resend-on-revoked refused + token not re-minted, extend-on-accepted refused).

## Gates (end of C1)
| Gate | Result |
|---|---|
| Sacred files | **40/40** byte-identical |
| Money core sha16 | **01cd36130ee1c0cb** (unchanged) |
| tsc `--noEmit` | **598** (net-new **0**) |
| Guard | **exit 0** — 926 / 194 / 92 (no route/nav/page change) |
| Build | **OK** |
| Payments / Airwallex | untouched |
| Migrations | none |
| Tests | C1 4/4; regression: Shadie-v6 + v15 invitation flow pass |

## Pre-existing (NOT a C1 regression)
`server/__tests__/sprint21_invitations.test.ts` has 2 failing co-soft-circle
visibility tests (403 vs 200) — confirmed identical on pristine HEAD (git stash).
Unrelated to invitation actions or the rounds sort.

## Still open in Shadie QA (later waves, per Ozan)
- **C2:** 1a + 1b — CRM investor added at Step 4 must land on the round + send an
  invitation email. Needs a live reproduction first.
- **C3:** 2a (manual-investor dialog: Stage focus + Personal note + Expires-in,
  land + email) + 7a (round-name uniqueness per company, auto-suggest a unique
  name). NOTE: `createInvitation` already accepts `stageFocus` / `note`
  (v25.53 8a) — 2a may need no migration.
