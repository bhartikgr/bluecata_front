# Independent verification brief — Capavate Wave B2 (Consortium Partner QA 3b/3c)

You are an INDEPENDENT verifier. Return APPROVE or REVISE with concrete
file:line defects + fixes. Read the real files, not just the diff. Be adversarial;
flag only REAL issues.

Build tree: `/home/user/workspace/capavate_work` (deps installed). Diff:
`WAVE_B2_SOURCE.diff`. Report: `FIX_REPORT_WAVE_B2.md`.

## What B2 is
Client-only wave in `client/src/pages/partner/PartnerPipeline.tsx` (+ one test).
NO server change, NO new route/nav/page, NO migration. It reuses existing
endpoints. Two parallel process-box rows that are DYNAMIC (items move between
columns automatically as status/stage changes), plus a Following restyle.

- **Row 1 (companies):** existing 6-stage funnel Kanban. Added per-card
  "Publish to Collective" (existing admin-reviewed `POST /api/partner/me/pipeline/:id/promote-to-collective`)
  and "Make Private" (existing `POST /api/partner/me/promotions/:id/withdraw`).
- **Row 2 (SPVs):** NEW lifecycle stage-column row keyed by SPV status
  (draft→open→deployed→distributing→closed→wound_down; all 6 real SPV_STATUSES
  covered, unknown→draft). Inline status dropdown PATCHes
  `/api/partner/me/spv/:id { status }` and invalidates the SPV query so the card
  re-buckets. Publish/Make-Private flips `distributionScope`
  collective_only↔private via the same PATCH. "In Collective" badge when
  collective_only.
- **Row 3 (Following):** restyled pills → cards, same click-through.

## HARD RULES (any violation = REVISE)
1. Sacred 40/40 byte-identical.
2. Money `server/captableCommitStore.ts` sha16 `01cd36130ee1c0cb`.
3. tsc net-new = 0 → exactly **598**.
4. Guard exit 0 (client-only; route/nav/page counts UNCHANGED at 926/194/92).
5. No new `require()` in server TS (this wave is client-only; confirm no server
   file changed at all except the new test).
6. Payments/Airwallex untouched; no new migration.

## Correctness / behaviour to verify
- **Dynamic bucketing (the KEY requirement):** confirm each company renders in
  the column matching its `stage`, and each SPV renders in the column matching
  its `status`; and that changing status/stage persists server-side and the
  query is invalidated so the item moves automatically. Confirm no SPV is
  dropped (every SPV_STATUSES value has a column; unknown falls back to draft).
- **Company Publish/Make-Private:** Publish opens the reviewed Promote flow;
  Make-Private withdraws the live/pending collective promotion. Confirm the
  toggle logic picks the correct promotion (collective_deal_room, live OR
  pending) and that withdraw is server-gated (managing_partner).
- **SPV scope toggle:** collective_only ↔ private via PATCH; confirm the UI
  reads current scope to show the right button + badge.
- **Isolation:** confirm cross-partner SPV mutation is refused server-side (the
  test asserts 401/403 + no mutation). Confirm no client value overrides
  server-resolved partner/user identity.
- **No sacred/ledger path touched** by the SPV status/scope changes.

## Known pre-existing (NOT a regression — do not fail B2 for this)
`server/__tests__/v25_50_group_b_spv.test.ts` has 7 failing B3/B4 LP-commit
tests. They fail identically on pristine HEAD (verify via `git stash` if you
wish). B2 does not touch that path.

Run:
```
cd /home/user/workspace/capavate_work
npx tsc --noEmit 2>&1 | grep -c "error TS"                 # 598
npm run sacred                                      # SACRED OK: 47/47, exit 0
# WAVE 39 (Review 4A N1): use `npm run sacred`, NOT
#   `sha256sum -c sacred_baseline/SACRED_SHA256.txt`.
#   That base-manifest reader is WAIVER-BLIND: it prints 5 FAILED and exits 1 on a
#   HEALTHY tree, because rateLimit.ts, capTableMembership.ts, Billing.tsx,
#   LearnSection.jsx and PricingSection.jsx are under owner-signed waivers whose
#   frozen hashes live in scripts/sacred_check.sh, not in the base manifest.
sha256sum server/captableCommitStore.ts | cut -c1-16        # 01cd36130ee1c0cb
npm run guard 2>&1 | tail -3                                 # exit 0, 926/194/92
npx vitest run server/__tests__/waveB2_pipeline_dynamic.test.ts   # 4 pass
git diff --name-only                                         # only PartnerPipeline.tsx + docs (no server src)
```
If you run `npm run build`, restore: `git checkout -- server/public && git clean -fdq server/public/assets dist`. Do NOT commit.

## Output
Write to `/home/user/workspace/capavate_work/VERDICT_B2_<model>.md`:
1. VERDICT: APPROVE / REVISE
2. Gate results (actual numbers)
3. Per-check confirmation or defect (file:line + fix)
