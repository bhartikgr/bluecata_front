# VERDICT: APPROVE

Wave B1 Round 2 fixes are confirmed. I re-read the real files, re-ran the requested tests/gates, and found no remaining real defect or new Round-2 regression.

## Gate results

| Gate | Result |
|---|---:|
| `npx tsc --noEmit 2>&1 \| grep -c "error TS"` | 598 |
| Sacred baseline `: OK` count | 40/40 |
| `server/captableCommitStore.ts` sha16 | `01cd36130ee1c0cb` |
| `npm run guard` | exit 0; `OK: 925 routes, 194 pages, 92 nav — no silent drops` |
| Requested full test set | 4 files passed, 17 tests passed |
| Targeted adversarial rollback test | 1 file passed, 1 test passed |

Saved raw gate outputs:
- `tsc_b1_gpt55_round2.txt`
- `sacred_b1_gpt55_round2.txt`
- `guard_b1_gpt55_round2.txt`

## Round-1 defect fix confirmations

1. **Attribution failure orphan rollback — fixed.**
   - `server/partnerPortfolioCompanyRoutes.ts:157-163` wraps `linkConsortiumPartner(companyId, ctx.partnerId)` in a required fail-closed block, calls `rollbackFounderCompany(ownerUserId, companyId)`, and returns `500 ATTRIBUTION_LINK_FAILED`.
   - `server/multiCompanyStore.ts:687-715` soft-deletes `companies` and `company_members` in one transaction, sets `company_members.is_active = 0`, evicts `USER_COMPANIES`, and clears `USER_ACTIVE_COMPANY` if it points at the rolled-back company.
   - Hydration excludes the rolled-back company because live company hydration filters both live members and live companies (`server/multiCompanyStore.ts:1055-1063`); the rollback leaves no live membership and a deleted company row.
   - `server/__tests__/waveB1_adversarial_attribution_orphan.test.ts:45-69` forces `consortium_links` insert failure, expects `500 ATTRIBUTION_LINK_FAILED`, and verifies no live active membership remains; the test passed.

2. **Defensive invitation table `sent_at` — fixed.**
   - `server/partnerPortfolioCompanyRoutes.ts:63-84` now mirrors the authoritative `server/lib/founderTeamStore.ts:41-64` pattern, including the idempotent guarded `ALTER TABLE founder_team_invitations ADD COLUMN sent_at TEXT`.

3. **Owner invite required / no 201 without claim link — fixed.**
   - `server/partnerPortfolioCompanyRoutes.ts:171-193` declares `inviteToken: string`, inserts the owner invite inside a required try/catch, unlinks attribution, rolls back the company, and returns `500 FOUNDER_INVITE_FAILED` on any invite failure.
   - The only 201 path is `server/partnerPortfolioCompanyRoutes.ts:210-216`, after the invite token exists, and it always returns `founderInvite: { email, claimUrl: .../auth/redeem?token=... }`.
   - The client success toast is therefore accurate because the server no longer reports success without a claim link.

## Additional guardrail checks

- No `require()` in `server/partnerPortfolioCompanyRoutes.ts`.
- No forbidden imports of sacred `companyProfileStore.ts` or singular `subscriptionStore.ts`; the route imports only non-sacred plural `subscriptionsStore.ts`.
- Sacred files remain byte-identical at 40/40.
- Money core hash remains `01cd36130ee1c0cb`.
- `WAVE_B1_SOURCE.diff` contains no migration file diff and no payments/Airwallex wiring change.
- Round-2 rollback helper introduced no TypeScript errors in its new region; remaining `multiCompanyStore.ts` TypeScript errors are pre-existing baseline lines outside the new helper.

## Notes

- The adversarial test uses an `afterAll` trigger cleanup, so it did not leak into the full 4-file run.
- The client still has a defensive unreachable `founderInvite` null rendering branch, but the server-side contract now prevents a 201 without a claim link; this is not a blocking defect.
