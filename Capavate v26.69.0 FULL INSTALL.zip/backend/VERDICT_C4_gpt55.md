# VERDICT: APPROVE

No blocking defects found. Wave C4 fixes the projection-tab crash in the application path without touching the cap-table engine package or sacred/money-path files.

## Gate results

| Gate | Result |
|---|---:|
| `npx tsc --noEmit` error count | 598 |
| Sacred hashes OK count | 40/40 |
| Sacred overlap in `git diff HEAD~1 --name-only` | 0 |
| Money checksum `server/captableCommitStore.ts` sha16 | `01cd36130ee1c0cb` |
| `npm run guard` | exit 0; `929 routes, 194 pages, 92 nav` |
| `npx vitest run client/src/lib/engineDemo.waveC4.test.ts` | 1 file passed; 4 tests passed |
| `packages/cap-table-engine/**` in diff | none |
| migrations / payments / Airwallex in diff | none |

## Correctness checks

- Fresh-round crash path is gated off: `ProjectionPanel` computes `preMoneyNum = Number(round.preMoney)` and `targetNum = Number(round.targetAmount)`, then `canProject = Number.isFinite(preMoneyNum) && preMoneyNum > 0 && Number.isFinite(targetNum) && targetNum > 0` at `client/src/pages/founder/RoundDetail.tsx:1031-1034`. For `round.preMoney = null` and `round.targetAmount = 0`, this evaluates to `false` (`Number(null) === 0`, `0 > 0` is false), so `post` is set to `null` and `projectPostClose` is not called at `client/src/pages/founder/RoundDetail.tsx:1034-1040`.
- The false branch renders the current pre-close table plus guidance state, including `data-testid="projection-needs-terms"` and `data-testid="projection-gated-note"`, at `client/src/pages/founder/RoundDetail.tsx:1066-1078`.
- Valid rounds still project: the true branch still renders the original two `SideTable`s and allocation/formula line at `client/src/pages/founder/RoundDetail.tsx:1055-1064`, and `projectPostClose` is still called with positive numeric `preMoneyNum` / `targetNum` at `client/src/pages/founder/RoundDetail.tsx:1034-1039`.
- Pre-close calculation remains unconditional after securities load: `runEngine(securities.data, "fully_diluted", "US")` is still called at `client/src/pages/founder/RoundDetail.tsx:1024`. I probed this path with an empty cap table and a founder common-share cap table; both returned successfully (`rows 0 total 0`, `rows 1 total 8000000`).
- Engine package was not edited. The BigInt failure site remains in `packages/cap-table-engine/src/captable/compute.ts:101`, and `git diff HEAD~1 -- packages/cap-table-engine/**` is empty.
- `projectPostClose` now accepts `number | null | undefined` inputs and coerces through `Number.isFinite(Number(...))` before calling `.toString()` at `client/src/lib/engineDemo.ts:240-263`. Valid numeric inputs are preserved, and the positive-input targeted test passes. Direct degenerate inputs can still produce the engine's `Cannot convert NaN to a BigInt`, but the only real application call site is now gated so the engine is not invoked with 0/0 or null terms.

## Artifacts saved

- `verify_c4_gpt55_tsc_full.txt`, `verify_c4_gpt55_tsc_count.txt`
- `verify_c4_gpt55_sacred_full.txt`, `verify_c4_gpt55_sacred_count.txt`, `verify_c4_gpt55_sacred_overlap_precise.txt`
- `verify_c4_gpt55_money_sha16.txt`
- `verify_c4_gpt55_guard_full.txt`, `verify_c4_gpt55_guard_full_rerun.txt`, `verify_c4_gpt55_guard_summary.txt`
- `verify_c4_gpt55_waveC4_vitest_full.txt`
- `verify_c4_gpt55_code_trace.txt`, `verify_c4_gpt55_runEngine_probe.txt`, `verify_c4_gpt55_projectPostClose_probe.txt`, `verify_c4_gpt55_diff_checks.txt`
