# VERIFIER BRIEF — Wave 1 (Security Hardening) — v26.2.0

You are independently verifying Wave 1 in the git tree `/home/user/workspace/capavate_work`
(HEAD `e990117`). READ-ONLY: do NOT edit files, do NOT run the app. You MAY run
read-only git/tsc/vitest/grep.

## What to read
- `FIX_REPORT_WAVE_SEC.md` — the claims.
- `WAVE_SEC_SOURCE.diff` — the exact change (or `git diff HEAD~1`).
- `ROADMAP_SPEC_SECURITY.md` — the spec the wave implements.

## Rules you must confirm are upheld
- Sacred 47/47 byte-identical (`npm run sacred`, exit 0); Use `npm run sacred` (waiver-aware; `SACRED OK: 47/47`, exit 0). The raw `sha256sum -c sacred_baseline/SACRED_SHA256.txt` reader is **waiver-blind** and reports the five owner-waived files as `FAILED` (35 OK of 40, exit 1) on a healthy tree — by design, not corruption.
  money core `server/captableCommitStore.ts` sha16 = `01cd36130ee1c0cb`.
- NO Airwallex/payment gateway code edited (rule #14). H6 may only touch
  membership/billing STATE tables + the new queue table.
- tsc net-new 0 (total 598); `npm run guard` exit 0; ESM only (no new bare require);
  migration 0109 additive + idempotent + MIRRORED (migrations/ AND server/db/migrations/)
  + inline self-heal in connection.ts; no silent-drops.
- To restore build artifacts if you build: `git checkout -- server/public && git clean -fdq server/public/assets dist`. Do NOT `git checkout -- .`.

## What to check per fix (correctness + security)
1. C1/C2: does `partnerCanAccessInvestorCompliance` fail CLOSED and correctly prove the
   partner↔investor relationship? Are BOTH GET and PUT guarded BEFORE any read/write?
   Is the PUT zod schema strict (rejects unknown keys)? Any bypass?
2. H2: is `/api/collective/spvs` actually gated by `requireCollectiveMember` now?
3. H3/H4: is the relationship proof correct? Does GET return 404 (not 403) with NO
   company name/logo leak for unrelated companies? Does PATCH check BEFORE body parse?
   Is "following" correctly excluded as a proof?
4. H5: is the route admin-only (401 unauth / 403 non-admin) with strict validation and
   a company-existence check? Confirm no client/test regressed (grep for callers).
5. H6: does the gate deny on an open marker BEFORE the 4-source active check? Is intent
   recorded BEFORE deactivate (fail-closed)? Does recovery clear markers? Confirm NO
   Airwallex/payment code touched. Is the migration mirrored + self-healed?
6. ELIG: is `?userId` admin-only, with anonymous/non-admin silently ignored (no oracle)?

## Also verify
- `npx tsc --noEmit 2>&1 | grep -c "error TS"` = 598.
- `npx vitest run server/__tests__/waveSEC_collective_gating.test.ts` = 14/14 pass.
- Pre-existing failures unchanged: `sprint21_invitations` (2), `spvEngine` (30) — NOT
  new regressions (verify via `git stash` if unsure).

## Your verdict
Write to `/home/user/workspace/VERDICT_SEC_<model>.md`: APPROVE or REVISE, with specific
file:line issues if REVISE. Focus on real security correctness and rule compliance, not
style. Then reply with a 6-line summary ending in `VERDICT: APPROVE` or `VERDICT: REVISE`.
