import { describe, it } from "vitest";
import { computeCarryForward } from "../server/roundCarryForwardEngine";
import { rounds, securities, companies } from "../server/mockData";
describe("debug", () => {
  it("dump", () => {
    console.error("MD rounds:", rounds.length);
    console.error("MD securities:", securities.length);
    const r = computeCarryForward({ companyId: "co_novapay", proposedType: "preseed", proposedName: "x", proposedRoundSizeUsd: 0 } as any);
    console.error("result:", JSON.stringify(r, null, 2).slice(0, 500));
  });
});
