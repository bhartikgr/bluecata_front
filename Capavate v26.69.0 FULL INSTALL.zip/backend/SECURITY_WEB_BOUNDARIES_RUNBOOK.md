# Capavate Web Boundaries Runbook (Security Wave C)

Operator instructions for browser origins, security headers, nginx and the
inbound bridge receivers. It contains no credentials. Never paste keys, cookies
or tokens into tickets or logs.

## 1. Trusted browser origins

- Production always trusts exactly `https://capavate.com` and
  `https://www.capavate.com`.
- Extra preview or embedding hosts are allowed ONLY through
  `TRUSTED_PREVIEW_ORIGINS`, a comma-separated list of exact origins, for example
  `TRUSTED_PREVIEW_ORIGINS=https://preview-1.example.com,https://127.0.0.1:8443`.
  - Each entry is `https://host[:port]` with nothing after it: no path, no
    trailing `/`, no query, no fragment, no `user:password@`, no `*`, not `null`.
  - Invalid entries are ignored and grant nothing. The log shows only a count:
    `TRUSTED_PREVIEW_ORIGINS: N invalid entries ignored`. Fix the list if you see it.
- The old `*.pplx.app` wildcard is removed on purpose. A preview host that is
  not listed exactly is unavailable for writes, CORS and framing; that is not a
  reason to restore a wildcard.
- Localhost/127.0.0.1 defaults apply only outside production. In production a
  loopback origin needs its own exact HTTPS entry.
- The same list feeds CORS, the write-origin check and CSP `frame-ancestors`.

## 2. Write protection (what users may see)

- A POST/PUT/PATCH/DELETE from a browser page on a non-trusted origin gets
  `403 origin_not_allowed`.
- A cookie-carrying write that the browser marks `Sec-Fetch-Site: cross-site` is
  refused even without an Origin header.
- Requests with neither header (server-to-server tools) behave as before.
- Only these seven machine POSTs skip the browser checks; their own signature
  checks or 410 responses still run:
  `/api/webhooks/payment-gateway`, `/api/webhooks/payment-gateway/airwallex`,
  `/api/webhooks/payment-gateway/stripe` (410), `/api/airwallex/webhook/collective`,
  `/api/stripe/webhook/collective` (410), `/api/bridge/inbound`,
  `/api/bridge/collective-receive`.
- Known baseline limit: CORS is still applied after the authentication guard, so
  an anonymous preflight (OPTIONS) to a protected route returns 401.

## 3. Security headers and nginx (host acceptance gate)

The application sends the headers on everything it serves. Pages nginx serves
directly need the include:

1. Copy `docs/nginx-capavate-security-headers.conf` to
   `/etc/nginx/snippets/capavate-security-headers.conf`.
2. Include it in the Capavate `server {}` block and in every `location` that has
   its own `add_header` (those locations do not inherit server-level headers).
3. If previews are configured, add the same exact origins to its
   `frame-ancestors`.
4. `nginx -t`, reload, then run the read-only checker with an HTML page, a static
   asset and an error page:
   `node scripts/check-security-headers.mjs https://capavate.com/ https://capavate.com/assets/<file>.js https://capavate.com/__no_such_page__`
   Exit 0 = all present. The checker only sends GET requests; it never reloads or
   edits anything.

A source package does not prove direct-served pages carry the headers; only the
checker run on the host does.

## 4. Inbound bridge receiver configuration (host acceptance gate)

In production the inbound receivers refuse to use the built-in fallback key.

- `/api/bridge/inbound` (and the retained mock receiver) verify with
  `BRIDGE_INBOUND_HMAC_SECRET`, else `BRIDGE_HMAC_SECRET`, read at startup.
- `/api/bridge/collective-receive` accepts a signature made with
  `COLLECTIVE_WEBHOOK_SECRET` (else `BRIDGE_OUTBOUND_HMAC_SECRET`, else
  `BRIDGE_INBOUND_HMAC_SECRET`) or with the inbound key above.
- A missing, placeholder (for example `changeme`) or fallback key makes the
  affected receiver answer `503 bridge_verifier_unavailable`. The rest of the
  application, sign-in and outbound queuing keep working. A wrong signature
  with a configured key is still `401`.

Checklist:
1. Generate strong private keys on the host (for example 32+ random bytes, hex).
   Do not reuse example values and never send keys over chat or email.
2. Set them in the host environment and restart the application (keys are read
   at startup).
3. Confirm the sender signs with the same key as the receiver.
4. Already queued outbound events keep the existing retry/recovery procedures.
5. Known residual D-S14-1: the receivers still sit behind the normal session
   guard; machine-to-machine delivery without a session is a separate
   integration item, not solved by this wave.

No live bridge probe is part of this runbook.
