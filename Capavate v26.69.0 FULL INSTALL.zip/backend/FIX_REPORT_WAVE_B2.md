# FIX REPORT — Wave B2 (Consortium Partner QA slides 3b/3c)

Mostly client. Reuses EXISTING endpoints; the only server changes are small,
non-sacred guards added during REVISE (SPV status validation, the on-Capavate
publish invariant, one error-map entry). No new route/nav, no new migration. All
gates green (bottom).

## REVISE fixes (GPT-5.5 deciding, round 1) + on-Capavate invariant
Opus + Gemini APPROVED; GPT-5.5 (decides, rule #7) REVISE with 4 defects, all
fixed; plus Ozan's on-Capavate invariant:
1. **Make-Private UI gate now matches the server gate** — withdraw is
   managing_partner-only server-side, so the "Make Private" button is gated on
   `canWithdrawPromotion` (managing_partner). Associates see a read-only
   "In Collective"/"In review" badge instead of a control they can't use.
2. **`pending_collective_review` recognized** — collective promotions are
   created with that status (not `pending`); the client type + the active-promo
   lookup now include it, so a company under review correctly shows Make-Private.
3. **SPV status PATCH is validated server-side** — new `isSpvStatus` guard in
   `shared/spvEngine.ts`; `updateSpv`/`createSpv` reject an out-of-enum status
   with `INVALID_SPV_STATUS` (mapped to 400). Client UI can't persist a bad
   lifecycle state.
4. **Draft-SPV discoverability copy corrected** — draft SPVs are excluded from
   Collective discovery, so "Publish to Collective" is disabled while Draft (with
   an explanatory tooltip), the badge reads "Collective (on launch)" until the
   SPV leaves Draft, and the toast no longer overstates discoverability.
5. **On-Capavate invariant (Ozan)** — a company must exist ON CAPAVATE (cap
   table + rounds operating) BEFORE it can be published to the Collective. The
   promote endpoint now returns 409 `COMPANY_NOT_ON_CAPAVATE` for a bare
   name-only deal (no linked `companyId`/company record); the client shows an
   "Add to Capavate first" link (to Wave B1 Add Portfolio Company) instead of
   Publish for such deals.

Server files touched (all non-sacred): `server/partnerRoutes.ts` (promote
invariant), `server/spvEngineRoutes.ts` (err-map), `server/spvEngineStore.ts`
(status validation), `shared/spvEngine.ts` (`isSpvStatus`). Client:
`client/src/pages/partner/PartnerPipeline.tsx`.

## 3b — Two parallel process-box rows, both fully dynamic
**Row 1 (Portfolio Companies)** — the existing 6-stage company funnel Kanban
(Invited → Committed). A company is bucketed into the column matching its
`stage`; advancing the stage (existing inline dropdown → `stageMut` → invalidates
`/api/partner/me/pipeline`) makes the company move to the new column
automatically. Added per-card visibility controls:
- **Publish to Collective** → the existing admin-reviewed **Promote-to-Collective**
  flow (answer 3b-6 = a). Shown when the company has no live/pending collective
  promotion.
- **Make Private** → withdraws the live/pending promotion via the existing
  `POST /api/partner/me/promotions/:id/withdraw` (answer 3b-7 = Yes). Shown when a
  collective promotion exists. (Refer-to-Capavate retained.)

**Row 2 (SPVs)** — NEW: re-rendered from a flat 3-col grid into a **matching
process-box row keyed by the SPV's REAL lifecycle** (answer 3b-5 = a):
Draft → Open → Deployed → Distributing → Closed → Wound-down. (All six real
`SPV_STATUSES` are covered so no SPV is ever dropped; unknown/legacy status
falls back to Draft.) Each SPV is bucketed into the column matching its `status`.
- **Dynamic movement:** an inline status dropdown PATCHes
  `/api/partner/me/spv/:id { status }` and invalidates the SPV query, so the SPV
  moves to the matching column automatically (mirrors the company row).
- **Publish to Collective / Make Private:** instant scope flip via the SPV
  Engine's own `PATCH … { distributionScope }` — `collective_only` (Publish) ↔
  `private` (Make Private) (answer 3b-6 = a: SPVs keep the instant toggle). An
  "In Collective" badge shows when scope = collective_only.
- Each card links to the SPV Engine to manage fully.

Both rows use identical box styling (`grid … grid-cols-6`, per-column count +
description, cards with inline stage/status control) so they read as two parallel
process rows.

## 3c — Following from Collective (restyle)
Restyled from pill chips into **cards** matching the two process rows (answer
3c-8 = restyle into card), keeping the same click-through to the full Collective
profile (`/collective/companies/:id`, new tab).

## Dynamic behaviour (explicit)
The item (company or SPV) moves between boxes automatically as its status
progresses — this is data-driven bucketing (each item rendered under the column
matching its current stage/status), not drag-and-drop of card shells. Proven by
`waveB2_pipeline_dynamic.test.ts`: an SPV status PATCH persists the new status
(so it re-buckets), the scope PATCH flips private↔collective_only, and the
company withdraw returns a `withdrawn` promotion. Cross-partner isolation holds
(a non-member PATCH is rejected and does not mutate the SPV).

## Security / isolation
- All actions go through the existing partner-auth + sub-role + signed-agreement
  gated endpoints; no new endpoint or auth surface was added.
- Company withdraw is `managing_partner`-gated server-side; the UI shows the
  control under the same `canPromote` gate. SPV status/scope PATCH is write-role
  gated server-side; UI shows controls under `canWrite`.
- Cross-partner SPV mutation is refused by the server (test asserts 401/403 and
  no mutation).

## Gates (end of B2)
| Gate | Result |
|---|---|
| Sacred files | **40/40** byte-identical |
| Money core sha16 | **01cd36130ee1c0cb** (unchanged) |
| tsc `--noEmit` | **598** (net-new **0**) |
| Guard | **exit 0** — 926 routes / 194 pages / 92 nav (no route/nav/page change) |
| Build | **OK** |
| New `require()` in server TS | none |
| Payments / Airwallex | untouched |
| Migrations | none |
| Tests | B2 **7/7** (dynamic SPV move, scope flip, status-validation reject, draft-vs-open discovery, cross-partner isolation, on-Capavate invariant, publish+withdraw); canonical SPV 9/9 |

## Pre-existing (NOT a B2 regression)
`server/__tests__/v25_50_group_b_spv.test.ts` has 7 failing B3/B4 LP-commit tests.
Confirmed identical on pristine HEAD (git stash → same 7 fail). B2 touches none
of that ledger path.
