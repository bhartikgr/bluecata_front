import { runAuditChainBootVerifier } from "./server/lib/hydrateStores";
import { rawDb } from "./server/db/connection";

async function run() {
  const db = rawDb();
  // Clear and insert 100 tenants
  db.exec("DELETE FROM audit_log; DELETE FROM audit_chain_health;");
  const stmt = db.prepare("INSERT INTO audit_log (tenant_id, id, action, created_at, hash) VALUES (?, ?, ?, ?, ?)");
  db.transaction(() => {
    for (let i = 0; i < 100; i++) {
      stmt.run(`tenant_${i}`, `log_${i}`, "test", new Date().toISOString(), "hash");
    }
  })();
  
  console.log("Running verifier (max 10)...");
  setTimeout(() => {
      console.log("3 seconds passed, exiting...");
      process.exit(0);
  }, 3000);
  
  await runAuditChainBootVerifier({ maxTenants: 10 });
}
run();
