# Analysis — Shadie's QA feedback (Capavate Founder → Rounds)

Source: `EDITS-version2-Shadie-CAPAVATE.pptx` (7 slides). This QA is about the
**Founder Rounds** flow — round creation Step 4 (Investors), the round
Invitations table, and the Rounds list — NOT Consortium Partners (Waves A/B).
Every item was located in the current v26.1.0 build and diagnosed below.

Verified live URLs in the deck: `/founder/rounds/new`, `/founder/rounds/:id`,
`/founder/rounds`.

Legend: **BUG** = broken behavior; **ENH** = enhancement/new control; sev H/M/L.

---

## 1a — CRM investor "added" in Step 4 but NOT on the round after create  · BUG · sev H
**Shadie:** In Step 4, adding an investor available from your CRM shows "Added",
but the investor is not on the round once it's created. Please add it.
**Where:** `client/src/pages/founder/RoundNew.tsx` — Step 4 "Available from your
CRM" → "+ Add" moves the pick into `selectedShareholders`; the create payload
maps `selectedShareholders` (RoundNew.tsx ~L364-395), and the server persists
initial shareholders / issues invitations.
**Diagnosis (needs live repro to confirm root cause):** the pick shows in
"Selected for this round" locally, but is not landing on the created round. Most
likely one of: (a) CRM-sourced picks (which supply only a display name, no
discrete email/identity) are dropped by the create payload builder, or (b) they
are added as initial shareholders but no round *invitation* is created, so they
don't appear in the Invitations table. I need to reproduce on the live/staging
round to see whether the pick is missing from initial-shareholders, from
invitations, or both.
**Fix shape:** ensure a CRM pick with a resolvable email is (i) attached to the
round on create AND (ii) issued an invitation; if it has no email, block the add
with a clear message rather than silently "Adding". Ties to 1b.

## 1b — No invitation email sent when a CRM investor is added in Step 4  · BUG/ENH · sev M
**Shadie:** Adding a CRM investor in Step 4 shows added but the investor gets no
email; send a notification once added at this stage.
**Where:** same Step 4 add path. Invitations issued from the round detail page DO
send email (RoundDetail resend → "A fresh invitation email … was sent").
**Diagnosis:** the Step-4 (create-time) add path does not trigger the invitation
email that the round-detail invite path does. Depends on 1a's root cause (if the
CRM pick isn't creating an invitation at all, no email is the symptom).
**Fix shape:** when a CRM investor is added at Step 4 and the round is created,
issue the standard round invitation (same path as the detail-page invite) so the
existing invitation email fires. Reuse the existing invite/email flow — do NOT
add a new email path (rule #14 keeps payments/Airwallex untouched; this is comms
email, already implemented).

## 2a — Manual "Add a non-Capavate investor" needs 3 new fields + must land + email · ENH · sev M
**Shadie:** In the "Add a non-Capavate investor" dialog (Step 4), add:
  1. **Stage focus** (optional)
  2. **Personal note** (optional)
  3. **Expires in** box
…then ensure the manually-added investor shows on the created round and gets an
invitation email.
**Where:** `RoundNew.tsx` manual dialog (~L1077-1103): currently First name*,
Last name*, Company (opt), Email*, Check size (opt), "Add to round".
**Diagnosis:** ENH — the three fields do not exist in the dialog. "Expires in"
should map to the invitation `expiryDays` the invite/PATCH flow already supports;
"Stage focus" and "Personal note" are new optional metadata to carry onto the
invitation. Also the same land-on-round + send-email requirement as 1a/1b.
**Fix shape:** add the 3 fields (both first two optional; Expires-in a
day-count/date), carry them into the create payload → invitation, and fire the
invitation email on create. Rule #13 (last name required) already holds — Last
name is a required field here. Confirm whether Stage focus / Personal note need
persisting on the invitation row (may need an additive, mirrored migration —
next free id 0109 — I will ask before adding).

## 3a — Revoke button still active for already-Revoked invitations (and re-notifies) · BUG · sev H
**Shadie:** The Revoke button is still active for Revoked invitations; clicking it
re-shows the confirm and the investor gets ANOTHER notification. No notification
should be sent to an already-revoked invitation.
**Where:** `client/src/pages/founder/RoundDetail.tsx:545` — the Revoke button is
disabled only via nothing (`onClick={() => setRevokeId(i.id)}`), NOT gated on
`i.state === "revoked"`. Confirmed in code.
**Fix shape:** disable Revoke when `i.state === "revoked"` (client), AND make the
server revoke endpoint idempotent/fail-closed: revoking an already-revoked
invitation must be a no-op that sends NO notification. Both layers (defense in
depth), matching the Wave-A pattern.

## 4a — Expiry-extend button active for Revoked invitations · BUG · sev H
**Shadie:** For a Revoked invitation, the expiration-extend button still works.
Once revoked, the extend button should be inactive.
**Where:** `RoundDetail.tsx:544` — `extendExpiryMut` button disabled only on
`extendExpiryMut.isPending`, NOT on revoked state. Confirmed. Toast "Expiry
extended +30 days" fires even for revoked.
**Fix shape:** disable extend when `i.state === "revoked"` (also "accepted"?
confirm) client-side, AND have the server reject an extend on a revoked
invitation (fail-closed).

## 5a — Reminder/resend active for Revoked invitations (and re-notifies) · BUG · sev H
**Shadie:** When an invitation is revoked, the reminder action should be
inactive; the reminder was sent to the revoked investor.
**Where:** `RoundDetail.tsx:543` — resend disabled only on
`resendMut.isPending || i.state === "accepted"`, NOT on "revoked". Confirmed. So
a revoked invite can be resent, emailing the revoked investor.
**Fix shape:** add `|| i.state === "revoked"` to the resend disable (client), AND
fail-close the resend endpoint for revoked invitations (no email).

> 3a/4a/5a share ONE root cause: the three invitation action buttons don't
> account for the `revoked` state, and the corresponding endpoints aren't
> fail-closed against acting on a revoked invitation. Fix together: a small
> `isRevoked` (and terminal-state) guard on the client buttons + fail-closed
> server guards. This is a clean, self-contained wave.

## 6a — Rounds list is sorted oldest-first; should be newest-active on top · BUG · sev M
**Shadie:** Created Round 1 first, Round 3 last; the list shows Round 1 on top.
The latest active round should be on top, then chronological below.
**Where:** `GET /api/rounds` (`server/routes.ts:1582`) returns rounds in
insertion order (no ORDER BY); `client/src/pages/founder/Rounds.tsx:155`
renders `rounds.data?.map(...)` with NO sort. Confirmed.
**Answer from Ozan:** newest (latest-created) round on TOP, oldest at the bottom
— i.e. a simple `createdAt` DESCENDING sort, regardless of state (NOT
active-first).
**Fix shape:** sort the Rounds list by `createdAt` descending (newest first).
Safest as a **client-side sort** in `Rounds.tsx` (no API/contract change, lowest
risk); optionally also order the API for consistency. Tie-break stably (e.g. by
round id) when two rounds share a createdAt.

## 7a — Two rounds of the SAME stage can share the SAME name ("Round 5") · BUG/ENH · sev M
**Shadie:** You can pick the same stage twice (e.g. Pre-Seed + Pre-Seed), fine,
but the round NAMES must be unique — currently both Pre-Seed rounds can be
"Round 5". Same-stage rounds can't have the same name.
**Where:** `server/roundsStore.ts` create — `name: input.name` is stored with NO
uniqueness/duplicate check; the client name field defaults to empty. Confirmed no
`ROUND_NAME`/duplicate guard exists.
**Fix shape:** enforce round-name uniqueness per company (at least within the
same stage/type, per Shadie's wording — confirm scope: per-company-global vs.
per-stage). Server: reject a create/rename that duplicates an existing
non-deleted round name (fail-closed, e.g. `ROUND_NAME_DUPLICATE` → 409). Client:
inline validation + a sensible unique default (e.g. auto-suffix). Confirm the
exact uniqueness scope before building.

---

## Cross-cutting notes
- **Scope:** none of this touches Consortium Partners (Waves A/B), the sacred 40,
  the money core, or payments/Airwallex. It's the founder Rounds surface —
  `RoundNew.tsx`, `RoundDetail.tsx`, `Rounds.tsx`, `roundsStore.ts`, and the
  rounds routes. All non-sacred (to confirm at build time).
- **Invitation emails already exist** — 1b/2a reuse the existing round-invitation
  email path, not a new one.
- **Likely one migration at most** (0109, additive + mirrored) IF 2a's Stage
  focus / Personal note must persist on the invitation row. I will ask before
  adding any migration (rule #12).
- **Standing rules still apply:** ask-before-assume, last-name-everywhere,
  fail-closed writes, triple-verify each wave (GPT-5.5 decides), backup.

## Recommended sequencing (proposed — awaiting Ozan)
- **Wave C1 (BUG cluster, do first):** 3a + 4a + 5a (revoked-state guards) + 6a
  (sort: newest createdAt on top). Self-contained, high-value, low-risk, no
  migration.
- **Wave C2:** 1a + 1b (CRM pick lands on round + email) — needs a live repro to
  confirm root cause first.
- **Wave C3:** 2a (manual-investor new fields + land + email) + 7a (name
  uniqueness). May need the one additive migration (2a metadata).

## Questions I need answered before building (rule #12 — no assumptions)
1. **6a sort:** ANSWERED — newest (latest-created) on top, `createdAt` DESC,
   regardless of state.
2. **7a uniqueness scope:** must names be unique **per company across all
   rounds**, or only **within the same stage/type**? And on collision, block with
   an error, or auto-suggest a unique name?
3. **2a fields:** should "Stage focus" and "Personal note" be **persisted** on
   the invitation (durable, needs migration 0109) or only passed into the
   invitation email body (no migration)? What values should "Stage focus" offer
   (free text, or the round stages)? Is "Expires in" a day-count (e.g. 30) or a
   date picker?
4. **4a extend:** disable extend only for **revoked**, or also for **accepted**
   (an accepted investor arguably shouldn't need an expiry extension)?
5. **Can I reproduce on the LIVE site** using the founder login for 1a/1b, or is
   there a staging build with v26.1.0 I should test against? (Live is still
   26.0.0, so 1a/1b repro on live reflects the OLD build.)
6. **Sequencing:** OK to start with **Wave C1** (3a/4a/5a/6a) now while you answer
   the rest?
