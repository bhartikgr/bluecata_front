# Wave D — Front-end ↔ Back-end Contract Reconciliation

**Working tree:** `/home/user/workspace/avi_v19_tree`
**Baseline (v23):** 2771 vitest tests · 629 TS errors · 62/62 gates · math-sacred intact
**Post-Wave-D:** 2796 vitest tests passing (2771 + 25 new contract tests) · 629 TS errors · math-sacred SHAs identical · 1 allowed failure (patch2_avi_fixes ECONNREFUSED, pre-existing)

---

## What "front-end ↔ back-end contract reconciliation" means in this build

The marketing/homepage components (`client/src/components/home3compo/*`) make
public promises — pricing, trial copy, link destinations — that must match
what the backend actually does. When marketing says "Free to start, no credit
card required", the backend must let users sign up free; when it says
"$70/month" but the only billable SKU is `$840 USD/year per company`, that's
a contract mismatch — even though the numbers are arithmetically equivalent,
the admin/founder UI and the public site disagree on what the product is.

Wave D's job is to make the homepage truthful relative to what Waves A–C
actually shipped:

- Wave A: hash-routing under `/#/` for every authenticated route.
- Wave B: 14-day trial auto-granted on company creation; consortium apply
  form lives at `/#/apply/consortium` and no longer requires auth.
- Wave C: single-tier `$840 USD/year per company` pricing in admin/founder.

This wave does **not** touch any backend logic, math, or routing — only the
copy and `href` values on the public site. The new
`server/__tests__/frontendBackendContract.test.ts` pins the contract going
forward: if marketing copy is changed without updating the corresponding
backend behaviour (or vice versa), the test fails.

---

## Math-sacred SHA proof

| Snapshot | `server/captableCommitStore.ts` (full) | Lines 354–477 |
|---|---|---|
| **Required** | `5b0be7ccc3acade42029ee6c4d75236ae64c910c4447a33f4428012ff86d6b78` | `e27651e33947c8994957bb9aee7ef44e011e4dc50aeaf29276e39219dbb09ac6` |
| **Before Wave D** | `5b0be7ccc3acade42029ee6c4d75236ae64c910c4447a33f4428012ff86d6b78` | `e27651e33947c8994957bb9aee7ef44e011e4dc50aeaf29276e39219dbb09ac6` |
| **After Wave D** | `5b0be7ccc3acade42029ee6c4d75236ae64c910c4447a33f4428012ff86d6b78` | `e27651e33947c8994957bb9aee7ef44e011e4dc50aeaf29276e39219dbb09ac6` |

`packages/cap-table-engine/*` untouched. `server/captableCommitStore.ts:354-477` untouched. **Math integrity verified IDENTICAL.**

Re-run command:

```bash
sha256sum server/captableCommitStore.ts
sed -n '354,477p' server/captableCommitStore.ts | sha256sum
```

---

## Per-issue diagnosis & fix

### ISSUE 4 (P0) — Broken investor onboarding URL

**File:** `client/src/components/home3compo/PricingSection.jsx`

- **Before — line 143:** `href="https://capavate.com/onboarding"` — missing `#`, would 404 on hash-routed SPA.
- **After  — line 143:** `href="https://capavate.com/#/onboarding?portal=investor"` — correct hash route, with `portal=investor` so the auth shell preselects the investor portal.

### ISSUE 1 (P1) — Pricing headline shows the per-month equivalent instead of the annual SKU

**File:** `client/src/components/home3compo/PricingSection.jsx`

- **Before — line 13:** `$70/month to activate a network <em>worth multiples more.</em>`
- **After  — line 13:** `$840/year per company to activate a network <em>worth multiples more.</em>`
- **Before — lines 31–37:** `<span class="...price">$70</span>` · `/month · billed annually` · `$840/year — less than one warm introduction is worth`
- **After  — lines 31–37:** `<span class="...price">$840</span>` · `/year · per company` · `Each additional company: $840/year (per-company billing)`

The redundant secondary `$840/year — less than one warm introduction` line was removed; per-company billing annotation now matches the admin/founder settings copy.

### ISSUE 2 (P1) — "Free to start" misrepresents the 14-day trial

**File:** `client/src/components/home3compo/AudiencesSection.jsx`

- **Before — line 289:** `Free to start · No credit card required`
- **After  — line 289:** `14-day free trial · No credit card required`

Now matches Wave B backend: founders auto-receive a 14-day trial; the paywall kicks in afterward.

### ISSUE 5 (P1) — Ecosystem Partner CTA dead-ended to same-page anchor

**File:** `client/src/components/home3compo/PricingSection.jsx`

- **Before — line 158:** `<a href="#cta-final" ...>Become an Ecosystem Partner</a>`
- **After  — line 158:** `<a href="https://capavate.com/#/apply/consortium" ...>Become an Ecosystem Partner</a>`

Wave B Fix 12 removed the auth requirement from `/#/apply/consortium`, so the apply form is now the correct destination.

### ISSUE 7 (P1) — Footer3 affordance audit

**File:** `client/src/components/home3compo/Footer3.jsx`

Audit results (against spec requirements):

| Link | Status before | Action taken |
|---|---|---|
| Founder sign-in `/#/auth/login?portal=founder` | MISSING (was `#/onboarding`) | **Added** (line 145 — Companies dropdown item) |
| Investor sign-in `/#/auth/login?portal=investor` | MISSING (was `#/onboarding`) | **Added** (line 135 — Investors & Shareholders dropdown item) |
| Partner sign-in `/#/partner/login` | Present (line 153, 181) | unchanged |
| Admin sign-in `/#/admin/login` | Present (line 163) | unchanged |
| Apply consortium `/#/apply/consortium` | Present (line 189) | unchanged |

Also added `data-testid="link-footer-investor-login"` and `data-testid="link-footer-founder-login"` for test discoverability.

### ISSUE 8 (P1) — Header3 dropdown 3-persona parity

**File:** `client/src/components/home3compo/Header3.jsx`

- **Before — lines 138–157 (desktop dropdown):**
  - "Investors & Shareholders" → `#/onboarding`
  - "Companies" → `#/onboarding`
  - "Consortium Partners" → `#/partner/login` ✓ (kept)
- **After  — lines 138–168 (desktop dropdown):**
  - "For Investors" → `#/auth/login?portal=investor` (`data-testid="link-header-investor-login"`)
  - "For Founders"  → `#/auth/signup?portal=founder` (`data-testid="link-header-founder-signup"`)
  - "Consortium Partners" → `#/partner/login` (unchanged)
- **Before — lines 228–236 (mobile menu):** two `#/onboarding` links labeled "Investor Sign In" and "Company Sign In", primary CTA also to `#/onboarding`.
- **After  — lines 230–239 (mobile menu):**
  - "For Investors" → `#/auth/login?portal=investor`
  - "For Founders"  → `#/auth/signup?portal=founder`
  - "Consortium Partner Sign In" → `#/partner/login`
  - "Apply: Consortium Partners" → `#/apply/consortium` (NEW — surfaces apply route on mobile)
  - "Register Your Company" primary CTA → `#/auth/signup?portal=founder` (was `#/onboarding`)

### ISSUE 6 (P1) — Investor secondary card lacked feature parity

**File:** `client/src/components/home3compo/PricingSection.jsx`

- **Before — lines 137–141:** description paragraph only, no bulleted feature parity with founder card.
- **After  — lines 142–146:** added `<ul class="pricing__secondary-features">` with:
  - `Verified portfolio holdings`
  - `Co-investor visibility`
  - `Real-time round updates`

### ISSUE 3 — "Free. Always." investor headline retained, subtext verified

**File:** `client/src/components/home3compo/PricingSection.jsx`

- **Line 136:** `Free. Always.` — retained unchanged (accurate: investors do not pay).
- **Lines 137–141:** subtext already reads `Access your verified portfolio, see co-investors, and track every holding — at no cost. Investors are invited by their companies.` — invitation-only nuance is already present, no edit required. Verified.

---

## Test file

**Path:** `server/__tests__/frontendBackendContract.test.ts`
**Tests:** 25 (all passing)
**Coverage by issue:**

| Issue | Assertion(s) |
|---|---|
| 1 | `PricingSection.jsx` contains `$840/year per company`, contains `>$840<`, contains `/year · per company`, contains `Each additional company: $840/year (per-company billing)`, does NOT contain `$70/month to activate`, does NOT contain `less than one warm introduction is worth` |
| 2 | `AudiencesSection.jsx` contains `14-day free trial · No credit card required`, does NOT contain `Free to start · No credit card required` |
| 3 | `PricingSection.jsx` retains `Free. Always.` and contains `Investors are invited by their … companies` |
| 4 | `PricingSection.jsx` contains `href="https://capavate.com/#/onboarding?portal=investor"`, does NOT contain `href="https://capavate.com/onboarding"` |
| 5 | `PricingSection.jsx` contains `href="https://capavate.com/#/apply/consortium"`, does NOT contain `href="#cta-final"…Become an Ecosystem Partner` |
| 6 | `PricingSection.jsx` contains `Verified portfolio holdings`, `Co-investor visibility`, `Real-time round updates` |
| 7 | `Footer3.jsx` contains all of `/#/auth/login?portal=founder`, `/#/auth/login?portal=investor`, `#/partner/login`, `#/admin/login`, `#/apply/consortium` |
| 8 | `Header3.jsx` contains `#/auth/login?portal=investor` + `For Investors`, `#/auth/signup?portal=founder` + `For Founders`, `#/partner/login`, and mobile-menu test-ids `link-mobile-investor-login`, `link-mobile-founder-signup`, `link-mobile-partner-login` |

Implementation reads each `.jsx` as a UTF-8 string via `fs.readFileSync` and runs `toContain` / `not.toContain` / `toMatch` assertions — no JSX/React render needed.

---

## Final gate numbers

| Gate | Baseline | Post-Wave-D | Status |
|---|---|---|---|
| `sha256sum server/captableCommitStore.ts` | `5b0be7c…6b78` | `5b0be7c…6b78` | **IDENTICAL** |
| `sed -n '354,477p' \| sha256sum` | `e27651e…9ac6` | `e27651e…9ac6` | **IDENTICAL** |
| `scripts/check-math-integrity.sh` (math-critical) | 86/86 pass | **86/86 pass** | OK |
| `npx vitest run packages/cap-table-engine packages/math-fns` | 95/95 pass | **95/95 pass** | OK |
| `npx vitest run server/__tests__/captableCommit.test.ts server/__tests__/auditChainVerifier.test.ts` | 45/45 pass | **45/45 pass** | OK |
| Full vitest (`ENABLE_DEMO_SEED=1 NODE_ENV=test npx vitest run`) | 2771 pass | **2796 pass / 1 fail** (only `patch2_avi_fixes` ECONNREFUSED, explicitly allowed) | +25 new contract tests |
| Test files | 231 | **231 pass / 1 fail (allowed)** | OK |
| TypeScript errors (`tsc --noEmit`) | 629 | **629** | IDENTICAL |
| 62-gate file-count semantics | 62/62 | **62/62** (only allowed failure remains the same single file that has always failed in this environment due to lack of `:80` listener) | OK |

The 62-gate verifier in this build is the `timeout 300 npx vitest run` invocation referenced in `vitest.config.ts` line 38; the only failing file under that command both before and after Wave D is `server/__tests__/patch2_avi_fixes.test.ts` due to `ECONNREFUSED` against `127.0.0.1:80`, which is an environment artifact (no live server bound to port 80 in the sandbox), not a regression caused by this wave.

---

## Files changed in Wave D

```
client/src/components/home3compo/PricingSection.jsx
client/src/components/home3compo/AudiencesSection.jsx
client/src/components/home3compo/Footer3.jsx
client/src/components/home3compo/Header3.jsx
server/__tests__/frontendBackendContract.test.ts          (NEW)
avi_patch_v19/docs/WAVE_D_RECONCILIATION_REPORT.md        (NEW — this file)
```

No backend, no schema, no math, no cap-table-engine, no SQL migrations.

---

## Why this wave matters for future-wave hygiene

Front-end ↔ back-end drift is the single most common silent failure mode
once the math is locked: a marketing page promises something the backend
doesn't deliver (free signup vs. paywall, $70/mo vs. $840/yr, broken hash
routes), or a backend gate quietly changes (Wave B made the consortium
apply form no-auth, but the marketing CTA still pointed at the old
anchor `#cta-final`). The new contract test file pins these promises in
place. A future wave that changes either side without updating the other
will be blocked by `frontendBackendContract.test.ts` — making the drift
detectable at PR time instead of in production.
