# AVI_DEPLOY_PACKAGE_REPORT — Capavate v23.2

**Goal:** make deployment Avi-proof. If he follows `DEPLOY_FOR_AVI.md` and runs
`scripts/install_avi.sh`, the deploy succeeds. If anything goes wrong,
`scripts/install_verifier.sh` tells him exactly what.

**Math-sacred integrity:** 18 files SHA-checked before & after this patch — **IDENTICAL**.
No code touched in `server/`, `client/src/`, `shared/`, or `packages/`.

---

## The 5 deliverables

### 1. `scripts/install_verifier.sh`  — the foolproof verifier
> 8 sections: build artifacts → env vars → DB connectivity → migrations
> applied → server starts → critical endpoints → demo-seed availability →
> colored summary with copy-paste fixes. Bash strict mode, ANSI colors,
> macOS+Linux compatible. Auto-handles CRLF `.env` files (with a clear warning).
> Hits public `/api/healthz` for liveness, accepts 401 on auth-gated routes,
> spawns and cleans up its own `npm start`. Exit 0 iff PASS, 1 if any FAIL.

### 2. `DEPLOY_FOR_AVI.md` (repo root) — single-source-of-truth playbook
> 7 parts: Quick start → what `install_avi.sh` does → manual install
> (with expected output AND failure symptoms+fixes for each step) →
> full env-var reference table with "what each var does and why" →
> 9-step post-deploy verification → common errors + fixes → rollback
> procedure with an emphatic **BACKUP THE DB BEFORE MIGRATING** banner.

### 3. `scripts/install_avi.sh` — one-shot master install
> `set -euo pipefail`. Verifies the zip, installs deps, prepares `.env`,
> runs migrations (with friendly diagnostics for every failure mode),
> seeds demo (dev only — never in prod), builds, then calls the verifier.
> Idempotent — safe to re-run.

### 4. `.env.example` (repo root) — every env var with sensible dev defaults
> Replaces the legacy v11-era example. Now includes the new required
> variables: `DISABLE_DEV_BYPASS`, `ALLOW_DEV_BYPASS`, `COLLECTIVE_ENABLED`,
> `CONSORTIUM_ENABLED`, `PAYMENT_GATEWAY_DEFAULT=airwallex`, all
> `AIRWALLEX_*` and `STRIPE_COLLECTIVE_*_PRICE_ID` keys, `SENTRY_DSN`,
> `GIT_SHA`. Each block carries a one-line comment explaining what it
> does. `cp .env.example .env` then fill in real values.

### 5. Verifier test run — proves the verifier works on the live tree
> Ran `bash scripts/install_verifier.sh` against this v23.1 tree.
> Iterations discovered AND fixed:
> - Auth-gated `/api/health` → switched liveness probe to `/api/healthz`
>   (public).
> - CRLF in `.env` from a Windows editor caused `PORT=5000\r` →
>   "Malformed URL" inside the verifier; now auto-stripped on source +
>   reported as a WARN.
> - Race between server bind and route table → log-based "serving on port"
>   detection plus 5-probe retry confirmation.
>
> Final run: **18 PASS, 12 WARN (all expected dev-mode warnings), 0 FAIL,
> exit code 0**. Captured at `avi_patch_v19/docs/VERIFIER_TEST_RUN.log`.

---

## File map

| Deliverable | Path in tree | Mirror copy |
|---|---|---|
| Install verifier | `scripts/install_verifier.sh` | `avi_patch_v19/scripts/install_verifier.sh` |
| Master installer | `scripts/install_avi.sh` | `avi_patch_v19/scripts/install_avi.sh` |
| Deploy playbook | `DEPLOY_FOR_AVI.md` | `avi_patch_v19/root/DEPLOY_FOR_AVI.md` |
| `.env.example` | `.env.example` | `avi_patch_v19/root/dot_env_example.txt` |
| Verifier test run | n/a (transient) | `avi_patch_v19/docs/VERIFIER_TEST_RUN.log` |
| Math-sacred SHAs | n/a | `avi_patch_v19/docs/MATH_SACRED_SHAS.txt` |

---

## What Avi must do — 7-line checklist

1. Unzip `capavate_v23.2_FINAL_24_may.zip` and `cd` into `capavate_app/`.
2. `cp .env.example .env` then fill in real values (Stripe, AirWallex, Sentry, DB).
3. Run `bash scripts/install_avi.sh` — it installs, migrates, seeds (dev only), builds, verifies.
4. If it stops with a FAIL, read the line ABOVE the error — that's the fix; apply it and re-run.
5. `npm start` (or your process manager) and point your reverse proxy at the running server.
6. Run `bash scripts/install_verifier.sh` once on the live host — it MUST exit 0.
7. Walk through the 9 browser checks in `DEPLOY_FOR_AVI.md` Part 5. **If any fail, do not call the deploy done.**

---

## Math-sacred SHA verification

Before any work in this patch:
```
$ sha256sum packages/cap-table-engine/test/{golden-master,property,ledger,reconcile}/**/*.ts \
            packages/math-fns/test/reconcile.test.ts \
            server/__tests__/captableCommit.test.ts \
  | wc -l
18
```
After all deliverables written:
```
$ diff /tmp/math_sacred_before.txt /tmp/math_sacred_after.txt
$ echo $?
0   # IDENTICAL
```
Full SHA list at `avi_patch_v19/docs/MATH_SACRED_SHAS.txt` (18 files,
all hashes preserved). No code modified outside `scripts/`, `docs/`,
and root-level `.md` / `.sh` / `.env.example`.
