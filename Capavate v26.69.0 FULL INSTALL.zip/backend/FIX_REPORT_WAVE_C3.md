# FIX REPORT — Wave C3 (Shadie QA 2a + 7a)

Founder → Rounds. Non-sacred files only. **No migration** (the invitation `note`
column already exists and persists). All gates green (bottom).

## 2a — Personalize + EXACT-HTML preview of the invitation email
Shadie wanted the founder to (a) add a personal note to the invitation, and
(b) SEE the actual email before it goes out (delicate — you're inviting
investors). Per Ozan: admin templates untouched; personalization is ONLY the
message text (never terms/duration/round name); available in BOTH invite entry
points; live preview with exact HTML; note persists.

- **Single source of truth for the email:** extracted `renderInvitationEmail()`
  (exported) in `server/roundInvitationsStore.ts`. Both the real send
  (`createInvitation`) AND the preview render through it, so **what the founder
  previews == what the investor receives** (byte-identical). All interpolated
  values are HTML-escaped (Lane A NH4).
- **Preview endpoints (READ-ONLY — no token, no invite, no email):**
  - `POST /api/rounds/:id/invitations/preview` (round-detail invite) — founder-
    owns-round gated; company/round names resolved server-side (NOT client-
    overridable). Only the personal note + investor name come from the client.
  - `POST /api/companies/:companyId/invitation-preview` (Step-4, pre-create,
    where no round id exists yet) — company-owner gated; round name from the
    wizard draft.
  The preview link is a clearly-labelled placeholder; the real secure token is
  minted only at send time.
- **Persistence:** the note is stored on the invitation via the EXISTING `note`
  column (already in the INSERT + hydrate + publicView) — no migration needed.
- **Client (both entry points):**
  - `client/src/pages/founder/RoundDetail.tsx` (round-detail "Invite investor"):
    the existing Personal-note field now has a **"Preview email"** button that
    renders the exact server HTML; a helper line states the note is added to the
    standard email and the terms/name/expiry are unchanged.
  - `client/src/pages/founder/RoundNew.tsx` (Step-4 "Add a non-Capavate
    investor" dialog): new optional **Personal note** field + **Preview email**;
    the note is carried onto the selected shareholder → `initial-shareholders`
    PATCH → injected into that investor's invitation email (via the C2 issuance
    path). Only the note is editable; terms/duration/name are fixed.
- The `note` now flows through the Step-4 issuance chain
  (`server/lib/roundInitialShareholdersStore.ts` passes `note` to
  `createInvitation`).

## 7a — Round names unique per company (auto-suggested, editable)
Two rounds named "MVP" for one company confuse investors. Per Ozan: unique per
company across all rounds; on collision auto-suggest a unique, EDITABLE name.

- **Scope: PER COMPANY, not platform-wide** (confirmed by Ozan). Two different
  companies may each have a round named "Seed"/"MVP"; only within one company
  must names differ. `roundNameExistsForCompany` only inspects rounds of the
  SAME companyId. Verified by a dedicated cross-company test.
- **Server fail-closed (authoritative):** `server/roundsStore.ts` `createRound`
  rejects a duplicate name for the company (case-insensitive) with
  `ROUND_NAME_DUPLICATE`, and an empty name with `ROUND_NAME_REQUIRED`. New
  exported helpers `roundNameExistsForCompany()` + `suggestUniqueRoundName()`
  (suffixes " (2)", " (3)", …).
- **Route:** `POST /api/rounds` maps `ROUND_NAME_DUPLICATE` → 409 (with a
  `suggestedName`) and `ROUND_NAME_REQUIRED` → 400. New read-only helper
  `GET /api/rounds/name-availability` (owner-gated) returns `{ available,
  suggestedName }`.
- **Client:** `RoundNew.tsx` checks availability on blur of the round-name field
  and, if taken, auto-fills the editable unique suggestion with an amber hint;
  the create `onError` also applies the server's suggestion as a race backstop.

## Files
- `server/roundInvitationsStore.ts` (shared `renderInvitationEmail`; send uses it)
- `server/roundsStore.ts` (7a uniqueness guard + suggest helpers)
- `server/routes.ts` (2 preview endpoints + name-availability + 409/400 mapping)
- `server/lib/roundInitialShareholdersStore.ts` (carry `note` into issuance)
- `client/src/pages/founder/RoundDetail.tsx` (preview in round-detail invite)
- `client/src/pages/founder/RoundNew.tsx` (Step-4 note + preview; 7a name UX)
- **New** `server/__tests__/waveC3_invite_preview_and_round_name.test.ts` — 6
  tests (preview renders + escapes note; note omitted when blank; duplicate name
  rejected case-insensitive; suggestion is unique + creatable + advances;
  empty-name rejected; unique name unchanged; per-company scope — two companies
  may reuse a name while one company cannot). 7 tests total.

## Gates (end of C3)
| Gate | Result |
|---|---|
| Sacred files | **40/40** byte-identical |
| Money core sha16 | **01cd36130ee1c0cb** (unchanged) |
| tsc `--noEmit` | **598** (net-new **0**) |
| Guard | **exit 0** — **929** routes / 194 / 92 (+3 informational: 2 preview + name-availability) |
| Build | **OK** |
| Migrations | **none** (note column already exists) |
| Payments / Airwallex | untouched |
| Tests | C3 6/6; regression C1/C2 + round create/persist/detail/price + invitation flow (74 passed across suites) |

## Security / safety
- Preview endpoints are READ-ONLY (no token/invite/email) and ownership-gated;
  company/round facts are server-resolved, not client-overridable.
- The preview HTML is server-rendered with every interpolated value escaped;
  the client renders it via `dangerouslySetInnerHTML` of server-controlled,
  escaped markup only.
- 7a is fail-closed server-side, so a duplicate name can't be persisted even via
  a direct API call; the client UX is a convenience on top.

## Note
Admin email-template area is intentionally untouched (Ozan). The
"every investor must register before soft-circling" rule is unchanged by C3.
