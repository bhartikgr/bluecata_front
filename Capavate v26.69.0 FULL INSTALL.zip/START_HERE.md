# Avinay: Capavate v26.69.0 full installation

> This runbook ships inside the installer, so it never states the installer's own SHA-256, entry counts or rehearsal results. Take the SHA-256 from the outer `SHA256SUMS.txt`, as shown below.
>
> This runbook is **cumulative and self-contained**. It replaces the v26.68.0 `START_HERE.md` at both the outer-package and installer root. Every v26.68.0, v26.67.0, v26.66.0 and v26.65.0 step is carried forward here, either unchanged or with only its release identity updated, so no earlier runbook is needed. The v26.63.0 security runbooks still ship byte-identical inside the installer, at `backend/SECURITY_RECOVERY_RUNBOOK.md` (`569d79e2…`) and `backend/SECURITY_WEB_BOUNDARIES_RUNBOOK.md` (`f56601d5…`).

Use this handover with the following files from the outer package:
- the full installer;
- the checksum file;
- the standalone verifier;
- `readiness-census.py`;
- `FINAL_RELEASE_RECEIPT.md`.

`ENGINEERING_AND_VERIFICATION.md` records the scope, the 92 changed source paths (and 58 test files), the tests that were actually run and every retained named failure.

**Production deployment has not been performed.** This full cumulative package is for controlled staging and handover. It is not whole-platform or end-to-end UI approval. Local source and compiled evidence does not establish live acceptance. The private source and compiled test runs for this release are summarized in `ENGINEERING_AND_VERIFICATION.md`; they used private synthetic databases only. No browser run was made for v26.69.0.

## Scope and inherited cutover

This is a cumulative full release from the v26.68.0 installer (the live release at build time, source `7edffa75…`). v26.69.0 is the **Pricing & Payments** release built from the owner's annotated engineering report and rulings R1–R14 (`ENGINEERING_AND_VERIFICATION.md` lists every changed path, the tests actually run, the three independent review rounds and every retained named failure). It changes server, client and shared source across the admin Pricing & Payments console, the Collective membership and application-fee flow, the Consortium Partner billing flow, discount codes, referral earnings and the founder billing readers. Nothing outside those money paths was changed on purpose; sacred files are untouched (48/48).

What v26.69.0 does, in plain terms:

- **Admin console (`/admin/fees`)** — one place for every price, fee, code and ledger. New: a *Start here* readiness panel (computed from live data: unpriced tiers, pending data operations, legacy records, open questions), a *Company standing* view (every company is Capavate-annual, comped or unsubscribed — ruling R5; a legacy `subscriptions` row is shown as a record, never as the state), *Collective member categories* (Individual investor and Fund / investment bank as registry rows; the $840/yr Individual price is published by the owner as a live package per category — R3), *Discount codes* with max uses, per-company assignment, reservation/redemption ledger and release action (R10/R11), *Record refund* (reason + Airwallex reference required; record-only, no money moves from the platform — R7), the *$70.00 per month, billed annually* display switch (one DB flag; signed-in pages read `/api/price-display-policy`, public pages get it through `/api/pricing-public`), and the Promotions tab in a computed "awaiting owner clarification" state (R12: nothing recorded there changes a price; approving is refused).
- **Collective** — the application fee is a real charge raised at approval (R4): approval creates the charge and hosted-checkout intent on an idempotency key; the member is *pending payment* until the gateway confirms; an attempt failure keeps the same payment open ("you will not be charged twice"); a failed row is reconciled with the provider before any new key is minted. Member Subscribe is disabled (with the reason shown) until a live package with a price exists for the member's category; none is published by this release, pending the owner's answer on whether the application fee is the first-year dues.
- **Consortium Partners** — `/consortium/pricing` is signed-in and "by approval only" (R9); Founding Member is full access at zero cost with an open-ended exemption grant the admin can move to another tier (R2/R8); the 17 test "catalyst" partners move to nexus (R1); 23 unbacked invoices are voided and 7 test charges marked, guarded by the owner's $3,360.00 real total (R6); invoices show full price and discount, never partner fees (R13); partner referral approval delivery (attribution, notification, bridge event, invite) is a resumable, idempotent record — a failed step is reported and retried, never silently dropped or repeated.
- **Founder billing** — the monthly-equivalent figure is display-only and flag-controlled; the store derives no monthly price from an annual one; legacy founder charge endpoints answer 410 and write nothing.

Everything delivered in v26.68.0 (strict-close lapse audit after commit, test repairs), v26.67.0 (membership setup at approval, annual arrangement, partner dashboard labels, referral dates, public referral preview), v26.66.0 (categorized console, refusal guidance) and v26.65.0 (received amounts, strict close, carry-forward, round Q&A) is preserved. The v26.63.0 security runbooks still ship byte-identical inside the installer (`backend/SECURITY_RECOVERY_RUNBOOK.md`, `backend/SECURITY_WEB_BOUNDARIES_RUNBOOK.md`).

v26.69.0 **adds three migrations (0242–0244, additive only) and three one-time data operations that run at first boot** (see *Backup, migration and cutover*). It adds no dependency. It changes no live price except through the recorded data operations above; every other price, exemption or offer remains an owner decision entered through the console after installation.

No production installation was performed or verified by this task. Check the actual host release before choosing the cutover path: version, source/build identity and migration state. Do not assume any particular installed version. Depending on what the host is running, this package also carries the following.

- **If the host is older than v26.68.0:** the v26.68.0 strict-close correction.
- **If the host is older than v26.67.0:** the v26.67.0 partner self-service controls.
- **If the host is older than v26.66.0:** the v26.66.0 console and refusal guidance.
- **If the host is older than v26.65.0:** the v26.65.0 changes, and the strict close and storage readiness census below, which is required.
- **If the host is older than v26.64.0:** the v26.64.0 finance, currency and Q&A protections.
- **If the host is older than v26.63.0:** the v26.63.0 security upgrade, **which remains mandatory** (migration 0241, coordinated worker cutover with users re-authenticating, MFA recovery controls, trusted-origin configuration, the two security runbooks).

This is not a file-only patch.

## Post-install acceptance for v26.69.0 (controlled records only — read before the inherited acceptance list)

Do these first, in order, on the installed host. None of them creates a price, a charge or an invoice.

1. **Identity and health.** `GET /healthz` must show the new version and **no** `data_op_failed:` code. `backend/INSTALL_RECEIPT.json` → `sourceCommit` equals `buildReceipt.gitHead`.
2. **Data operations recorded.** In the console's *Start here → Price Source Map* tab (`/admin/fees?tab=source-map`), the readiness panel at the top lists the three data operations as *applied* with their counts (17 contacts moved or already nexus; grants created; 23 voided / 7 marked). If one shows *failed*, stop and report — nothing partial was written.
3. **Company standing (R5).** `/admin/fees?tab=capavate-pricing` (Capavate Pricing & Gateway) → the *Company standing* card lists every company as Capavate annual / comped / unsubscribed; a legacy record, where one exists, is labelled as a record. Filters and badges on `/admin/companies` agree.
4. **Member categories (R3).** `/admin/fees?tab=collective-subscriptions` shows the two category rows (Individual investor; Fund / investment bank), each with the empty state "No live package … members in this category cannot subscribe until one is published". The Collective membership page shows Subscribe disabled with the reason. **No package is published by this release** — the owner publishes the $840/yr Individual package when ready.
5. **Application fee (R4) — read only.** Open an existing Collective application: the fee state reads *Not raised* / *Awaiting payment* / *Paid* / *Payment failed* / *Waived* truthfully. Do **not** approve a real application as a test.
6. **Discount codes (R10/R11).** `/admin/fees?tab=discount-codes` lists every code with Max redemptions / Used / Reserved / Remaining (reservations in progress count against capacity); the banner names the connected checkout ("Capavate Annual checkout").
7. **Record refund (R7).** `/admin/fees?tab=capavate-pricing` → Invoices → *Record refund* on a paid invoice requires a reason and an Airwallex reference before the button enables; the Ledger & Invoices quick action (`?tab=ledger-invoices`) asks for the same two values. Do not record a refund as a test.
8. **Positioning switch.** `/admin/fees?tab=fee-schedules` → *Show annual prices as “per month, billed annually”*: toggling changes the founder plan, Collective and partner price displays together; the charged annual amount shown next to it never changes.
9. **Promotions (R12).** `/admin/fees?tab=tier-prices` (Partner Tier Prices & Billing Ops) shows the amber "awaiting owner clarification" notice at the top; the Promotions moderation card inside the billing operations (also at `/admin/partner-billing-ops` → Promotions) shows the computed count of approved promotions on record; *Approve (R12)* is disabled; Reject/Changes work.
10. **Consortium pricing (R9).** `/consortium/pricing` signed out redirects to sign-in; signed in it shows "by approval only" and no public price.
11. **Founder billing.** The founder plan page shows "$70.00 per month, billed annually ($840.00/yr)" while the switch is on, and "$840.00 per year" when off; no monthly subscription can be started.
12. **Partner referral queue (API).** `GET /api/admin/partner-referrals` (admin session) returns pending items plus any `enrolment_failed` / `delivery_incomplete` rows; there must be none of the latter two after a clean first boot.

## Rollback for v26.69.0

Keep the previous matched release and the backup. Code rollback is the established procedure (previous release + its database backup). The three data operations are reversible from the admin console without a database restore: an invoice voided by `pp2669-03` is restored with `POST /api/admin/invoices/:id/restore` (Capavate Pricing & Gateway → Invoices → *Restore*, reason required); a test-charge mark is removed with `DELETE /api/admin/invoices/:id/disposition`; a partner moved by `pp2669-01` is moved back on its partner record (the previous tier is in the admin audit row); a grant created by `pp2669-02` is revoked on the partner's membership card. Migrations 0242–0244 are additive and need no down-migration for a code rollback.

## Verify and stage

Extract the outer package into a new release directory. From that **outer package folder**, run:

```sh
sha256sum --check SHA256SUMS.txt
expected="$(awk '$2=="capavate_v26.69.0_FULL_INSTALL.zip" {print $1}' SHA256SUMS.txt)"
test "${#expected}" -eq 64
python3 verify-bundle.py capavate_v26.69.0_FULL_INSTALL.zip "$expected"
```

Release identity:
- **Installer filename and SHA:** `capavate_v26.69.0_FULL_INSTALL.zip`. Its SHA-256 is the matching line in the outer `SHA256SUMS.txt` (the `expected` value above), and the outer `FINAL_RELEASE_RECEIPT.md` repeats it.
- **Source/build commit:** read `backend/INSTALL_RECEIPT.json` → `sourceCommit` and `buildReceipt.gitHead`. They must be equal: `5da26bce63ef9845f2d287e438bc8bd8c282f983`. The build receipt is embedded in `INSTALL_RECEIPT.json` → `buildReceipt` (output hashes of `dist/index.cjs`, `server/public/index.html` and its entry assets).
- **Extracted-installation rehearsal:** this runbook does not state its result. It is recorded only in `records/EXTRACTED_INSTALL_VERIFICATION.md` inside the outer `verification-evidence.zip`, and summarized in the outer `FINAL_RELEASE_RECEIPT.md`. Its method is described only there, if the outer evidence includes one; this release's rehearsal ran `npm ci --include=dev` on the extracted tree in the build sandbox (recorded there), and the host install above still runs `npm ci`.
- **Baseline:** v26.68.0 installer `b8f690a836c5f5e801224b862d87b49066fcad86055411f0142adeefd651cddf`, built from source `7edffa752d495e57ceea2cee8cb50fb4dbdbcd75` (the live release at the time of this build).

Before cutover, compare against the actual host release and any local hotfixes. Do not overwrite a newer or independently modified deployment without reconciliation.

Then change into the extracted `backend/` directory and run:

```sh
node scripts/verify-install.mjs
npm ci --include=dev --no-audit --no-fund
node scripts/verify-install.mjs --runtime
SPEC_ROOT="$PWD/spec" npm run sacred
```

The protected check must report:

- 48/48 entries;
- 1 extra frozen identity;
- **4** exact reviewed exceptions.

Never regenerate the lockfile, force-update dependencies, copy an old `node_modules` or override an integrity failure. The dependency set is unchanged from v26.68.0 apart from the release version field.

The served frontend must be the `dist/public` and `server/public` files whose hashes the installer manifest records; `node scripts/verify-install.mjs` checks them. Entry assets: `index-DcE2qXR4.js` (`137e6174…`) with `index-B2HY1bnY.css` (`e612ffdd…`). The compiled server `dist/index.cjs` is `f62a4463…`, changed in this release. The v26.68.0 entry was `index-16wQPUKG.js`. Never mix these assets with an older backend.

## Read-only host readiness

Find the actual database and journal mode from the secure host configuration. Never guess a path, and never open it in create mode.

Confirm that the database runs in WAL mode and that every worker uses the same database.

Run the inherited SQL census on an isolated, consistent backup, using a read-only connection. Then run the census tool in the next subsection. Both are censuses, not remediation. v26.69.0 adds three additive migrations (0242–0244) but no change to the tables these censuses read, so both censuses are unchanged from v26.65.0 and still apply.

### Inherited v26.64 finance census (unchanged)

```sql
PRAGMA journal_mode;

SELECT COUNT(*) AS unbound_funded_queue_rows
FROM funded_queue q LEFT JOIN rounds r ON r.id = q.round_id
WHERE r.id IS NULL OR r.deleted_at IS NOT NULL
   OR COALESCE(TRIM(r.company_id), '') = '' OR q.company_id <> r.company_id
   OR COALESCE(TRIM(q.investor_id), '') = '';

SELECT COUNT(*) AS conflicting_stated_queue_currencies
FROM funded_queue q JOIN rounds r ON r.id = q.round_id
WHERE r.deleted_at IS NULL
  AND COALESCE(TRIM(r.currency), '') <> '' AND COALESCE(TRIM(q.currency), '') <> ''
  AND UPPER(TRIM(q.currency)) <> UPPER(TRIM(r.currency));

SELECT COUNT(*) AS already_committed_invitations_still_queued
FROM funded_queue q
WHERE EXISTS (SELECT 1 FROM captable_commits c
              WHERE c.invitation_id = q.invitation_id AND c.deleted_at IS NULL);
```

### Strict close and storage readiness census (v26.65.0, unchanged; required before production)

A strict close validates **every** live carry-forward audit row before it filters by company. One malformed row therefore makes close return `503 CLOSE_UNAVAILABLE` for **every company**. A malformed freeze row blocks the close of its own round.

**Requirements:** `python3` and the installed production `node` must both be on `PATH`. The census uses Node's own `JSON.parse`/`Date.parse` semantics for the row-shape checks.

The reviewed tool `readiness-census.py` (`43f438d563a820db25390125844b1f6ad94441c63f7d1ee5d15e0d99e03c0f67`) is byte-identical to v26.65.0. Its hash is in the outer `SHA256SUMS.txt`, which you checked above.

Run it read-only against the actual database (or an isolated consistent backup), with its existing WAL context intact: keep the `-wal`/`-shm` files beside the database, and do not copy the main file alone. The helper is in the **outer package folder**, not in `backend/`. Run it from there, or give its absolute path if your shell is still inside `backend/`:

```sh
cd /path/to/extracted-outer-package   # the folder containing readiness-census.py
python3 readiness-census.py /actual/database.sqlite
echo "census exit: $?"
# or, from anywhere:
python3 /path/to/extracted-outer-package/readiness-census.py /actual/database.sqlite
```

The census opens the database in SQLite `mode=ro` with `query_only` and performs no DDL, repair, seeding or writes.

It checks:

- that the required tables and columns exist and are readable (companies, rounds, securities, commits, shareholder records, profile, conversion, privacy, carry audit, freezes and Q&A storage);
- the shape of live carry-forward audit rows;
- the shape of freeze rows;
- the shape of live Q&A rows.

| Table | A row is valid when |
|---|---|
| `kv_carryForwardAuditLog` | `id` is non-empty; `payload_json` is a JSON object whose `id` equals the row `id`; `companyId` is non-empty; `entryHash` is 64 lowercase hex characters; `timestamp` is strict ISO-8601 |
| `round_chain_head_freezes` | `round_id` and `company_id` are non-empty; `chain_head` is `CARRY_FORWARD_GENESIS` or 64 lowercase hex characters; `frozen_at` is strict ISO-8601 |

**Exit codes:**

- **0:** the census passed. Continue with the remaining required checks; passing is not acceptance.
- **2:** STOP. Do not cut over. Report the JSON output, which lists missing tables, storage errors and invalid-row counts.
  - Do not create tables by hand.
  - Do not delete, rewrite or manually backfill audit, freeze, Q&A or financial history to make the census pass.
  - Remediation requires an owner-approved plan.
- **Any other exit or a Python/Node error:** STOP and report it. This is not a pass.

**Limits:** the census validates prerequisite storage and legacy row shape only. It does not check:

- securities or terms economics;
- that each freeze belongs to its round;
- the integrity of the audit chain;
- deleted-row Q&A replay outcomes.

**Status:**

- For v26.65.0, Main ran the census's 15 synthetic tests: 15/15 passed, with the database hash unchanged.
- Main also ran it read-only on a closed private database: it passed with the database hash unchanged.
- The tool was not changed or re-run for v26.66.0, v26.67.0, v26.68.0 or v26.69.0.
- The census on the production host is **still required** and has not been run.

### Other strict conditions (inherited)

The following make the affected reads strictly unavailable:

- invalid securities or terms, and live rounds with non-text currency values: they make carry unavailable for the company;
- uninitialized required KV tables: they make the affected reads unavailable;
- a failure of the privacy storage initializer at start.

None of these is an empty success. Do not repair them silently.

## Backup, migration and cutover

1. Rehearse on a consistent backup, with external mail, payments and bridge dispatch disabled.
2. Preserve:
   - the environment;
   - uploads and storage;
   - the process-manager configuration;
   - the database and WAL backup;
   - the previous matched release.
3. Stop **all** workers, then run:

   ```sh
   npm run db:migrate
   ```

   **Three new migrations are included** — `0242_pp2669_platform_ledgers.sql`, `0243_pp2669_collective_categories_and_fee.sql`, `0244_pp2669_discount_redemptions_and_referral_closure.sql` — additive DDL only (new tables, new nullable/defaulted columns, indexes), with byte-identical mirrors under `server/db/migrations/`. The inventory is 216 SQL files; it still includes 0241, and `0040_perf_indexes` remains PENDING on a fresh database exactly as before. Check the full inventory and its recorded deferrals, not just the highest number.
   
   **Data operations at first boot (v26.69.0).** After the migrations, the first start of v26.69.0 runs three one-time, idempotent data operations and records each in `data_ops_applied` (`pp2669-01` catalyst→nexus for 17 named partner contacts; `pp2669-02` exemption grants for partners already on a zero annual override; `pp2669-03` disposition of 23 unbacked invoices as void and 7 as test charges, guarded by the owner's $3,360.00 non-test total). A guard or manifest-drift failure writes nothing, marks the op failed, and `/healthz` shows `data_op_failed:<id>` until it is resolved and the server restarted. Check `/healthz` after the first boot and stop if any `data_op_failed:` code is present.
4. Start all workers on the same release and database. Through the secure host configuration, set:
   - `APP_VERSION=26.69.0`;
   - `BUILD_SHA` to exactly `INSTALL_RECEIPT.json` → `buildReceipt.gitHead` (the same commit as above).

   If a metadata-only packaging commit differs, use the receipt's build commit, not an assumed checkout HEAD. Keep the established launch mode.
5. Never run mixed authentication versions. Users crossing the pre-26.63 boundary must sign in again (see `backend/SECURITY_RECOVERY_RUNBOOK.md`).
6. Keep the production demo identity bypass and reset-link debugging disabled.
7. An unreadable security store is never a reason to disable MFA or to recreate enrolment data.
8. Nginx HTML, error and asset headers remain host responsibilities (`backend/SECURITY_WEB_BOUNDARIES_RUNBOOK.md`). Adapt the supplied configuration, run `nginx -t`, then use the controlled reload. The existing Content Security Policy blocks the Google Fonts stylesheet, so the browser renders fallback fonts. Do not weaken the policy to change this.

## Post-install acceptance (controlled test records only)

- **Identity:** version, commit, migration inventory, health, physical dependencies and served asset hashes all match the receipt.
- **Strict close lapse audit (v26.68.0):** only on a controlled, non-production round with pending commitments. A successful strict close publishes its lapse entries to the audit mirror and health counter after the durable close, and durable `audit_log` rows match each published entry by id and hash. A refused or rolled-back close leaves no lapse entry in the mirror and does not advance the audit-success count. The rolled-back path was exercised only in private tests with injected faults; do not induce a write failure, close a real round or lapse a real commitment to check it.
- **Membership setup at approval (v26.67.0):** only on a controlled, non-production application, or on a genuine application an authorized admin has decided to approve.
  - with the option unticked, approval behaves as in v26.66.0;
  - with it ticked, Approve stays disabled until a current preview exists, and changing a pricing field cancels the preview;
  - Individual free exemption previews "Explicit free exemption: no annual invoice will be raised."; founding member alone is not free;
  - a refused approval creates no partner, contact, tier, arrangement or invoice.
  Never approve, set a price, set a zero price or exemption, or raise an invoice merely as a test.
- **Annual arrangement (v26.67.0):** on a controlled partner record, review → confirm saves the arrangement with a reason and creates no charge, invoice or subscription; a concurrent change shows "Reload current value" and saves nothing; a monthly save leaves the annual price untouched.
- **Partner dashboard (v26.67.0):** "Configured future price" is never presented as the billed amount; an active subscription shows its persisted amount separately.
- **Public referral preview (v26.67.0):** on the signup page, checking a controlled code works without a session; other methods and paths under the same prefix still return 401 without a session.
- **Referral dates (v26.67.0):** on a controlled code, a date outside the inclusive UTC window refuses new registrations by code, approved email and partner client; accepted referrals keep their benefit; the cap, fee and benefit rules are unchanged. Do not create a real offer, discount, fee or campaign as a test.
- **Pricing console (v26.66.0):**
  - all 19 sections in six groups are present once and reachable;
  - the current section is highlighted;
  - `?tab=` deep links, invalid-key fallback, the 13 legacy paths and Back/Forward all work;
  - desktop and mobile layout work;
  - the nested partner and pricing tools are reachable.

  Opening sections must not trigger a save, approval or charge.
- **Refusal guidance (v26.66.0):**
  - The guidance is client-local. It appears only in the browser session that received an approval refusal, and **it is not persisted**. Reloading the page or opening an earlier refused application does not show it again.
  - Do **not** expect it on an already-refused record, and do not claim it was verified that way.
  - Verify it only on a future genuine, authorized business approval that is actually refused, or against a controlled non-production mock.
  - Durable refusal records remain the existing audit log.
  - Never retry an approval, set a price, set a zero price or exemption, or raise an invoice as a test.
- **Preservation (v26.66.0):** check that these are unchanged:
  - the existing price editors, including the Consortium Promotions projection writer;
  - fee schedules, invoices and payments;
  - the diagnostic tools.

  The End schedule and Refund controls depend on existing rows, so check them only where such rows exist.
- **Received amount (#3, v26.65.0):**
  - the original indication is preserved;
  - a differing amount is recorded in the round's fixed currency, and the queue and audit read back correctly;
  - commit goes through the existing atomic batch;
  - replay neither resets the amount nor recreates a committed row.
- **Close (#7, v26.65.0):**
  - a round is never shown closed before durable confirmation;
  - refusal and unknown outcomes create no local seal;
  - pending intents lapse, while confirmed, wired and committed records are preserved;
  - the closed state survives restart and is visible to a second worker;
  - the terminal banner shows "Recorded close date: …" with the note that this can be a scheduled date and that the time the close was performed is not shown. It must never present a future planned date as the time of the close.
  - **Known limit:** the close panel's local preview gate requires the reconciliation, the founder acknowledgement and the admin acknowledgement. The final v26.65 private run stopped at genuine browser-preview divergence before sign-offs, so UI close submission remains unaccepted. Those preview inputs are not the canonical company ledger. Report this; do not bypass it. The strict server close can be verified through its API on a controlled round.
- **Carry (#5, v26.65.0):**
  - a genuine committed prior-round instrument appears on the next round from database inputs, including on another worker;
  - unknown and conflicting facts are explicit;
  - use a legitimately entitled company for the paid wizard walkthrough;
  - decisions and projections are never labelled executed conversions. Converted-instrument exclusion is **OPEN**.
- **Q&A (#10, v26.65.0):**
  - a saved question is visible to the founder;
  - a private reply reaches only the intended investor;
  - the question is visible after restart and on a second worker;
  - a same-key retry does not duplicate it;
  - "saved" is not a read or delivery receipt;
  - the inherited cold-load DM outage display remains a known failure: a 503 can leave "Select a conversation" instead of the error. Do not treat that as an empty successful thread.
- **Preservation (all):** recheck:
  - login and role/company switching;
  - agreement and accreditation gates, and holds;
  - the existing financial effects;
  - the privacy settings;
  - partner, admin and Wish List access.

Do not create real commitments, send investor invitations or send real messages as a test.

## Rollback and retained limits

Keep the previous matched release and the backup. If acceptance fails, stop the new workers and follow the established rollback procedure. Never restore an old database over newer business writes without reconciling them.

The retained regression failures are listed file by file in `REGRESSION_CLASSIFICATION.md` (outer package) and summarized in `ENGINEERING_AND_VERIFICATION.md`: 165 test files fail identically on the untouched v26.68.0 baseline and on this release; 6 failures new to this release were resolved before packaging; 2 baseline failures were fixed. The 21 named v26.66–v26.68 failures are a subset of the 165. None was weakened, skipped or re-baselined.

Also retained:

- **From v26.65.0:**
  - the inherited gaps in close-snapshot holder metadata;
  - the legacy (non-strict) close function, which was not changed; the strict close no longer publishes its lapse entries before the outer commit (v26.68.0);
  - the separate close-route families;
  - earlier out-of-scope items (#6, #9).
- **From v26.66.0:**
  - the missing Catalyst annual price, which is an owner decision.
- **v26.69.0:**
  - every Pricing & Payments change was verified in private source, compiled and jsdom tests and a fresh-database boot; none has run on a production host;
  - Promotions (R12), the Collective membership package price (R3/Q3), the Billing Metrics headline, the refund amount default and the 7-day reservation abandonment window are owner decisions recorded in `ASSUMPTIONS_AND_DELTA.md`.
- **v26.68.0:**
  - the strict-close correction was verified only in private source and compiled tests; it has not been run on a production host;
  - P0.3 and P0.4 (canonical preview and converted-instrument exclusion) are not addressed by this release.
- **v26.67.0:**
  - this task has not created or changed live account or offer values; new prices, exemptions and offers are owner decisions entered after installation;
  - the v26.66.0 limit "no annual-exemption editor for new applicants" is addressed by the membership setup above, but only for applications approved after installation.

Stop and report any of the following:

- an identity mismatch;
- a failed census (exit 2);
- unavailable financial state;
- an unexpected workflow result.

Never weaken assertions, broaden gate exceptions or use demo data to proceed.

## Admin guide after installation (inherited unchanged from v26.67.0)

**Status:** these controls were introduced in v26.67.0 (commit `ba6df55ccc44ab996f2d764e039d3b49f676a8bc`) and are unchanged in this release's source (`5da26bce63ef9845f2d287e438bc8bd8c282f983`); the v26.68.0 source was `7edffa752d495e57ceea2cee8cb50fb4dbdbcd75`. They are not live and not deployed. They require this installation (or the v26.67 installation); existing features are preserved. Test and build results are reported in the release receipt, not here.

**Live values.** This task has not created or changed live account or offer values; existing settings are preserved. Application and offer writes during QA were private synthetic fixtures only. Every value below is chosen by an authorized admin in the UI after installation.

### Approve Agile as a free founding member

1. Open **Admin → Consortium applications** (`/admin/consortium-applications`) and open Agile's application. It must be submitted or under review.
2. Under **Membership setup at approval**, tick **Choose a membership tier and annual arrangement**.
3. Set the following:
   - **Membership tier:** founding member.
   - **Annual arrangement:** Individual free exemption.
   - **Annual price currency:** choose one of the active currencies; there is no default.
   - **Membership setup reason:** required, for example the decision and who approved it.
4. Click **Preview annual charge**. It must say "Explicit free exemption: no annual invoice will be raised." Changing any pricing field cancels the preview, and Approve stays disabled until there is a current preview.
5. Click **Approve**.

**What approval checks and does:**
- It re-checks the price and every existing agreement and compliance requirement. If any check fails, nothing is created and the refusal is shown on the same screen.
- Choosing founding member alone is **not** free. Only Individual free exemption records the explicit 0 annual price that lets approval proceed without an invoice.
- If you leave the box unticked, approval works exactly as before: the partner starts on Catalyst, and its annual price must be resolvable.

### Change a partner from free to paid later

1. Open **Admin → Partners** and choose the partner (`/admin/partners/<id>`).
2. In **Annual subscription arrangement**, choose an **Annual pricing** option. Nothing is preselected.
   - **Custom annual price:** choose an active **Currency**, then enter the price as a whole number of **minor units**. The label shows each currency's exponent; for example, 1 USD = 100 minor units.
   - **Free:** an individual exemption of exactly 0.
   - **Tier price:** clears the individual annual price, so the tier's annual price applies.
3. Enter the **Reason**, click **Review annual arrangement**, check the summary, then click **Confirm and save**.

**What saving does and does not do:**
- Saving does **not** charge the partner (nothing is charged automatically), does **not** issue a retroactive invoice and does **not** start a subscription. The price is used at the partner's next approval invoice or annual checkout.
- If someone else changed the value in the meantime, nothing is saved. Click **Reload current value** and review again.
- The **Custom monthly price** in the Arrangement card above is separate and has its own currency. Saving that card changes only the monthly price, and never removes the annual price.

**What the partner sees:** the partner's dashboard labels this figure **Configured future price**. With no active subscription, it says nothing is billed or charged automatically. With an active subscription, it says the configured price is not the current billed amount, shows the actual current subscription amount separately, and links to **Billing → Subscription**.

### Create a referral code with a company discount and a partner referral fee

1. On the same partner page, go to **Company referral program** and click **Create new code**.
2. Enter:
   - **Referral code** and **Status:** Active.
   - **Discount type:** Percentage or Fixed amount, then **Company discount**.
   - **Eligible subscription currency** and **Eligible annual company plans**.
   - **Fixed partner referral fee** (major currency units) and **Partner fee currency**.
   - **Total referrals allowed under this code:** the lifetime cap.
   - The response interval, introduction expiry and **Referral agreement reference**.
   - Optionally, **Registration opens** and **Registration closes**.
3. Click **Save referral offer**. The partner then sees the offer, the dates and their shareable registration link under **Company referrals**.

**Rules that apply to every code:**
- **Benefit (unchanged):** the company discount applies to the company's first eligible annual subscription, within one year of the referral being accepted. The partner referral fee is a fixed positive amount, subject to the existing payment-verification and payout-approval steps. The discounted subscription price must stay above zero.
- **Registration dates (new, optional):**
  - Dates are UTC calendar dates, and both ends are inclusive.
  - A blank date means no limit.
  - The dates only control when a company may register with the code, by public code, approved email or partner client.
  - Closing or editing the dates never removes or shortens the benefit of a company that was already accepted.
  - Editing an offer asks companies holding an unconfirmed selection to confirm again.
- **Lifetime cap:**
  - Accepted registrations and pending registrations in progress both use a slot. Clicks, previews and unconfirmed selections do not.
  - Refunds and revocations do not free a slot.
  - The cap cannot be set below the number of slots already used.
  - Each company can be referred only once, and each partner has one active code.
