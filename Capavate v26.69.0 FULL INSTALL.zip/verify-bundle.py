#!/usr/bin/env python3
"""
Capavate release bundle verifier — v26.69.0.

Usage:  python3 verify-bundle.py capavate_v26.69.0_FULL_INSTALL.zip <expected-sha256>

Checks, in order (all must pass; the script exits non-zero on the first group that fails):
  1. the archive's SHA-256 equals the expected value (from the outer SHA256SUMS.txt);
  2. every entry is a regular file (no directories-as-entries, no symlinks, no absolute or ../ paths),
     and no forbidden path is present (node_modules, .env*, *.db, .git);
  3. BUNDLE_SHA256SUMS.txt lists every other entry exactly once with the right hash;
  4. backend/FILE_SHA256SUMS.txt lists every backend file (except itself and INSTALL_RECEIPT.json) with the
     right hash; backend/INSTALL_RECEIPT.json.manifestSha256 matches the manifest; version fields agree
     (receipt, package.json, package-lock.json root + packages[""]);
  5. every receipt.runtimeClosure path is manifested; dist/index.cjs and server/public/index.html hashes equal
     receipt.buildReceipt.outputs; every asset referenced by index.html exists;
  6. every migration present in both migrations/ and server/db/migrations/ is byte-identical;
     the three v26.69.0 migrations (0242, 0243, 0244) are present in both;
  7. frontend/** equals backend/dist/public/** equals backend/server/public/** byte-for-byte.
Prints a one-line summary per group and `BUNDLE_OK` at the end.
"""
import hashlib, json, re, sys, zipfile

FORBIDDEN = re.compile(r"(^|/)(node_modules|\.env(\..*)?|data\.db(-wal|-shm|-journal)?|\.git)(/|$)|\.db$|\.sqlite$")

def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()

def fail(msg: str):
    print(f"FAIL: {msg}"); sys.exit(1)

def main():
    if len(sys.argv) != 3: fail("usage: verify-bundle.py <installer.zip> <expected-sha256>")
    path, expected = sys.argv[1], sys.argv[2].strip().lower()
    if not re.fullmatch(r"[a-f0-9]{64}", expected): fail("expected sha256 must be 64 hex chars")
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""): h.update(chunk)
    if h.hexdigest() != expected: fail(f"archive sha256 {h.hexdigest()} != expected {expected}")
    print(f"1 archive sha256 ok: {expected}")

    z = zipfile.ZipFile(path)
    infos = z.infolist()
    names = []
    for zi in infos:
        n = zi.filename
        if zi.is_dir(): fail(f"directory entry {n}")
        if n.startswith("/") or ".." in n.split("/"): fail(f"unsafe path {n}")
        mode = (zi.external_attr >> 16) & 0o170000
        if mode and mode != 0o100000: fail(f"non-regular entry {n} (mode {oct(mode)})")
        if FORBIDDEN.search(n): fail(f"forbidden path {n}")
        names.append(n)
    if len(set(names)) != len(names): fail("duplicate entries")
    lower = set()
    for n in names:
        if n.lower() in lower: fail(f"case collision {n}")
        lower.add(n.lower())
    data = {n: z.read(n) for n in names}
    print(f"2 entries ok: {len(names)} regular files, no forbidden paths")

    bundle = data.get("BUNDLE_SHA256SUMS.txt")
    if bundle is None: fail("BUNDLE_SHA256SUMS.txt missing")
    listed = {}
    for line in bundle.decode().splitlines():
        m = re.fullmatch(r"([a-f0-9]{64})  (.+)", line)
        if not m: fail(f"bad BUNDLE_SHA256SUMS line: {line}")
        listed[m.group(2)] = m.group(1)
    others = set(names) - {"BUNDLE_SHA256SUMS.txt"}
    if set(listed) != others: fail(f"BUNDLE_SHA256SUMS mismatch: missing={sorted(others-set(listed))[:5]} extra={sorted(set(listed)-others)[:5]}")
    for n, s in listed.items():
        if sha(data[n]) != s: fail(f"bundle hash mismatch {n}")
    print(f"3 bundle sums ok: {len(listed)} entries")

    man = data.get("backend/FILE_SHA256SUMS.txt"); rec_b = data.get("backend/INSTALL_RECEIPT.json")
    if man is None or rec_b is None: fail("backend manifest/receipt missing")
    receipt = json.loads(rec_b)
    if receipt.get("manifestSha256") != sha(man): fail("receipt.manifestSha256 != manifest")
    manifest = {}
    for line in man.decode().splitlines():
        m = re.fullmatch(r"([a-f0-9]{64})  (.+)", line)
        if not m: fail(f"bad FILE_SHA256SUMS line: {line}")
        manifest[m.group(2)] = m.group(1)
    backend_files = {n[len("backend/"):] for n in names if n.startswith("backend/")} - {"FILE_SHA256SUMS.txt", "INSTALL_RECEIPT.json"}
    if set(manifest) != backend_files: fail(f"manifest coverage mismatch: missing={sorted(backend_files-set(manifest))[:5]} extra={sorted(set(manifest)-backend_files)[:5]}")
    for n, s in manifest.items():
        if sha(data["backend/" + n]) != s: fail(f"backend hash mismatch {n}")
    pkg = json.loads(data["backend/package.json"]); lock = json.loads(data["backend/package-lock.json"])
    v = receipt.get("version")
    if not (pkg["version"] == v == lock["version"] == lock["packages"][""]["version"]): fail("version fields disagree")
    print(f"4 backend manifest ok: {len(manifest)} files, version {v}, sourceCommit {receipt.get('sourceCommit')}")

    for n in receipt.get("runtimeClosure", []):
        if n not in manifest: fail(f"runtimeClosure path not manifested: {n}")
    outputs = receipt.get("buildReceipt", {}).get("outputs", {})
    for n, s in outputs.items():
        if manifest.get(n) != s: fail(f"build output hash mismatch {n}")
    html = data["backend/server/public/index.html"].decode()
    for m in re.finditer(r"""(?:src|href)=["'](/?assets/[^"'?#]+)""", html):
        if "backend/server/public/" + m.group(1).lstrip("/") not in data: fail(f"index.html asset missing {m.group(1)}")
    print(f"5 runtime closure ok: {len(receipt.get('runtimeClosure', []))} paths; build outputs {len(outputs)} verified")

    migs = {n[len("backend/migrations/"):] for n in names if n.startswith("backend/migrations/") and n.endswith(".sql")}
    mirrors = {n[len("backend/server/db/migrations/"):] for n in names if n.startswith("backend/server/db/migrations/") and n.endswith(".sql")}
    # The two directories are not a 1:1 mirror historically (the early files differ by name — a
    # pre-existing layout); every file present in BOTH must be byte-identical, and the three
    # v26.69.0 migrations must be present in both.
    both = migs & mirrors
    for m_ in sorted(both):
        if data["backend/migrations/" + m_] != data["backend/server/db/migrations/" + m_]: fail(f"migration mirror differs {m_}")
    for want in ("0242_", "0243_", "0244_"):
        if not any(m_.startswith(want) for m_ in both): fail(f"v26.69.0 migration {want} missing from migrations/ or server/db/migrations/")
    print(f"6 migrations ok: {len(migs)} canonical SQL files, {len(both)} mirrored byte-identical, 0242–0244 present in both")

    fe = {n[len("frontend/"):]: data[n] for n in names if n.startswith("frontend/")}
    dp = {n[len("backend/dist/public/"):]: data[n] for n in names if n.startswith("backend/dist/public/")}
    sp = {n[len("backend/server/public/"):]: data[n] for n in names if n.startswith("backend/server/public/")}
    if not fe or fe != dp or dp != sp: fail(f"frontend/dist/server public trees differ (frontend={len(fe)} dist={len(dp)} server={len(sp)})")
    print(f"7 frontend mirrors ok: {len(fe)} files identical in frontend/, backend/dist/public/, backend/server/public/")
    print("BUNDLE_OK")

if __name__ == "__main__":
    main()
