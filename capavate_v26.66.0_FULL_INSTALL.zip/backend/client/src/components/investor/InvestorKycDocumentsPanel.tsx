/**
 * WAVE 18 — ORP-040 (DEF-040), KYC half: the orphaned investor KYC document
 * surface.
 *
 * WHAT WAS WRONG. Two live endpoints, registered at server/routes.ts:1143
 * (`registerKycDocumentRoutes`), had ZERO client callers — an investor could not
 * upload a single KYC document from anywhere in the product, and could not see
 * what had already been uploaded or whether an administrator had verified it:
 *
 *   POST /api/investor/kyc/documents   server/lib/kycDocumentStore.ts:132
 *   GET  /api/investor/kyc/documents   server/lib/kycDocumentStore.ts:218
 *
 * Verified by `grep -rn "kyc/documents" client/src` before this file existed:
 * no match. So this item is **WIRING** — no route, no store method, no migration.
 *
 * SCOPING IS THE SERVER'S. Both routes read `ctx.userId` from the session and the
 * GET filters `WHERE investor_id = ?` (:227). No investor id is ever sent from
 * this client; a client-supplied id would be an authorisation hole.
 *
 * DOC TYPES ARE NOT DUPLICATED BY HAND. The five allowed values are the ones the
 * server validates against (`KYC_DOC_TYPES`, kycDocumentStore.ts:39), and the
 * server answers 400 `invalid_doc_type` with the allowed list for anything else.
 * The list here is deliberately declared once, exported, and asserted in the suite
 * against the server constant, so a drift cannot ship an option that always fails.
 *
 * FAIL-CLOSED STATES ARE RENDERED. Every documented refusal has copy:
 * `invalid_doc_type` (400), `fileName_required` / `mimeType_required` /
 * `blobBase64_required` (400), `invalid_base64` (400), `empty_blob` (400),
 * `file_too_large` (413, `maxBytes` echoed by the server at :164) and
 * `insert_failed` (500). None of them is swallowed and none is shown as success.
 *
 * NO MONEY on this surface, so there is no `formatMinor` call and no currency —
 * intentionally, since inventing one would be worse than omitting it.
 */
import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { KYC_ACCEPT, MAX_KYC_RAW_BYTES } from "@shared/kycUploadPolicy";

/** Mirrors `KYC_DOC_TYPES` (server/lib/kycDocumentStore.ts:39) — the exact list
 *  the POST route validates against at :139. */
export const KYC_DOC_TYPE_OPTIONS: ReadonlyArray<{ value: string; label: string }> = [
  { value: "passport", label: "Passport" },
  { value: "drivers_license", label: "Driver's licence" },
  { value: "accreditation_letter", label: "Accreditation letter" },
  { value: "source_of_funds", label: "Source of funds" },
  { value: "other", label: "Other" },
];

/** Mirrors `KycDocSummary` (server/lib/kycDocumentStore.ts rowToSummary). */
export interface KycDocSummary {
  id: string;
  investorId: string;
  kycId: string | null;
  docType: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  sha256: string;
  verified: boolean;
  verifiedBy: string | null;
  verifiedAt: string | null;
  verificationNotes: string | null;
  uploadedAt: string;
}

/** Every refusal the two routes can return, with human copy. Keys are the exact
 *  `error` strings in server/lib/kycDocumentStore.ts. */
export const KYC_ERROR_COPY: Record<string, string> = {
  invalid_doc_type: "That document type is not accepted. Choose one of the listed types.",
  fileName_required: "Choose a file before uploading.",
  mimeType_required: "This file has no detectable type. Try a PDF or an image.",
  blobBase64_required: "The file could not be read. Try selecting it again.",
  invalid_base64: "The file could not be encoded for upload. Try selecting it again.",
  empty_blob: "That file is empty.",
  file_too_large: "That file is larger than the 10 MB limit.",
  insert_failed: "The upload could not be saved. Nothing was stored — please retry.",
  UNAUTHORIZED: "Your session has expired. Sign in again to upload documents.",
  too_large: "That file is larger than the 10 MB limit.",
  read_failed: "The file could not be read. Select it again and retry.",
  invalid_file_name: "Use a filename without quotes, path separators or control characters, up to 255 bytes.",
  unsupported_file_type: "Choose a PDF, JPEG, PNG or WebP file.",
  mime_mismatch: "The file contents do not match its declared format. Choose the original PDF or supported image.",
  unsupported_media_type: "The upload format was not supported. Refresh this page and select your file again.",
  unsupported_encoding: "Compressed upload requests are not supported. Select the original file and retry.",
  unsupported_charset: "The upload encoding was not supported. Refresh this page and retry.",
  invalid_json: "The upload could not be decoded. Select the file again and retry.",
  invalid_body: "The upload request was not valid. Refresh this page and retry.",
  invalid_kyc_reference: "That supporting-record reference could not be used for your account.",
  storage_unavailable: "Document storage is temporarily unavailable. Please retry later.",
  forbidden: "This upload was not permitted. Check your account access and try again from Capavate.",
  list_failed: "Your document list could not be refreshed. Please retry.",
  unconfirmed: "The upload result could not be confirmed. Refresh the document list before retrying.",
};

export function kycErrorCopy(error: string | null | undefined): string {
  if (!error) return "The upload did not complete. Nothing was stored.";
  if (!Object.prototype.hasOwnProperty.call(KYC_ERROR_COPY, error)) return "The upload result could not be confirmed. Refresh the document list before retrying.";
  return KYC_ERROR_COPY[error] ?? "The upload result could not be confirmed. Refresh the document list before retrying.";
}

function uploadErrorCode(error: unknown): string {
  const e = error as { status?: number; code?: string; message?: string } | null;
  if (e?.status === 413) return "file_too_large";
  if (e?.status === 401) return "UNAUTHORIZED";
  if (e?.status === 403) return "forbidden";
  if (e?.code && Object.prototype.hasOwnProperty.call(KYC_ERROR_COPY, e.code)) return e.code;
  if (e?.status === 415) return "unsupported_media_type";
  if (e?.status === 503) return "storage_unavailable";
  // Only our own reader error is carried by message, never arbitrary server text.
  if (e?.message === "read_failed") return "read_failed";
  return "unconfirmed";
}

/** Bytes → a short human string. Not money; no currency involved. */
export function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

/** Strip the `data:...;base64,` prefix a FileReader data-URL carries, because the
 *  server does `Buffer.from(blobBase64, "base64")` on the raw value (:155). */
export function stripDataUrlPrefix(dataUrl: string): string {
  const comma = dataUrl.indexOf(",");
  return comma >= 0 && dataUrl.slice(0, comma).includes("base64") ? dataUrl.slice(comma + 1) : dataUrl;
}

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read_failed"));
    reader.onabort = () => reject(new Error("read_failed"));
    reader.onload = () => resolve(stripDataUrlPrefix(String(reader.result ?? "")));
    reader.readAsDataURL(file);
  });
}

export function InvestorKycDocumentsPanel() {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const pendingRef = useRef(false);
  const [docType, setDocType] = useState<string>("passport");
  const [refusal, setRefusal] = useState<string | null>(null);
  const [uploaded, setUploaded] = useState<string | null>(null);

  const listQ = useQuery<{ ok: boolean; documents?: KycDocSummary[]; error?: string }>({
    queryKey: ["/api/investor/kyc/documents"],
    queryFn: async () => (await apiRequest("GET", "/api/investor/kyc/documents")).json(),
    retry: false,
  });

  const upload = useMutation({
    mutationFn: async (file: File) => {
      if (!file.size) throw Object.assign(new Error("empty_blob"), { code: "empty_blob" });
      if (file.size > MAX_KYC_RAW_BYTES) throw Object.assign(new Error("file_too_large"), { code: "file_too_large" });
      const blobBase64 = await readFileAsBase64(file);
      const res = await apiRequest("POST", "/api/investor/kyc/documents", {
        docType,
        fileName: file.name,
        mimeType: file.type || "application/octet-stream",
        blobBase64,
      });
      const body = await res.json();
      if (body?.ok !== true || typeof body.document?.id !== "string" ||
        !body.document.id || body.document.verified !== false ||
        typeof body.document.fileName !== "string" || !body.document.fileName) {
        throw new Error("Upload result unconfirmed");
      }
      return body as { ok: true; document: KycDocSummary };
    },
    onSuccess: (body) => {
      setRefusal(null);
      setUploaded(body.document.fileName);
      if (fileRef.current) fileRef.current.value = "";
      qc.invalidateQueries({ queryKey: ["/api/investor/kyc/documents"] });
    },
    onError: (err: unknown) => {
      setUploaded(null);
      setRefusal(uploadErrorCode(err));
    },
    onSettled: () => { pendingRef.current = false; },
  });

  const docs = listQ.data?.documents ?? [];

  return (
    <Card className="mb-6" data-testid="investor-kyc-documents-panel">
      <CardHeader>
        <CardTitle className="text-lg">KYC documents</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-xs text-muted-foreground">
          Documents you upload here are stored with a SHA-256 checksum so an
          administrator can verify they have not been altered. Only you and an
          administrator can see them.
        </div>
        <p className="text-xs text-muted-foreground">
          Supporting uploads are not universally required by Capavate. The issuing company may
          require applicable documents for its process; provide the records it requests.
          Uploading a file does not verify your identity or accreditation.
        </p>
        <p className="text-xs text-muted-foreground">
          PDF, JPEG, PNG and WebP are supported, up to 10 MiB (10,485,760 bytes).
          Checks cover file size and format only, not document authenticity or malware scanning.
        </p>

        <div className="flex flex-wrap items-end gap-3">
          <div>
            <Label htmlFor="kyc-doc-type" className="text-xs">
              Document type
            </Label>
            <select
              id="kyc-doc-type"
              data-testid="investor-kyc-doc-type"
              className="mt-1 block h-9 rounded-md border border-input bg-background px-2 text-sm"
              value={docType}
              onChange={(e) => setDocType(e.target.value)}
            >
              {KYC_DOC_TYPE_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label htmlFor="kyc-doc-file" className="text-xs">
              File (10 MB maximum)
            </Label>
            <input
              id="kyc-doc-file"
              data-testid="investor-kyc-file"
              ref={fileRef}
              type="file"
              accept={KYC_ACCEPT}
              className="mt-1 block text-sm"
            />
          </div>
          <Button
            data-testid="investor-kyc-upload"
            disabled={upload.isPending}
            onClick={() => {
              if (pendingRef.current) return;
              setUploaded(null);
              setRefusal(null);
              const f = fileRef.current?.files?.[0];
              if (!f) {
                setUploaded(null);
                setRefusal("fileName_required");
                return;
              }
              if (!f.size || f.size > MAX_KYC_RAW_BYTES) {
                setRefusal(f.size ? "file_too_large" : "empty_blob");
                return;
              }
              pendingRef.current = true;
              upload.mutate(f);
            }}
          >
            {upload.isPending ? "Uploading…" : "Upload document"}
          </Button>
        </div>

        {refusal && (
          <div className="text-sm text-amber-900" data-testid="investor-kyc-refusal">
            {kycErrorCopy(refusal)}
          </div>
        )}
        {uploaded && !refusal && (
          <div className="text-sm text-emerald-900" data-testid="investor-kyc-uploaded">
            Uploaded {uploaded}. An administrator will review it.
          </div>
        )}
        {uploaded && listQ.isError && (
          <p className="text-sm text-amber-900">
            Your upload was accepted, but the document list could not refresh. Refresh the list before uploading it again.
          </p>
        )}

        <div>
          <div className="text-sm font-semibold">Uploaded so far</div>
          {listQ.isLoading && <Skeleton className="h-16 w-full mt-2" />}
          {listQ.isError && (
            <div className="mt-2 text-sm text-amber-900" data-testid="investor-kyc-list-error">
              Your documents could not be loaded right now. Nothing has been lost.
            </div>
          )}
          {!listQ.isLoading && !listQ.isError && docs.length === 0 && (
            <div className="mt-2 text-sm text-muted-foreground" data-testid="investor-kyc-empty">
              No documents uploaded yet.
            </div>
          )}
          {docs.length > 0 && (
            <ul className="mt-2 space-y-2">
              {docs.map((d) => (
                <li
                  key={d.id}
                  className="flex flex-wrap items-baseline justify-between gap-2 text-sm"
                  data-testid={`investor-kyc-row-${d.id}`}
                >
                  <span>
                    <span className="font-medium">{d.fileName}</span>
                    <span className="ml-2 text-xs text-muted-foreground">
                      {KYC_DOC_TYPE_OPTIONS.find((o) => o.value === d.docType)?.label ?? d.docType}
                      {" · "}
                      {formatBytes(d.sizeBytes)}
                    </span>
                  </span>
                  {d.verified ? (
                    <Badge data-testid={`investor-kyc-verified-${d.id}`}>Verified</Badge>
                  ) : (
                    <Badge variant="outline" data-testid={`investor-kyc-pending-${d.id}`}>
                      Awaiting verification
                    </Badge>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default InvestorKycDocumentsPanel;
