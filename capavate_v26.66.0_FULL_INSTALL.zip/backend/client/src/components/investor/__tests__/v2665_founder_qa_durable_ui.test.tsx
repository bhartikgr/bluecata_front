/**
 * Real Q component + real apiRequest/React Query, stubbed network only.
 * These DOM cases are not process/delivery evidence. Main runs them.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import FounderQABox from "../FounderQABox";

const observed = vi.hoisted(() => ({
  navigate: vi.fn(), toast: vi.fn(),
  identity: { userId: "u_current", isAuthed: true },
}));
vi.mock("wouter", async () => ({
  ...await vi.importActual<Record<string, unknown>>("wouter"),
  useLocation: () => ["/founder/rounds/rnd_qdur", observed.navigate],
}));
vi.mock("@/hooks/use-toast", () => ({ useToast: () => ({ toast: observed.toast }) }));
vi.mock("@/lib/entitlement", () => ({ useEntitlement: () => ({ data: observed.identity }) }));

const RID = "rnd_qdur";
const CHANNEL = `qa_co_unknown_${RID}`;
type Message = {
  id: string; channelId: string; authorId: string; authorName: string;
  authorRole: "investor" | "founder"; body: string; publicWithinRound: boolean; createdAt: string;
};
const privateQuestion: Message = {
  id: "qa_private_1", channelId: CHANNEL, authorId: "u_intended",
  authorName: "Private Investor", authorRole: "investor", body: "Question not to be forwarded",
  publicWithinRound: false, createdAt: "2026-10-08T12:00:00.000Z",
};
type Call = { method: string; url: string; body: Record<string, any>; headers: Record<string, string> };
let calls: Call[] = [];
let rows: Message[] = [];
let postHandler: (c: Call) => Response | Promise<Response>;
let readStatus = 200;
let readChannel: string | null = null;
let clients: QueryClient[] = [];
const roundOf = (url: string) => decodeURIComponent(url.split("/rounds/")[1].split("/")[0]);
const channelOf = (round: string) => {
  const match = round.match(/^rnd_([a-z0-9]+)_/);
  return `qa_co_${match ? `co_${match[1]}` : "unknown"}_${round}`;
};

function response(status: number, body: unknown): Response {
  return {
    status, ok: status >= 200 && status < 300, statusText: String(status),
    json: async () => body, text: async () => JSON.stringify(body),
    clone: () => response(status, body),
  } as Response;
}
const posts = () => calls.filter((c) => c.method === "POST" && c.url.endsWith("/founder-qa"));
function acknowledgement(c: Call, extra: Record<string, unknown> = {}) {
  return response(201, { ok: true, message: {
    id: "qa_saved_1", channelId: channelOf(roundOf(c.url)), authorId: "u_current",
    authorName: "Current User", authorRole: "investor",
    body: c.body.body, publicWithinRound: c.body.publicWithinRound,
    createdAt: "2026-10-08T12:01:00.000Z", ...extra,
  } });
}
function mount(founderView = false, roundId = RID) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false, gcTime: 0 }, mutations: { retry: false } },
  });
  clients.push(qc);
  const tree = (round: string) => <QueryClientProvider client={qc}><FounderQABox roundId={round} founderView={founderView} /></QueryClientProvider>;
  const view = render(tree(roundId));
  return { ...view, qc, change: (round = roundId) => view.rerender(tree(round)) };
}
function typeBody(body: string) { fireEvent.change(screen.getByTestId("qa-input"), { target: { value: body } }); }
function deferredResponse() {
  let finish!: (value: Response) => void;
  const promise = new Promise<Response>((resolve) => { finish = resolve; });
  return {
    promise,
    settle: async (value: Response) => {
      await act(async () => {
        finish(value);
        await promise;
        await new Promise((resolve) => setTimeout(resolve, 0));
      });
    },
  };
}

beforeEach(() => {
  calls = []; rows = []; readStatus = 200; readChannel = null;
  observed.identity = { userId: "u_current", isAuthed: true };
  observed.navigate.mockReset(); observed.toast.mockReset();
  postHandler = (c) => acknowledgement(c);
  vi.stubGlobal("fetch", vi.fn(async (url: string, init?: RequestInit) => {
    const c: Call = {
      method: init?.method ?? "GET", url: String(url),
      body: init?.body ? JSON.parse(String(init.body)) : {},
      headers: (init?.headers ?? {}) as Record<string, string>,
    };
    calls.push(c);
    if (c.method === "GET") {
      return readStatus === 200
        ? response(200, { roundId: roundOf(c.url), channelId: readChannel ?? channelOf(roundOf(c.url)), messages: rows })
        : response(readStatus, { error: "qa_storage_unavailable", message: "Round Q&A storage is unavailable." });
    }
    return postHandler(c);
  }));
});
afterEach(() => {
  cleanup();
  for (const q of clients) q.clear();
  clients = [];
  vi.unstubAllGlobals();
});

describe("v26.65 #10 Q&A UI contract", () => {
  it("read failure is visible, never 'No questions'; successful empty read still renders empty state", async () => {
    readStatus = 503;
    mount();
    await screen.findByTestId("qa-read-error");
    expect(screen.queryByTestId("qa-empty-state")).toBeNull();
    readStatus = 200;
    fireEvent.click(screen.getByText("Reload Q&A"));
    await screen.findByTestId("qa-empty-state");
    expect(screen.queryByTestId("qa-read-error")).toBeNull();
  });

  it("unknown outcome retains draft/privacy/key; retry posts identical intent; only verified 201 clears it", async () => {
    let attempts = 0;
    postHandler = (c) => {
      if (++attempts === 1) throw new TypeError("lost response");
      return acknowledgement(c);
    };
    mount();
    await screen.findByTestId("qa-empty-state");
    typeBody("  Retain this question  ");
    fireEvent.click(screen.getByTestId("qa-public-checkbox"));
    fireEvent.click(screen.getByTestId("button-send-question"));
    await screen.findByTestId("qa-save-error");
    const draft = screen.getByTestId("qa-input") as HTMLTextAreaElement;
    expect(draft.value).toBe("  Retain this question  ");
    expect(draft.disabled).toBe(true);
    expect(posts()).toHaveLength(1);
    const first = posts()[0];
    expect(first.body).toEqual({ body: "Retain this question", publicWithinRound: false });
    expect(first.headers["Idempotency-Key"]).toMatch(/^qa-[a-f0-9]{32}$/);
    expect(observed.toast).not.toHaveBeenCalledWith(expect.objectContaining({ title: "Question saved to round Q&A" }));
    fireEvent.click(screen.getByTestId("button-send-question"));
    await waitFor(() => expect((screen.getByTestId("qa-input") as HTMLTextAreaElement).value).toBe(""));
    expect(posts()).toHaveLength(2);
    expect(posts()[1].headers["Idempotency-Key"]).toBe(first.headers["Idempotency-Key"]);
    expect(posts()[1].body).toEqual(first.body);
    expect(observed.toast).toHaveBeenCalledWith({ title: "Question saved to round Q&A" });
    expect(screen.queryByText("Question sent to founder")).toBeNull();
  });

  it.each([
    ["unexpected 200", (c: Call) => response(200, { ok: true, message: { ...privateQuestion, body: c.body.body } })],
    ["privacy mismatch", (c: Call) => acknowledgement(c, { publicWithinRound: false })],
    ["wrong body", (c: Call) => acknowledgement(c, { body: "different" })],
    ["malformed message", () => response(201, { ok: true, message: {} })],
    ["extra metadata", (c: Call) => acknowledgement(c, { roundId: RID })],
    ["foreign author", (c: Call) => acknowledgement(c, { authorId: "u_someone_else" })],
    ["foreign round", (c: Call) => acknowledgement(c, { channelId: channelOf("rnd_other") })],
    ["wrong generated company", (c: Call) => acknowledgement(c, { channelId: `qa_co_wrong_${RID}` })],
  ])("does not claim a save on %s", async (_name, handler) => {
    postHandler = handler as (c: Call) => Response;
    mount();
    await screen.findByTestId("qa-empty-state");
    typeBody("Keep me");
    fireEvent.click(screen.getByTestId("button-send-question"));
    await screen.findByTestId("qa-save-error");
    expect((screen.getByTestId("qa-input") as HTMLTextAreaElement).value).toBe("Keep me");
    expect(observed.toast).not.toHaveBeenCalledWith(expect.objectContaining({ title: "Question saved to round Q&A" }));
  });

  it("conflicting replay retains its key until explicit new intent; edited new message uses a different key", async () => {
    postHandler = () => response(409, { error: "qa_request_conflict", message: "This request key was already used for different content." });
    mount();
    await screen.findByTestId("qa-empty-state");
    typeBody("Original intent");
    fireEvent.click(screen.getByTestId("button-send-question"));
    await screen.findByTestId("qa-save-error");
    const originalKey = posts()[0].headers["Idempotency-Key"];
    expect(screen.getByTestId("qa-save-error").textContent).toContain("Reload Q&A");
    fireEvent.click(screen.getByTestId("qa-new-intent"));
    typeBody("Explicit new intent");
    postHandler = (c) => acknowledgement(c);
    fireEvent.click(screen.getByTestId("button-send-question"));
    await waitFor(() => expect(posts()).toHaveLength(2));
    expect(posts()[1].headers["Idempotency-Key"]).not.toBe(originalKey);
    expect(posts()[1].body.body).toBe("Explicit new intent");
  });

  it("founder panel reaches existing DM recipient contract without forwarding private question text", async () => {
    rows = [privateQuestion];
    postHandler = (c) => c.url === "/api/comms/dm/start"
      ? response(200, { ok: true, channelId: "dm__u_founder__u_intended" })
      : acknowledgement(c);
    mount(true);
    await screen.findByTestId("qa-message-qa_private_1");
    expect(screen.getByText("Round Q&A")).toBeTruthy();
    expect(screen.getByText(/current company members and administrators/)).toBeTruthy();
    expect(screen.queryByTestId("qa-public-checkbox")).toBeNull();
    fireEvent.click(screen.getByTestId("qa-private-reply-qa_private_1"));
    await waitFor(() => expect(observed.navigate).toHaveBeenCalled());
    const dm = calls.filter((c) => c.url === "/api/comms/dm/start");
    expect(dm).toHaveLength(1);
    expect(dm[0].body).toEqual({ targetUserId: "u_intended" });
    expect(JSON.stringify(dm)).not.toContain(privateQuestion.body);
    expect(calls.some((c) => c.method === "POST" && /\/channels\/.*\/messages/.test(c.url))).toBe(false);
    expect(observed.navigate).toHaveBeenCalledWith("/founder/messages?thread=dm__u_founder__u_intended&channel=dm__u_founder__u_intended");
  });

  it("founder DM refusal is visible and never navigates; investor component does not offer private-reply action", async () => {
    rows = [privateQuestion];
    postHandler = () => response(403, { error: "dm_forbidden", message: "This private conversation is not permitted." });
    const view = mount(true);
    await screen.findByTestId("qa-private-reply-qa_private_1");
    fireEvent.click(screen.getByTestId("qa-private-reply-qa_private_1"));
    await screen.findByTestId("qa-dm-error");
    expect(observed.navigate).not.toHaveBeenCalled();
    view.unmount();
    mount();
    await screen.findByTestId("qa-message-qa_private_1");
    expect(screen.queryByTestId("qa-private-reply-qa_private_1")).toBeNull();
  });

  it("founder composer saves a public reply, never a private Q row disguised as investor delivery", async () => {
    mount(true);
    await screen.findByTestId("qa-empty-state");
    typeBody("Public answer");
    fireEvent.click(screen.getByTestId("button-send-question"));
    await waitFor(() => expect(observed.toast).toHaveBeenCalledWith({ title: "Reply saved to round Q&A" }));
    expect(posts()[0].body).toEqual({ body: "Public answer", publicWithinRound: true });
  });

  it.each(["outer channel", "message channel"])("refuses a foreign GET %s without rendering its private thread", async (kind) => {
    if (kind === "outer channel") readChannel = channelOf("rnd_other");
    rows = [{ ...privateQuestion, channelId: channelOf("rnd_other") }];
    mount();
    await screen.findByTestId("qa-read-error");
    expect(screen.queryByTestId("qa-message-qa_private_1")).toBeNull();
    expect(screen.queryByTestId("qa-empty-state")).toBeNull();
  });

  it("accepts the delivered derived-company channel and the unknown fallback without redesigning metadata", async () => {
    const round = "rnd_demo_seed";
    rows = [{ ...privateQuestion, channelId: "qa_co_co_demo_rnd_demo_seed" }];
    mount(false, round);
    await screen.findByTestId("qa-message-qa_private_1");
    typeBody("Known company metadata");
    fireEvent.click(screen.getByTestId("button-send-question"));
    await waitFor(() => expect(observed.toast).toHaveBeenCalledWith({ title: "Question saved to round Q&A" }));
    expect(posts()[0].url).toBe(`/api/rounds/${round}/founder-qa`);
    // The other positive cases use qa_co_unknown_rnd_qdur.
  });

  it("unknown identity disables all Q reads and saves; transient unknown retains same-actor retry intent", async () => {
    observed.identity = { userId: "fallback_persona", isAuthed: false };
    const view = mount();
    expect(screen.getByTestId("qa-identity-unavailable")).toBeTruthy();
    expect((screen.getByTestId("button-send-question") as HTMLButtonElement).disabled).toBe(true);
    expect(calls).toHaveLength(0);
    observed.identity = { userId: "u_current", isAuthed: true };
    view.change();
    await screen.findByTestId("qa-empty-state");
    postHandler = () => { throw new TypeError("lost response"); };
    typeBody("Same actor retry");
    fireEvent.click(screen.getByTestId("button-send-question"));
    await screen.findByTestId("qa-save-error");
    const first = posts()[0];
    observed.identity = { userId: "u_current", isAuthed: false };
    view.change();
    expect((screen.getByTestId("qa-input") as HTMLTextAreaElement).value).toBe("");
    fireEvent.click(screen.getByTestId("button-send-question"));
    expect(posts()).toHaveLength(1);
    observed.identity = { userId: "u_current", isAuthed: true };
    view.change();
    expect((screen.getByTestId("qa-input") as HTMLTextAreaElement).value).toBe("Same actor retry");
    postHandler = (c) => acknowledgement(c);
    fireEvent.click(screen.getByTestId("button-send-question"));
    await waitFor(() => expect(observed.toast).toHaveBeenCalledWith({ title: "Question saved to round Q&A" }));
    expect(posts()).toHaveLength(2);
    expect(posts()[1].headers["Idempotency-Key"]).toBe(first.headers["Idempotency-Key"]);
    expect(posts()[1].body).toEqual(first.body);
  });

  it("actor A unknown-outcome attempt never becomes actor B's retry or private query cache", async () => {
    rows = [privateQuestion];
    postHandler = () => { throw new TypeError("lost response"); };
    const view = mount();
    await screen.findByTestId("qa-message-qa_private_1");
    typeBody("Actor A private draft");
    fireEvent.click(screen.getByTestId("qa-public-checkbox"));
    fireEvent.click(screen.getByTestId("button-send-question"));
    await screen.findByTestId("qa-save-error");
    const firstKey = posts()[0].headers["Idempotency-Key"];
    observed.identity = { userId: "fallback_persona", isAuthed: false };
    view.change();
    expect(screen.queryByTestId("qa-message-qa_private_1")).toBeNull();
    expect((screen.getByTestId("qa-input") as HTMLTextAreaElement).value).toBe("");
    expect((screen.getByTestId("button-send-question") as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(screen.getByTestId("button-send-question"));
    expect(posts()).toHaveLength(1);
    observed.identity = { userId: "u_next", isAuthed: true };
    rows = [];
    view.change();
    expect(screen.queryByTestId("qa-message-qa_private_1")).toBeNull();
    expect((screen.getByTestId("qa-input") as HTMLTextAreaElement).value).toBe("");
    expect(screen.queryByTestId("qa-save-error")).toBeNull();
    fireEvent.click(screen.getByTestId("button-send-question"));
    expect(posts()).toHaveLength(1);
    await screen.findByTestId("qa-empty-state");
    expect(view.qc.getQueryData(["/api/rounds", RID, "founder-qa", "u_next"])).toEqual({
      roundId: RID, channelId: CHANNEL, messages: [],
    });
    typeBody("Actor B deliberate draft");
    postHandler = (c) => acknowledgement(c, { authorId: "u_next" });
    fireEvent.click(screen.getByTestId("button-send-question"));
    await waitFor(() => expect(observed.toast).toHaveBeenCalledWith({ title: "Question saved to round Q&A" }));
    expect(posts()).toHaveLength(2);
    expect(posts()[1].headers["Idempotency-Key"]).not.toBe(firstKey);
    expect(posts()[1].body.body).toBe("Actor B deliberate draft");
  });

  it.each([
    ["round", "success"], ["round", "error"], ["actor", "success"], ["actor", "error"], ["unmount", "success"], ["unmount", "error"],
  ])("ignores delayed save %s transition / %s without clearing or claiming the current draft", async (transition, result) => {
    const pending = deferredResponse();
    postHandler = () => pending.promise;
    const view = mount();
    await screen.findByTestId("qa-empty-state");
    typeBody("Old intent");
    fireEvent.click(screen.getByTestId("button-send-question"));
    await waitFor(() => expect(posts()).toHaveLength(1));
    const original = posts()[0];
    if (transition === "unmount") view.unmount();
    else {
      if (transition === "actor") observed.identity = { userId: "u_next", isAuthed: true };
      view.change(transition === "round" ? "rnd_next" : RID);
      await screen.findByTestId("qa-empty-state");
      typeBody("Current unsaved draft");
    }
    await pending.settle(result === "success" ? acknowledgement(original) : response(503, { error: "qa_storage_unavailable" }));
    expect(observed.toast).not.toHaveBeenCalled();
    expect(observed.navigate).not.toHaveBeenCalled();
    expect(screen.queryByTestId("qa-save-error")).toBeNull();
    if (transition !== "unmount") expect((screen.getByTestId("qa-input") as HTMLTextAreaElement).value).toBe("Current unsaved draft");
    expect(posts()).toHaveLength(1);
  });

  it.each([
    ["round", "success"], ["round", "error"], ["actor", "success"], ["actor", "error"], ["unmount", "success"], ["unmount", "error"],
  ])("ignores delayed private-DM %s transition / %s without stale navigation or errors", async (transition, result) => {
    rows = [privateQuestion];
    const pending = deferredResponse();
    postHandler = () => pending.promise;
    const view = mount(true);
    await screen.findByTestId("qa-private-reply-qa_private_1");
    fireEvent.click(screen.getByTestId("qa-private-reply-qa_private_1"));
    await waitFor(() => expect(calls.filter((c) => c.url === "/api/comms/dm/start")).toHaveLength(1));
    if (transition === "unmount") view.unmount();
    else {
      rows = [];
      if (transition === "actor") observed.identity = { userId: "u_next", isAuthed: true };
      view.change(transition === "round" ? "rnd_next" : RID);
      await screen.findByTestId("qa-empty-state");
    }
    await pending.settle(result === "success"
      ? response(200, { ok: true, channelId: "dm__u_current__u_intended" })
      : response(403, { error: "dm_forbidden", message: "Not permitted" }));
    expect(observed.navigate).not.toHaveBeenCalled();
    expect(observed.toast).not.toHaveBeenCalled();
    expect(screen.queryByTestId("qa-dm-error")).toBeNull();
    expect(posts()).toHaveLength(0);
  });
});
