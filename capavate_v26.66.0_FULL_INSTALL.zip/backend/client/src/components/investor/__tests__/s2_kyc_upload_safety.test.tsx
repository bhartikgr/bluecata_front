/** S2 author tests: mount the actual investor KYC panel and use the real
 * apiRequest/ApiError transport. Network and FileReader are the only fakes.
 * No identity document, private DB, live route or outbound request is used. */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { InvestorKycDocumentsPanel } from "../InvestorKycDocumentsPanel";
import { KYC_ACCEPT, MAX_KYC_RAW_BYTES } from "@shared/kycUploadPolicy";

const endpoint = "/api/investor/kyc/documents";
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

let reads: string[];
let mode: "success" | "error" | "abort";
let postBodies: Array<Record<string, unknown>>;
let fetchImpl: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

class Reader {
  result: string | null = null;
  onload: ((event: ProgressEvent<FileReader>) => void) | null = null;
  onerror: ((event: ProgressEvent<FileReader>) => void) | null = null;
  onabort: ((event: ProgressEvent<FileReader>) => void) | null = null;
  readAsDataURL(file: File) {
    reads.push(file.name);
    queueMicrotask(() => {
      if (mode === "error") this.onerror?.({} as ProgressEvent<FileReader>);
      else if (mode === "abort") this.onabort?.({} as ProgressEvent<FileReader>);
      else {
        this.result = "data:application/pdf;base64,JVBERi0xLjQK";
        this.onload?.({} as ProgressEvent<FileReader>);
      }
    });
  }
}

function mount() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } });
  return render(<QueryClientProvider client={qc}><InvestorKycDocumentsPanel /></QueryClientProvider>);
}

function choose(name: string, size: number, type = "application/pdf") {
  const file = new File(["%PDF-1.4\n"], name, { type });
  // Metadata-only size fixture: no 10 MiB buffer allocation.
  Object.defineProperty(file, "size", { configurable: true, value: size });
  fireEvent.change(screen.getByTestId("investor-kyc-file"), { target: { files: [file] } });
  return file;
}

function submit() { fireEvent.click(screen.getByTestId("investor-kyc-upload")); }

beforeEach(() => {
  reads = [];
  mode = "success";
  postBodies = [];
  fetchImpl = async (input, init) => {
    const url = String(input);
    if (url.endsWith(endpoint) && init?.method === "POST") {
      const body = JSON.parse(String(init.body)) as Record<string, unknown>;
      postBodies.push(body);
      return json({ ok: true, document: {
        id: "kycd_synthetic", investorId: "u_synthetic", kycId: null,
        docType: body.docType, fileName: body.fileName, mimeType: body.mimeType,
        sizeBytes: 9, sha256: "a".repeat(64), verified: false,
        verifiedBy: null, verifiedAt: null, verificationNotes: null,
        uploadedAt: "2026-09-23T00:00:00.000Z",
      } }, 201);
    }
    if (url.endsWith(endpoint) && (!init?.method || init.method === "GET")) return json({ ok: true, documents: [] });
    throw new Error(`Unexpected test request: ${url}`);
  };
  vi.stubGlobal("fetch", vi.fn((input: RequestInfo | URL, init?: RequestInit) => fetchImpl(input, init)));
  vi.stubGlobal("FileReader", Reader);
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("S2 investor KYC upload safety — actual panel", () => {
  it("shares the server's accept/size policy and refuses >10 MiB before reading or POST", async () => {
    expect(MAX_KYC_RAW_BYTES).toBe(10 * 1024 * 1024);
    mount();
    expect(screen.getByTestId("investor-kyc-file").getAttribute("accept")).toBe(KYC_ACCEPT);
    choose("too-large.pdf", MAX_KYC_RAW_BYTES + 1);
    submit();
    expect((await screen.findByTestId("investor-kyc-refusal")).textContent).toMatch(/10 MB|too large/i);
    expect(reads).toHaveLength(0);
    expect(postBodies).toHaveLength(0);
    expect(screen.queryByTestId("investor-kyc-uploaded")).toBeNull();
  });

  it("refuses zero bytes before FileReader and never reports success", async () => {
    mount(); choose("empty.pdf", 0); submit();
    expect((await screen.findByTestId("investor-kyc-refusal")).textContent).toMatch(/empty/i);
    expect(reads).toHaveLength(0);
    expect(postBodies).toHaveLength(0);
    expect(screen.queryByTestId("investor-kyc-uploaded")).toBeNull();
  });

  it.each(["error", "abort"] as const)("handles FileReader %s with no request or positive upload", async (event) => {
    mode = event;
    mount(); choose("unreadable.pdf", 9); submit();
    expect(await screen.findByTestId("investor-kyc-refusal")).toBeTruthy();
    expect(reads).toEqual(["unreadable.pdf"]);
    expect(postBodies).toHaveLength(0);
    expect(screen.queryByTestId("investor-kyc-uploaded")).toBeNull();
  });

  it("maps a non-JSON proxy 413 through real apiRequest without displaying raw text", async () => {
    const proxySecret = "PROXY_INTERNAL_HTML_DO_NOT_SHOW";
    fetchImpl = async (_input, init) => init?.method === "POST"
      ? new Response(`<html>${proxySecret}</html>`, { status: 413, headers: { "content-type": "text/html" } })
      : json({ ok: true, documents: [] });
    mount(); choose("small.pdf", 9); submit();
    expect((await screen.findByTestId("investor-kyc-refusal")).textContent).toMatch(/10 MB|too large|limit/i);
    expect(document.body.textContent).not.toContain(proxySecret);
    expect(screen.queryByTestId("investor-kyc-uploaded")).toBeNull();
  });

  it("locks repeated click while pending so only one POST occurs", async () => {
    let release!: (res: Response) => void;
    const pending = new Promise<Response>((resolve) => { release = resolve; });
    fetchImpl = async (_input, init) => {
      if (init?.method === "POST") { postBodies.push(JSON.parse(String(init.body))); return pending; }
      return json({ ok: true, documents: [] });
    };
    mount(); choose("one.pdf", 9); submit();
    await waitFor(() => expect(postBodies).toHaveLength(1));
    expect(screen.getByTestId("investor-kyc-upload")).toHaveProperty("disabled", true);
    submit();
    expect(postBodies).toHaveLength(1);
    release(json({ ok: false, error: "insert_failed" }, 500));
    expect(await screen.findByTestId("investor-kyc-refusal")).toBeTruthy();
  });

  it("does not reflect an unknown error's raw server string or malformed success as an upload", async () => {
    const rawSecret = "internal database connection and private file path";
    fetchImpl = async (_input, init) => init?.method === "POST"
      ? json({ ok: false, error: rawSecret, message: rawSecret }, 500)
      : json({ ok: true, documents: [] });
    const view = mount(); choose("fail.pdf", 9); submit();
    expect(await screen.findByTestId("investor-kyc-refusal")).toBeTruthy();
    expect(document.body.textContent).not.toContain(rawSecret);
    expect(screen.queryByTestId("investor-kyc-uploaded")).toBeNull();
    view.unmount();
    fetchImpl = async (_input, init) => init?.method === "POST"
      ? json({ ok: true, document: { fileName: "missing-id.pdf", verified: true } }, 200)
      : json({ ok: true, documents: [] });
    mount(); choose("fail2.pdf", 9); submit();
    expect(await screen.findByTestId("investor-kyc-refusal")).toBeTruthy();
    expect(screen.queryByTestId("investor-kyc-uploaded")).toBeNull();
    expect(screen.queryByText("Verified")).toBeNull();
  });

  it("shows a stored upload fact, not verification, even when subsequent GET fails", async () => {
    let getCount = 0;
    fetchImpl = async (_input, init) => {
      if (init?.method === "POST") {
        postBodies.push(JSON.parse(String(init.body)));
        return json({ ok: true, document: {
          id: "kycd_synthetic", fileName: "pending.pdf", verified: false,
          investorId: "u_synthetic", kycId: null, docType: "passport",
          mimeType: "application/pdf", sizeBytes: 9, sha256: "a".repeat(64),
          verifiedBy: null, verifiedAt: null, verificationNotes: null,
          uploadedAt: "2026-09-23T00:00:00.000Z",
        } }, 201);
      }
      getCount++;
      return getCount === 1 ? json({ ok: true, documents: [] }) : json({ ok: false, error: "read_failed" }, 500);
    };
    mount(); choose("pending.pdf", 9); submit();
    expect((await screen.findByTestId("investor-kyc-uploaded")).textContent).toContain("pending.pdf");
    await waitFor(() => expect(getCount).toBeGreaterThan(1));
    expect(await screen.findByTestId("investor-kyc-list-error")).toBeTruthy();
    expect(screen.getByTestId("investor-kyc-uploaded").textContent).toContain("pending.pdf");
    expect(screen.queryByText("Verified")).toBeNull();
    expect(postBodies).toHaveLength(1);
    expect(postBodies[0]).toMatchObject({ docType: "passport", fileName: "pending.pdf", mimeType: "application/pdf" });
  });
});
