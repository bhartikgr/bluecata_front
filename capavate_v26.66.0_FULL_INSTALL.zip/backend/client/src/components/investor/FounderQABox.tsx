/**
 * Sprint 21 Wave B — B7: FounderQABox
 *
 * "Ask the founder" box displayed on the Overview tab.
 *
 * Fetches GET /api/rounds/:roundId/founder-qa (last 10 messages)
 * POST /api/rounds/:roundId/founder-qa to send a question.
 *
 * DB-current polling every 30s; no realtime or delivery guarantee.
 * Founder view reuses the existing private Messages recipient/policy contract.
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLayoutEffect, useRef, useState, type MutableRefObject } from "react";
import { useLocation } from "wouter";
import { apiRequest, ApiError } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { MessageCircle, Send } from "lucide-react";
import { fmtDate } from "@/lib/format";
import { useToast } from "@/hooks/use-toast";
import { useEntitlement } from "@/lib/entitlement";

interface QAMessage {
  id: string;
  channelId: string;
  authorId: string;
  authorName: string;
  authorRole: "founder" | "investor";
  body: string;
  publicWithinRound: boolean;
  createdAt: string;
}

interface QAResponse {
  roundId: string;
  messages: QAMessage[];
  channelId: string;
}

interface Props {
  roundId: string;
  founderView?: boolean;
}

type Context = { roundId: string; authorId: string | null };
type Attempt = { key: string; body: string; publicWithinRound: boolean; roundId: string; authorId: string };
type DmAttempt = { targetUserId: string; roundId: string; authorId: string };
const isObject = (v: unknown): v is Record<string, unknown> =>
  v !== null && typeof v === "object" && !Array.isArray(v);
function isMessage(v: unknown): v is QAMessage {
  return isObject(v) &&
    ["id", "channelId", "authorId", "authorName", "body", "createdAt"].every((k) => typeof v[k] === "string" && String(v[k]).trim().length > 0) &&
    (v.authorRole === "founder" || v.authorRole === "investor") &&
    typeof v.publicWithinRound === "boolean" && Number.isFinite(Date.parse(String(v.createdAt)));
}
function requestKey(): string {
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  return `qa-${Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("")}`;
}
function isRoundChannel(channelId: unknown, roundId: string): channelId is string {
  // Preserve the delivered metadata generator, including its unknown fallback.
  const match = roundId.match(/^rnd_([a-z0-9]+)_/);
  return channelId === `qa_co_${match ? `co_${match[1]}` : "unknown"}_${roundId}`;
}

export default function FounderQABox(props: Props) {
  const { data: ctx } = useEntitlement();
  const authorId = ctx?.isAuthed === true && typeof ctx.userId === "string" && ctx.userId.trim()
    ? ctx.userId : null;
  // Transient unknown identity disables the same actor's box, but does not
  // discard its retry key. A confirmed different actor receives a fresh box.
  const ownerRef = useRef<string | null>(null);
  if (authorId) ownerRef.current = authorId;
  const context = useRef<Context>({ roundId: props.roundId, authorId });
  context.current = { roundId: props.roundId, authorId };
  return <QaThread key={JSON.stringify([props.roundId, ownerRef.current])} {...props}
    authorId={authorId} context={context} />;
}

function QaThread({ roundId, founderView = false, authorId, context }: Props & {
  authorId: string | null; context: MutableRefObject<Context>;
}) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [questionBody, setQuestionBody] = useState("");
  const [makePublic, setMakePublic] = useState(true);
  const attemptRef = useRef<Attempt | null>(null);
  const [attempt, setAttempt] = useState<Attempt | null>(null);
  const [saveError, setSaveError] = useState("");
  const [dmError, setDmError] = useState("");
  const live = useRef(false);
  useLayoutEffect(() => {
    live.current = true;
    return () => { live.current = false; };
  }, []);
  const isCurrent = (sent: Context) => live.current && sent.authorId !== null &&
    context.current.authorId === sent.authorId && context.current.roundId === sent.roundId;
  const isCurrentAttempt = (sent: Attempt) => isCurrent(sent) && attemptRef.current === sent;
  const queryKey = ["/api/rounds", roundId, "founder-qa", authorId];

  const { data, isLoading, isError, refetch } = useQuery<QAResponse>({
    queryKey,
    queryFn: async () => {
      const reading = { roundId, authorId };
      if (!isCurrent(reading)) throw new Error("Q&A identity unavailable");
      const res = await apiRequest("GET", `/api/rounds/${roundId}/founder-qa`);
      if (!res.ok) throw new Error("Q&A unavailable");
      const value: unknown = await res.json();
      if (!isCurrent(reading) || !isObject(value) || value.roundId !== roundId || !isRoundChannel(value.channelId, roundId) ||
          !Array.isArray(value.messages) || !value.messages.every((msg) =>
            isMessage(msg) && msg.channelId === value.channelId)) throw new Error("Q&A response unavailable");
      return value as unknown as QAResponse;
    },
    enabled: !!roundId && !!authorId,
    // Events are not cross-worker delivery evidence. Every poll reads the DB.
    refetchInterval: 30_000,
    retry: false,
  });

  const sendMutation = useMutation({
    mutationFn: async (sent: Attempt) => {
      if (!isCurrentAttempt(sent)) throw new Error("Q&A context changed");
      const res = await apiRequest("POST", `/api/rounds/${sent.roundId}/founder-qa`, {
        body: sent.body,
        publicWithinRound: sent.publicWithinRound,
      }, { "Idempotency-Key": sent.key });
      const value: unknown = await res.json();
      // A transport 2xx alone is not a durable acknowledgement. Retain the
      // draft/key for retry on malformed, truncated or unexpected success.
      if (res.status !== 201 || !isObject(value) ||
          Object.keys(value).sort().join(",") !== "message,ok" || value.ok !== true ||
          !isMessage(value.message) ||
          Object.keys(value.message).sort().join(",") !== "authorId,authorName,authorRole,body,channelId,createdAt,id,publicWithinRound" ||
          value.message.authorId !== sent.authorId || !isRoundChannel(value.message.channelId, sent.roundId) ||
          value.message.body !== sent.body || value.message.publicWithinRound !== sent.publicWithinRound) {
        throw new Error("The save acknowledgement could not be verified.");
      }
      return value.message;
    },
    onSuccess: (_message, sent) => {
      if (!isCurrentAttempt(sent)) return;
      attemptRef.current = null;
      setAttempt(null);
      setSaveError("");
      toast({ title: founderView ? "Reply saved to round Q&A" : "Question saved to round Q&A" });
      setQuestionBody("");
      // Invalidate to refresh the thread
      queryClient.invalidateQueries({ queryKey: ["/api/rounds", sent.roundId, "founder-qa", sent.authorId] });
    },
    onError: (err: Error, sent) => {
      if (!isCurrentAttempt(sent)) return;
      const conflict = err instanceof ApiError && (err.code === "qa_request_conflict" || err.code === "qa_message_deleted");
      setSaveError(conflict
        ? "This request cannot be saved again. Reload Q&A before starting a new message. Your draft is retained."
        : "Save not confirmed. Your draft is retained. Retry the same request; it will not create a second saved message.");
    },
    retry: false,
  });

  const privateReply = useMutation({
    mutationFn: async (sent: DmAttempt) => {
      if (!isCurrent(sent)) throw new Error("Q&A context changed");
      const res = await apiRequest("POST", "/api/comms/dm/start", { targetUserId: sent.targetUserId });
      const value: unknown = await res.json();
      if (!res.ok || !isObject(value) || value.ok !== true || typeof value.channelId !== "string" || !value.channelId.startsWith("dm__")) {
        throw new Error("A private conversation could not be opened.");
      }
      return value.channelId;
    },
    onSuccess: (channelId, sent) => {
      if (!isCurrent(sent)) return;
      setDmError("");
      // No question/reply text is transferred into the private conversation.
      setLocation(`/founder/messages?thread=${encodeURIComponent(channelId)}&channel=${encodeURIComponent(channelId)}`);
    },
    onError: (err: Error, sent) => {
      if (isCurrent(sent)) setDmError(err instanceof ApiError ? err.message : "A private conversation could not be opened. Please retry.");
    },
    retry: false,
  });

  const handleSend = () => {
    if (sendMutation.isPending || !authorId || !isCurrent({ roundId, authorId })) return;
    if (attemptRef.current) {
      if (!isCurrentAttempt(attemptRef.current)) return;
      setSaveError("");
      sendMutation.mutate(attemptRef.current);
      return;
    }
    if (!questionBody.trim()) {
      toast({ title: "Please type a question", variant: "destructive" });
      return;
    }
    try {
      const sent = { key: requestKey(), body: questionBody.trim(), publicWithinRound: founderView ? true : makePublic, roundId, authorId };
      attemptRef.current = sent;
      setAttempt(sent);
      setSaveError("");
      sendMutation.mutate(sent);
    } catch {
      setSaveError("A safe request key could not be created. Your draft has not been submitted.");
    }
  };

  return (
    <Card data-testid="founder-qa-box">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <MessageCircle className="h-4 w-4 text-[hsl(0_100%_40%)]" />
          {founderView ? "Round Q&A" : "Ask the founder"}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-xs text-muted-foreground">
          Latest 10 messages visible to you. Refreshes every 30 seconds. Saved does not mean read or delivered.
        </p>
        {!authorId && <p role="alert" className="text-sm" data-testid="qa-identity-unavailable">Q&A is paused until your signed-in identity can be verified.</p>}
        {authorId && isError && (
          <div role="alert" className="text-sm space-y-2" data-testid="qa-read-error">
            <p>Q&A could not be loaded. This does not mean the round has no questions.</p>
            <Button type="button" variant="outline" size="sm" onClick={() => void refetch()}>Reload Q&A</Button>
          </div>
        )}
        {authorId && dmError && <p role="alert" className="text-sm" data-testid="qa-dm-error">{dmError}</p>}
        {/* Message thread */}
        <div className="space-y-3 max-h-72 overflow-y-auto" data-testid="qa-thread">
          {authorId && isLoading && (
            <div className="space-y-2">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-4/5" />
            </div>
          )}

          {authorId && !isLoading && !isError && data?.messages.length === 0 && (
            <p className="text-sm text-muted-foreground py-4 text-center" data-testid="qa-empty-state">
              No questions yet. Start the conversation.
            </p>
          )}

          {authorId && !isLoading && !isError &&
            data?.messages?.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.authorRole === "founder" ? "flex-row-reverse" : ""}`}
                data-testid={`qa-message-${msg.id}`}
              >
                {/* Avatar */}
                <div
                  className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 ${
                    msg.authorRole === "founder"
                      ? "bg-[hsl(0_100%_40%)] text-white"
                      : "bg-[hsl(219_45%_20%)] text-white"
                  }`}
                >
                  {msg.authorName
                    .split(" ")
                    .map((s) => s[0])
                    .slice(0, 2)
                    .join("")}
                </div>

                {/* Bubble */}
                <div
                  className={`flex-1 rounded-lg p-3 text-sm ${
                    msg.authorRole === "founder"
                      ? "bg-[hsl(0_100%_40%)]/10 border border-[hsl(0_100%_40%)]/20"
                      : "bg-secondary border border-border"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1 gap-2">
                    <span className="font-medium text-xs">{msg.authorName}</span>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {fmtDate(msg.createdAt)}
                    </span>
                  </div>
                  <p className="leading-relaxed">{msg.body}</p>
                  {!msg.publicWithinRound && (
                    <span className="mt-1 inline-block text-xs text-muted-foreground">
                      Private — visible to its author, current company members and administrators.
                    </span>
                  )}
                  {founderView && msg.authorRole === "investor" && (
                    <Button type="button" variant="outline" size="sm" className="mt-2"
                      disabled={privateReply.isPending}
                      onClick={() => {
                        if (!authorId || !isCurrent({ roundId, authorId })) return;
                        setDmError(""); privateReply.mutate({ targetUserId: msg.authorId, roundId, authorId });
                      }}
                      data-testid={`qa-private-reply-${msg.id}`}>
                      Reply privately in Messages
                    </Button>
                  )}
                </div>
              </div>
            ))}
        </div>

        {/* Composer */}
        <div className="space-y-2 pt-2 border-t border-border">
          {founderView && <p className="text-xs text-muted-foreground">Replies here are public to eligible round participants. Use “Reply privately in Messages” for a private conversation.</p>}
          <Textarea
            rows={3}
            aria-label={founderView ? "Public reply to round Q&A" : "Question for the founder"}
            placeholder={founderView ? "Write a public reply to round Q&A…" : "Type your question for the founder…"}
            value={authorId ? questionBody : ""}
            onChange={(e) => setQuestionBody(e.target.value)}
            disabled={!authorId || attempt !== null}
            maxLength={1000}
            data-testid="qa-input"
            className="resize-none"
          />
          <div className="text-right text-xs text-muted-foreground">
            {authorId ? questionBody.length : 0}/1000
          </div>
          <div className="flex items-center justify-between">
            {!founderView && <label className="flex items-center gap-2 text-xs cursor-pointer" data-testid="qa-public-label">
              <Checkbox
                checked={makePublic}
                onCheckedChange={(v) => setMakePublic(!!v)}
                disabled={!authorId || attempt !== null}
                data-testid="qa-public-checkbox"
              />
              <span className="text-muted-foreground">Make my question public to eligible round participants</span>
            </label>}
            <Button
              size="sm"
              onClick={handleSend}
              disabled={!authorId || sendMutation.isPending || !questionBody.trim()}
              className="bg-[hsl(0_100%_40%)] hover:bg-[hsl(0_100%_32%)] text-white gap-2"
              data-testid="button-send-question"
            >
              <Send className="h-3.5 w-3.5" />
              {sendMutation.isPending ? "Saving…" : attempt ? "Retry same save" : founderView ? "Save public reply" : "Save question"}
            </Button>
          </div>
          {authorId && saveError && <p role="alert" className="text-sm" data-testid="qa-save-error">{saveError}</p>}
          {authorId && attempt && !sendMutation.isPending && (
            <div className="space-y-2 text-xs text-muted-foreground">
              <p>Starting a new message may duplicate an earlier save. Check Q&A first. Leaving this page discards the local retry key and draft.</p>
              <Button type="button" variant="outline" size="sm" onClick={() => void refetch()}>Reload Q&A</Button>
              <Button type="button" variant="ghost" size="sm" data-testid="qa-new-intent"
                onClick={() => { attemptRef.current = null; setAttempt(null); setSaveError(""); }}>
                Edit as a new message
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
