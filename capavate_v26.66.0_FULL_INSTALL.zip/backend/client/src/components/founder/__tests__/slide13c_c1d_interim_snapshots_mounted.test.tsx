/**
 * Slide 13C · C1D — mounted opt-in rendering of CapTableInterim / CapTableSnapshots.
 *
 * `apiRequest` is mocked (the same seam as the existing w55b/w90/w60 suites);
 * every success Response carries the real proof headers and server-shaped
 * sidecars. Asserts exact-decimal cells, provenance, four-state late-mark copy,
 * own-only percentage refusal, commit note (including the unproved funded
 * Commit control), timestamp withholding, the fault panel on any proof failure,
 * and the A→B→A generation key with the B render observed before A is revisited
 * and the stale visit-1 release flushed inside act.
 */
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, waitFor, act } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  COPY,
  buildSubtotal,
  recordedFact,
  type ExactMoneyFactV1,
} from "@shared/capTableInterimSnapshotMoney";

vi.mock("@/hooks/use-toast", () => ({ useToast: () => ({ toast: vi.fn() }) }));
const apiRequestMock = vi.fn();
vi.mock("@/lib/queryClient", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queryClient")>("@/lib/queryClient");
  return { ...actual, apiRequest: (...args: unknown[]) => apiRequestMock(...args) };
});

import { CapTableInterim } from "../CapTableInterim";
import CapTableSnapshots from "../CapTableSnapshots";

const PROOF = { "x-captable-display-truth": "1", "cache-control": "no-store" };
function respond(body: unknown, headers: Record<string, string> = PROOF): Response {
  return {
    ok: true, status: 200, headers: { get: (n: string) => headers[n.toLowerCase()] ?? null },
    json: async () => body, text: async () => JSON.stringify(body),
  } as unknown as Response;
}
const usd = (minor: bigint, evidence: "stored_code" | "stored_code_default_or_explicit" = "stored_code") =>
  recordedFact(minor, "USD", 2, evidence);
const committedRow = (inv: string, amount: number, fact: ExactMoneyFactV1, extra: object = {}) => ({
  investorId: `u_${inv}`, holderName: `Holder ${inv}`, roundId: "rnd_1", roundName: "Seed", amount, currency: "USD",
  shares: 100, kind: "committed", invitationId: inv, acceptedAfterClose: false, lateAcceptance: null,
  displayMoney: { version: 1, source: { kind: "ledger_committed", rowRef: inv }, amount: fact },
  displayLateMark: { version: 1, state: "none_on_record" }, ...extra,
});
function interimBody(companyId: string, own: boolean, committed: any[], funded: any[] = [], soft: any[] = []) {
  return {
    companyId, committed, funded, soft_circle: soft,
    subtotals: { committed: { count: committed.length, amount: 0, shares: 0 }, funded: { count: funded.length, amount: 0, shares: 0 }, soft_circle: { count: soft.length, amount: 0, shares: 0 } },
    ownershipBasis: "committed_ledger_shares",
    ownershipBasisLabel: "committed shares on this company's ledger",
    ownershipBasisSentence: own ? COPY.ownOnlyBasisSentence : "Percentages are each holder's share of committed shares.",
    displayTruth: own
      ? { version: 1, companyId, endpoint: "interim", scope: "own_position_only", ownership: "withheld_own_position" }
      : { version: 1, companyId, endpoint: "interim", scope: "full", ownership: "legacy_committed_basis_visible" },
    displaySubtotals: {
      committed: buildSubtotal(committed.map((r) => r.displayMoney.amount)),
      funded: buildSubtotal(funded.map((r) => r.displayMoney.amount)),
      soft_circle: buildSubtotal(soft.map((r) => r.displayMoney.amount)),
    },
  };
}
/** Release a stale response and let every microtask/macrotask it schedules drain inside act. */
async function flushStale(release: () => void) {
  await act(async () => {
    release();
    for (let i = 0; i < 5; i++) await new Promise((r) => setTimeout(r, 0));
  });
}
function mount(ui: React.ReactElement) {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } });
  return { qc, ...render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>) };
}
afterEach(() => { cleanup(); apiRequestMock.mockReset(); });

describe("C1D interim — opt-in request and exact rendering", () => {
  it("requests ?displayTruth=1 and renders the exact recorded decimal, never a rounded float", async () => {
    apiRequestMock.mockImplementation(async () =>
      respond(interimBody("co_c1d", false, [committedRow("inv_a", 1234.5, usd(123450n), { ownershipPct: 12.5 })])));
    mount(<CapTableInterim companyId="co_c1d" readOnly />);
    expect(await screen.findByTestId("interim-amount-committed-0")).toBeTruthy();
    expect(apiRequestMock.mock.calls[0][1]).toBe("/api/companies/co_c1d/captable/interim?displayTruth=1");
    expect(screen.getByTestId("interim-amount-committed-0").textContent).toBe("1,234.50 USD");
    expect(screen.getByTestId("interim-subtotal-amount-committed").textContent).toBe("1,234.50 USD");
    expect(screen.getByTestId("interim-own-committed-0").textContent).toBe("12.50%");
  });

  it("own-position scope: Own % refusal cell, withheld header basis and refusal sentence; no percentage anywhere", async () => {
    apiRequestMock.mockImplementation(async () =>
      respond(interimBody("co_c1d", true, [committedRow("inv_a", 100, usd(10000n))])));
    mount(<CapTableInterim companyId="co_c1d" readOnly />);
    expect(await screen.findByText(COPY.ownOnlyBasisSentence)).toBeTruthy();
    expect(screen.getByTestId("interim-own-committed-0").textContent).toBe(COPY.ownOnlyPercentCell);
    expect(screen.getByTestId("interim-own-basis-committed").textContent).toBe(COPY.ownOnlyHeaderBasis);
    expect(document.body.textContent ?? "").not.toMatch(/\d+\.\d+%/);
  });

  it.each([
    ["recorded"], ["none_on_record"], ["recorded_revoked"], ["recorded_nonqualifying"],
  ] as const)("late mark %s renders its exact qualified copy", async (state) => {
    apiRequestMock.mockImplementation(async () =>
      respond(interimBody("co_c1d", false, [committedRow("inv_a", 1, usd(100n), { displayLateMark: { version: 1, state } })])));
    mount(<CapTableInterim companyId="co_c1d" readOnly />);
    expect((await screen.findByTestId("interim-late-committed-0")).textContent).toBe(COPY.lateMark[state]);
  });

  it("soft-circle recorded code shows the default-or-explicit provenance; unproven rows show a label and a partial subtotal", async () => {
    const soft = {
      investorId: "u_s", holderName: "Soft Holder", roundId: "rnd_1", amount: 5, currency: "USD", shares: 0,
      kind: "soft_circle", softCircleId: "sc_1", status: "confirmed", acceptedAfterClose: false, lateAcceptance: null,
      displayMoney: { version: 1, source: { kind: "soft_circle_confirmed", rowRef: "sc_1" }, amount: usd(500n, "stored_code_default_or_explicit") },
      displayLateMark: { version: 1, state: "none_on_record" },
    };
    const unproven = committedRow("inv_b", 7, { state: "unproved" });
    apiRequestMock.mockImplementation(async () =>
      respond(interimBody("co_c1d", false, [committedRow("inv_a", 1, usd(100n)), unproven], [], [soft])));
    mount(<CapTableInterim companyId="co_c1d" readOnly />);
    expect((await screen.findByTestId("interim-amount-soft_circle-0-provenance")).textContent).toBe(COPY.softCircleCurrencyProvenance);
    expect(screen.getByTestId("interim-amount-committed-1").textContent).toBe(COPY.amountNotVerified);
    expect(screen.getByTestId("interim-subtotal-amount-committed").textContent).toContain(COPY.subtotalPartialSuffix);
  });

  it("funded Commit action keeps its behaviour and gains only a display note on mismatch", async () => {
    const funded = {
      investorId: "u_f", holderName: "Funded Holder", roundId: "rnd_1", amount: 100.001, currency: "USD", shares: 1,
      kind: "funded", invitationId: "inv_f", acceptedAfterClose: false, lateAcceptance: null,
      displayMoney: { version: 1, source: { kind: "funded_queue", rowRef: "inv_f" }, amount: usd(10000n) },
      displayLateMark: { version: 1, state: "none_on_record" },
    };
    apiRequestMock.mockImplementation(async () => respond(interimBody("co_c1d", false, [], [funded])));
    mount(<CapTableInterim companyId="co_c1d" />);
    expect(await screen.findByTestId("button-commit-now-inv_f")).toBeTruthy();
    expect(screen.getByTestId("interim-commit-note-0").textContent).toBe(COPY.recordedActionMismatch);
  });

  it.each([
    ["missing proof header", {}, undefined],
    ["cache-control without no-store", { "x-captable-display-truth": "1", "cache-control": "max-age=5" }, undefined],
    ["wrong company binding", PROOF, "co_other"],
  ] as const)("%s → fault panel and no figure", async (_label, headers, bodyCompany) => {
    apiRequestMock.mockImplementation(async () =>
      respond(interimBody(bodyCompany ?? "co_c1d", false, [committedRow("inv_a", 1, usd(100n))]), headers as Record<string, string>));
    mount(<CapTableInterim companyId="co_c1d" readOnly />);
    const panel = await screen.findByTestId("captable-interim-error");
    expect(panel.textContent ?? "").not.toMatch(/USD|\$|\d+\.\d{2}/);
    expect(screen.queryByTestId("interim-amount-committed-0")).toBeNull();
  });

  it("A→B→A (delayed): a late visit-1 response never replaces the visit-3 render; every visit has its own key", async () => {
    const pending: Array<{ url: string; resolve: (r: Response) => void }> = [];
    apiRequestMock.mockImplementation((_m: string, url: string) =>
      new Promise<Response>((resolve) => pending.push({ url, resolve })));
    const { qc, rerender } = mount(<CapTableInterim companyId="co_a" readOnly />);
    await waitFor(() => expect(pending).toHaveLength(1));
    rerender(<QueryClientProvider client={qc}><CapTableInterim companyId="co_b" readOnly /></QueryClientProvider>);
    await waitFor(() => expect(pending).toHaveLength(2));
    pending[1].resolve(respond(interimBody("co_b", false, [committedRow("inv_b", 2, usd(200n))])));
    /* The B render is OBSERVED before A is revisited. */
    expect((await screen.findByTestId("interim-amount-committed-0")).textContent).toBe("2.00 USD");
    rerender(<QueryClientProvider client={qc}><CapTableInterim companyId="co_a" readOnly /></QueryClientProvider>);
    await waitFor(() => expect(pending).toHaveLength(3));
    expect(pending.map((p) => p.url)).toEqual([
      "/api/companies/co_a/captable/interim?displayTruth=1",
      "/api/companies/co_b/captable/interim?displayTruth=1",
      "/api/companies/co_a/captable/interim?displayTruth=1",
    ]);
    pending[2].resolve(respond(interimBody("co_a", false, [committedRow("inv_a3", 3, usd(300n))])));
    await waitFor(() => expect(screen.getByTestId("interim-amount-committed-0").textContent).toBe("3.00 USD"));
    await flushStale(() => pending[0].resolve(respond(interimBody("co_a", false, [committedRow("inv_a1", 1, usd(100n))]))));
    expect(screen.getByTestId("interim-amount-committed-0").textContent).toBe("3.00 USD");
    expect(document.body.textContent ?? "").not.toContain("1.00 USD");
    const aKeys = qc.getQueryCache().getAll().map((q) => JSON.stringify(q.queryKey)).filter((k) => k.includes('"co_a"'));
    expect(new Set(aKeys).size).toBe(2);
    expect(aKeys.every((k) => k.includes('"display-truth",1'))).toBe(true);
  });

  it.each([
    ["recorded fact whose decimal disagrees with its minor", { state: "recorded", currencyCode: "USD", minorUnitExponent: 2, minor: "100", decimal: "1.01", denominationEvidence: "stored_code" }],
    ["unknown money state", { state: "estimated" }],
  ] as const)("malformed sidecar (%s) → fault panel, no figure", async (_label, amount) => {
    const bad = committedRow("inv_a", 1, amount as unknown as ExactMoneyFactV1);
    apiRequestMock.mockImplementation(async () => respond(interimBody("co_c1d", false, [bad])));
    mount(<CapTableInterim companyId="co_c1d" readOnly />);
    const panel = await screen.findByTestId("captable-interim-error");
    expect(panel.textContent ?? "").not.toMatch(/USD|\$|\d+\.\d{2}/);
    expect(screen.queryByTestId("interim-amount-committed-0")).toBeNull();
  });
});

describe("C1D interim — actions keep their exact request bytes and enablement", () => {
  const funded = (inv: string, amount: number, shares: number) => ({
    investorId: `u_${inv}`, holderName: `Funded ${inv}`, roundId: "rnd_1", amount, currency: "USD", shares,
    kind: "funded", invitationId: inv, acceptedAfterClose: false, lateAcceptance: null,
    displayMoney: { version: 1, source: { kind: "funded_queue", rowRef: inv }, amount: usd(10000n) },
    displayLateMark: { version: 1, state: "none_on_record" },
  });
  const soft = (id: string, status: string) => ({
    investorId: `u_${id}`, holderName: `Soft ${id}`, roundId: "rnd_1", amount: 5, currency: "USD", shares: 0,
    kind: "soft_circle", softCircleId: id, status, acceptedAfterClose: false, lateAcceptance: null,
    displayMoney: { version: 1, source: { kind: "soft_circle_confirmed", rowRef: id }, amount: usd(500n, "stored_code_default_or_explicit") },
    displayLateMark: { version: 1, state: "none_on_record" },
  });
  const posts = () => apiRequestMock.mock.calls.filter((c) => c[0] === "POST").map((c) => [c[1], JSON.stringify(c[2])]);
  const ok = () => ({ ok: true, status: 200, headers: { get: () => null }, json: async () => ({ ok: true }) }) as unknown as Response;

  it("commit-now posts the legacy row values (String(amount), never the display decimal)", async () => {
    apiRequestMock.mockImplementation(async (m: string) =>
      m === "POST" ? ok() : respond(interimBody("co_c1d", false, [], [funded("inv_f", 100.001, 7)])));
    mount(<CapTableInterim companyId="co_c1d" />);
    const btn = await screen.findByTestId("button-commit-now-inv_f");
    expect((btn as HTMLButtonElement).disabled).toBe(false);
    btn.click();
    await waitFor(() => expect(posts()).toHaveLength(1));
    expect(posts()[0]).toEqual(["/api/founder/captable/commit-funded", JSON.stringify({
      invitationId: "inv_f", roundId: "rnd_1", companyId: "co_c1d", investorId: "u_inv_f",
      amount: "100.001", currency: "USD", shares: "7", fromState: "funded",
    })]);
  });

  it("unproved funded amount: Commit stays enabled, note and cell are exactly amountNotVerified, click posts the exact legacy body", async () => {
    const row = { ...funded("inv_u", 42.5, 3),
      displayMoney: { version: 1, source: { kind: "funded_queue", rowRef: "inv_u" }, amount: { state: "unproved" } } };
    apiRequestMock.mockImplementation(async (m: string) =>
      m === "POST" ? ok() : respond(interimBody("co_c1d", false, [], [row])));
    mount(<CapTableInterim companyId="co_c1d" />);
    const btn = await screen.findByTestId("button-commit-now-inv_u");
    /* Enablement depends only on commitOne.isPending (CapTableInterim.tsx:348), never on the display fact. */
    expect((btn as HTMLButtonElement).disabled).toBe(false);
    expect(screen.getByTestId("interim-commit-note-0").textContent).toBe(COPY.amountNotVerified);
    expect(screen.getByTestId("interim-amount-funded-0").textContent).toBe(COPY.amountNotVerified);
    btn.click();
    await waitFor(() => expect(posts()).toHaveLength(1));
    expect(posts()[0]).toEqual(["/api/founder/captable/commit-funded", JSON.stringify({
      invitationId: "inv_u", roundId: "rnd_1", companyId: "co_c1d", investorId: "u_inv_u",
      amount: String(42.5), currency: "USD", shares: "3", fromState: "funded",
    })]);
  });

  it("commit-all posts one batch per funded round with the exact legacy body", async () => {
    apiRequestMock.mockImplementation(async (m: string) =>
      m === "POST" ? ok() : respond(interimBody("co_c1d", false, [], [funded("inv_f", 1, 1)])));
    mount(<CapTableInterim companyId="co_c1d" />);
    const btn = await screen.findByTestId("button-commit-all-funded");
    expect((btn as HTMLButtonElement).disabled).toBe(false);
    btn.click();
    await waitFor(() => expect(posts()).toHaveLength(1));
    expect(posts()[0]).toEqual(["/api/founder/captable/commit-funded-batch", JSON.stringify({ companyId: "co_c1d", roundId: "rnd_1" })]);
  });

  it("wire-funded is enabled only for confirmed rows and posts the exact legacy path and empty body", async () => {
    apiRequestMock.mockImplementation(async (m: string) =>
      m === "POST" ? ok() : respond(interimBody("co_c1d", false, [], [], [soft("sc_ok", "confirmed"), soft("sc_no", "pending")])));
    mount(<CapTableInterim companyId="co_c1d" />);
    const okBtn = await screen.findByTestId("button-wire-funded-sc_ok");
    expect((okBtn as HTMLButtonElement).disabled).toBe(false);
    expect((screen.getByTestId("button-wire-funded-sc_no") as HTMLButtonElement).disabled).toBe(true);
    okBtn.click();
    await waitFor(() => expect(posts()).toHaveLength(1));
    expect(posts()[0]).toEqual(["/api/founder/rounds/rnd_1/soft-circle/sc_ok/wire-funded", "{}"]);
  });

  it("readOnly renders no action button at all", async () => {
    apiRequestMock.mockImplementation(async () =>
      respond(interimBody("co_c1d", false, [], [funded("inv_f", 1, 1)], [soft("sc_ok", "confirmed")])));
    mount(<CapTableInterim companyId="co_c1d" readOnly />);
    await screen.findByTestId("interim-amount-funded-0");
    for (const id of ["button-commit-now-inv_f", "button-commit-all-funded", "button-wire-funded-sc_ok"]) {
      expect(screen.queryByTestId(id)).toBeNull();
    }
  });
});

describe("C1D snapshots — opt-in rendering", () => {
  const position = (id: string, minor: bigint) => ({
    id, holderName: `H ${id}`, instrument: "equity", shares: 10, investmentAmount: Number(minor) / 100, roundId: "rnd_1",
    investorId: `u_${id}`,
    displayMoney: { version: 1, source: { kind: id.startsWith("ccm_sec_") ? "ledger_snapshot" : "base", rowRef: id }, amount: usd(minor) },
  });
  const body = (own: boolean) => ({
    ok: true,
    pending: { hasPending: true, roundIds: ["rnd_1"], roundNames: { rnd_1: "Seed" }, positions: [position("sec_1", 150050n)] },
    previous: { hasPrevious: true, roundId: "rnd_0", roundName: "Pre-seed", committedAt: own ? null : "2026-01-02T00:00:00.000Z",
      positions: [position("ccm_sec_inv_0", 25000000n)] },
    displayTruth: own
      ? { version: 1, companyId: "co_s", endpoint: "snapshots", scope: "own_position_only", ownership: "not_applicable", previousTimestamp: "withheld_own_position" }
      : { version: 1, companyId: "co_s", endpoint: "snapshots", scope: "full", ownership: "not_applicable", previousTimestamp: "legacy_selected_round" },
  });

  it("renders exact decimals and requests the opt-in URL", async () => {
    apiRequestMock.mockImplementation(async () => respond(body(false)));
    mount(<CapTableSnapshots companyId="co_s" sym="$" />);
    expect((await screen.findByTestId("snapshot-row-amount-sec_1")).textContent).toBe("1,500.50 USD");
    expect(apiRequestMock.mock.calls[0][1]).toBe("/api/companies/co_s/captable/snapshots?displayTruth=1");
    expect(screen.queryByTestId("snapshot-previous-timestamp-withheld")).toBeNull();
  });

  it("own-position: the previous card shows the withheld note and no timestamp", async () => {
    apiRequestMock.mockImplementation(async () => respond(body(true)));
    mount(<CapTableSnapshots companyId="co_s" sym="$" />);
    expect((await screen.findByTestId("snapshot-previous-timestamp-withheld")).textContent).toBe(COPY.previousTimestampWithheld);
    expect(screen.getByTestId("snapshot-previous").textContent ?? "").not.toContain("committed 2026");
  });

  it("A→B→A (delayed): a late visit-1 snapshot never replaces the visit-3 render", async () => {
    const pending: Array<{ url: string; resolve: (r: Response) => void }> = [];
    apiRequestMock.mockImplementation((_m: string, url: string) =>
      new Promise<Response>((resolve) => pending.push({ url, resolve })));
    const bodyFor = (c: string, minor: bigint) => {
      const b: any = body(false);
      b.displayTruth.companyId = c;
      b.pending.positions = [position("sec_1", minor)];
      return b;
    };
    const { qc, rerender } = mount(<CapTableSnapshots companyId="co_a" sym="$" />);
    await waitFor(() => expect(pending).toHaveLength(1));
    rerender(<QueryClientProvider client={qc}><CapTableSnapshots companyId="co_b" sym="$" /></QueryClientProvider>);
    await waitFor(() => expect(pending).toHaveLength(2));
    pending[1].resolve(respond(bodyFor("co_b", 200n)));
    /* The B render is OBSERVED before A is revisited. */
    expect((await screen.findByTestId("snapshot-row-amount-sec_1")).textContent).toBe("2.00 USD");
    rerender(<QueryClientProvider client={qc}><CapTableSnapshots companyId="co_a" sym="$" /></QueryClientProvider>);
    await waitFor(() => expect(pending).toHaveLength(3));
    expect(pending.map((p) => p.url)).toEqual([
      "/api/companies/co_a/captable/snapshots?displayTruth=1",
      "/api/companies/co_b/captable/snapshots?displayTruth=1",
      "/api/companies/co_a/captable/snapshots?displayTruth=1",
    ]);
    pending[2].resolve(respond(bodyFor("co_a", 300n)));
    await waitFor(() => expect(screen.getByTestId("snapshot-row-amount-sec_1").textContent).toBe("3.00 USD"));
    await flushStale(() => pending[0].resolve(respond(bodyFor("co_a", 100n))));
    expect(screen.getByTestId("snapshot-row-amount-sec_1").textContent).toBe("3.00 USD");
    expect(document.body.textContent ?? "").not.toContain("1.00 USD");
    const aKeys = qc.getQueryCache().getAll().map((q) => JSON.stringify(q.queryKey)).filter((k) => k.includes('"co_a"'));
    expect(new Set(aKeys).size).toBe(2);
  });

  it.each([
    ["missing hasPending", (b: any) => { delete b.pending.hasPending; }],
    ["non-boolean hasPrevious", (b: any) => { b.previous.hasPrevious = "true"; }],
    ["malformed position money", (b: any) => { b.pending.positions[0].displayMoney.amount = { state: "recorded" }; }],
  ] as const)("malformed snapshots body (%s) → the existing error card, no figure", async (_label, mutate) => {
    const b: any = body(false);
    mutate(b);
    apiRequestMock.mockImplementation(async () => respond(b));
    mount(<CapTableSnapshots companyId="co_s" sym="$" />);
    expect(await screen.findByTestId("snapshots-error")).toBeTruthy();
    expect(screen.queryByTestId("snapshot-row-amount-sec_1")).toBeNull();
  });

  it("proof failure → the existing error card, no figure", async () => {
    apiRequestMock.mockImplementation(async () => respond(body(false), {}));
    mount(<CapTableSnapshots companyId="co_s" sym="$" />);
    expect(await screen.findByTestId("snapshots-error")).toBeTruthy();
    expect(screen.queryByTestId("snapshot-row-amount-sec_1")).toBeNull();
  });
});
