/** S4d missing mounted readers: real CapitalizationJourney and CapTable. */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { getQueryFn } from "@/lib/queryClient";
import CapitalizationJourney from "@/components/CapitalizationJourney";
import CapTable from "@/pages/founder/CapTable";
import { roundMoneyOnRecord } from "../../../../../server/lib/roundRaisedTotals";
import { roundMoneyUnavailable } from "@shared/roundMoneyOnRecordView";
import { ROUND_CURRENCY_NOT_RECORDED_STATEMENT } from "@shared/roundCurrencyOnRecordView";
import { symbolOnRecord } from "@/lib/currencyOnRecordDisplay";

const COMPANY_ID = "co_s4d_mounted";
const ROUND_ID = "rnd_s4d_mounted";
const state = vi.hoisted(() => ({ currency: "CAD" as string | null, wireMoney: null as unknown }));
const apiRequestMock = vi.hoisted(() => vi.fn());

vi.mock("@/hooks/use-toast", () => ({ useToast: () => ({ toast: vi.fn() }) }));
vi.mock("@/components/AppShell", async () => {
  const actual = await vi.importActual<typeof import("@/components/AppShell")>("@/components/AppShell");
  return {
    ...actual,
    PageBody: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
    PageHeader: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  };
});
vi.mock("@/lib/useActiveCompany", () => ({
  useActiveCompanyId: () => COMPANY_ID,
  useActiveCompany: () => ({
    isLoading: false,
    data: {
      activeCompanyId: COMPANY_ID,
      company: { id: COMPANY_ID, companyName: "Synthetic Company", defaultCurrency: state.currency },
    },
  }),
}));
vi.mock("@/lib/queryClient", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queryClient")>("@/lib/queryClient");
  return { ...actual, apiRequest: (...args: unknown[]) => apiRequestMock(...args) };
});
vi.mock("wouter", async () => {
  const actual = await vi.importActual<Record<string, unknown>>("wouter");
  return { ...actual, useLocation: () => ["/founder/captable", vi.fn()] };
});

class ResizeObserverStub {
  observe(): void {}
  unobserve(): void {}
  disconnect(): void {}
}
(globalThis as { ResizeObserver?: unknown }).ResizeObserver ??= ResizeObserverStub;

const normal = roundMoneyOnRecord({
  roundId: ROUND_ID,
  rows: [{ id: "sc_s4d_journey", roundId: ROUND_ID, status: "confirmed", currency: "CAD", amountMinor: 2500800 }],
  roundCurrency: "CAD",
  targetAmount: 250_000,
});
const malformed = { ...normal, subscribedMinor: "NaN" };
const unavailable = roundMoneyUnavailable(ROUND_ID);

const round = () => ({
  id: ROUND_ID, companyId: COMPANY_ID, name: "Synthetic Seed", type: "seed",
  state: "active", currency: "CAD", targetAmount: 250_000, raisedAmount: 0,
  preMoney: 1_000_000, postMoney: 1_250_000, closeDate: "2027-12-31",
  moneyOnRecord: state.wireMoney,
});

const response = (value: unknown): Response => ({
  ok: true, status: 200, json: async () => value,
  text: async () => JSON.stringify(value),
}) as unknown as Response;

beforeEach(() => {
  state.currency = "CAD";
  state.wireMoney = normal;
  apiRequestMock.mockImplementation(async (_method: string, url: string) => {
    if (url.endsWith("/securities")) return response([]);
    if (url.includes("/api/rounds")) return response([round()]);
    if (url.includes("/api/auth/me")) return response({ id: "u_s4d_mounted", role: "founder" });
    return response([]);
  });
  vi.stubGlobal("fetch", vi.fn(async (url: unknown) => {
    const path = String(url);
    if (path.startsWith("/api/rounds")) return response([round()]);
    if (path.includes("/securities")) return response([]);
    return response([]);
  }));
});
afterEach(() => {
  cleanup();
  apiRequestMock.mockReset();
  vi.unstubAllGlobals();
});

const mount = (node: React.ReactNode) => {
  const client = new QueryClient({
    defaultOptions: { queries: { queryFn: getQueryFn({ on401: "throw" }), retry: false, refetchOnWindowFocus: false } },
  });
  return render(
    <QueryClientProvider client={client}>
      <TooltipProvider>{node}</TooltipProvider>
    </QueryClientProvider>,
  );
};

describe("S4d real CapitalizationJourney reader", () => {
  for (const [name, projection] of [
    ["normal", normal],
    ["malformed", malformed],
    ["book_unavailable", unavailable],
  ] as const) {
    it(`${name}: no partial KPI or fabricated subscribed value`, async () => {
      state.wireMoney = projection;
      mount(<CapitalizationJourney companyId={COMPANY_ID} />);
      if (name === "normal") {
        await waitFor(() => expect(screen.getAllByText(normal.subscribedDisplay).length).toBeGreaterThan(0));
        expect(screen.queryByTestId("journey-money-unavailable")).toBeNull();
      } else {
        const refusal = await screen.findByTestId("journey-money-unavailable");
        expect(refusal.textContent).toContain("at least one");
        expect(refusal.textContent).not.toContain(normal.subscribedDisplay);
        expect(screen.queryByText(normal.subscribedDisplay)).toBeNull();
      }
    });
  }
});

describe("S4d real CapTable currency-display reader (a different contract)", () => {
  for (const code of ["CAD", "JPY", null] as const) {
    it(`${code ?? "missing"}: actual page header follows the company-recorded denomination`, async () => {
      state.currency = code;
      mount(<CapTable />);
      const page = await screen.findByTestId("captable-region-scope-note");
      expect(page.textContent).toContain("does not change the currency");
      const body = document.body.textContent ?? "";
      const displayLine = Array.from(document.querySelectorAll("span.font-mono"))
        .find((el) => el.parentElement?.textContent?.startsWith("Display currency:"));
      expect(displayLine?.textContent).toBe(symbolOnRecord(code) ?? ROUND_CURRENCY_NOT_RECORDED_STATEMENT);
      if (code === null) {
        expect(body).toContain(ROUND_CURRENCY_NOT_RECORDED_STATEMENT);
      } else {
        expect(body).not.toContain(ROUND_CURRENCY_NOT_RECORDED_STATEMENT);
      }
      expect(screen.getByTestId("select-region-captable")).toBeTruthy();
    });
  }
});
