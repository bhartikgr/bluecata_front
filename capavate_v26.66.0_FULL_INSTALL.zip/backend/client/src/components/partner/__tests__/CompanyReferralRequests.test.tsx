import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { FounderReferralProgram, PartnerReferralNoticeSettings, PartnerReferralRequests } from "../CompanyReferralRequests";

vi.mock("@/lib/queryClient", () => ({ apiRequest: vi.fn() }));
const clients: QueryClient[] = [];
const contextUrl = "/api/companies/company_a/referral-help-context";
const future = () => new Date(Date.now() + 86_400_000).toISOString();
const preview = { companyName: "Consented Company", contactName: "Founder Person", contactEmail: "founder@example.invalid", contactPhone: null };
function context(extra = {}) {
  return { canManage: true, referral: { id: "ref_a", endsAt: future() },
    display: { kind: "referral", label: "Advisory Partner", partnerId: "partner_a", referralId: "ref_a", engagementId: null },
    contactPreview: preview, requests: [], engagements: [], ...extra };
}
function request(extra = {}) {
  return { id: "help_a", companyId: "company_a", purpose: "advisory", message: "Please help plan our round.",
    state: "requested", version: 1, responseDueAt: future(), expiresAt: future(), overdue: false,
    contactSnapshot: preview, deliveryState: "pending", conversion: null,
    acceptedMode: null, acceptedScope: [], acceptanceVersion: null, declineReason: null, ...extra };
}
function mount(ui: JSX.Element) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
  clients.push(client);
  render(<QueryClientProvider client={client}>{ui}</QueryClientProvider>);
  return client;
}
beforeEach(() => { vi.mocked(apiRequest).mockReset(); });
afterEach(() => { cleanup(); clients.splice(0).forEach(c => c.clear()); });
describe("Referral introduction UI", () => {
  it("uses a distinct referral badge and waits for explicit sharing consent", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => context() } as Response);
    mount(<FounderReferralProgram companyId="company_a" legacyBadge={<span>Legacy sponsor</span>} />);
    const badge = await screen.findByTestId("referral-partner-badge");
    expect(badge.className).toContain("amber");
    expect(screen.queryByText("Legacy sponsor")).toBeNull();
    fireEvent.click(screen.getByText("Engage with your assigned Consortium Partner"));
    expect((await screen.findByTestId("referral-contact-preview")).textContent).toContain("founder@example.invalid");
    expect((screen.getByText("Send introduction request") as HTMLButtonElement).disabled).toBe(true);
    fireEvent.change(screen.getByLabelText("Referral help purpose"), { target: { value: "advisory" } });
    fireEvent.change(screen.getByLabelText("Briefly describe the help you want"), { target: { value: "Please help us prepare." } });
    fireEvent.click(screen.getByRole("checkbox", { name: /I consent to sharing/ }));
    await waitFor(() => expect((screen.getByText("Send introduction request") as HTMLButtonElement).disabled).toBe(false));
    fireEvent.click(screen.getByText("Send introduction request"));
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("POST",
      "/api/companies/company_a/referral-help-requests", {
        purpose: "advisory", message: "Please help us prepare.", operationKey: expect.any(String),
        shareContactConfirmed: true, contactPreview: preview,
      }));
    const posted = vi.mocked(apiRequest).mock.calls.find(c => c[0] === "POST")![2] as any;
    expect(posted).not.toHaveProperty("partnerId"); expect(posted).not.toHaveProperty("actorId");
  });
  it("clears contact consent when the authoritative preview changes", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => context() } as Response);
    const client = mount(<FounderReferralProgram companyId="company_a" />);
    fireEvent.click(await screen.findByText("Engage with your assigned Consortium Partner"));
    const consent = screen.getByRole("checkbox", { name: /I consent to sharing/ }) as HTMLInputElement;
    fireEvent.click(consent); expect(consent.checked).toBe(true);
    act(() => client.setQueryData([contextUrl], context({ contactPreview: { ...preview, contactEmail: "changed@example.invalid" } })));
    await waitFor(() => expect(consent.checked).toBe(false));
    expect(vi.mocked(apiRequest).mock.calls.some(c => c[0] === "POST")).toBe(false);
  });
  it("preserves the original sponsor widget for non-program companies", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => context({ referral: null }) } as Response);
    mount(<FounderReferralProgram companyId="company_a" legacyBadge={<button>Original partner contact picker</button>} />);
    expect(await screen.findByText("Original partner contact picker")).toBeTruthy();
    expect(screen.queryByTestId("referral-partner-badge")).toBeNull();
  });
  it("removes an expired referral badge while retaining an independently open request", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => context({
      display: { kind: "none", label: null }, requests: [request()],
      referral: { id: "ref_a", endsAt: new Date(Date.now() - 1000).toISOString() },
    }) } as Response);
    mount(<FounderReferralProgram companyId="company_a" />);
    fireEvent.click(await screen.findByText("View partner introductions"));
    expect(screen.queryByTestId("referral-partner-badge")).toBeNull();
    expect(screen.getByText("Please help plan our round.")).toBeTruthy();
    expect(screen.getByText("Cancel request")).toBeTruthy();
  });
  it("requires a second explicit confirmation of the exact partner offer version", async () => {
    const accepted = request({ state: "accepted", version: 2, acceptedMode: "B", acceptedScope: ["advisory"], acceptanceVersion: 2 });
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => context({ requests: [accepted] }) } as Response);
    mount(<FounderReferralProgram companyId="company_a" />);
    fireEvent.click(await screen.findByText("View partner introductions"));
    const confirm = screen.getByText("Confirm client relationship") as HTMLButtonElement;
    expect(confirm.disabled).toBe(true);
    fireEvent.click(screen.getByRole("checkbox", { name: /I confirm this exact partner offer/ }));
    fireEvent.click(confirm);
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("POST",
      "/api/companies/company_a/referral-engagement-confirmations", {
        requestId: "help_a", expectedVersion: 2, acceptedVersion: 2,
        operationKey: expect.any(String), confirmEngagement: true,
      }));
  });
  it("shows an acknowledged partner request without claiming a client engagement", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => ({ requests: [{
      ...request({ state: "acknowledged" }), companyName: preview.companyName,
      contact: { contactName: preview.contactName, contactEmail: preview.contactEmail, contactPhone: null },
    }] }) } as Response);
    mount(<PartnerReferralRequests />);
    expect(await screen.findByText(/Consented Company · acknowledged/)).toBeTruthy();
    expect(screen.queryByText(/Working with/)).toBeNull();
    expect(screen.getByText("Propose relationship or decline")).toBeTruthy();
    expect(vi.mocked(apiRequest).mock.calls.some(c => c[0] === "POST")).toBe(false);
  });
  it("keeps optional notices off until a separate server-confirmed save", async () => {
    let resolveSave!: (value: Response) => void;
    let saved = false;
    vi.mocked(apiRequest).mockImplementation(async (method) => {
      if (method === "POST") return new Promise<Response>(resolve => { resolveSave = resolve; });
      return { json: async () => ({ initialized: true, enabled: saved }) } as Response;
    });
    mount(<PartnerReferralNoticeSettings canWrite />);
    const box = screen.getByRole("checkbox", { name: /Optional email reminders/ }) as HTMLInputElement;
    await waitFor(() => expect(box.disabled).toBe(false));
    expect(box.checked).toBe(false);
    fireEvent.click(box);
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("POST", "/api/partner/me/referral-notice-settings", { enabled: true }));
    expect(box.checked).toBe(false);
    await act(async () => { saved = true; resolveSave({ json: async () => ({ ok: true, enabled: true }) } as Response); });
    await waitFor(() => expect(box.checked).toBe(true));
  });
});
