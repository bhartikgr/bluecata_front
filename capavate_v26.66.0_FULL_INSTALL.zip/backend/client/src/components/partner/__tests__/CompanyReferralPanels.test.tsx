import React, { useState } from "react";
import { render, screen, waitFor, cleanup, fireEvent, act } from "@testing-library/react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { AdminCompanyReferralPanel, ReferralCodeInput, parseReferralMinor } from "../CompanyReferralPanels";
import { apiRequest } from "@/lib/queryClient";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

vi.mock("@/lib/queryClient", () => ({
  apiRequest: vi.fn(),
}));

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

function renderWithClient(ui: React.ReactElement) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return { queryClient, ...render(<QueryClientProvider client={queryClient}>{ui}</QueryClientProvider>) };
}

const mockCatalogue = {
  currencies: [
    { code: "USD", minor_unit_exponent: 2 },
    { code: "JPY", minor_unit_exponent: 0 },
    { code: "KWD", minor_unit_exponent: 3 },
    { code: "CLF", minor_unit_exponent: 4 }
  ],
  tiers: [
    { id: "tier_pro", name: "Pro Tier", currency: "USD", annualPriceCents: 120000 },
    { id: "tier_starter", name: "Starter Tier", currency: "USD", annualPriceCents: 50000 },
    { id: "tier_jpy", name: "Japan Pro", currency: "JPY", annualPriceCents: 120000 }
  ]
};

describe("CompanyReferralPanels", () => {
  describe("parseReferralMinor (Real Currency Helper Contracts)", () => {
    it("correctly applies exponent 0 for zero-decimal currencies (e.g. JPY)", () => {
      expect(parseReferralMinor("1500", "JPY")).toBe(1500);
    });

    it("correctly applies exponent 3 for currencies like KWD", () => {
      expect(parseReferralMinor("15.5", "KWD")).toBe(15500);
    });
    
    it("correctly applies exponent 4 for currencies like CLF", () => {
      expect(parseReferralMinor("2.5000", "CLF")).toBe(25000);
    });

    it("strictly enforces non-negative plain decimal shapes", () => {
      expect(() => parseReferralMinor("-10", "USD")).toThrow("Enter a non-negative plain decimal amount.");
      expect(() => parseReferralMinor("10.0.0", "USD")).toThrow("Enter a non-negative plain decimal amount.");
    });
  });

  describe("AdminCompanyReferralPanel HTTP Contract & Resiliency", () => {
    it("submits the correct HTTP payload (deliberately omitting partnerId as it is derived from the path)", async () => {
      const endpoint = "/api/admin/partners/partner_999/company-referral-program";
      vi.mocked(apiRequest).mockResolvedValueOnce({
        json: async () => ({ codes: [], catalogue: mockCatalogue })
      } as any);

      renderWithClient(<AdminCompanyReferralPanel partnerId="partner_999" />);

      // Wait for React Query to resolve and the button to render.
      const createButton = await screen.findByRole("button", { name: /Create new code/i });
      act(() => { fireEvent.click(createButton); });

      // After clicking create, the form renders. Target specific label matches due to overlapping labels.
      const codeInputs = await screen.findAllByLabelText(/Referral code/i);
      const codeInput = codeInputs.find(node => node.tagName === "INPUT") as HTMLInputElement;
      
      act(() => { fireEvent.change(codeInput, { target: { value: "SUMMER2026" } }); });
      
      // Target the select explicitly
      const statusSelect = screen.getByRole("combobox", { name: /Referral code status/i });
      act(() => { fireEvent.change(statusSelect, { target: { value: "active" } }); });
      
      // Percent discount (15.5% -> 1550 bps)
      act(() => { fireEvent.change(screen.getByLabelText(/Company discount \(%\)/i), { target: { value: "15.5" } }); });
      
      // Type currency to filter the tier checkboxes
      const currencyInput = screen.getByLabelText(/Eligible subscription currency \(ISO code\)/i);
      act(() => { fireEvent.change(currencyInput, { target: { value: "USD" } }); });
      
      // Fixed fee (500 USD -> 50000 minor)
      act(() => { fireEvent.change(screen.getByLabelText(/Fixed partner referral fee \(major currency units\)/i), { target: { value: "500.00" } }); });
      act(() => { fireEvent.change(screen.getByLabelText(/Partner fee currency \(ISO code\)/i), { target: { value: "USD" } }); });
      
      // Caps and constraints
      act(() => { fireEvent.change(screen.getByLabelText(/Total referrals allowed under this code/i), { target: { value: "10" } }); });
      
      // Wait for filtered checkboxes to appear in DOM since currency was changed
      const proTierCheckbox = await screen.findByRole("checkbox", { name: /Pro Tier/i });
      act(() => { fireEvent.click(proTierCheckbox); });

      act(() => { fireEvent.change(screen.getByLabelText(/Partner response interval \(hours\)/i), { target: { value: "48" } }); });
      act(() => { fireEvent.change(screen.getByLabelText(/Introduction request expiry \(days\)/i), { target: { value: "14" } }); });
      act(() => { fireEvent.change(screen.getByLabelText(/Referral agreement reference/i), { target: { value: "AGR-123" } }); });

      // Full code payload mock response to prevent load(c) from throwing
      vi.mocked(apiRequest).mockResolvedValueOnce({
        json: async () => ({
          code: {
            id: "code_1",
            code: "SUMMER2026",
            status: "active",
            version: 1,
            maxReferrals: 10,
            terms: {
              discountKind: "percent",
              discountBps: 1550,
              discountMinor: null,
              currency: "USD",
              feeMinor: 50000,
              feeCurrency: "USD",
              eligibleTierIds: ["tier_pro"],
              responseHours: 48,
              requestExpiryDays: 14,
              agreementRef: "AGR-123"
            },
            acceptedCount: 0,
            bindingCount: 0,
            remaining: 10,
            createdAt: "2026-09-28T00:00:00Z",
            updatedAt: "2026-09-28T00:00:00Z"
          }
        })
      } as any);

      act(() => {
        fireEvent.click(screen.getByRole("button", { name: /Save referral offer/i }));
      });

      await waitFor(() => {
        expect(apiRequest).toHaveBeenCalledWith(
          "POST", 
          endpoint, 
          expect.objectContaining({
            code: "SUMMER2026",
            status: "active",
            maxReferrals: 10,
            terms: {
              discountKind: "percent",
              discountBps: 1550,
              discountMinor: null,
              currency: "USD",
              feeMinor: 50000,
              feeCurrency: "USD",
              eligibleTierIds: ["tier_pro"],
              responseHours: 48,
              requestExpiryDays: 14,
              agreementRef: "AGR-123"
            }
          })
        );
        // Explicitly check that partnerId was correctly omitted from body (derived via path)
        const callBody = vi.mocked(apiRequest).mock.calls[1][2];
        expect(callBody).not.toHaveProperty("partnerId");
      });
    });

    it("does not wipe unsubmitted form state on background data refresh", async () => {
      const endpoint = "/api/admin/partners/partner_999/company-referral-program";
      vi.mocked(apiRequest).mockResolvedValueOnce({
        json: async () => ({ codes: [], catalogue: mockCatalogue })
      } as any);

      const { queryClient } = renderWithClient(<AdminCompanyReferralPanel partnerId="partner_999" />);

      // Await rendering of the button
      const createButton = await screen.findByRole("button", { name: /Create new code/i });
      act(() => { fireEvent.click(createButton); });

      const codeInputs = await screen.findAllByLabelText(/Referral code/i);
      const codeInput = codeInputs.find(node => node.tagName === "INPUT") as HTMLInputElement;

      act(() => { fireEvent.change(codeInput, { target: { value: "MYCODE123" } }); });
      
      // Wait for React to apply the update before expecting
      await waitFor(() => {
        expect(codeInput.value).toBe("MYCODE123");
      });

      // Simulate a background data refresh from react-query
      act(() => {
        queryClient.setQueryData([endpoint], { 
          codes: [{ 
            id: "code_X", 
            code: "OTHERCODE", 
            status: "active", 
            terms: { discountKind: "percent", eligibleTierIds: [] },
            acceptedCount: 0,
            bindingCount: 0,
            remaining: 0,
            version: 1
          }],
          catalogue: mockCatalogue
        });
      });
      
      // Allow react to render, verify state was not wiped by the background load
      await waitFor(() => {
        expect(codeInput.value).toBe("MYCODE123");
      });
    });
  });

  describe("ReferralCodeInput Resiliency", () => {
    it("does not overwrite current UI state with a delayed error from an older request", async () => {
      let rejectFirst: (reason: Error) => void = () => { throw new Error("Promise not initialized"); };
      const firstPromise = new Promise((_res, rej) => { rejectFirst = rej; });
      
      let resolveSecond: any;
      const secondPromise = new Promise((res) => { resolveSecond = res; });
      
      vi.mocked(apiRequest)
        .mockReturnValueOnce(firstPromise as any)
        .mockReturnValueOnce(secondPromise as any);
        
      function Wrapper() {
        const [val, setVal] = useState("CODE1");
        return (
           <div>
             <ReferralCodeInput value={val} onChange={setVal} />
             <button onClick={() => setVal("CODE2")}>Change to CODE2</button>
           </div>
        );
      }

      renderWithClient(<Wrapper />);
      
      const checkBtn = await screen.findByRole("button", { name: /Check code/i });
      
      // 1. Fire first request for CODE1
      act(() => { fireEvent.click(checkBtn); });
      await waitFor(() => expect(apiRequest).toHaveBeenCalledWith(
        "POST", "/api/company-referrals/preview", { code: "CODE1" },
      ));
      
      // 2. User changes input to CODE2
      const changeBtn = await screen.findByRole("button", { name: /Change to CODE2/i });
      act(() => { fireEvent.click(changeBtn); });
      
      // The Check button is disabled while pending. Exercise the reachable
      // delayed-error case against newly typed input, not a fictitious second
      // request started by clicking a disabled button.
      await act(async () => {
        rejectFirst(new Error("Invalid code CODE1"));
        await firstPromise.catch(() => undefined);
      });
      await waitFor(() => expect((checkBtn as HTMLButtonElement).disabled).toBe(false));
      expect(screen.queryByRole("alert")).toBeNull();
      expect((screen.getByLabelText("Referral code (optional)") as HTMLInputElement).value).toBe("CODE2");
      act(() => { fireEvent.click(checkBtn); });
      await waitFor(() => expect(apiRequest).toHaveBeenCalledWith(
        "POST", "/api/company-referrals/preview", { code: "CODE2" },
      ));
      // The current code can now be checked normally.
      await act(async () => {
        resolveSecond({ 
          json: async () => ({ 
            offer: { code: "CODE2", partnerName: "Partner 2", version: 1, terms: { discountKind: "percent", discountBps: 1000 }, remaining: 5 }
          })
        });
      });
      
      expect(await screen.findByText(/Referred by Partner 2/)).toBeTruthy();
      expect(screen.queryByRole("alert")).toBeNull();
    });
  });
});
