import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { CompanyReferralQuoteNotice, useCompanyReferralQuote } from "../CompanyReferralQuote";

vi.mock("@/lib/queryClient", () => ({ apiRequest: vi.fn() }));
const clients: QueryClient[] = [];
const click = vi.fn();
const offer = {
  enrolled: true, eligible: true, listMinor: 10000, discountMinor: 1250,
  netMinor: 8750, currency: "CAD", termsDigest: "a".repeat(64), checkoutBlocked: false,
};
function Fixture() {
  const [company, setCompany] = useState("company_a");
  const quote = useCompanyReferralQuote(company, "tier_a", "annual");
  return <>
    <CompanyReferralQuoteNotice quote={quote} />
    <button onClick={() => click(quote.requestFields())} disabled={!quote.ready}>Checkout</button>
    <button onClick={() => setCompany("company_b")}>Change company</button>
  </>;
}
function mount() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
  clients.push(client);
  render(<QueryClientProvider client={client}><Fixture /></QueryClientProvider>);
  return client;
}
beforeEach(() => { vi.mocked(apiRequest).mockReset(); click.mockReset(); });
afterEach(() => { cleanup(); for (const c of clients.splice(0)) c.clear(); });
describe("Referral checkout quote consumers", () => {
  it("shows the server discount and sends only its digest and stable operation key", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => offer } as Response);
    mount();
    await screen.findByText(/Amount due:/);
    await waitFor(() => expect((screen.getByText("Checkout") as HTMLButtonElement).disabled).toBe(false));
    fireEvent.click(screen.getByText("Checkout")); fireEvent.click(screen.getByText("Checkout"));
    expect(click.mock.calls[0][0]).toEqual({
      referralQuoteDigest: offer.termsDigest, referralQuoteAcknowledged: true,
      referralOperationKey: expect.any(String),
    });
    expect(click.mock.calls[1][0]).toEqual(click.mock.calls[0][0]);
    expect(click.mock.calls[0][0]).not.toHaveProperty("amountMinor");
  });
  it("preserves ordinary no-program checkout without new referral fields", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => ({ ...offer, enrolled: false, eligible: false }) } as Response);
    mount();
    await waitFor(() => expect((screen.getByText("Checkout") as HTMLButtonElement).disabled).toBe(false));
    expect(screen.queryByTestId("company-referral-quote")).toBeNull();
    fireEvent.click(screen.getByText("Checkout"));
    expect(click).toHaveBeenCalledWith({});
  });
  it("allows a server-rechecked ordinary POST during quote outage, without claiming a discount", async () => {
    vi.mocked(apiRequest).mockRejectedValue(new Error("Quote unavailable"));
    mount();
    await screen.findByRole("alert");
    await waitFor(() => expect((screen.getByText("Checkout") as HTMLButtonElement).disabled).toBe(false));
    fireEvent.click(screen.getByText("Checkout"));
    expect(click).toHaveBeenCalledWith({});
    expect(screen.queryByText(/Amount due:/)).toBeNull();
  });
  it("uses the saved operation key and price when resuming an owned attempt", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => ({
      ...offer, eligible: false, canResume: true, reason: "open_attempt", operationKey: "saved_operation_12345",
    }) } as Response);
    mount();
    await screen.findByText(/existing checkout will be resumed/);
    fireEvent.click(screen.getByText("Checkout"));
    expect(click.mock.calls[0][0].referralOperationKey).toBe("saved_operation_12345");
  });
  it("does not start another owner's reservation", async () => {
    vi.mocked(apiRequest).mockResolvedValue({ json: async () => ({
      ...offer, eligible: false, canResume: false, reason: "open_attempt", checkoutBlocked: true,
    }) } as Response);
    mount();
    await screen.findByText(/Resolve the pending checkout/);
    expect((screen.getByText("Checkout") as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(screen.getByText("Checkout"));
    expect(click).not.toHaveBeenCalled();
  });
  it("never reuses the previous company's quote while the next company's request is pending", async () => {
    let resolveNext!: (v: Response) => void;
    vi.mocked(apiRequest).mockResolvedValueOnce({ json: async () => offer } as Response)
      .mockReturnValueOnce(new Promise(resolve => { resolveNext = resolve; }));
    mount();
    await screen.findByText(/Amount due:/);
    fireEvent.click(screen.getByText("Change company"));
    expect((screen.getByText("Checkout") as HTMLButtonElement).disabled).toBe(true);
    expect(screen.queryByText(/Amount due:/)).toBeNull();
    await act(async () => resolveNext({ json: async () => ({ ...offer, termsDigest: "b".repeat(64) }) } as Response));
    await waitFor(() => expect((screen.getByText("Checkout") as HTMLButtonElement).disabled).toBe(false));
    fireEvent.click(screen.getByText("Checkout"));
    expect(click.mock.calls[0][0].referralQuoteDigest).toBe("b".repeat(64));
  });
});
