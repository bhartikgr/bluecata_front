import { useEffect, useRef, useState, type ReactNode } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import type { ReferralContactSnapshot, ReferralDisplay, ReferralHelpRequest, ReferralHelpRequestCard, ReferralEngagementConversion } from "@shared/companyReferralRequest";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

type RequestView = Omit<ReferralHelpRequest, "terms" | "contactDigest" | "acceptedSeatId" | "acceptedSubRole"> & {
  conversion: ReferralEngagementConversion | null;
  noticeSummary?: { available: boolean; sent?: number; queued?: number; review?: number };
};
type Context = {
  canManage: boolean;
  referral: { id: string; endsAt: string } | null;
  display: ReferralDisplay;
  contactPreview: ReferralContactSnapshot | null;
  requests: RequestView[];
  engagements: Array<{ id: string; partnerId: string; partnerName: string | null; legalName: string; mode: string }>;
};
const friendly = (s: string) => s.replaceAll("_", " ");
const at = (s: string) => new Date(s).toLocaleString();
const isOpen = (s: string) => ["requested", "acknowledged", "accepted"].includes(s);
function useDeadlineRefresh(dates: string[], refresh: () => unknown) {
  const signature = dates.join("|");
  useEffect(() => {
    let cancelled = false, timer: ReturnType<typeof setTimeout> | undefined;
    const schedule = () => {
      if (cancelled) return;
      const now = Date.now();
      const next = dates.map(Date.parse).filter(t => Number.isFinite(t) && t > now).sort((a, b) => a - b)[0];
      if (next === undefined) return;
      timer = setTimeout(() => {
        void Promise.resolve(refresh()).finally(schedule);
      }, Math.min(2_147_483_647, Math.max(50, next - now + 50)));
    };
    schedule();
    return () => { cancelled = true; if (timer) clearTimeout(timer); };
  }, [signature, refresh]);
}

export function FounderReferralProgram({ companyId, legacyBadge }: { companyId: string; legacyBadge?: ReactNode }) {
  const qc = useQueryClient();
  const endpoint = `/api/companies/${encodeURIComponent(companyId)}/referral-help-context`;
  const q = useQuery<Context>({
    queryKey: [endpoint], enabled: !!companyId,
    queryFn: async () => (await apiRequest("GET", endpoint)).json(), retry: false,
    refetchOnWindowFocus: true,
  });
  useDeadlineRefresh([
    ...(q.data?.referral ? [q.data.referral.endsAt] : []),
    ...(q.data?.requests ?? []).flatMap(r => [r.expiresAt, r.responseDueAt]),
  ], q.refetch);
  const [open, setOpen] = useState(false), [purpose, setPurpose] = useState(""), [message, setMessage] = useState("");
  const [consent, setConsent] = useState(false), [error, setError] = useState(""), [notice, setNotice] = useState("");
  const [confirmations, setConfirmations] = useState<Record<string, boolean>>({});
  const [designation, setDesignation] = useState("");
  const requestKey = useRef(crypto.randomUUID()), confirmationKeys = useRef<Record<string, string>>({});
  useEffect(() => { setConsent(false); }, [JSON.stringify(q.data?.contactPreview ?? null)]);
  useEffect(() => { setConfirmations({}); }, [JSON.stringify((q.data?.requests ?? []).map(r =>
    [r.id, r.acceptanceVersion, r.acceptedMode, r.acceptedScope, r.authorityArtifactRef, r.authorityExpiresAt]))]);
  useEffect(() => {
    setOpen(false); setConsent(false); setPurpose(""); setMessage(""); setError(""); setNotice("");
    setConfirmations({}); setDesignation(""); requestKey.current = crypto.randomUUID(); confirmationKeys.current = {};
  }, [companyId]);
  const mutation = useMutation({
    mutationFn: async ({ path, body }: { path: string; body: unknown }) => (await apiRequest("POST", path, body)).json(),
    onSuccess: async data => {
      setError(""); setConsent(false);
      setNotice(data.conversion?.state === "converted"
        ? "Client relationship confirmed through the existing engagement process."
        : "Saved. Your original referral discount and fee attribution have not been reassigned.");
      await q.refetch();
      qc.invalidateQueries({ queryKey: ["/api/companies", companyId, "attribution"] });
    },
    onError: async e => {
      setError(e instanceof Error ? e.message : "The request could not be completed.");
      await q.refetch();
    },
  });
  function create() {
    if (!q.data?.contactPreview || !consent || !purpose || !message.trim()) return;
    mutation.mutate({ path: `/api/companies/${encodeURIComponent(companyId)}/referral-help-requests`, body: {
      purpose, message: message.trim(), operationKey: requestKey.current,
      shareContactConfirmed: true, contactPreview: q.data.contactPreview,
    } });
  }
  if (!companyId) return null;
  if (q.isLoading) return <p className="mt-2 text-xs text-muted-foreground">Checking partner relationship…</p>;
  if (q.isError) return <p role="status" className="mt-2 text-xs">Partner status unavailable. <Button size="sm" variant="ghost" className="underline" onClick={() => q.refetch()}>Retry</Button></p>;
  const data = q.data;
  if (!data?.referral) return <>{legacyBadge}</>;
  const display = data.display;
  const canRequest = data.canManage && display.kind === "referral";
  const purposeAlreadyOpen = data.requests.some(r => r.purpose === purpose && isOpen(r.state));
  return <div className="mt-2" data-testid="founder-referral-program">
    {display.kind === "consortium_link" ? legacyBadge : display.kind === "referral" ? <div className="flex flex-wrap items-center gap-2">
      <Badge className="border-amber-300 bg-amber-50 text-amber-900" data-testid="referral-partner-badge">Referred by {display.label}</Badge>
      {data.canManage && <Button size="sm" variant="ghost" className="underline" onClick={() => setOpen(true)}>Engage with your assigned Consortium Partner</Button>}
    </div> : display.kind === "engagement" ? <Badge className="border-emerald-300 bg-emerald-50 text-emerald-900" data-testid="engaged-partner-badge">
      Working with {display.label}
    </Badge> : display.kind === "review" ? <Badge variant="outline" data-testid="partner-review-badge">Partner relationship requires review</Badge> : null}
    {data.canManage && (data.requests.length > 0 || data.engagements.length > 1) &&
      <Button size="sm" variant="ghost" className="underline" onClick={() => setOpen(true)}>View partner introductions</Button>}
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Consortium Partner introductions</DialogTitle>
          <DialogDescription>A referral is not a client engagement or access permission. Choose what to share, then separately confirm any partner offer.</DialogDescription>
        </DialogHeader>
        {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
        {notice && <p role="status" className="text-sm">{notice}</p>}
        {canRequest && <section className="space-y-3 rounded-md border p-4">
          <h3 className="font-semibold">Request help from {display.label}</h3>
          <p className="text-xs text-muted-foreground">Referral badge deadline: {at(data.referral.endsAt)}. A submitted request has its own response and expiry deadlines.</p>
          <label className="block text-sm">What help do you need?
            <select aria-label="Referral help purpose" value={purpose} disabled={mutation.isPending} onChange={e => {
              setPurpose(e.target.value); requestKey.current = crypto.randomUUID();
            }} className="mt-1 h-10 w-full rounded-md border bg-background px-3">
              <option value="">Choose a purpose</option><option value="round_preparation">Preparing my round</option>
              <option value="capital_sourcing">Investor introductions</option><option value="advisory">Business or professional advice</option>
            </select>
          </label>
          <Label htmlFor="referral-help-message">Briefly describe the help you want</Label>
          <Textarea id="referral-help-message" maxLength={2000} value={message} disabled={mutation.isPending} onChange={e => {
            setMessage(e.target.value); requestKey.current = crypto.randomUUID();
          }} />
          {data.contactPreview && <div className="rounded-md bg-muted p-3 text-sm" data-testid="referral-contact-preview">
            <p className="font-medium">Details shared with this partner</p>
            <p>{data.contactPreview.companyName}<br />{data.contactPreview.contactName}<br />{data.contactPreview.contactEmail}</p>
            <p className="mt-2 text-xs">Your selected purpose and message are included. No investor list, financial figures, cap table or documents are shared by this request.</p>
          </div>}
          <label className="flex gap-2 text-sm"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} />
            I consent to sharing the exact details above with this Consortium Partner.</label>
          {purposeAlreadyOpen && <p className="text-xs">An open request for this purpose already exists. Manage it below.</p>}
          <Button type="button" disabled={!consent || !purpose || !message.trim() || mutation.isPending || purposeAlreadyOpen} onClick={create}>Send introduction request</Button>
        </section>}
        {data.requests.map(r => <section key={r.id} className="rounded-md border p-4 space-y-2 text-sm">
          <h3 className="font-semibold">{friendly(r.purpose)} · {friendly(r.state)}</h3>
          <p>{r.message}</p><p className="text-xs">Response due {at(r.responseDueAt)} · Request expires {at(r.expiresAt)}{r.overdue ? " · Response overdue" : ""}</p>
          <p className="text-xs">{r.noticeSummary?.available
            ? `Optional email reminders: ${r.noticeSummary.sent ?? 0} handed to the mail provider, ${r.noticeSummary.queued ?? 0} awaiting handoff, ${r.noticeSummary.review ?? 0} need review.`
            : "Optional email status is unavailable."} The in-app request remains authoritative; email handoff is not mailbox delivery confirmation.</p>
          {r.declineReason && <p>Partner response: {r.declineReason}. Your discount is unchanged.</p>}
          {r.state === "accepted" && !r.conversion && <div className="space-y-2 rounded-md bg-muted p-3">
            <p>Proposed relationship: {r.acceptedMode === "A" ? "Mode A, delegated services subject to verified authority evidence" : "Mode B, non-delegated client relationship"}.</p>
            <p>Agreed scope: {r.acceptedScope.join(", ")}.</p>
            {r.acceptedMode === "A" && <p>Authority record {r.authorityArtifactRef}; expiry {r.authorityExpiresAt ? at(r.authorityExpiresAt) : "not recorded"}.</p>}
            <label className="flex gap-2"><input type="checkbox" checked={confirmations[r.id] === true}
              onChange={e => setConfirmations(old => ({ ...old, [r.id]: e.target.checked }))} />
              I confirm this exact partner offer and authorize the existing client-engagement process. Badge changes alone grant no access.</label>
            <Button type="button" disabled={!confirmations[r.id] || mutation.isPending} onClick={() => {
              const key = confirmationKeys.current[r.id] ??= crypto.randomUUID();
              mutation.mutate({ path: `/api/companies/${encodeURIComponent(companyId)}/referral-engagement-confirmations`, body: {
                requestId: r.id, expectedVersion: r.version, acceptedVersion: r.acceptanceVersion,
                operationKey: key, confirmEngagement: true,
              } });
            }}>Confirm client relationship</Button>
          </div>}
          {r.conversion && r.conversion.state !== "converted" && <div className="space-y-2">
            <p role="status">Relationship pending review: {friendly(r.conversion.failureCode ?? r.conversion.state)}. No successful engagement is being claimed.</p>
            <Button type="button" size="sm" variant="outline" disabled={mutation.isPending} onClick={() => mutation.mutate({
              path: `/api/company-referrals/help-requests/${encodeURIComponent(r.id)}/reconcile`, body: {},
            })}>Retry verified completion</Button>
          </div>}
          {isOpen(r.state) && !r.conversion && <Button type="button" size="sm" variant="outline" disabled={mutation.isPending} onClick={() => mutation.mutate({
            path: `/api/company-referrals/help-requests/${encodeURIComponent(r.id)}/cancel`, body: { expectedVersion: r.version },
          })}>Cancel request</Button>}
          {r.state === "requested" && <Button type="button" size="sm" variant="outline" disabled={mutation.isPending} onClick={() => mutation.mutate({
            path: `/api/company-referrals/help-requests/${encodeURIComponent(r.id)}/notice`, body: {},
          })}>Retry optional email reminder</Button>}
        </section>)}
        {data.engagements.length > 0 && <section className="space-y-2 border-t pt-3 text-sm">
          <h3 className="font-semibold">Display an existing active client relationship</h3>
          <p>This changes the dashboard badge only. It does not transfer your discount, referral fee, permissions or company records.</p>
          <select aria-label="Existing partner engagement" className="h-10 w-full rounded-md border bg-background px-3"
            value={designation} onChange={e => setDesignation(e.target.value)}>
            <option value="">Choose an existing engagement</option>
            {data.engagements.map(e => <option key={e.id} value={e.id}>{e.partnerName || e.legalName} · Mode {e.mode}</option>)}
          </select>
          <Button type="button" variant="outline" disabled={!designation || mutation.isPending} onClick={() => mutation.mutate({
            path: `/api/companies/${encodeURIComponent(companyId)}/referral-engagement-designation`,
            body: { engagementId: designation, expectedReferralId: data.referral!.id, confirmDesignation: true },
          })}>Use this partner badge</Button>
        </section>}
      </DialogContent>
    </Dialog>
  </div>;
}

export function ReferralRoundHelpLink({ companyId }: { companyId: string }) {
  const endpoint = `/api/companies/${encodeURIComponent(companyId)}/referral-help-context`;
  const q = useQuery<Context>({ queryKey: [endpoint], enabled: !!companyId,
    queryFn: async () => (await apiRequest("GET", endpoint)).json(), retry: false });
  if (!q.data?.referral || !q.data.canManage || !["referral", "review"].includes(q.data.display.kind)) return null;
  return <p className="my-3 text-sm"><Link href="/founder/dashboard" className="underline">Need help with your round? Review your Consortium Partner introduction on the dashboard.</Link></p>;
}

export function PartnerReferralRequests({ compact = false }: { compact?: boolean }) {
  const endpoint = "/api/partner/me/referral-help-requests";
  const q = useQuery<{ requests: ReferralHelpRequestCard[] }>({ queryKey: [endpoint],
    queryFn: async () => (await apiRequest("GET", endpoint)).json(), refetchOnWindowFocus: true, retry: false });
  useDeadlineRefresh((q.data?.requests ?? []).flatMap(r => [r.expiresAt, r.responseDueAt]), q.refetch);
  const [filter, setFilter] = useState("open"), [selected, setSelected] = useState<string | null>(null);
  const [mode, setMode] = useState(""), [scope, setScope] = useState(""), [artifact, setArtifact] = useState(""), [expiry, setExpiry] = useState("");
  const [reason, setReason] = useState(""), [error, setError] = useState("");
  const m = useMutation({
    mutationFn: async ({ id, action, body }: { id: string; action: string; body: unknown }) =>
      (await apiRequest("POST", `/api/company-referrals/help-requests/${encodeURIComponent(id)}/${action}`, body)).json(),
    onSuccess: async () => { setSelected(null); setError(""); await q.refetch(); },
    onError: async e => { setError(e instanceof Error ? e.message : "Could not update this request."); await q.refetch(); },
  });
  const rows = (q.data?.requests ?? []).filter(r => filter === "all" || (filter === "open" ? isOpen(r.state) : r.overdue));
  return <Card data-testid="partner-referral-help-queue"><CardHeader><CardTitle>Founder introduction requests</CardTitle></CardHeader>
    <CardContent className="space-y-3">
      <p className="text-sm text-muted-foreground">These founders explicitly shared the details below. Acknowledging or accepting a request grants no company access; the founder must separately confirm your offer.</p>
      <label className="block text-sm">Request view<select aria-label="Referral request view" className="ml-2 rounded-md border bg-background p-2" value={filter} onChange={e => setFilter(e.target.value)}>
        <option value="open">Open requests</option><option value="overdue">Overdue responses</option><option value="all">All request history</option>
      </select></label>
      {q.isLoading && <p>Loading introduction requests…</p>}
      {q.isError && <p role="alert">Requests could not be loaded for your role. <Button type="button" variant="outline" onClick={() => q.refetch()}>Retry</Button></p>}
      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
      {q.data && !rows.length && <p className="text-sm">No requests in this view.</p>}
      {compact && rows.length > 5 && <p className="text-xs">Showing 5 of {rows.length} requests. <Link className="underline" href="/partner/clients">Open all requests</Link></p>}
      {(compact ? rows.slice(0, 5) : rows).map(r => <section key={r.id} className="rounded-md border p-4 space-y-2 text-sm">
        <h3 className="font-semibold">{r.companyName} · {friendly(r.state)}</h3>
        <p>{r.contact.contactName} · {r.contact.contactEmail}</p>
        <p>{friendly(r.purpose)}: {r.message}</p>
        <p className="text-xs">Respond by {at(r.responseDueAt)} · Expires {at(r.expiresAt)}{r.overdue ? " · Overdue" : ""}</p>
        {r.declineReason && <p>Declined: {r.declineReason}</p>}
        {["requested", "acknowledged"].includes(r.state) && <div className="flex flex-wrap gap-2">
          {r.state === "requested" && <Button type="button" size="sm" variant="outline" disabled={m.isPending} onClick={() => m.mutate({
            id: r.id, action: "respond", body: { action: "acknowledge", expectedVersion: r.version },
          })}>Acknowledge</Button>}
          <Button type="button" size="sm" disabled={m.isPending} onClick={() => {
            setSelected(r.id); setMode(""); setScope(""); setArtifact(""); setExpiry(""); setReason("");
          }}>Propose relationship or decline</Button>
        </div>}
        {selected === r.id && <div className="space-y-3 rounded-md bg-muted p-3">
          <label className="block">Relationship mode<select aria-label="Proposed engagement mode" className="mt-1 w-full rounded-md border bg-background p-2" value={mode} onChange={e => setMode(e.target.value)}>
            <option value="">Choose explicitly</option><option value="B">Mode B: non-delegated client relationship</option>
            <option value="A">Mode A: delegated services with verified authority</option>
          </select></label>
          <label className="block">Agreed scope (comma-separated scope names)<Input aria-label="Proposed engagement scope" value={scope} onChange={e => setScope(e.target.value)} /></label>
          <p className="text-xs">Scope describes the proposed services. Delegated actions require matching existing authority records; this form creates no document or authority grant.</p>
          {mode === "A" && <>
            <label className="block">Existing verified authority artifact reference<Input aria-label="Authority artifact reference" value={artifact} onChange={e => setArtifact(e.target.value)} /></label>
            <label className="block">Exact authority expiry (ISO timestamp)<Input aria-label="Authority expiry" value={expiry} onChange={e => setExpiry(e.target.value)} /></label>
          </>}
          <Button type="button" size="sm" disabled={m.isPending || !mode || !scope.trim() || (mode === "A" && (!artifact || !expiry))} onClick={() => m.mutate({
            id: r.id, action: "accept", body: { expectedVersion: r.version, mode,
              scope: scope.split(",").map(s => s.trim()).filter(Boolean),
              ...(mode === "A" ? { authorityArtifactRef: artifact, authorityExpiresAt: expiry } : {}),
            },
          })}>Send offer for founder confirmation</Button>
          <label className="block">Optional decline reason<Input aria-label="Decline reason" maxLength={1000} value={reason} onChange={e => setReason(e.target.value)} /></label>
          <Button type="button" size="sm" variant="outline" disabled={m.isPending} onClick={() => m.mutate({
            id: r.id, action: "respond", body: { action: "decline", reason, expectedVersion: r.version },
          })}>Decline request</Button>
          <Button type="button" size="sm" variant="ghost" onClick={() => setSelected(null)}>Close proposal</Button>
        </div>}
      </section>)}
    </CardContent>
  </Card>;
}

export function PartnerReferralNoticeSettings({ canWrite }: { canWrite: boolean }) {
  const endpoint = "/api/partner/me/referral-notice-settings";
  const q = useQuery<{ enabled: boolean; initialized: boolean }>({
    queryKey: [endpoint], queryFn: async () => (await apiRequest("GET", endpoint)).json(), retry: false,
  });
  const [error, setError] = useState("");
  const m = useMutation({
    mutationFn: async (enabled: boolean) => (await apiRequest("POST", endpoint, { enabled })).json(),
    onSuccess: async () => { setError(""); await q.refetch(); },
    onError: e => setError(e instanceof Error ? e.message : "The notification preference was not saved."),
  });
  return <section className="border-t pt-3 space-y-2" data-testid="partner-referral-notice-settings">
    <label className="flex items-start gap-2 text-sm"><input type="checkbox"
      checked={q.data?.enabled === true} disabled={!canWrite || !q.data?.initialized || q.isError || m.isPending}
      onChange={e => m.mutate(e.target.checked)} />Optional email reminders for founder referral requests</label>
    <p className="text-xs text-muted-foreground">Off by default. When enabled, eligible partner seats may receive a generic reminder at their current account email. Founder details stay in the signed-in request queue. This preference saves separately from other settings.</p>
    {q.isLoading && <p className="text-xs">Loading saved preference…</p>}
    {q.isError && <p role="alert" className="text-xs">Could not read the saved preference. <Button size="sm" variant="ghost" className="underline" onClick={() => q.refetch()}>Retry</Button></p>}
    {q.data && !q.data.initialized && <p className="text-xs">Save your existing workspace settings before enabling this optional reminder.</p>}
    {m.isPending && <p role="status" className="text-xs">Saving preference…</p>}
    {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
  </section>;
}
