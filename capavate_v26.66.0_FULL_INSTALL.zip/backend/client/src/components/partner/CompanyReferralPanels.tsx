import { useEffect, useId, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import type { ReferralCode, ReferralTerms } from "@shared/companyReferral";
import { apiRequest } from "@/lib/queryClient";
import { currencyExponent, formatMinor } from "@/lib/currency";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export interface ReferralOfferPreview {
  code: string; partnerName: string; version: number;
  terms: Pick<ReferralTerms, "discountKind" | "discountBps" | "discountMinor" | "currency" | "eligibleTierIds">;
  remaining: number;
}
function minorText(value: number, currency: string): string {
  const exp = currencyExponent(currency);
  const digits = String(value).padStart(exp + 1, "0");
  return exp ? `${digits.slice(0, -exp)}.${digits.slice(-exp)}` : digits;
}
export function parseReferralMinor(value: string, currency: string): number {
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error("Enter an explicit three-letter currency.");
  return parseDecimal(value, currencyExponent(currency));
}
function parseDecimal(value: string, exponent: number): number {
  if (!/^\d+(?:\.\d+)?$/.test(value.trim())) throw new Error("Enter a non-negative plain decimal amount.");
  const [whole, fraction = ""] = value.trim().split(".");
  if (fraction.length > exponent) throw new Error(`This amount allows ${exponent} decimal places.`);
  const result = BigInt(whole) * (10n ** BigInt(exponent)) + BigInt(fraction.padEnd(exponent, "0") || "0");
  if (result > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("This amount is too large.");
  return Number(result);
}
function positiveInteger(value: string, label: string): number {
  if (!/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value))) throw new Error(`${label} must be a positive whole number.`);
  return Number(value);
}
export function referralOfferText(terms: ReferralOfferPreview["terms"]): string {
  return terms.discountKind === "percent"
    ? `${(terms.discountBps! / 100).toFixed(2).replace(/\.?0+$/, "")}% off the first eligible annual company subscription`
    : `${formatMinor(terms.discountMinor!, terms.currency, { currencyDisplay: "code" })} off the first eligible annual company subscription`;
}
const selectClass = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm";
function Field({ label, value, onChange, disabled = false }: { label: string; value: string; onChange: (s: string) => void; disabled?: boolean }) {
  const id = useId();
  return <div className="space-y-1"><Label htmlFor={id}>{label}</Label><Input id={id} value={value} onChange={e => onChange(e.target.value)} disabled={disabled} /></div>;
}

export function ReferralCodeInput({ value, onChange, onOffer }: {
  value: string; onChange: (s: string) => void; onOffer?: (offer: ReferralOfferPreview | null) => void;
}) {
  const id = useId();
  const [offer, setOffer] = useState<ReferralOfferPreview | null>(null);
  const [error, setError] = useState("");
  const pending = useRef(0);
  useEffect(() => { pending.current++; setOffer(null); setError(""); onOffer?.(null); }, [value]);
  const check = useMutation({
    mutationFn: async ({ request, code }: { request: number; code: string }) => {
      const r = await apiRequest("POST", "/api/company-referrals/preview", { code });
      const body = await r.json();
      return { request, offer: body.offer as ReferralOfferPreview };
    },
    onSuccess: result => {
      if (result.request !== pending.current) return;
      setOffer(result.offer); setError(""); onOffer?.(result.offer);
    },
    onError: (e, variables) => {
      if (variables.request !== pending.current) return;
      setError(e instanceof Error ? e.message : "Could not check the code."); setOffer(null); onOffer?.(null);
    },
  });
  return <section className="space-y-2 rounded-md border p-3" data-testid="referral-code-input">
    <Label htmlFor={id}>Referral code (optional)</Label>
    <div className="flex gap-2"><Input id={id} value={value} maxLength={64} onChange={e => onChange(e.target.value)} autoComplete="off" />
      <Button type="button" variant="outline" disabled={!value.trim() || check.isPending}
        onClick={() => check.mutate({ request: ++pending.current, code: value })}>Check code</Button></div>
    <p className="text-xs text-muted-foreground">You can register without a code. A referral does not grant the partner access to your company.</p>
    {error && <p role="alert" className="text-sm text-red-700">{error} You may clear the code to continue without its benefit.</p>}
    {offer && <div className="text-sm" data-testid="referral-offer-preview">
      <p>Referred by {offer.partnerName}. {referralOfferText(offer.terms)}.</p>
      <p>{offer.remaining > 0 ? `${offer.remaining} registrations remaining.` : "This code's allowance is exhausted. You can register without the benefit."} Eligibility lasts one year from company registration.</p>
    </div>}
  </section>;
}

export function AdminCompanyReferralPanel({ partnerId }: { partnerId: string }) {
  const endpoint = `/api/admin/partners/${encodeURIComponent(partnerId)}/company-referral-program`;
  const query = useQuery<{ codes: ReferralCode[]; referrals?: Array<{
    id: string; codeId: string; codeVersion: number; companyId: string; companyName: string | null;
    companyArchived: boolean; state: string; boundAt: string | null; endsAt: string;
  }>; catalogue: {
    currencies: Array<{ code: string; minor_unit_exponent: number }>;
    tiers: Array<{ id: string; name: string; currency: string; annualPriceCents: number }>;
  } }>({
    queryKey: [endpoint], queryFn: async () => (await apiRequest("GET", endpoint)).json(),
  });
  const [selected, setSelected] = useState<ReferralCode | null>(null);
  const [newCode, setNewCode] = useState(false);
  const [code, setCode] = useState("");
  const [status, setStatus] = useState("");
  const [kind, setKind] = useState<"percent" | "fixed">("percent");
  const [discount, setDiscount] = useState("");
  const [currency, setCurrency] = useState("");
  const [fee, setFee] = useState("");
  const [feeCurrency, setFeeCurrency] = useState("");
  const [max, setMax] = useState("");
  const [tiers, setTiers] = useState("");
  const [response, setResponse] = useState("");
  const [expiry, setExpiry] = useState("");
  const [agreement, setAgreement] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const initializedPartner = useRef<string | null>(null);
  const load = (c: ReferralCode | null) => {
    setSelected(c); setCode(c?.code ?? ""); setStatus(c?.status ?? "");
    setKind(c?.terms.discountKind ?? "percent");
    setDiscount(c ? c.terms.discountKind === "percent" ? String(c.terms.discountBps! / 100) : minorText(c.terms.discountMinor!, c.terms.currency) : "");
    setCurrency(c?.terms.currency ?? ""); setFee(c ? minorText(c.terms.feeMinor, c.terms.feeCurrency) : "");
    setFeeCurrency(c?.terms.feeCurrency ?? ""); setMax(c ? String(c.maxReferrals) : "");
    setTiers(c?.terms.eligibleTierIds.join(", ") ?? ""); setResponse(c ? String(c.terms.responseHours) : "");
    setExpiry(c ? String(c.terms.requestExpiryDays) : ""); setAgreement(c?.terms.agreementRef ?? "");
  };
  useEffect(() => {
    // Refresh capacity in the query without replacing a user's unsaved draft.
    // The draft retains its original version so stale saves fail server-side.
    if (query.data && initializedPartner.current !== partnerId) {
      initializedPartner.current = partnerId; setNewCode(false);
      load(query.data.codes.find(c => c.status === "active") ?? query.data.codes[0] ?? null);
    }
  }, [query.data, partnerId]);
  const save = useMutation({
    mutationFn: async () => {
      if (!["active", "retired"].includes(status)) throw new Error("Select the code status.");
      if (!/^[A-Z]{3}$/.test(currency)) throw new Error("Enter an explicit three-letter subscription currency.");
      if (currency !== feeCurrency) throw new Error("The referral fee and subscription offer must use the same currency.");
      if (!query.data?.catalogue?.currencies.some(c => c.code === currency)) throw new Error("Select an active supported currency.");
      const terms: ReferralTerms = {
        discountKind: kind, discountBps: kind === "percent" ? parseDecimal(discount, 2) : null,
        discountMinor: kind === "fixed" ? parseReferralMinor(discount, currency) : null,
        currency, feeMinor: parseReferralMinor(fee, feeCurrency), feeCurrency,
        eligibleTierIds: tiers.split(",").map(s => s.trim()).filter(Boolean),
        responseHours: positiveInteger(response, "Response hours"),
        requestExpiryDays: positiveInteger(expiry, "Request expiry days"), agreementRef: agreement.trim(),
      };
      const r = await apiRequest("POST", endpoint, {
        ...(selected && !newCode ? { id: selected.id, expectedVersion: selected.version } : {}),
        code, status, maxReferrals: positiveInteger(max, "Total referrals"), terms,
      });
      return (await r.json()).code as ReferralCode;
    },
    onSuccess: async c => { setNewCode(false); load(c); setError(""); setNotice("Referral offer saved."); await query.refetch(); },
    onError: e => setError(e instanceof Error ? e.message : "The offer was not saved."),
  });
  return <Card data-testid="admin-company-referral"><CardHeader><CardTitle>Company referral program</CardTitle></CardHeader><CardContent className="space-y-4">
    <p className="text-sm text-muted-foreground">Separate from this partner's own subscription. Accepted company terms are preserved; editing an offer does not reset code usage.</p>
    {query.isLoading && <p>Loading referral offers…</p>}
    {query.isError && <p role="alert">Could not load referral offers. <Button type="button" variant="outline" onClick={() => query.refetch()}>Retry</Button></p>}
    {query.data && <>
      <div className="flex flex-wrap gap-2">
        {query.data.codes.map(c => <Button key={c.id} type="button" variant="outline" onClick={() => { setNewCode(false); load(c); setNotice(""); }}>{c.code} · {c.status}</Button>)}
        <Button type="button" variant="outline" onClick={() => { setNewCode(true); load(null); setNotice(""); }}>Create new code</Button>
      </div>
      {selected && !newCode && <p className="text-sm" data-testid="referral-capacity">Accepted {selected.acceptedCount} · Pending {selected.bindingCount} · Remaining {selected.remaining} / {selected.maxReferrals} · Version {selected.version}</p>}
      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
      {notice && <p role="status" className="text-sm">{notice}</p>}
      <form onSubmit={e => { e.preventDefault(); setNotice(""); save.mutate(); }} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Referral code" value={code} onChange={setCode} disabled={!!selected && !newCode} />
          <label className="space-y-1 text-sm">Status<select aria-label="Referral code status" className={selectClass} value={status} onChange={e => setStatus(e.target.value)}><option value="">Select status</option><option value="active">Active</option><option value="retired">Retired</option></select></label>
          <label className="space-y-1 text-sm">Discount type<select aria-label="Company discount type" className={selectClass} value={kind} onChange={e => { setKind(e.target.value as "percent" | "fixed"); setDiscount(""); }}><option value="percent">Percentage</option><option value="fixed">Fixed amount</option></select></label>
          <Field label={kind === "percent" ? "Company discount (%)" : "Company discount (major currency units)"} value={discount} onChange={setDiscount} />
          <Field label="Eligible subscription currency (ISO code)" value={currency} onChange={v => setCurrency(v.toUpperCase())} />
          <Field label="Fixed partner referral fee (major currency units)" value={fee} onChange={setFee} />
          <Field label="Partner fee currency (ISO code)" value={feeCurrency} onChange={v => setFeeCurrency(v.toUpperCase())} />
          <Field label="Total referrals allowed under this code" value={max} onChange={setMax} />
          <fieldset className="space-y-2 sm:col-span-2">
            <legend className="text-sm font-medium">Eligible annual company plans</legend>
            {(query.data.catalogue?.tiers ?? []).filter(t => t.currency === currency).map(t => <label key={t.id} className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={tiers.split(",").map(s => s.trim()).includes(t.id)}
                onChange={e => {
                  const chosen = new Set(tiers.split(",").map(s => s.trim()).filter(Boolean));
                  e.target.checked ? chosen.add(t.id) : chosen.delete(t.id);
                  setTiers([...chosen].join(", "));
                }} />
              {t.name} · {formatMinor(t.annualPriceCents, t.currency, { currencyDisplay: "code" })} annually
            </label>)}
            {!query.data.catalogue?.tiers.some(t => t.currency === currency) &&
              <p className="text-xs text-muted-foreground">No paid annual company plans are available in this currency. Configure the existing pricing catalogue first.</p>}
          </fieldset>
          <Field label="Partner response interval (hours)" value={response} onChange={setResponse} />
          <Field label="Introduction request expiry (days)" value={expiry} onChange={setExpiry} />
          <Field label="Referral agreement reference" value={agreement} onChange={setAgreement} />
        </div>
        <p className="text-xs text-muted-foreground">The allowance counts accepted companies, not clicks or payments. Refunds and revocations do not restore used slots. Net subscription price must remain positive.</p>
        <Button type="submit" disabled={save.isPending}>{save.isPending ? "Saving…" : "Save referral offer"}</Button>
      </form>
      <details>
        <summary className="cursor-pointer text-sm">Company referral registrations ({query.data.referrals?.length ?? 0})</summary>
        <ul className="mt-3 space-y-2">{(query.data.referrals ?? []).map(r => <li key={r.id} className="rounded-md border p-3 text-sm">
          <p className="font-medium">{r.companyName ?? "Company name unavailable"}{r.companyArchived ? " · Archived" : ""}</p>
          <p>{r.state} · Offer version {r.codeVersion} · {r.boundAt ? `Accepted ${new Date(r.boundAt).toLocaleDateString()}` : "Acceptance pending"}</p>
          <p className="text-xs text-muted-foreground">Company {r.companyId} · Benefit deadline {new Date(r.endsAt).toLocaleDateString()}</p>
        </li>)}</ul>
      </details>
    </>}
  </CardContent></Card>;
}

export function PartnerCompanyReferralPanel() {
  const q = useQuery<{ codes: ReferralCode[]; summary: { accepted: number; pending: number }; referrals: Array<{ id: string; state: string; boundAt: string | null; endsAt: string }> }>({
    queryKey: ["/api/partner/me/company-referrals"],
    queryFn: async () => (await apiRequest("GET", "/api/partner/me/company-referrals")).json(),
    refetchOnWindowFocus: true,
  });
  const [copyStatus, setCopyStatus] = useState("");
  const linkInput = useRef<HTMLInputElement>(null);
  const c = q.data?.codes.find(row => row.status === "active");
  const link = c ? `${window.location.origin}/auth/signup?referralCode=${encodeURIComponent(c.code)}` : "";
  async function copy() {
    try { await navigator.clipboard.writeText(link); setCopyStatus("Registration link copied."); }
    catch { linkInput.current?.focus(); linkInput.current?.select(); setCopyStatus("Select and copy the registration link."); }
  }
  return <Card data-testid="partner-company-referrals"><CardHeader><CardTitle>Company referrals</CardTitle></CardHeader><CardContent className="space-y-3">
    {q.isLoading && <p>Loading your referral program…</p>}
    {q.isError && <p role="alert">Referral information is unavailable. <Button variant="outline" onClick={() => q.refetch()}>Retry</Button></p>}
    {q.data && <>
      {!c ? <p>No active referral code is configured. Ask Capavate Admin to enable your agreed company offer.</p> : <>
        <p className="text-lg font-semibold">{c.code}</p><p>{referralOfferText(c.terms)}.</p>
        <p className="text-sm">Fixed referral fee: {formatMinor(c.terms.feeMinor, c.terms.feeCurrency, { currencyDisplay: "code" })}, subject to a qualifying real payment and review.</p>
        <p data-testid="partner-referral-capacity">Accepted {c.acceptedCount} · Pending {c.bindingCount} · Remaining {c.remaining} of {c.maxReferrals}</p>
        <Label htmlFor="partner-referral-link">Your shareable company registration link</Label>
        <Input id="partner-referral-link" ref={linkInput} value={link} readOnly />
        <Button variant="outline" type="button" onClick={copy}>Copy registration link</Button>
        {copyStatus && <p role="status" className="text-sm">{copyStatus}</p>}
      </>}
      <p className="text-xs text-muted-foreground">A referral does not give access to a company's data. Company identity is shared only through a permitted client relationship or a founder-approved introduction.</p>
      <details><summary className="cursor-pointer text-sm">Referral history ({q.data.referrals.length})</summary>
        <ul className="mt-2 space-y-2">{q.data.referrals.map(r => <li key={r.id} className="text-sm border-t pt-2">Reference {r.id} · {r.state} · Benefit deadline {new Date(r.endsAt).toLocaleDateString()}</li>)}</ul>
      </details>
    </>}
  </CardContent></Card>;
}
