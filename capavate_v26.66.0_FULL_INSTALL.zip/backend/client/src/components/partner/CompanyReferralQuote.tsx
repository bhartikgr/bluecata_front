import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatMinor } from "@/lib/currency";
import { Button } from "@/components/ui/button";
import type { CompanyReferralQuote } from "@shared/companyReferralCheckout";
export type { CompanyReferralQuote } from "@shared/companyReferralCheckout";

/** One server quote is used by every existing company checkout surface. */
export function useCompanyReferralQuote(companyId: string | undefined, tierId: string | undefined,
  billingCycle: string, enabled = true) {
  const identity = `${companyId ?? ""}/${tierId ?? ""}/${billingCycle}`;
  const attempt = useRef<{ identity: string; key: string }>({ identity, key: crypto.randomUUID() });
  if (attempt.current.identity !== identity) attempt.current = { identity, key: crypto.randomUUID() };
  const q = useQuery<CompanyReferralQuote>({
    queryKey: ["/api/company-referrals/quote", companyId, tierId, billingCycle],
    enabled: enabled && !!companyId && !!tierId,
    queryFn: async () => {
      const params = new URLSearchParams({ companyId: companyId!, tierId: tierId!, billingCycle });
      return (await apiRequest("GET", `/api/company-referrals/quote?${params}`)).json();
    },
    staleTime: 0, retry: false, refetchOnWindowFocus: true,
  });
  useEffect(() => {
    if (q.data?.operationKey) attempt.current.key = q.data.operationKey;
  }, [q.data?.operationKey]);
  const requestFields = () => {
    if (!enabled) return {};
    // The POST rechecks durable enrollment. Non-program customers retain
    // ordinary checkout during a quote outage; enrolled customers are refused
    // without a reviewed quote, never silently charged a different price.
    if (q.isError) return {};
    if (!q.data || q.isError || q.isFetching) throw new Error("Wait for the current checkout quote.");
    if (q.data.checkoutBlocked) throw new Error(q.data.reason ?? "This referral checkout needs review.");
    return q.data.enrolled ? {
      referralOperationKey: q.data.operationKey ?? attempt.current.key,
      referralQuoteDigest: q.data.termsDigest,
      referralQuoteAcknowledged: true,
    } : {};
  };
  return { ...q, requestFields, ready: !enabled || q.isError || (!!q.data && !q.isFetching && !q.data.checkoutBlocked) };
}

export function CompanyReferralQuoteNotice({ quote }: {
  quote: ReturnType<typeof useCompanyReferralQuote>;
}) {
  if (quote.isLoading || quote.isFetching) return <p role="status" className="text-xs text-muted-foreground">Checking current referral pricing…</p>;
  if (quote.isError) return <div role="alert" className="text-sm">
    Referral pricing could not be verified. Checkout will recheck your eligibility before charging; it will not silently omit an enrolled benefit. <Button type="button" variant="outline" size="sm" onClick={() => quote.refetch()}>Retry quote</Button>
  </div>;
  const q = quote.data;
  if (!q?.enrolled) return null;
  return <div data-testid="company-referral-quote" className="rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950">
    {q.eligible || q.canResume ? <>
      <p>Company referral discount: {formatMinor(q.discountMinor, q.currency, { currencyDisplay: "code" })}.</p>
      <p>Amount due: {formatMinor(q.netMinor, q.currency, { currencyDisplay: "code" })}.</p>
      {q.canResume && <p>Your existing checkout will be resumed; no new referral benefit is created.</p>}
    </> : <p>No referral discount on this purchase: {(q.reason ?? "not eligible").replaceAll("_", " ")}.</p>}
    {q.checkoutBlocked && <p role="alert">Resolve the pending checkout before starting another discounted purchase.</p>}
  </div>;
}

export function ReferralPlanCheckoutAction({ companyId, tierId, billingCycle, label, pending, onCheckout }: {
  companyId: string; tierId: string; billingCycle: string; label: string; pending: boolean;
  onCheckout: (fields: Record<string, unknown>) => void;
}) {
  const quote = useCompanyReferralQuote(companyId, tierId, billingCycle);
  return <div className="space-y-2">
    <CompanyReferralQuoteNotice quote={quote} />
    <Button size="sm" className="w-full bg-[hsl(0_100%_40%)] hover:bg-[hsl(0_100%_32%)] text-white"
      disabled={pending || !quote.ready} data-testid={`button-switch-${tierId}`}
      onClick={() => onCheckout(quote.requestFields())}>{label}</Button>
  </div>;
}
