import { useEffect, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatMinor } from "@/lib/currency";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { parseReferralMinor } from "./CompanyReferralPanels";

type Earning = {
  id: string; referralId: string; kind: string; amountMinor: number; currency: string;
  state: string; createdAt: string; paidAt: string | null;
};
type ProgramReport = {
  entries: any[];
  totalsByCurrency: Array<{ currency: string; pending: number; approved: number; held: number; paid: number; adjustments: number }>;
  candidates?: Array<{ chargeId: string; companyId: string; partnerId: string; paymentIntentId: string;
    merchantOrderId: string; netMinor: number; currency: string; feeMinor: number; feeCurrency: string;
    verification: string | null; alreadyRecorded: boolean; blockedByRevshare: boolean }>;
  attempts?: Array<{ id: string; state: string; payment_intent_id: string | null; net_minor: number; currency: string }>;
  refundReceipts?: Array<{ feeEntryId: string; refundInvoiceId: string; refundMinor: number; currency: string; state: string; adjustmentEntryId: string | null }>;
};
const money = (minor: number, currency: string) => formatMinor(minor, currency, { currencyDisplay: "code" });
export function CompanyReferralEarningsPanel({ admin = false, partnerId }: { admin?: boolean; partnerId?: string }) {
  const endpoint = admin ? `/api/admin/company-referral-earnings${partnerId ? `?partnerId=${encodeURIComponent(partnerId)}` : ""}`
    : "/api/partner/me/company-referral-earnings";
  const q = useQuery<ProgramReport>({
    queryKey: [endpoint], queryFn: async () => (await apiRequest("GET", endpoint)).json(), retry: false,
  });
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [action, setAction] = useState<{ path: string; title: string; kind: "evidence" | "hold" | "payout" | "resolve" | "refund"; currency?: string; negative?: boolean } | null>(null);
  const [reference, setReference] = useState(""), [amount, setAmount] = useState(""), [reason, setReason] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  useEffect(() => { setAction(null); setError(""); setNotice(""); }, [endpoint]);
  function open(next: NonNullable<typeof action>) {
    setAction(next); setReference(""); setAmount(""); setReason(""); setConfirmed(false); setError(""); setNotice("");
  }
  const mutate = useMutation({
    mutationFn: async ({ path, body }: { path: string; body: Record<string, unknown> }) => {
      return (await apiRequest("POST", path, body)).json();
    },
    onSuccess: async () => { setAction(null); setError(""); setNotice("Saved. No bank transfer or gateway refund was initiated."); await q.refetch(); },
    onError: e => setError(e instanceof Error ? e.message : "The action was not saved."),
  });
  function submit() {
    if (!action) return;
    try {
      const body: Record<string, unknown> = {};
      if (["evidence", "resolve", "payout", "refund"].includes(action.kind) && !reference.trim()) throw new Error("Enter an evidence or transaction reference.");
      if (action.kind === "evidence") {
        if (!confirmed) throw new Error("Confirm the provider facts before saving evidence.");
        Object.assign(body, { evidenceRef: reference.trim(), providerFactsChecked: true });
      } else if (action.kind === "resolve") {
        if (!confirmed || !reason.trim()) throw new Error("Provide the resolution reason and confirm that provider evidence proves this intent cannot charge.");
        Object.assign(body, { reason: reason.trim(), evidenceRef: reference.trim(), evidenceClass: "provider_nonchargeable", cannotChargeConfirmed: true });
      } else if (action.kind === "hold") {
        if (!reason.trim()) throw new Error("Enter the hold reason.");
        body.reason = reason.trim();
      } else if (action.kind === "payout") {
        if (!confirmed) throw new Error("Confirm the transfer has already occurred before recording payout.");
        Object.assign(body, { amountMinor: parseReferralMinor(amount, action.currency!) * (action.negative ? -1 : 1), currency: action.currency, payoutRef: reference.trim() });
      } else {
        Object.assign(body, { refundInvoiceId: reference.trim(), refundMinor: parseReferralMinor(amount, action.currency!),
          currency: action.currency, verified: confirmed });
      }
      mutate.mutate({ path: action.path, body });
    } catch (e) { setError(e instanceof Error ? e.message : "Check the entered values."); }
  }
  const entries: Earning[] = (q.data?.entries ?? []).map(e => admin ? ({
    id: e.billing_entry_id, referralId: e.referral_id, kind: e.kind, amountMinor: e.amount_minor,
    currency: e.currency, state: e.approval_state, createdAt: e.created_at, paidAt: e.paid_at,
  }) : e);
  return <Card data-testid={admin ? "admin-company-referral-earnings" : "partner-company-referral-earnings"}>
    <CardHeader><CardTitle>Company referral earnings</CardTitle></CardHeader>
    <CardContent className="space-y-4">
      <p className="text-sm text-muted-foreground">Company acquisition fees are separate from investment commissions and partner subscription charges. Totals are never converted or added across currencies.</p>
      {q.isLoading && <p>Loading company referral earnings…</p>}
      {q.isError && ((q.error as { status?: number })?.status === 403
        ? <p className="text-sm">Company referral earnings are visible to your managing partner.</p>
        : <p role="alert">Company referral earnings are unavailable. <Button variant="outline" type="button" onClick={() => q.refetch()}>Retry</Button></p>)}
      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
      {notice && <p role="status" className="text-sm">{notice}</p>}
      {q.data && <>
        {q.data.totalsByCurrency.map(t => <div key={t.currency} className="rounded-md border p-3 text-sm">
          <p className="font-semibold">{t.currency}</p>
          <p>Pending review {money(t.pending, t.currency)} · Approved {money(t.approved, t.currency)} · Held {money(t.held, t.currency)}</p>
          <p>Paid fees {money(t.paid, t.currency)} · Refund adjustments {money(t.adjustments, t.currency)}</p>
        </div>)}
        {!entries.length && <p className="text-sm">No company referral fees have been recorded.</p>}
        {entries.map(e => <div key={e.id} className="rounded-md border p-3 space-y-2 text-sm">
          <p>{e.kind === "fee" ? "Referral fee" : "Refund adjustment"}: {money(e.amountMinor, e.currency)} · {e.state}</p>
          <p className="break-all text-xs text-muted-foreground">Referral {e.referralId}</p>
          {admin && e.state !== "paid" && <div className="flex flex-wrap gap-2">
            {e.state !== "approved" && <Button type="button" size="sm" variant="outline" disabled={mutate.isPending}
              onClick={() => mutate.mutate({ path: `/api/admin/company-referral-earnings/${e.id}/approve`, body: {} })}>Approve verified fee</Button>}
            <Button type="button" size="sm" variant="outline" onClick={() => open({ path: `/api/admin/company-referral-earnings/${e.id}/hold`, title: "Hold referral earning", kind: "hold" })}>Place on hold</Button>
            {e.state === "approved" && <Button type="button" size="sm" onClick={() => open({ path: `/api/admin/company-referral-earnings/${e.id}/mark-paid`, title: "Record completed payout or recovery", kind: "payout", currency: e.currency, negative: e.kind === "adjustment" })}>Record payment</Button>}
          </div>}
          {admin && e.kind === "fee" && <Button type="button" size="sm" variant="outline" onClick={() => open({
            path: `/api/admin/company-referral-earnings/${e.id}/refund`, title: "Record refund evidence or hold", kind: "refund", currency: e.currency,
          })}>Refund review</Button>}
        </div>)}
        {admin && <>
          {(q.data.refundReceipts ?? []).filter(r => r.state === "unverified").map(r => <div key={`${r.feeEntryId}/${r.refundInvoiceId}`} className="rounded-md border border-amber-300 p-3 text-sm">
            <p>Refund verification pending: {r.refundInvoiceId} · {money(r.refundMinor, r.currency)}.</p>
            <p>This remains on record even if the original referral fee was already paid.</p>
            <Button type="button" size="sm" variant="outline" onClick={() => open({
              path: `/api/admin/company-referral-earnings/${r.feeEntryId}/refund`, title: "Verify recorded refund",
              kind: "refund", currency: r.currency,
            })}>Review refund evidence</Button>
          </div>)}
          <Button type="button" variant="outline" disabled={mutate.isPending} onClick={() => mutate.mutate({
            path: "/api/admin/company-referral-earnings/reconcile", body: { ...(partnerId ? { partnerId } : {}) },
          })}>Reconcile recorded subscription payments</Button>
          <p className="text-xs text-muted-foreground">Reconciliation uses the existing successful payment ledger. It does not create a charge, transfer funds or assume that an active subscription was paid.</p>
          {(q.data.candidates ?? []).filter(c => !c.alreadyRecorded).map(c => <div key={c.chargeId} className="rounded-md border p-3 text-sm space-y-2">
            <p>Company {c.companyId} · Customer payment {money(c.netMinor, c.currency)} · Partner fee {money(c.feeMinor, c.feeCurrency)}</p>
            <p className="break-all">Provider intent: {c.paymentIntentId}<br />Merchant reference: {c.merchantOrderId}</p>
            <p>Verification: {c.verification ?? "required"}{c.blockedByRevshare ? " · Blocked by existing acquisition fee" : ""}</p>
            {!c.verification && <Button type="button" size="sm" variant="outline" onClick={() => open({
              path: `/api/admin/company-referral-payments/${c.chargeId}/evidence`, title: "Record provider payment evidence", kind: "evidence",
            })}>Record provider evidence</Button>}
          </div>)}
          <Button type="button" disabled={mutate.isPending} onClick={() => mutate.mutate({
            path: "/api/admin/company-referral-earnings/materialize", body: { ...(partnerId ? { partnerId } : {}) },
          })}>Record verified referral fees</Button>
          <details><summary className="cursor-pointer text-sm">Checkout reservations and exceptions</summary>
            {(q.data.attempts ?? []).map(a => <div className="border-t py-2 text-sm" key={a.id}>
              <p>{a.id} · {a.state} · {money(a.net_minor, a.currency)}</p>
              {["created", "intent_bound"].includes(a.state) && <Button type="button" size="sm" variant="outline" onClick={() => open({
                path: `/api/admin/company-referral-payments/${a.id}/resolve`, title: "Resolve a nonchargeable checkout", kind: "resolve",
              })}>Resolve with provider evidence</Button>}
            </div>)}
          </details>
        </>}
      </>}
      {action && <section className="rounded-md border-2 p-4 space-y-3" aria-label={action.title}>
        <h3 className="font-semibold">{action.title}</h3>
        {action.kind !== "hold" && <label className="block text-sm">Evidence reference / refund invoice ID / completed transfer reference
          <Input aria-label="Referral evidence reference" value={reference} maxLength={1000} onChange={e => setReference(e.target.value)} />
        </label>}
        {["hold", "resolve"].includes(action.kind) && <label className="block text-sm">Reason<Input aria-label="Referral hold or resolution reason" value={reason} onChange={e => setReason(e.target.value)} /></label>}
        {["payout", "refund"].includes(action.kind) && <label className="block text-sm">Amount ({action.currency}, major units)<Input aria-label="Referral transaction amount" value={amount} onChange={e => setAmount(e.target.value)} /></label>}
        {action.kind !== "hold" && <label className="flex gap-2 text-sm"><input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} />
          {action.kind === "resolve" ? "I verified provider evidence proving this earlier intent cannot charge."
            : action.kind === "evidence" ? "I verified successful real payment, exact amount, currency and merchant reference in the provider."
            : action.kind === "refund" ? "The refund has been independently verified. Leave unchecked to hold the fee for review."
            : "The stated transfer or recovery has already completed; this only records it."}
        </label>}
        <div className="flex gap-2"><Button type="button" disabled={mutate.isPending} onClick={submit}>Save record</Button>
          <Button type="button" variant="outline" onClick={() => setAction(null)}>Cancel</Button></div>
      </section>}
    </CardContent>
  </Card>;
}
