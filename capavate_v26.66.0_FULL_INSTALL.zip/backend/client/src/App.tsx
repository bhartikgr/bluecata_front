import { Switch, Route, Router, useLocation, Redirect } from "wouter";
import { V23413_FIXES_SHIPPED } from "@/lib/v23413Marker";
void V23413_FIXES_SHIPPED;
// v23.4.3 Phase 2: removed useHashLocation import — switched to BrowserRouter
// (History API). URLs are now /founder/dashboard, not /#/founder/dashboard.
// Ozan architectural decision #1 locked.
import { type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { useEntitlement } from "@/lib/entitlement";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme";
import { RoleProvider } from "@/lib/role";
import NotFound from "@/pages/not-found";
// Wave C FIX C7 — polished admin 404.
import AdminNotFound from "@/pages/admin/AdminNotFound";
import FinancialsFill from "@/pages/FinancialsFill";
import { AppShell } from "@/components/AppShell";

import Home from "@/pages/home/Home";
import LegalTermsPage from "@/pages/Terms"; // v25.26 — stub Terms of Service page (was 404 fallback to login)
import LegalPrivacyPage from "@/pages/Privacy"; // v25.26 — stub Privacy Policy page (note: separate from @/pages/settings/PrivacyPage which is the settings screen)
import { AdoptedLegalDocumentPage } from "@/components/AdoptedLegalDocumentPage";
// Sprint-fix May 14 2026 — import the new guard + boundary components
import { RequireAuth } from "@/components/RequireAuth";
import { ErrorBoundary } from "@/components/ErrorBoundary";

import Landing from "@/pages/Landing";
import Login from "@/pages/auth/Login";
import Signup from "@/pages/auth/Signup";
import Forgot from "@/pages/auth/Forgot";
import Redeem from "@/pages/auth/Redeem";
import SetPasswordPage from "@/pages/SetPasswordPage"; // v23.4.1 Task C — consortium partner invite
import SelectCompany from "@/pages/SelectCompany";

import FounderDashboard from "@/pages/founder/Dashboard";
import FounderCompany from "@/pages/founder/Company";
// v25.45 F8 — Company Management parent landing page (new left-nav item).
import FounderCompanyManagement from "@/pages/founder/CompanyManagement";
import FounderCapTable from "@/pages/founder/CapTable";
/* WAVE 92 — the exit waterfall screen. `GET /api/founder/captable/waterfall` had
   ZERO client callers, so three waves of corrected exit maths (88, 91, 94) were
   invisible to every customer and untestable by QA. Founder-scoped exactly as the
   endpoint is (`ownsCompany`); NOT widened to investors in this wave (pre-flight
   `OQ-W-6`). */
import FounderExitWaterfall from "@/pages/founder/ExitWaterfall";
import FounderRounds from "@/pages/founder/Rounds";
import FounderRoundNew from "@/pages/founder/RoundNew";
import FounderRoundDetail from "@/pages/founder/RoundDetail";
import FounderTermSheet from "@/pages/founder/TermSheet";
import FounderCRM from "@/pages/founder/CRM";
import FounderCRMNew from "@/pages/founder/CRMNew";
import FounderDataroom from "@/pages/founder/Dataroom";
import FounderReports from "@/pages/founder/Reports";
import FounderReportNew from "@/pages/founder/ReportNew";
import FounderActivity from "@/pages/founder/Activity";
import FounderSettings from "@/pages/founder/Settings";
import FounderProfileWizard from "@/pages/founder/ProfileWizard";
import FounderCollective from "@/pages/founder/Collective";
import FounderMessages from "@/pages/founder/Messages";
import FounderApplyToCollective from "@/pages/founder/ApplyToCollective";
import FounderWelcome from "@/pages/founder/Welcome";
import FounderGlossary from "@/pages/founder/Glossary";
import FounderNetworkPosts from "@/pages/founder/NetworkPosts";
import InvestorNetworkPosts from "@/pages/investor/NetworkPosts";
import PostDetail from "@/pages/PostDetail";

// Patch v6 — Partner workspace pages
import PartnerDashboard from "@/pages/partner/PartnerDashboard";
import PartnerPipeline from "@/pages/partner/PartnerPipeline";
import PartnerAddPortfolioCompany from "@/pages/partner/PartnerAddPortfolioCompany"; /* Wave B1 (3a) */
/* W2-A — restored Clients CRM pages (components were never deleted; only their
   routes were trimmed in v25.50.0). W2-D — new Private Portfolio page. */
import PartnerClients from "@/pages/partner/PartnerClients";
import PartnerClientDetail from "@/pages/partner/PartnerClientDetail";
/* W-MFCRM — Managed Founders page (additive; DB-driven via /api/partner/me/mfcrm*). */
import PartnerManagedFounders from "@/pages/partner/PartnerManagedFounders";
import PartnerMfcrmPersonas from "@/pages/partner/PartnerMfcrmPersonas";
import PartnerPortfolio from "@/pages/partner/PartnerPortfolio";
/* WAVE 30 ENGINE 2 — partner_company_relationship spine, first surface. */
import PartnerRelationships from "@/pages/partner/PartnerRelationships";
import PartnerSpvTemplates from "@/pages/partner/PartnerSpvTemplates";
import PartnerContacts from "@/pages/partner/PartnerContacts";
import PartnerTeam from "@/pages/partner/PartnerTeam";
import PartnerNotes from "@/pages/partner/PartnerNotes";
/* WAVE 7 W-8 (DEF-057) / W-5 (DEF-056) — PartnerTasks.tsx and PartnerFiles.tsx
   were never deleted; v25.50.0 Phase 6 removed only their routes, their nav
   entries and their server route surfaces, leaving the pages and both stores
   (partnerTasksStore / partnerFilesStore) on disk and unreachable. The stores
   and their partner_tasks / partner_files tables are restored to reachability
   here. This is WIRING — no page component was rewritten from scratch. */
import PartnerTasks from "@/pages/partner/PartnerTasks";
import PartnerFiles from "@/pages/partner/PartnerFiles";
import PartnerSettings from "@/pages/partner/PartnerSettings";
import PartnerSpvs from "@/pages/partner/PartnerSpvs";
import PartnerSpvDetail from "@/pages/partner/PartnerSpvDetail";
import PartnerSpvEngine from "@/pages/partner/PartnerSpvEngine";
import PartnerFunds from "@/pages/partner/PartnerFunds";
import PartnerBilling from "@/pages/partner/PartnerBilling"; /* v25.32 A3 — consortium partner commission ledger */
import PartnerCheckoutReturn from "@/pages/partner/PartnerCheckoutReturn"; /* WAVE 14 / CP-SUB-17 — gateway return landing */
import AdminPartnerBillingOps from "@/pages/admin/AdminPartnerBillingOps"; /* WAVE 14 — partner money engine admin surface */
/* v25.33 Consortium Partner Payment Model — partner self-service pages. */
import PartnerAgreementSign from "@/pages/partner/PartnerAgreementSign";
import PartnerTaxForm from "@/pages/partner/PartnerTaxForm";
import PartnerFundDetail from "@/pages/partner/PartnerFundDetail";
// v25.49 Phase-3B — partner NETWORK surfaces (reuse shared comms components).
import PartnerMessages from "@/pages/partner/PartnerMessages";
import PartnerPosts from "@/pages/partner/PartnerPosts";
import RedeemPartnerInvite from "@/pages/auth/RedeemPartnerInvite";

import InvestorDashboard from "@/pages/investor/Dashboard";
import InvestorInvitations from "@/pages/investor/Invitations";
import InvestorInvitationDetail from "@/pages/investor/InvitationDetail";
import InvestorPortfolio from "@/pages/investor/Portfolio";
import InvestorCRM from "@/pages/investor/CRM";
import InvestorCRMNew from "@/pages/investor/CRMNew";
import InvestorApplyToCollective from "@/pages/investor/ApplyToCollective";
import InvestorProfile from "@/pages/investor/Profile";
/* WAVE 10 / EN-3 — LP self-serve link for positions taken by email before the
   investor had an account. Read-widening only; the sacred ledger is untouched. */
import InvestorClaimPositions from "@/pages/investor/ClaimPositions";
/* WAVE 10 / EN-1 + EN-2 — SPV performance surface over the ILPA cash-flow ledger. */
import SpvPerformanceRoute from "@/pages/partner/SpvPerformanceRoute";
import InvestorAccreditation from "@/pages/investor/Accreditation"; /* v26.1.x AVI-ACCRED */
import InvestorMessages from "@/pages/investor/Messages";
import InvestorCollective from "@/pages/investor/Collective";
import InvestorSignup from "@/pages/investor/Signup";
import InvestorLogin from "@/pages/investor/Login";
import InvestorCompanyDetail from "@/pages/investor/CompanyDetail";
import FounderCompanyDetail from "@/pages/founder/CompanyDetail";
// Sprint 20 Wave 2 — new investor pages
import InvestorSettings from "@/pages/investor/Settings";
import InvestorGlossary from "@/pages/investor/Glossary";
import InvestorNotifications from "@/pages/investor/Notifications";

import AdminLogin from "@/pages/admin/Login";
// 23-May Fix 7 — dedicated Consortium Partner login + signup-apply pages
import PartnerLogin from "@/pages/partner/PartnerLogin";
import PartnerSignup from "@/pages/partner/PartnerSignup";
import AdminDashboard from "@/pages/admin/Dashboard";
import AdminWishList from "@/pages/admin/AdminWishList";
import AdminCompanies from "@/pages/admin/Companies";
import AdminCompanyDetail from "@/pages/admin/CompanyDetail";
import AdminInvestors from "@/pages/admin/Investors";
import AdminInvestorImport from "@/pages/admin/InvestorImport";
import AdminUsers from "@/pages/admin/Users";
import AdminFormulas from "@/pages/admin/Formulas";
import AdminFormulaDetail from "@/pages/admin/FormulaDetail";
import AdminFormulaNew from "@/pages/admin/FormulaNew";
import AdminLifecyclePolicies from "@/pages/admin/LifecyclePolicies";
import AdminRegionsExtensions from "@/pages/admin/RegionsExtensions";
import AdminRegionExtensionDetail from "@/pages/admin/RegionExtensionDetail";
import AdminAuditLog from "@/pages/admin/AuditLog";
import AuditChainVerifyPage from "@/pages/admin/AuditChainVerifyPage"; /* v19 Phase C */
import AdminCrmDedupReview from "@/pages/admin/CrmDedupReview"; /* WAVE 28 / CP-CRM-04 */
import AdminCompedMemberships from "@/pages/admin/CompedMemberships"; /* WAVE 155 — R124.4.3 admin-granted membership */
import AdminSpvLaunchGate from "@/pages/admin/SpvLaunchGate"; /* WAVE 156 — R124.4.1 / R114.3 the override lever */
import AdminIntegrations from "@/pages/admin/AdminIntegrations"; /* W-V44 FIX K — market-data integrations */
/* D2.5 SLICE 1 — the 15 old admin fee routes were RETIRED.

   ⚠ WAVE 7 RS-3 (DEF-054) — CORRECTION. The sentence that stood here said the
   thirteen page components were "deleted along with" their imports. That was
   FALSE and had been false since D2.5: only the imports and routes were
   removed. All thirteen .tsx files were verified present on disk under
   client/src/pages/admin/ before this comment was rewritten — FeeHub.tsx,
   Payments.tsx, PartnerFeeSchedules.tsx, AdminApplicationFee.tsx,
   AdminPlatformFees.tsx, CollectiveSubscriptions.tsx, AdminCommissionRates.tsx,
   PartnerPL.tsx, CollectivePaymentSchedules.tsx, CollectivePaymentPL.tsx,
   Pricing.tsx, PricingModels.tsx, PricingModelDetail.tsx. A comment claiming
   code is gone when it is merely unreachable is how ten things in this project
   came to be "rebuilt" when they only needed wiring, so it is corrected rather
   than deleted.

   WAVE 7 R-1 dispositions each of the thirteen individually; see the R-1 block
   in the route table below and build_log/wave7_r1_disposition.json. Seven are
   re-routed (each is the only client caller of a write endpoint) and their
   imports are restored immediately below; six are descoped and stay unrouted.

   Everything the descoped six did lives in ONE page:
     /admin/fees → AdminFeesConsolidated
   Capavate is in test mode, so there is NO redirect/deprecation window —
   the old URLs fall through to the /admin/:rest* AdminNotFound catch-all
   (HTTP-equivalent 404 for an SPA). Server routes are UNCHANGED.
   WAVE 4A EXCEPTION: /admin/collective-payment-schedules and /admin/partner-fees
   are no longer 404s. They are aliased onto AdminFeesConsolidated's Fee
   Schedules tab (see the routes below) because the consolidation lost their
   WRITE capability, not just their URL. No page component was re-imported. */
import AdminFeesConsolidated from "@/pages/admin/AdminFeesConsolidated"; /* D2.5 Slice 1 — unified /admin/fees */
/* WAVE 7 R-1 — the seven retired fee pages that are the SOLE client caller of
   at least one write endpoint. Re-imported so their capability is reachable
   again; see the R-1 block in the route table for the per-page evidence. */
import CollectiveSubscriptions from "@/pages/admin/CollectiveSubscriptions";
import AdminCommissionRates from "@/pages/admin/AdminCommissionRates";
import AdminPricing from "@/pages/admin/Pricing";
import PricingModels from "@/pages/admin/PricingModels";
import PricingModelDetail from "@/pages/admin/PricingModelDetail";
import AdminReconciliation from "@/pages/admin/Reconciliation";
/* v25.33 Consortium Partner Payment Model — admin surfaces (DB-driven). */
import AdminPartners from "@/pages/admin/Partners";
/* WAVE 4B (PT-2) — admin CRUD for the partner-classification lookup tables. */
import PartnerTaxonomyAdmin from "@/pages/admin/PartnerTaxonomyAdmin";
/* slide13b WAVE D — admin CRUD for the DB-backed COMPANY-sector taxonomy (taxonomy_terms, 0236). Separate from partner classification. */
import CompanyTaxonomyAdmin from "@/pages/admin/CompanyTaxonomyAdmin";
import PartnerResponders from "@/pages/admin/PartnerResponders"; /* W6 — Ask-an-Expert partner-responder registry */
import AdminTelemetry from "@/pages/admin/Telemetry";
// Sprint 12 — new admin + cross-role pages
import NotificationCenter from "@/pages/NotificationCenter";

/** 2026-09-19 — exact legacy `/partner/pipeline` → mounted partner pipeline, query/hash kept. */
function LegacyPartnerPipelineRedirect() {
  const suffix = typeof window !== "undefined" ? `${window.location.search}${window.location.hash}` : "";
  return <Redirect to={`/collective/partner/pipeline${suffix}`} replace />;
}
import AdminBridge from "@/pages/admin/Bridge";
import AdminBridgeHistory from "@/pages/admin/BridgeHistory";
import AdminPartnerDetail from "@/pages/admin/PartnerDetail";
import AdminEmail from "@/pages/admin/Email";
import AdminEmailComposer from "@/pages/admin/EmailComposer";
import AdminNotifications from "@/pages/admin/Notifications";
import AdminNotificationComposer from "@/pages/admin/NotificationComposer";
// Sprint 28 Billing — founder subscription + billing pages
import FounderSubscribe from "@/pages/founder/Subscribe";
import FounderBilling from "@/pages/founder/Billing";
// v24.2 Airwallex wiring — hosted-checkout return landing (polls activation).
import BillingReturn from "@/pages/founder/BillingReturn";
import AdminInvestorDetail from "@/pages/admin/InvestorDetail";
import AdminSync from "@/pages/admin/Sync";
/* WAVE 15 — ORP-062 / ORP-053 / A-2 / A-3b all produced real server state with
   no human-visible surface. This page is that surface. */
import AdminPlatformSurfaces from "@/pages/admin/PlatformSurfaces";
import AdminMigration from "@/pages/admin/Migration";
// CP Phase B — Apply flow + Admin queue + Onboarding + Privacy
import ConsortiumApplyPage from "@/pages/public/ConsortiumApplyPage";
import AdminConsortiumApplicationsPage from "@/pages/admin/ConsortiumApplicationsPage";
// v23.5 C-003 — admin Collective pages
import AdminCollectiveApplications from "@/pages/admin/CollectiveApplications";
import AdminCollectiveMembers from "@/pages/admin/CollectiveMembers";
import AdminCollectiveSettings from "@/pages/admin/CollectiveSettings";
import AdminCollectiveWaitlist from "@/pages/admin/CollectiveWaitlist";
// v25.47 APD-022 / APD-023 — admin Pulse Symbols + Post Moderation surfaces.
import AdminPulseSymbols from "@/pages/admin/PulseSymbols";
import AdminPostsModeration from "@/pages/admin/PostsModeration";
// v25.47 APD-020 — public Consortium Partner pricing.
import ConsortiumPricing from "@/pages/consortium/ConsortiumPricing";
import { V25_COLLECTIVE_SHIPPED } from "@/lib/v25Marker"; void V25_COLLECTIVE_SHIPPED;
import { V26_FIXES_SHIPPED } from "@/lib/v26Marker"; void V26_FIXES_SHIPPED;
import PartnerOnboardingChecklistPage from "@/pages/partner/OnboardingChecklistPage";
import PrivacyPage from "@/pages/settings/PrivacyPage";
/* WAVE 305 · R251 — the user-facing two-step sign-in screen. Opt-in; nothing on
   it changes how anybody else signs in. */
import TwoFactorSetup from "@/pages/settings/TwoFactorSetup";
import CollectivePreview from "@/pages/CollectivePreview";
import { seedSprint3Telemetry } from "@/lib/sprint3Seed";
import { useRealtimeSync } from "@/lib/realtimeSync";
// Wave C-3 + C-4 — Collective Shell
import { CollectiveShell } from "@/components/CollectiveShell";
import CollectiveDashboard from "@/pages/collective/CollectiveDashboard";
import CollectiveDealRoom from "@/pages/collective/CollectiveDealRoom";
import CollectiveDealRoomDetail from "@/pages/collective/CollectiveDealRoomDetail";
import CollectiveMembers from "@/pages/collective/CollectiveMembers";
import CollectiveCompanies from "@/pages/collective/CollectiveCompanies";
import CollectiveCompanyDetail from "@/pages/collective/CollectiveCompanyDetail";
import CollectiveSoftCircles from "@/pages/collective/CollectiveSoftCircles";
import CollectiveDscPipeline from "@/pages/collective/CollectiveDscPipeline";
import CollectiveDscScores from "@/pages/collective/CollectiveDscScores";
import CollectiveTransactionPrep from "@/pages/collective/CollectiveTransactionPrep";
import CollectiveMembership from "@/pages/collective/CollectiveMembership";
// v25.22 NC-4 fix — the live self-serve membership UI (tier catalog +
// Subscribe buttons + working Airwallex checkout/portal mutations) lives in
// MembershipPage.tsx. It was previously unreachable: every router (App.tsx +
// backup copies) routed `/collective/membership` to the read-only
// `CollectiveMembership.tsx` summary, and its "Upgrade Membership" button
// navigated back to the same route. The upgrade/payment happy path was dead
// code. We now mount MembershipPage at the same route so members can
// actually checkout, and keep CollectiveMembership reachable as
// `/collective/membership-summary` for the read-only view.
import MembershipPage from "@/pages/collective/MembershipPage";
import CollectiveActivity from "@/pages/collective/CollectiveActivity";
import CollectiveSettings from "@/pages/collective/CollectiveSettings";
import EventsCalendarPage from "@/pages/collective/EventsCalendarPage";
import LeaderboardPage from "@/pages/collective/LeaderboardPage";
/* v25.12 NC2 — the three pages below are fully implemented but were never
 * imported or routed. Adding them so deep links from the calendar, nav
 * items, and notification CTAs no longer land on NotFoundOrLogin. */
import ScreeningEventsPage from "@/pages/collective/ScreeningEventsPage";
import AskExpertPage from "@/pages/collective/AskExpertPage";
// v25.42 (Bucket B) — 9 new Collective routes/components.
import CollectiveConnections from "@/pages/collective/Connections";
import CollectiveRecaps from "@/pages/collective/Recaps";
import CollectiveScreeningRecaps from "@/pages/collective/ScreeningRecaps";
import CollectiveChapters from "@/pages/collective/Chapters";
import CollectiveMyRequests from "@/pages/collective/MyRequests";
import CollectivePublicProfile from "@/pages/collective/PublicProfile";
import CollectivePartnersDirectory from "@/pages/collective/PartnersDirectory";
import QuestionDetailPage from "@/pages/collective/QuestionDetailPage";
// v25.44 Wave A + M&A + venture pages
import MaIntel from "@/pages/collective/MaIntel";
import MyPortfolioPage from "@/pages/collective/MyPortfolioPage";
import PresentationsPage from "@/pages/collective/PresentationsPage";
import NetworkPostsPage from "@/pages/collective/NetworkPostsPage";
import MonthlyMeetingsPage from "@/pages/collective/MonthlyMeetingsPage";
import SchedulePage from "@/pages/collective/SchedulePage";
import SyndicateApplyPage from "@/pages/collective/SyndicateApplyPage";

// Bootstrap demo telemetry once at app load
if (import.meta.env.MODE !== "production") {
  seedSprint3Telemetry();
}

/* ---------- Sprint 28 Billing — Subscription gate HOC ----------
 * Wraps any founder route that requires an active subscription.
 * Reads subscription from /api/founder/subscription on every mount.
 * Non-active statuses redirect to /founder/subscribe.
 * Does NOT gate: /founder/subscribe, /founder/company, /founder/settings, /founder/billing.
 * ---------------------------------------------------------------- */
const INACTIVE_STATUSES = new Set(["pending_payment", "past_due", "canceled", "cancelled", "paused", "unpaid"]);

function RequireActiveSubscription({ children }: { children: ReactNode }) {
  const { data: entCtx, isLoading: entLoading } = useEntitlement();
  // Patch v4: no demo fallback. If user has no active company, send them to
  // /founder/subscribe (which handles the empty state) instead of querying
  // for a hardcoded "co_novapay" subscription.
  const companyId = entCtx?.founder?.activeCompanyId ?? "";

  const subCacheKey = companyId ? `subscription_cache_${companyId}` : null;

  const { data, isLoading } = useQuery<{ ok: boolean; subscription: { status: string } }>({
    queryKey: ["/api/founder/subscription", companyId],
    queryFn: async () => {
      try {
        const API_BASE = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";
        const res = await fetch(`${API_BASE}/api/founder/subscription?companyId=${encodeURIComponent(companyId)}`);
        if (!res.ok) return { ok: false, subscription: { status: "pending_payment" } };
        const json = await res.json();
        // D2.5 Slice 3 Fix 4 — refresh the local cache on every successful
        // response so a LATER network error has something recent to fall
        // back on. Best-effort: localStorage can throw (quota/private mode);
        // never let a cache-write failure break a successful fetch.
        if (subCacheKey) {
          try {
            localStorage.setItem(subCacheKey, JSON.stringify({ ts: Date.now(), data: json }));
          } catch {
            /* best-effort cache write; ignore */
          }
        }
        return json;
      } catch {
        // D2.5 Slice 3 Fix 4 — was: fail OPEN, unconditionally returning
        // { ok: true, status: "active" } on ANY network error — the exact
        // "genuinely hardcoded value" the audit flagged: a value that never
        // varies no matter what the server actually says, because the server
        // is never actually consulted on this path.
        //
        // Fix: fail CLOSED, with a cache-based grace period so a flaky
        // network blip doesn't lock out a legitimately active subscriber.
        //   1) A cached response < 24h old — reuse the LAST KNOWN status
        //      (not an assumed "active"). If the cache says past_due, the
        //      user still sees the paywall; this is not a bypass.
        //   2) No usable cache — return the new "connection_error" sentinel,
        //      which the render logic below routes to a technical-error
        //      state, NOT the paywall (a network hiccup is not evidence of
        //      a lapsed subscription).
        if (subCacheKey) {
          try {
            const raw = localStorage.getItem(subCacheKey);
            if (raw) {
              const parsed = JSON.parse(raw) as { ts: number; data: { ok: boolean; subscription: { status: string } } };
              if (Date.now() - parsed.ts < 24 * 60 * 60 * 1000) {
                return parsed.data;
              }
            }
          } catch {
            /* corrupt/unreadable cache entry — fall through to connection_error */
          }
        }
        return { ok: false, subscription: { status: "connection_error" } };
      }
    },
    enabled: !!companyId,
    staleTime: 0,
    retry: false,
  });

  // v23.8 W-1: wait for the entitlement context before deciding. On a hard
  // navigation `useEntitlement()` is still loading, so `companyId` is "" and the
  // old code redirected every founder route to /founder/subscribe. Hold on a
  // skeleton until /api/auth/me resolves.
  if (entLoading || entCtx === undefined) {
    return (
      <div className="p-6" data-testid="subscription-gate-entitlement-loading">
        <div className="h-4 w-32 bg-muted animate-pulse rounded" />
      </div>
    );
  }

  // No active company yet (fresh user) — v25.43 F13: send first-time founders
  // to the company-creation step FIRST (company-before-subscribe onboarding),
  // not straight to the paywall. The ?onboarding=1 flag tells /company-profile
  // it's the create-company step; on a successful create it forwards to
  // /founder/dashboard (R3-8 — no longer the paywall). The INACTIVE_STATUSES redirect below (inactive
  // subscription state machine) is a DIFFERENT case and still goes to subscribe.
  if (!companyId) {
    return <Redirect to="/company-profile?onboarding=1" />;
  }

  if (isLoading) {
    return (
      <div className="p-6" data-testid="subscription-gate-loading">
        <div className="h-4 w-32 bg-muted animate-pulse rounded" />
      </div>
    );
  }

  const status = data?.subscription?.status ?? "pending_payment";

  // D2.5 Slice 3 Fix 4 — "connection_error" is a TECHNICAL failure (no cache,
  // network unreachable), not a subscription-state signal. It must never be
  // routed through INACTIVE_STATUSES → /founder/subscribe: that would show a
  // paywall to a user whose subscription might be perfectly active, purely
  // because their network blipped. Render an inline retry state instead —
  // matches the existing skeleton-render convention in this component rather
  // than introducing a new route (no server-rendered "connection error" page
  // exists yet; the full paywall UI is Slice 1's /admin/fees Config tab per
  // the task brief, this is scaffolding only).
  if (status === "connection_error") {
    return (
      <div className="p-6 text-center" data-testid="subscription-gate-connection-error">
        <p className="text-sm text-muted-foreground mb-3">
          We couldn&apos;t reach the server to verify your subscription. Check your connection and try again.
        </p>
        <button
          type="button"
          className="text-sm underline"
          data-testid="button-subscription-gate-retry"
          onClick={() => window.location.reload()}
        >
          Retry
        </button>
      </div>
    );
  }

  if (INACTIVE_STATUSES.has(status)) {
    return <Redirect to="/founder/subscribe" />;
  }

  return <>{children}</>;
}

function isAuthRoute(path: string) {
  return (
    path === "/onboarding" ||
    path === "/" ||
    path === "/login" ||
    // v26.7.3 FIX-2a — the established founder login alias must render bare,
    // just like /login and /auth/login, rather than inherit the app shell.
    path === "/user/login" ||
    path === "/signup" ||
    path === "/forgot-password" ||
    path === "/investor/login" ||
    path === "/admin/login" ||
    path === "/partner/login" ||
    path === "/partner/signup" ||
    // FIX 2c — the public consortium-partner application form must render bare
    // (no AppShell) exactly like /partner/signup, so a first-attempt visit
    // resolves immediately instead of bouncing through the cold auth probe.
    path === "/apply/consortium" ||
    path.startsWith("/investor/signup") ||
    path.startsWith("/collective/preview") ||
    path.startsWith("/collective/") ||
    // v25.44 R3 — /ma-intel renders inside CollectiveShell. Mark it bare
    // so the global AppShell doesn't double-wrap it (which was rendering
    // both the founder Workspace sidebar and the Collective sidebar side
    // by side).
    path === "/ma-intel" ||
    path.startsWith("/auth/") ||
    path === "/set-password" || // v23.4.1 Task C — public invite redemption
    path === "/select-company" ||
    // Wave B FIX 8 — legacy/leak paths render bare (no AppShell) so the
    // sidebar/role chip never leak to unauthenticated visitors.
    path === "/dashboard" ||
    path === "/cap-table" ||
    path === "/rounds" ||
    // v25.43 R3-6 — /company-profile is NO LONGER force-bare. The onboarding
    // step (/company-profile?onboarding=1) must render INSIDE the founder app
    // shell (sidebar + header + brand). Anonymous visitors are still protected
    // because AppRouter's `bare` flag also becomes true when `!isAuthed`, so
    // the shell never leaks to unauthenticated probers.
    path.startsWith("/invite/")
  );
}

/* ---------- Wave B FIX 8 (I-BUG-006, I-BUG-007) ---------- */
/* Common legacy paths the QA found exposed. Each component reads
 * /api/auth/me; unauthenticated → /auth/login?returnTo=...,
 * authenticated → the appropriate portal home. Renders BARE (no shell). */
function LegacyDashboardRedirect() {
  const [currentLocation] = useLocation();
  const { data, isLoading } = useQuery<{ isAuthed?: boolean; isAdmin?: boolean; founder?: { activeCompanyId: string | null }; investor?: { state: string } }>({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/auth/me");
        if (!res.ok) return { isAuthed: false };
        return res.json();
      } catch {
        return { isAuthed: false };
      }
    },
    staleTime: 30_000,
    retry: false,
  });
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" data-testid="legacy-redirect-loading">
        <div className="text-sm text-muted-foreground">Redirecting to your dashboard…</div>
      </div>
    );
  }
  if (!data?.isAuthed) {
    const returnTo = encodeURIComponent(currentLocation);
    return <Redirect to={`/auth/login?returnTo=${returnTo}`} />;
  }
  if (data.isAdmin) return <Redirect to="/admin/dashboard" />;
  if (data.investor && data.investor.state && data.investor.state !== "NONE")
    return <Redirect to="/investor/dashboard" />;
  return <Redirect to="/founder/dashboard" />;
}

function LegacyInviteRedirect() {
  // Always redirect to the public landing — invite tokens are now handled
  // via /auth/redeem (token in querystring) so the legacy /invite/:token
  // path is no longer the canonical ingress.
  const [currentLocation] = useLocation();
  // Pull the token out of the wouter path (last segment).
  const token = currentLocation.split("/").filter(Boolean).pop() ?? "";
  if (token && token !== "invite") {
    return <Redirect to={`/auth/redeem?token=${encodeURIComponent(token)}`} />;
  }
  return <Redirect to="/onboarding" />;
}

/* Auth-aware catch-all. If the user is signed in, show a real 404; if
 * not, send them to login. This stops the public 404 inside the founder shell
 * that the QA called out (I-BUG-008). */
function NotFoundOrLogin() {
  const { data, isLoading } = useQuery<{ isAuthed?: boolean }>({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/auth/me");
        if (!res.ok) return { isAuthed: false };
        return res.json();
      } catch {
        return { isAuthed: false };
      }
    },
    staleTime: 30_000,
    retry: false,
  });
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-sm text-muted-foreground">Loading…</div>
      </div>
    );
  }
  if (!data?.isAuthed) {
    // v26.7.3 FIX-2b — this catch-all proves the requested path has no
    // registered route. Do not hand an unroutable URL to Login's load-bearing
    // returnTo flow; RequireAuth remains the sole producer for real routes and
    // preserves legitimate deep links such as /founder/rounds.
    return <Redirect to="/auth/login" />;
  }
  return <NotFound />;
}

/* ---------- Wave C FIX C6 (I-FINAL-001) ---------- */
/* The Investor / Founder / Partner / Collective / Admin app shells must
 * never render to an UNAUTHENTICATED visitor — doing so leaks the sidebar,
 * "ROLE: Investor" pill, search bar, and other internal navigation to
 * anonymous URLs (e.g. /#/investor/pipeline, /#/investor/deal-flow,
 * /#/investor/billing, /#/investor/activity, /#/dashboard). Wave B FIX 8
 * patched a handful of explicit legacy paths via `isAuthRoute`, but any
 * unregistered URL under a portal namespace fell through to the catch-all
 * INSIDE <AppShell>, exposing the shell to anonymous probers.
 *
 * Fix: probe /api/auth/me once at the AppRouter level. If the visitor is
 * NOT authenticated, render the route tree BARE — no AppShell chrome.
 * Authenticated visitors keep the existing shell behaviour. Routes that
 * are intentionally public-and-bare (the auth shell, marketing landing,
 * etc.) are unaffected because they continue to opt in via isAuthRoute.
 */
function useIsAuthedProbe(): { isAuthed: boolean; isLoading: boolean } {
  const { data, isLoading } = useQuery<{ isAuthed?: boolean }>({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/auth/me");
        if (!res.ok) return { isAuthed: false };
        return res.json();
      } catch {
        return { isAuthed: false };
      }
    },
    staleTime: 30_000,
    retry: false,
  });
  return { isAuthed: Boolean(data?.isAuthed), isLoading };
}

function AppRouter() {
  const [location] = useLocation();
  const { isAuthed, isLoading: authProbeLoading } = useIsAuthedProbe();
  // Wave C FIX C6: never render AppShell to anonymous users. `bare` is true
  // if either the route is an explicit auth/landing path OR the visitor is
  // unauthenticated. While the auth probe is loading we render bare to
  // avoid a flash of shell chrome.
  const bare = isAuthRoute(location) || authProbeLoading || !isAuthed;
  useRealtimeSync();

  const routes = (
    /* Sprint-fix May 14 2026 — entire Switch wrapped in ErrorBoundary so that
     * any unhandled render error (e.g. "Cannot read properties of undefined
     * (reading 'tone')") shows the recovery card instead of a blank page. */
    <ErrorBoundary>
      <Switch>
        {/* ===== PUBLIC ROUTES — NO auth gate ===== */}
        <Route path="/" component={Home} />
        <Route path="/onboarding" component={Landing} />
        {/* v25.26 — Terms and Privacy stub routes. Previously these URLs fell
            through to the SPA login fallback (REG-NEW-103). Real legal
            content is in the Terms/Privacy components; replace with final
            policy content before general availability. */}
        <Route path="/terms" component={LegalTermsPage} />
        <Route path="/terms-of-service" component={LegalTermsPage} />
        <Route path="/privacy" component={LegalPrivacyPage} />
        <Route path="/privacy-policy" component={LegalPrivacyPage} />
        {/* WAVE 210 — the Cookie Policy, Acceptable Use Policy and Disclaimer
            existed in the corpus that every signup consent attests to, and no URL
            reached any of them. Public, additive; the four routes above are
            unchanged. */}
        <Route path="/legal/:docId">
          {(params: { docId: string }) => <AdoptedLegalDocumentPage docId={params.docId} />}
        </Route>
        {/* CP Phase B — Public consortium-partner application */}
        <Route path="/apply/consortium" component={ConsortiumApplyPage} />
        {/* v25.47 APD-020 — Public Consortium Partner pricing (no auth). */}
        <Route path="/consortium/pricing" component={ConsortiumPricing} />
        <Route path="/login" component={Login} />
        {/* v26.7.3 FIX-2a — additive founder-login alias for the owner's
            established /user/login URL; all existing login routes remain. */}
        <Route path="/user/login" component={Login} />
        <Route path="/signup" component={Signup} />
        <Route path="/forgot-password" component={Forgot} />

        {/* Sprint 15 — new auth shell (public) */}
        <Route path="/auth/login" component={Login} />
        <Route path="/auth/signup" component={Signup} />
        <Route path="/auth/forgot" component={Forgot} />
        <Route path="/auth/redeem" component={Redeem} />
        {/* v23.4.1 Task C — Consortium Partner set-password invite link (public) */}
        <Route path="/set-password" component={SetPasswordPage} />
        {/* A1 (v24.0) — alias for cached forgot-password email links that point to /auth/set-password */}
        <Route path="/auth/set-password" component={SetPasswordPage} />

        {/* dedicated admin login (public) */}
        <Route path="/admin/login" component={AdminLogin} />

        {/* 23-May Fix 7 — dedicated Consortium Partner login + signup-apply (public).
         * These mirror /admin/login: partner-only persona at a discoverable URL
         * instead of relying on /auth/login post-auth probing of /api/partner/me. */}
        <Route path="/partner/login" component={PartnerLogin} />
        <Route path="/partner/signup" component={PartnerSignup} />
        <Route path="/select-company" component={SelectCompany} />

        {/* Public token-gated flow — NOT wrapped in RequireAuth (token IS the auth) */}
        <Route path="/investor/login" component={InvestorLogin} />
        <Route path="/investor/signup" component={InvestorSignup} />

        {/* Patch v6 — partner magic-link redemption (public; one-time token) */}
        <Route path="/auth/redeem-partner-invite/:token" component={RedeemPartnerInvite} />

        {/* Public: collective preview */}
        <Route path="/collective/preview" component={CollectivePreview} />

        {/* Public: financials fill (token-gated at route level) */}
        <Route path="/financials-fill/:token" component={FinancialsFill} />

        {/* ===== FOUNDER ROUTES — RequireAuth + optional subscription gate ===== */}
        {/* Sprint 28 Billing — Subscribe + Billing are NOT gated (user may be mid-payment) */}
        <Route path="/founder/subscribe">
          {() => <RequireAuth><FounderSubscribe /></RequireAuth>}
        </Route>
        {/* WAVE 8 / ORP-027 (DEF-027) — REACHABILITY RESTORED.
            v25.45 F10c removed the Billing left-nav and made this path redirect
            to Settings → Billing & Subscription on the belief that Settings was
            "the canonical full Billing surface". It is not. Verified against
            this tree: client/src/pages/founder/Billing.tsx (683 lines) is the
            ONLY caller of four founder billing capabilities, and none of them
            exist anywhere in founder/Settings.tsx —
              PATCH /api/founder/subscription/payment-method   (Billing.tsx:157)
              POST  /api/founder/invoices/:invoiceId/email     (Billing.tsx:315)
              PATCH /api/founder/subscription cancel_at_period_end (Billing.tsx:399)
              POST  /api/founder/subscription/resume           (Billing.tsx:414)
            The redirect therefore silently dropped change-payment-method,
            email-invoice, cancel and resume from the product. The route now
            mounts the real page again; Settings keeps its summary tab and links
            here for the actions it does not implement. */}
        <Route path="/founder/billing">
          {() => <RequireAuth><FounderBilling /></RequireAuth>}
        </Route>
        {/* v24.2 Airwallex wiring — return from hosted checkout; NOT subscription-gated
            (the plan may still be activating when the browser lands here). */}
        <Route path="/founder/billing/return">
          {() => <RequireAuth><BillingReturn /></RequireAuth>}
        </Route>

        {/* Gated founder routes — require auth + active subscription */}
        <Route path="/founder/dashboard">
          {() => <RequireAuth><RequireActiveSubscription><FounderDashboard /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/captable">
          {() => <RequireAuth><RequireActiveSubscription><FounderCapTable /></RequireActiveSubscription></RequireAuth>}
        </Route>
        {/* WAVE 92 — ADDED AFTER the cap table route, never inserted before it: an
            ordinal insertion at the head of a container is how this project has
            previously shifted every following entry and tripped the drop detector
            (R82). Same guards as its neighbour, so it inherits exactly the same
            authentication and subscription posture. */}
        <Route path="/founder/captable/waterfall">
          {() => <RequireAuth><RequireActiveSubscription><FounderExitWaterfall /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/rounds/new">
          {() => <RequireAuth><RequireActiveSubscription><FounderRoundNew /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/rounds/:id/termsheet">
          {(p) => <RequireAuth><RequireActiveSubscription><FounderTermSheet /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/rounds/:id">
          {(p) => <RequireAuth><RequireActiveSubscription><FounderRoundDetail /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/rounds">
          {() => <RequireAuth><RequireActiveSubscription><FounderRounds /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/crm/new">
          {() => <RequireAuth><RequireActiveSubscription><FounderCRMNew /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/crm">
          {() => <RequireAuth><RequireActiveSubscription><FounderCRM /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/dataroom">
          {() => <RequireAuth><RequireActiveSubscription><FounderDataroom /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/reports/new">
          {() => <RequireAuth><RequireActiveSubscription><FounderReportNew /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/reports">
          {() => <RequireAuth><RequireActiveSubscription><FounderReports /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/messages">
          {() => <RequireAuth><RequireActiveSubscription><FounderMessages /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/network-posts">
          {() => <RequireAuth><RequireActiveSubscription><FounderNetworkPosts /></RequireActiveSubscription></RequireAuth>}
        </Route>
        <Route path="/founder/posts/:id">
          {() => <RequireAuth><RequireActiveSubscription><PostDetail role="founder" /></RequireActiveSubscription></RequireAuth>}
        </Route>

        {/* Founder routes — auth required, NOT subscription-gated */}
        <Route path="/founder/company">
          {() => <RequireAuth><FounderCompany /></RequireAuth>}
        </Route>
        {/* v25.45 F8b — Company Management parent landing page (Team sub-tab). */}
        <Route path="/founder/company-management">
          {() => <RequireAuth><FounderCompanyManagement /></RequireAuth>}
        </Route>
        {/* v25.45 F7 — Settings → Company tab deleted; redirect any deep-link
            to the canonical Company Profile page. */}
        <Route path="/founder/settings/company">
          {() => <Redirect to="/founder/company" />}
        </Route>
        <Route path="/founder/profile/wizard">
          {() => <RequireAuth><FounderProfileWizard /></RequireAuth>}
        </Route>
        <Route path="/founder/activity">
          {() => <RequireAuth><FounderActivity /></RequireAuth>}
        </Route>
        <Route path="/founder/settings">
          {() => <RequireAuth><FounderSettings /></RequireAuth>}
        </Route>
        <Route path="/founder/collective">
          {() => <RequireAuth><FounderCollective /></RequireAuth>}
        </Route>
        <Route path="/founder/apply-to-collective">
          {() => <RequireAuth><FounderApplyToCollective /></RequireAuth>}
        </Route>
        <Route path="/founder/welcome">
          {() => <RequireAuth><FounderWelcome /></RequireAuth>}
        </Route>
        <Route path="/founder/glossary">
          {() => <RequireAuth><FounderGlossary /></RequireAuth>}
        </Route>
        {/* HIGH-7 — founder notifications feed (same component as investor, auth-only, no subscription gate) */}
        <Route path="/founder/notifications">
          {() => <RequireAuth><InvestorNotifications /></RequireAuth>}
        </Route>
        <Route path="/founder/companies/:id">
          {() => <RequireAuth><FounderCompanyDetail /></RequireAuth>}
        </Route>

        {/* ===== INVESTOR ROUTES — RequireAuth ===== */}
        <Route path="/investor/dashboard">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorDashboard /></RequireAuth>}
        </Route>
        <Route path="/investor/companies/:id">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorCompanyDetail /></RequireAuth>}
        </Route>
        <Route path="/investor/invitations/:id">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorInvitationDetail /></RequireAuth>}
        </Route>
        <Route path="/investor/invitations">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorInvitations /></RequireAuth>}
        </Route>
        <Route path="/investor/portfolio">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorPortfolio /></RequireAuth>}
        </Route>
        <Route path="/investor/crm/new">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorCRMNew /></RequireAuth>}
        </Route>
        <Route path="/investor/crm">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorCRM /></RequireAuth>}
        </Route>
        <Route path="/investor/apply-to-collective">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorApplyToCollective /></RequireAuth>}
        </Route>
        <Route path="/investor/profile">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorProfile /></RequireAuth>}
        </Route>
        {/* v26.1.x AVI-ACCRED — accreditation self-declaration page; target of the
            money-core 412 resolutionUrl (/investor/accreditation?investorId=…). */}
        <Route path="/investor/accreditation">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorAccreditation /></RequireAuth>}
        </Route>
        {/* WAVE 10 / EN-3 — "I invested before I had an account."

            WAVE 22 · ITEM 3 (REVIEW B F-1) — COMMENT CORRECTED. The previous
            wording ("Linked here rather than buried in settings because the LP
            who needs it is looking at an EMPTY portfolio") asserted a link that
            DID NOT EXIST: Review B grepped the whole client tree and found ZERO
            inbound links to this route, so the page was reachable only by
            typing the URL, i.e. NOT SHIPPED under this project's own rule
            (WAVE7_REPORT.md:130). The claim was false when written and stayed
            false for eleven waves.

            The two inbound links now exist and are the statement of fact this
            comment used to be a wish for:
              1. investor nav, DEALS section — client/src/components/AppShell.tsx
                 (`/investor/earlier-investments`, label "Earlier Investments")
              2. the empty-portfolio CTA row —
                 client/src/components/investor/PortfolioCompanySwitcher.tsx
                 (`button-portfolio-claim-earlier`)
            A falsification harness asserts both, and fails if either is removed:
            scripts/__tests__/wave22_item3_orphan_link_falsify.sh */}
        <Route path="/investor/earlier-investments">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorClaimPositions /></RequireAuth>}
        </Route>
        <Route path="/investor/messages">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorMessages /></RequireAuth>}
        </Route>
        {/* v25.47 APD-035 (HIGH-6) — /investor/inbox alias to the investor inbox. */}
        <Route path="/investor/inbox">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorMessages /></RequireAuth>}
        </Route>
        <Route path="/investor/collective">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorCollective /></RequireAuth>}
        </Route>
        <Route path="/investor/network-posts">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorNetworkPosts /></RequireAuth>}
        </Route>
        <Route path="/investor/posts/:id">
          {() => <RequireAuth redirectTo="/investor/login"><PostDetail role="investor" /></RequireAuth>}
        </Route>
        <Route path="/investor/settings">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorSettings /></RequireAuth>}
        </Route>
        <Route path="/investor/glossary">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorGlossary /></RequireAuth>}
        </Route>
        <Route path="/investor/notifications">
          {() => <RequireAuth redirectTo="/investor/login"><InvestorNotifications /></RequireAuth>}
        </Route>

        {/* ===== CROSS-ROLE ROUTES ===== */}
        <Route path="/notifications">
          {() => <RequireAuth><NotificationCenter /></RequireAuth>}
        </Route>
        {/* 2026-09-19 — LEGACY BOOKMARK ALIAS. Notifications persisted before this
            date carry link `/partner/pipeline`, a path that never had a route
            (Page not found). The bell/center now repair it through the shared
            classifier, but a stored bookmark or an e-mail still lands here, so the
            EXACT legacy path forwards to the mounted partner pipeline with its
            query/hash preserved. Exact path only — no global `/partner/*`. */}
        <Route path="/partner/pipeline">
          {() => <LegacyPartnerPipelineRedirect />}
        </Route>

        {/* ===== ADMIN ROUTES — RequireAuth role="admin" ===== */}
        <Route path="/admin/wishlist">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminWishList /></RequireAuth>}
        </Route>
        <Route path="/admin/dashboard">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminDashboard /></RequireAuth>}
        </Route>
        <Route path="/admin/companies/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCompanyDetail /></RequireAuth>}
        </Route>
        <Route path="/admin/companies">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCompanies /></RequireAuth>}
        </Route>
        <Route path="/admin/investors/import">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminInvestorImport /></RequireAuth>}
        </Route>
        <Route path="/admin/investors/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminInvestorDetail /></RequireAuth>}
        </Route>
        <Route path="/admin/investors">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminInvestors /></RequireAuth>}
        </Route>
        <Route path="/admin/users">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminUsers /></RequireAuth>}
        </Route>
        <Route path="/admin/bridge">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminBridge /></RequireAuth>}
        </Route>
        {/* v25.0 Track 5 — E8: Bridge Event History */}
        <Route path="/admin/bridge-history">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminBridgeHistory /></RequireAuth>}
        </Route>
        {/* v25.33 Consortium Partner Payment Model — admin partner roster (DB-driven).
           MUST precede /admin/partners/:id so wouter matches the exact list path first. */}
        <Route path="/admin/partners">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminPartners /></RequireAuth>}
        </Route>
        {/* WAVE 4B (PT-2) — partner classification taxonomy admin. Same admin
            guard as every other /admin route; the guard does not read a
            classification (PT-5 scope fence). */}
        {/* WAVE 14 — the admin surface for the Wave 5 partner money engine:
            tier prices (CP-SUB-12/13), promotion moderation (CP-PROMO-20),
            roster reconciliation (CP-SUB-11) and the open pricing decisions
            (CP-SUB-19 / CP-PROMO-04/17/22). */}
        <Route path="/admin/partner-billing-ops">
          {/* Same guard as every neighbouring admin route: RequireAuth with
              role="admin" and the admin login redirect. There is no
              `RequireAdmin` component in this file — checked, rather than
              assumed from the name. */}
          {/* WAVE 131 — see the pricing-console note below: this renders the
              consolidated console on its Partner Tier Prices tab, which mounts
              AdminPartnerBillingOps itself. */}
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="tier-prices" /></RequireAuth>}
        </Route>
        <Route path="/admin/partner-taxonomy">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><PartnerTaxonomyAdmin /></RequireAuth>}
        </Route>
        {/* slide13b WAVE D — company-sector taxonomy admin (distinct from partner taxonomy). */}
        <Route path="/admin/company-taxonomy">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><CompanyTaxonomyAdmin /></RequireAuth>}
        </Route>
        {/* D2.5 SLICE 1 — the ONE consolidated fee page. Replaces 15 routes:
             /admin/pricing · /admin/pricing-models · /admin/pricing-models/:id
             /admin/application-fee · /admin/platform-fees · /admin/commission-rates
             /admin/partner-fees · /admin/partner-pl · /admin/collective-subscriptions
             /admin/collective-payment-schedules · /admin/collective-payment-pl
             /admin/payments · /admin/capavate-fees · /admin/collective-fees
             /admin/partner-fees-hub
           MUST stay above the /admin/:rest* catch-all. */}
        <Route path="/admin/fees">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated /></RequireAuth>}
        </Route>
        {/* WAVE 4A (RS-1 / RS-2) — the two legacy fee-schedule URLs are ALIASES
             onto the ONE consolidated page, deep-linked to its Fee Schedules
             tab. They are signage, not a second implementation: no standalone
             page component is re-routed, and `/admin/fees` remains the single
             fee surface the D2.5 consolidation created. Restoring the URLs is
             what makes the RS-1/RS-2 deferrals genuinely RESOLVED rather than
             forgiven — the guard baseline records these paths as user-reachable
             and they are user-reachable again. Same admin guard as /admin/fees.
             MUST stay above the /admin/:rest* catch-all. */}
        <Route path="/admin/collective-payment-schedules">
          {/* WAVE 131 — retargeted from the shared Fee Schedules tab to the tab
              that mounts the Collective Payment Schedules page itself, so the
              URL lands on the capability it names. */}
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="collective-payment-schedules" /></RequireAuth>}
        </Route>
        <Route path="/admin/partner-fees">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="fee-schedules" /></RequireAuth>}
        </Route>

        {/* ══ WAVE 7 R-1 — disposition of the 13 retired fee pages ════════

            R-1 asks for each of the thirteen to be re-routed or descoped
            INDIVIDUALLY. The decision was not made by reading the D2.5 intent;
            it was computed. `scripts/wave7_r1_fee_page_disposition.mjs` walks
            every .ts/.tsx under client/src EXCEPT the thirteen, collects every
            /api/... literal it can reach, and asks of each retired page: does
            it call an endpoint that nothing still-routed calls? Output is
            checked in at build_log/wave7_r1_disposition.json and the
            wave7_r1_disposition test re-derives it, so this ruling cannot rot
            silently.

            DESCOPE (8):
              (a) six whose every endpoint is reachable from a still-routed
                  page, so their URLs were pure duplication — FeeHub, Payments,
                  PartnerFeeSchedules, PartnerPL, CollectivePaymentSchedules,
                  CollectivePaymentPL;
              (b) two the computed pass flagged but a SETTLED RULING overrides —
                  AdminApplicationFee and AdminPlatformFees (see the note at
                  their would-be routes below).
            All eight stay on disk, unrouted. Nothing they can do is lost.

            RE-ROUTE (5) — each is the ONLY client caller of at least one WRITE
            endpoint, so retiring its URL silently removed an admin capability
            (not merely a URL). Restored below at their original paths. The
            server routes were never touched by D2.5, so this is WIRING: no page
            component was rewritten and no endpoint was added.

            Why aliasing onto AdminFeesConsolidated is NOT the answer here (it
            was, correctly, for RS-1/RS-2): an alias deep-links to a tab that
            already renders the capability. For these seven the capability is
            absent from the consolidated page entirely — the endpoint appears
            in no other client file at all. There is nothing to deep-link to. */}
        {/* AdminApplicationFee and AdminPlatformFees are the two pages the
            computed pass flagged as re-route candidates and that are
            DELIBERATELY NOT re-routed. Both are sole callers of
            /api/admin/collective/application-fee, but D2.5 removed that editor
            ON PURPOSE, not by omission: AdminFeesConsolidated.tsx:1231 states
            that the duplicate editor "which wrote display dollars into
            collective_application_fee_config" is deleted, and the surviving
            Application Fee tab writes platform_fees['collective_application_fee']
            in TRUE minor units. Restoring these two would put back a SECOND
            WRITER, in a different unit, for one fee — the precise failure this
            wave exists to prevent. Overriding a settled unit-correctness ruling
            is not R-1's job, so they are DESCOPED and the override is recorded
            in the disposition script rather than left as an unexplained gap. */}
        {/* WAVE 131 (R95 / R96 req 1 + req 6) — ONE pricing console. This URL is
            KEPT (an admin who bookmarked it must not get a 404) and now renders
            the consolidated console deep-linked to the tab that MOUNTS the very
            same page component. Nothing is dropped: the capability moved address,
            it did not disappear. */}
        <Route path="/admin/collective-subscriptions">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="collective-subscriptions" /></RequireAuth>}
        </Route>
        <Route path="/admin/commission-rates">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="commission-rates" /></RequireAuth>}
        </Route>
        {/* WAVE 131 — the three pricing pages wave 7 R-1 DESCOPED (left on disk,
            unrouted) are now reachable again, as tabs of the one console. A
            descoped page that an admin can no longer open is a dropped
            capability however it is labelled. */}
        <Route path="/admin/payments">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="payments" /></RequireAuth>}
        </Route>
        <Route path="/admin/partner-pl">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="partner-pl" /></RequireAuth>}
        </Route>
        <Route path="/admin/collective-payment-pl">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="collective-pl" /></RequireAuth>}
        </Route>
        {/* WAVE 131 — the three W-V44 hub URLs D2.5 DELETED now open the console
            on its Price Source Map tab instead of the admin 404. A hub URL whose
            job was "show me where pricing lives" is answered exactly by it. */}
        <Route path="/admin/capavate-fees">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="source-map" /></RequireAuth>}
        </Route>
        <Route path="/admin/collective-fees">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="source-map" /></RequireAuth>}
        </Route>
        <Route path="/admin/partner-fees-hub">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="source-map" /></RequireAuth>}
        </Route>
        {/* ══ WAVE 131 — THE FIVE DIRECT-VIEW ALIASES ═════════════════════

            R96 req 6: NOTHING MAY BE DROPPED. Repointing the five pricing URLs
            onto the consolidated console removed the only place these five page
            components were RENDERED from a route
            (AdminPricing, PricingModels, CollectiveSubscriptions,
            AdminCommissionRates, AdminPartnerBillingOps), which the restyle drop
            detector correctly reported as five bare disappearances from this
            file — to a user, a rendered surface that no route can produce is
            gone. The consolidated console MOUNTS all five as tabs, and that is
            where administration happens; these aliases exist so the standalone
            rendering ALSO still exists, unchanged, for anyone holding a direct
            link or debugging one page in isolation.

            They are deliberately NOT in the sidebar and are not linked from the
            console: the owner asked for ONE pricing link and there is one
            ("Pricing & Payments" → /admin/fees). Same admin guard as every
            neighbouring route. `/admin/pricing-models/direct` MUST precede
            `/admin/pricing-models/:id` or wouter would read "direct" as an id.
            Enforced by server/__tests__/wave131_one_pricing_console.test.ts §2. */}
        <Route path="/admin/pricing/direct">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminPricing /></RequireAuth>}
        </Route>
        <Route path="/admin/pricing-models/direct">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><PricingModels /></RequireAuth>}
        </Route>
        <Route path="/admin/collective-subscriptions/direct">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><CollectiveSubscriptions /></RequireAuth>}
        </Route>
        <Route path="/admin/commission-rates/direct">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCommissionRates /></RequireAuth>}
        </Route>
        <Route path="/admin/partner-billing-ops/direct">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminPartnerBillingOps /></RequireAuth>}
        </Route>
        {/* /admin/pricing-models/:id MUST precede /admin/pricing-models so
            wouter matches the detail path; and both must precede the
            /admin/:rest* catch-all. */}
        <Route path="/admin/pricing-models/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><PricingModelDetail /></RequireAuth>}
        </Route>
        <Route path="/admin/pricing-models">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="pricing-models" /></RequireAuth>}
        </Route>
        <Route path="/admin/pricing">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFeesConsolidated initialTab="capavate-pricing" /></RequireAuth>}
        </Route>
        {/* ══ /WAVE 7 R-1 ═════════════════════════════════════ */}
        <Route path="/admin/partner-responders">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><PartnerResponders /></RequireAuth>}
        </Route>
        {/* v25.0 Track 5 — E7: Admin Partner Detail */}
        <Route path="/admin/partners/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminPartnerDetail /></RequireAuth>}
        </Route>
        <Route path="/admin/sync">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminSync /></RequireAuth>}
        </Route>
        <Route path="/admin/platform-surfaces">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminPlatformSurfaces /></RequireAuth>}
        </Route>
        <Route path="/admin/migration">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminMigration /></RequireAuth>}
        </Route>
        <Route path="/admin/email/new">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminEmailComposer /></RequireAuth>}
        </Route>
        <Route path="/admin/email/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminEmailComposer /></RequireAuth>}
        </Route>
        <Route path="/admin/email">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminEmail /></RequireAuth>}
        </Route>
        <Route path="/admin/notifications/new">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminNotificationComposer /></RequireAuth>}
        </Route>
        <Route path="/admin/notifications/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminNotificationComposer /></RequireAuth>}
        </Route>
        <Route path="/admin/notifications">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminNotifications /></RequireAuth>}
        </Route>
        {/* 2026-09-19 — the admin's PERSONAL inbox (notices addressed to the admin
            session user, scoped to the admin workspace). Distinct from
            `/admin/notifications` above, which is the campaign composer/list and is
            not replaced. */}
        <Route path="/admin/inbox">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><NotificationCenter surface="admin" /></RequireAuth>}
        </Route>
        <Route path="/admin/formulas/new">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFormulaNew /></RequireAuth>}
        </Route>
        <Route path="/admin/formulas/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFormulaDetail /></RequireAuth>}
        </Route>
        <Route path="/admin/formulas">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminFormulas /></RequireAuth>}
        </Route>
        <Route path="/admin/regions/:id">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminRegionExtensionDetail /></RequireAuth>}
        </Route>
        <Route path="/admin/regions">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminRegionsExtensions /></RequireAuth>}
        </Route>
        <Route path="/admin/lifecycle-policies">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminLifecyclePolicies /></RequireAuth>}
        </Route>
        <Route path="/admin/audit-log">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminAuditLog /></RequireAuth>}
        </Route>
        {/* CP Phase B — Admin queue for consortium-partner applications + promotion moderation */}
        <Route path="/admin/consortium-applications">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminConsortiumApplicationsPage /></RequireAuth>}
        </Route>
        {/* WAVE 28 / CP-CRM-04 — CRM duplicate-contact review queue. Reads the
            crm_dedup_review table migration 0097 has been filling since v25.52
            with no reader anywhere in the tree. */}
        <Route path="/admin/crm-dedup-review">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCrmDedupReview /></RequireAuth>}
        </Route>
        {/* WAVE 155 (R123.1 / R124.4.3) — the admin-granted (comped) membership.
            `capavate_subscriptions` is written only by the payment flow and the
            gateway webhook, so with zero rows and an unconfigured payment path
            the SPV launch check had NO clearable path from admin at all. This is
            it. A comp is never presented as revenue anywhere it appears. */}
        <Route path="/admin/comped-memberships">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCompedMemberships /></RequireAuth>}
        </Route>
        {/* WAVE 156 (R124.4.1) — the SPV launch check. R114.3 makes the admin
            override a HARD release condition; before this route the endpoints in
            server/adminSpvLaunchGateRoutes.ts had no client caller anywhere, so
            the owner could not exercise the lever the ruling requires. */}
        <Route path="/admin/spv-launch-gate">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminSpvLaunchGate /></RequireAuth>}
        </Route>
        {/* v19 Phase C — Hash-chain audit verification UI */}
        <Route path="/admin/audit-chain-verify">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AuditChainVerifyPage /></RequireAuth>}
        </Route>
        {/* W-V44 FIX K — market-data provider Integrations (DB-driven, admin-config). */}
        <Route path="/admin/integrations">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminIntegrations /></RequireAuth>}
        </Route>
        {/* D2.5 SLICE 1 — the 3 W-V44 fee hub routes (/admin/capavate-fees,
            /admin/collective-fees, /admin/partner-fees-hub) are DELETED.
            Hub card decks became redundant the moment the leaf pages they
            deep-linked to were folded into /admin/fees tabs. */}
        {/* Wave B FIX 11 (A-BUG-002) — documented alias path used by the v19
            admin runbook + QA scripts. Both routes render the same page. */}
        <Route path="/admin/audit/verify-chain">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AuditChainVerifyPage /></RequireAuth>}
        </Route>
        {/* Wave B FIX (A-BUG-011) — alias for the audit-log page. */}
        <Route path="/admin/audit">
          {() => <Redirect to="/admin/audit-log" />}
        </Route>
        <Route path="/admin/reconciliation">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminReconciliation /></RequireAuth>}
        </Route>
        {/* D2.5 SLICE 1 — /admin/payments retired; the payment_ledger view now
            lives in the /admin/fees "Ledger & Invoices" tab (same endpoint,
            GET /api/admin/payments, which is UNCHANGED). */}
        <Route path="/admin/telemetry">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminTelemetry /></RequireAuth>}
        </Route>

        {/* Wave C FIX C7 — admin sidebar route reconciliation + 404 polish.
         * A-FINAL-023 (Avi, 24-May-2026): the live QA build returned the
         * generic dev 404 "Did you forget to add the page to the router?"
         * for /admin/lifecycle (sidebar uses /admin/lifecycle-policies) and
         * /admin/chapters (phantom URL never registered). This block:
         *
         *   1. Adds an explicit alias for /admin/lifecycle → the canonical
         *      /admin/lifecycle-policies URL so bookmarked / pasted links
         *      from older admin docs keep working.
         *   2. Adds an /admin/* catch-all rendering the polished
         *      AdminNotFound component (admin-branded card with a link
         *      back to the dashboard) for any unregistered admin path.
         *      This sits BEFORE the global NotFoundOrLogin catch-all so
         *      admin visitors see the admin-aware 404 instead of the dev
         *      placeholder. */}
        <Route path="/admin/lifecycle">
          {() => <Redirect to="/admin/lifecycle-policies" />}
        </Route>
        {/* v23.5 C-003 — admin Collective pages */}
        <Route path="/admin/collective/applications">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCollectiveApplications /></RequireAuth>}
        </Route>
        <Route path="/admin/collective/members">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCollectiveMembers /></RequireAuth>}
        </Route>
        <Route path="/admin/collective/settings">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCollectiveSettings /></RequireAuth>}
        </Route>
        <Route path="/admin/collective/waitlist">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminCollectiveWaitlist /></RequireAuth>}
        </Route>
        {/* W5.2 — de-duplicate admin Collective Settings. The hierarchical
           /admin/collective/settings (line ~871) is the CANONICAL route — it matches the
           established /admin/collective/* namespace used by members, waitlist, applications,
           etc., and is the path the admin nav (AppShell) links to. The former hyphenated
           alias /admin/collective-settings now 301-style redirects to it (single source of
           truth for the URL; the backend API path /api/admin/collective-settings is unchanged). */}
        <Route path="/admin/collective-settings">
          {() => <Redirect to="/admin/collective/settings" />}
        </Route>
        {/* v25.47 APD-022 — DB-driven Pulse index watchlist CRUD. */}
        <Route path="/admin/pulse-symbols">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminPulseSymbols /></RequireAuth>}
        </Route>
        {/* v25.47 APD-023 — network post moderation. */}
        <Route path="/admin/posts">
          {() => <RequireAuth role="admin" redirectTo="/admin/login"><AdminPostsModeration /></RequireAuth>}
        </Route>
        <Route path="/admin/:rest*">
          {() => (
            <RequireAuth role="admin" redirectTo="/admin/login">
              <AdminNotFound />
            </RequireAuth>
          )}
        </Route>

        {/* ===== COLLECTIVE ROUTES — RequireAuth ===== */}
        {/* v25.48.2 Q12 (Ozan) — bare /collective is not a page; send it to the
            Collective dashboard so the nav entry / deep links resolve instead of
            hitting the catch-all 404. */}
        <Route path="/collective">
          {() => <Redirect to="/collective/dashboard" />}
        </Route>
        {/* ════════════════════════════════════════════════════════════════════════
            WAVE 149 · ITEM 2 — THE INBOX, INSIDE THE PERSONA'S OWN SHELL.
            ════════════════════════════════════════════════════════════════════════
            `/notifications` (:876) already existed and is role-agnostic, but it
            renders `NotificationCenter` BARE — a Collective member or Consortium
            Partner following "View all" lost their rail, their topbar and their
            place. The SAME page is registered here wrapped in `CollectiveShell`,
            exactly as `/collective/dashboard` below is, so the reader keeps their
            shell. `/notifications` is left untouched: the investor and founder
            personas reach it through AppShell and nothing about their path changes.
            `isAuthRoute` (:437-465) and the forced-bare rule for `/collective/*`
            are NOT touched — they are what makes this shell the only chrome on the
            page, which is the point. */}
        <Route path="/collective/notifications">
          {() => <RequireAuth><CollectiveShell><NotificationCenter surface="collective" chrome="collective" /></CollectiveShell></RequireAuth>}
        </Route>
        {/* 2026-09-19 — the Consortium Partner's OWN inbox in the SAME shell, a
            separate route so partner notices are listed and counted apart from
            Collective-member notices. Partner nav (`nav-partner-notifications`)
            and the partner-mode bell's "View all" both point here. */}
        <Route path="/collective/partner/notifications">
          {() => <RequireAuth><CollectiveShell><NotificationCenter surface="partner" chrome="collective" /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE A · ITEM 3b — A SECOND DOOR ONTO THE SAME PAGE, SO A CONSORTIUM
            PARTNER KEEPS THEIR OWN SHELL.
            ──────────────────────────────────────────────────────────────────
            The onboarding checklist's retention acknowledgement linked at
            `/settings/privacy`, which is registered below WITHOUT CollectiveShell.
            The anchor is a plain `<a href>`, so following it was a full page load
            that dropped the partner out of their rail and topbar entirely — which
            is what "goes to a completely different section" feels like from the
            outside. Both anchors on that page resolve to real registered routes;
            this was never a dead link.

            The pattern is the one immediately above: a NEW path onto the SAME
            component, so there is no second source of truth and no duplicated
            page. The bare `/settings/privacy` registration below is UNTOUCHED —
            founder and investor personas reach it exactly as they did, and
            nothing is deleted (R195.5). */}
        <Route path="/collective/partner/privacy">
          {() => <RequireAuth><CollectiveShell><PrivacyPage /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 341 (productgaps2) · W335 — THE LEGAL PAGES SWITCHED THE SIDEBAR
            TO THE FOUNDER WORKSPACE. This is exactly the defect the precedent
            immediately above fixed, on the other legal surface, and the fix is
            the same shape.

            MEASURED, NOT ASSUMED. `/terms`, `/terms-of-service`, `/privacy`,
            `/privacy-policy` and `/legal/:docId` are registered at :628-637 as
            bare PUBLIC routes. `AppRouter` (:~1670) ends
            `return bare ? routes : <AppShell>{routes}</AppShell>`, and
            `isAuthRoute` (:443) only makes a path bare when it starts with
            "/collective/" — which none of those five do. `AppShell` then derives
            its own scope from the URL (AppShell.tsx:~810): /admin, /investor and
            /founder are matched by prefix and EVERYTHING ELSE FALLS BACK TO THE
            ROLE IN CONTEXT, whose initial value is "founder". Every Consortium
            Partner and Collective page lives under /collective/ inside
            CollectiveShell, which mounts the footer link
            (CollectiveShell.tsx:787) — so following it dropped the partner out
            of their own rail and into the Founder workspace sidebar.

            THE FIX. New paths onto the SAME components, inside the shell the
            visitor is already in. No new page and no second source of truth.
            The five bare public registrations at :628-637 are UNTOUCHED, so
            founder, investor, admin and anonymous visitors reach them exactly as
            they did, and nothing is deleted (R195.5).

            TWO SCOPES, NOT ONE, because CollectiveShell derives its theme from
            the URL as well (CollectiveShell.tsx:750): data-product is "partner"
            iff the path starts with "/collective/partner", else "collective".
            Sending a Collective MEMBER to a /collective/partner alias would
            silently re-theme their page as a partner page.
            client/src/lib/legalShellScope.ts picks the matching alias. */}
        <Route path="/collective/partner/terms-of-service">
          {() => <RequireAuth><CollectiveShell><LegalTermsPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/privacy-policy">
          {() => <RequireAuth><CollectiveShell><LegalPrivacyPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/legal/:docId">
          {(params: { docId: string }) => <RequireAuth><CollectiveShell><AdoptedLegalDocumentPage docId={params.docId} /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/terms-of-service">
          {() => <RequireAuth><CollectiveShell><LegalTermsPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/privacy-policy">
          {() => <RequireAuth><CollectiveShell><LegalPrivacyPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/legal/:docId">
          {(params: { docId: string }) => <RequireAuth><CollectiveShell><AdoptedLegalDocumentPage docId={params.docId} /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/dashboard">
          {/* v25.48.2 MF7 (Q9) — the member gate now lives inside CollectiveShell
              and wraps ALL member-only routes, so no per-route wrap here. */}
          {() => <RequireAuth><CollectiveShell><CollectiveDashboard /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/dealroom/:companyId">
          {(p) => <RequireAuth><CollectiveShell><CollectiveDealRoomDetail /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/dealroom">
          {() => <RequireAuth><CollectiveShell><CollectiveDealRoom /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/members">
          {() => <RequireAuth><CollectiveShell><CollectiveMembers /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/companies/:id">
          {(p) => <RequireAuth><CollectiveShell><CollectiveCompanyDetail /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/companies">
          {() => <RequireAuth><CollectiveShell><CollectiveCompanies /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/soft-circles">
          {() => <RequireAuth><CollectiveShell><CollectiveSoftCircles /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/dsc/pipeline">
          {() => <RequireAuth><CollectiveShell><CollectiveDscPipeline /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/dsc/scores">
          {() => <RequireAuth><CollectiveShell><CollectiveDscScores /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/dsc/prep">
          {() => <RequireAuth><CollectiveShell><CollectiveTransactionPrep /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/membership">
          {/* v25.22 NC-4 fix — swap to the live MembershipPage so the
              checkout flow is actually reachable. The read-only summary is
              now at /collective/membership-summary. */}
          {() => <RequireAuth><CollectiveShell><MembershipPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/membership-summary">
          {() => <RequireAuth><CollectiveShell><CollectiveMembership /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/activity">
          {() => <RequireAuth><CollectiveShell><CollectiveActivity /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/settings">
          {() => <RequireAuth><CollectiveShell><CollectiveSettings /></CollectiveShell></RequireAuth>}
        </Route>

        {/* ===== v25.42 (Bucket B) — new Collective routes R1–R6, R8 ===== */}
        <Route path="/collective/connections">
          {() => <RequireAuth><CollectiveShell><CollectiveConnections /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/recaps">
          {() => <RequireAuth><CollectiveShell><CollectiveRecaps /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/screening-recaps">
          {() => <RequireAuth><CollectiveShell><CollectiveScreeningRecaps /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/chapters">
          {() => <RequireAuth><CollectiveShell><CollectiveChapters /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/portal/requests">
          {() => <RequireAuth><CollectiveShell><CollectiveMyRequests /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/profile/:userId">
          {() => <RequireAuth><CollectiveShell><CollectivePublicProfile /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partners">
          {() => <RequireAuth><CollectiveShell><CollectivePartnersDirectory /></CollectiveShell></RequireAuth>}
        </Route>

        {/* v25.44 Wave A + M&A + venture routes. */}
        <Route path="/ma-intel">
          {() => <RequireAuth><CollectiveShell><MaIntel /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/ma-intel">
          {() => <RequireAuth><CollectiveShell><MaIntel /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/me/portfolio">
          {() => <RequireAuth><CollectiveShell><MyPortfolioPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/presentations">
          {() => <RequireAuth><CollectiveShell><PresentationsPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/posts">
          {() => <RequireAuth><CollectiveShell><NetworkPostsPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/monthly-meetings">
          {() => <RequireAuth><CollectiveShell><MonthlyMeetingsPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/schedule">
          {() => <RequireAuth><CollectiveShell><SchedulePage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/syndicate/apply">
          {() => <RequireAuth><CollectiveShell><SyndicateApplyPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/syndicate/apply">
          {() => <RequireAuth><CollectiveShell><SyndicateApplyPage /></CollectiveShell></RequireAuth>}
        </Route>

        {/* v19 Phase A — Events Calendar (month view) + Leaderboard.
         * Both pages are hidden client-side when COLLECTIVE_ENABLED is off
         * (the components return null on the feature-flag check). */}
        <Route path="/collective/calendar">
          {() => <RequireAuth><CollectiveShell><EventsCalendarPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/leaderboard">
          {() => <RequireAuth><CollectiveShell><LeaderboardPage /></CollectiveShell></RequireAuth>}
        </Route>
        {/* v25.12 NC2 — screening events list + detail. */}
        <Route path="/collective/screening-events/:id">
          {() => <RequireAuth><CollectiveShell><ScreeningEventsPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/screening-events">
          {() => <RequireAuth><CollectiveShell><ScreeningEventsPage /></CollectiveShell></RequireAuth>}
        </Route>
        {/* v25.12 NC2 — Expert Q&A list page. */}
        <Route path="/collective/ask-expert">
          {() => <RequireAuth><CollectiveShell><AskExpertPage /></CollectiveShell></RequireAuth>}
        </Route>
        {/* v25.12 NC2 — Expert Q&A detail page. */}
        <Route path="/collective/questions/:id">
          {() => <RequireAuth><CollectiveShell><QuestionDetailPage /></CollectiveShell></RequireAuth>}
        </Route>
        {/* v25.48 AI-6 — /collective/ask(+/:id) aliases. The server (expertQAStore)
            emits notification + email links to /collective/ask and /collective/ask/:id,
            and QuestionDetailPage's own back-nav uses /collective/ask, but only
            /collective/ask-expert and /collective/questions/:id were registered —
            so those in-app + emailed links 404'd. These aliases resolve them to the
            same pages without touching the 9 server link sites. */}
        <Route path="/collective/ask/:id">
          {() => <RequireAuth><CollectiveShell><QuestionDetailPage /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/ask">
          {() => <RequireAuth><CollectiveShell><AskExpertPage /></CollectiveShell></RequireAuth>}
        </Route>
        {/* v25.12 NC3 — announcement detail. We render the events calendar
         * page anchored to the announcement (the calendar shell already
         * surfaces announcement context); a dedicated detail page can be
         * added in v26 if richer detail rendering is required. */}
        <Route path="/collective/announcements/:id">
          {() => <RequireAuth><CollectiveShell><EventsCalendarPage /></CollectiveShell></RequireAuth>}
        </Route>

        {/* Patch v6 — Partner workspace routes live inside the CollectiveShell
         * at /collective/partner/*. Server API stays at /api/partner/me/*;
         * requirePartnerAuth resolves partnerId from the session. */}
        <Route path="/collective/partner/dashboard">
          {() => <RequireAuth><CollectiveShell><PartnerDashboard /></CollectiveShell></RequireAuth>}
        </Route>
        {/* W-MFCRM — Managed Founders (engagements + 3 CRM-layer drill-down tabs).
            Additive route; shadows nothing. Detail path before list so `:id` resolves. */}
        <Route path="/collective/partner/managed-founders/:id">
          {() => <RequireAuth><CollectiveShell><PartnerManagedFounders /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/managed-founders">
          {() => <RequireAuth><CollectiveShell><PartnerManagedFounders /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 20 XT-10 — Managed-Founder PERSONA tools. Additive route for the
            17 orphaned /api/partner/me/mfcrm/{angel,acct,law}/* endpoints
            (server/managedFounderPersonaRoutes.ts, mounted server/routes.ts:1014),
            which had zero client callers. Deliberately NOT nested under
            /collective/partner/managed-founders/* : that family already has a
            `:id` detail route registered above, and a sibling literal segment
            there would be swallowed by `:id`. A distinct top-level partner path
            shadows nothing. */}
        <Route path="/collective/partner/persona-tools">
          {() => <RequireAuth><CollectiveShell><PartnerMfcrmPersonas /></CollectiveShell></RequireAuth>}
        </Route>
        {/* W2-A — Clients CRM restored (routes re-added; server read endpoints
            rebuilt from the preserved attribution store). Detail route is
            registered BEFORE the list so the `:id` param path resolves. */}
        <Route path="/collective/partner/clients/:id">
          {() => <RequireAuth><CollectiveShell><PartnerClientDetail /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/clients">
          {() => <RequireAuth><CollectiveShell><PartnerClients /></CollectiveShell></RequireAuth>}
        </Route>
        {/* W2-D — Private Portfolio (API existed but was unrouted client-side). */}
        <Route path="/collective/partner/portfolio">
          {() => <RequireAuth><CollectiveShell><PartnerPortfolio /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 30 ENGINE 2 — the unified partner↔company relationship map.
            Migration 0136 shipped the spine with no route; this is it. */}
        <Route path="/collective/partner/relationships">
          {() => <RequireAuth><CollectiveShell><PartnerRelationships /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 30 ENGINE 3 — reusable SPV structure templates. `spv_template`
            was absent tree-wide before this wave; migration 0177 creates it and
            this is its only route. Applying a template prefills the SPV create
            form — it does NOT create an SPV, so the Wave 1c signed launch
            sign-off stays on the critical path. */}
        <Route path="/collective/partner/spv-templates">
          {() => <RequireAuth><CollectiveShell><PartnerSpvTemplates /></CollectiveShell></RequireAuth>}
        </Route>
        {/* GROUP F1 — Partner CRM person-level contacts (full parity). */}
        <Route path="/collective/partner/contacts">
          {() => <RequireAuth><CollectiveShell><PartnerContacts /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/pipeline">
          {() => <RequireAuth><CollectiveShell><PartnerPipeline /></CollectiveShell></RequireAuth>}
        </Route>
        {/* Wave B1 (3a) — Add Portfolio Company (create net-new independent company). */}
        <Route path="/collective/partner/add-portfolio-company">
          {() => <RequireAuth><CollectiveShell><PartnerAddPortfolioCompany /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/team">
          {() => <RequireAuth><CollectiveShell><PartnerTeam /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/notes">
          {() => <RequireAuth><CollectiveShell><PartnerNotes /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 7 W-8 (DEF-057) + W-5 (DEF-056) — Tasks and Files re-routed.
            The v25.50.0 Phase 6 note that used to stand here said the pages were
            "removed"; both files were still on disk, as were their stores and
            their DB tables. partner_tasks is the only partner model carrying an
            assignee, and partner_files now holds real bytes through
            objectStorage (the same seam the dataroom uses). */}
        <Route path="/collective/partner/tasks">
          {() => <RequireAuth><CollectiveShell><PartnerTasks /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/files">
          {() => <RequireAuth><CollectiveShell><PartnerFiles /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/settings">
          {() => <RequireAuth><CollectiveShell><PartnerSettings /></CollectiveShell></RequireAuth>}
        </Route>
        {/* v25.32 A3 — consortium partner billing (commission ledger; not subscription) */}
        <Route path="/collective/partner/billing">
          {() => <RequireAuth><CollectiveShell><PartnerBilling /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 14 / CP-SUB-17 — this is the exact path startPartnerCheckout
            hands the payment gateway as returnUrl
            (server/lib/partnerSubscriptionStore.ts:447). It was unrouted, so a
            partner who paid landed nowhere. Declared AFTER the billing route
            because wouter matches exact paths, so ordering is cosmetic here. */}
        <Route path="/collective/partner/billing/return">
          {() => <RequireAuth><CollectiveShell><PartnerCheckoutReturn /></CollectiveShell></RequireAuth>}
        </Route>
        {/* v25.50.0 Phase 6 (spec 9a): standalone Subscribe page removed; the
            subscribe/quote flow is merged into the Billing Subscription tab. */}
        <Route path="/collective/partner/agreement">
          {() => <RequireAuth><CollectiveShell><PartnerAgreementSign /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/tax-form">
          {() => <RequireAuth><CollectiveShell><PartnerTaxForm /></CollectiveShell></RequireAuth>}
        </Route>
        {/* CP Phase B — Partner onboarding checklist */}
        <Route path="/collective/partner/onboarding">
          {() => <RequireAuth><CollectiveShell><PartnerOnboardingChecklistPage /></CollectiveShell></RequireAuth>}
        </Route>
        {/* CP Phase B — Per-user privacy / GDPR controls */}
        {/* WAVE 305 · R251 — enrolment must be reachable by a real user, not by curl. */}
        <Route path="/settings/two-factor">
          {() => <RequireAuth><TwoFactorSetup /></RequireAuth>}
        </Route>
        <Route path="/settings/privacy">
          {() => <RequireAuth><PrivacyPage /></RequireAuth>}
        </Route>
        <Route path="/collective/partner/spv-engine">
          {() => <RequireAuth><CollectiveShell><PartnerSpvEngine /></CollectiveShell></RequireAuth>}
        </Route>
        {/* Ozan decision #4 — ONE canonical SPVs surface. The legacy plural list
            routes now REDIRECT to the canonical PartnerSpvEngine page so there is
            a single user-facing engine; the legacy detail routes stay reachable as
            read-only provenance (Sacred Rule #78 — nothing dropped). */}
        <Route path="/collective/partner/spvs/:id">
          {() => <RequireAuth><CollectiveShell><PartnerSpvDetail /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 10 / EN-1 + EN-2 — the vehicle's ILPA performance surface: the
            cash-flow ledger, the IRR/DPI/TVPI derived from it, the valuation
            mark those multiples rest on, and the chain-integrity verdict.

            WHY A ROUTE AND NOT A TAB ON THE DETAIL PAGE, which is where it
            belongs on the merits: adding a twelfth <TabsTrigger> to
            SpvDetailTabs.tsx trips the silent-drop guard. The guard identifies
            a TabsList by the concatenation of its children's text, so ADDING a
            tab changes that identity and the previous eleven-tab list reads as
            REMOVED. That is a false positive — nothing was dropped — but the
            two honest remedies are an allowlist entry (an owner decision, and
            wrong here because nothing was removed) or a deferral (moving an
            item to improve a count, which is forbidden). A sibling route
            preserves the guard's zero-drop invariant with no loss of
            functionality, and the limitation is recorded in WAVE10_REPORT.md
            rather than worked around silently. */}
        <Route path="/collective/partner/spvs/:id/performance">
          {(params) => (
            <RequireAuth>
              <CollectiveShell>
                <SpvPerformanceRoute spvId={String((params as { id?: string }).id ?? "")} />
              </CollectiveShell>
            </RequireAuth>
          )}
        </Route>
        <Route path="/collective/partner/spvs">
          {() => <Redirect to="/collective/partner/spv-engine" />}
        </Route>
        <Route path="/collective/partner/funds/:id">
          {() => <RequireAuth><CollectiveShell><PartnerFundDetail /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/funds">
          {() => <Redirect to="/collective/partner/spv-engine" />}
        </Route>
        {/* v25.49 Phase-3B — NETWORK group: Messages + Posts. Reuse the shared
            comms surfaces; feed visibility is fail-closed server-side. The
            posts :id route renders the same feed page (kept in the partner
            shell) so post-detail deeplinks/shares don't bounce out of context. */}
        <Route path="/collective/partner/messages">
          {() => <RequireAuth><CollectiveShell><PartnerMessages /></CollectiveShell></RequireAuth>}
        </Route>
        {/* WAVE 19 FE-12 — route table deliberately UNCHANGED. `PartnerPosts`
            itself now branches on the `:id` segment (see PartnerPosts.tsx), so
            the deeplink resolves to the detail page without repointing this
            route. Repointing it to a new component was tried first and the
            silent-drop guard correctly rejected it: a route TARGET signature is
            the (path, component) pair, so `/collective/partner/posts/:id |
            target=PartnerPosts` would have been a REMOVED target. Restored
            verbatim, not allow-listed. */}
        <Route path="/collective/partner/posts/:id">
          {() => <RequireAuth><CollectiveShell><PartnerPosts /></CollectiveShell></RequireAuth>}
        </Route>
        <Route path="/collective/partner/posts">
          {() => <RequireAuth><CollectiveShell><PartnerPosts /></CollectiveShell></RequireAuth>}
        </Route>

        {/* Wave B FIX 8 (I-BUG-006, I-BUG-007) — explicit redirects for legacy/
            unguarded paths that previously fell through to <NotFound> while
            rendering inside <AppShell>. The shell-leak was a P0 trust issue
            for anonymous visitors hitting copy-pasted internal URLs. These
            routes redirect: unauthenticated → /auth/login (with returnTo),
            authenticated → their portal default. */}
        <Route path="/dashboard" component={LegacyDashboardRedirect} />
        <Route path="/cap-table" component={LegacyDashboardRedirect} />
        <Route path="/rounds" component={LegacyDashboardRedirect} />
        {/* v25.43 F13 — /company-profile now renders the founder Company page so
            the first-time create-company onboarding step (?onboarding=1) lands
            on a real create-company surface instead of the legacy dashboard
            redirect. Company.tsx reads ?onboarding=1 and, after a successful
            create, forwards to /founder/subscribe. */}
        <Route path="/company-profile">
          {() => <RequireAuth><FounderCompany /></RequireAuth>}
        </Route>
        <Route path="/invite/:token" component={LegacyInviteRedirect} />

        {/* Wave B FIX 3 (F-BUG-004) — explicit /onboarding handler is the
            public Landing component (registered above), so no change here.
            The legacy /#/onboarding now resolves via the Landing route at
            line ~249. */}

        <Route component={NotFoundOrLogin} />
      </Switch>
    </ErrorBoundary>
  );

  return bare ? routes : <AppShell>{routes}</AppShell>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <RoleProvider>
          <TooltipProvider>
            <Toaster />
            {/* v23.4.3: BrowserRouter (History API) — no hook= prop means wouter
                uses window.history (pushState). Ozan architectural decision #1. */}
            <Router>
              <AppRouter />
            </Router>
          </TooltipProvider>
        </RoleProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
