/**
 * Sprint 10 — M&A Intelligence store + routes.
 *
 * Houses the per-company acquirer-fit scores, comparable-exits library,
 * top strategic-buyer shortlists, and the investor-led M&A initiative
 * thread index.
 *
 * Routes:
 *   GET  /api/investor/ma/intelligence/:companyId
 *   POST /api/investor/ma/initiative          — investor-led M&A start
 *
 * Scores are recomputed deterministically from a small set of inputs so
 * the math reconciles with the unit tests.
 */
/* v25.25.2 — createRequire shim: lazy require() calls in this file must work
   in BOTH the dev/prod tsx runtime (ESM, where `require` is undefined) AND
   the bundled CJS dist. This is the minimal, zero-risk way to unblock the
   v25.25 login 500 ("require is not defined" at userContext.ts:585 and other
   sites) without converting every lazy require() to a static import (which
   would re-introduce circular-import bugs). */
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);

import type { Express, Request, Response } from "express";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import {
  maInitiativeSchema,
  type MaIntelligence,
  type MaInitiativePayload,
} from "@shared/schema";
import { emitSync } from "./sprint10Telemetry";
import { DEMO_SEED_ENABLED } from "./lib/demoGate";
/* v25.44 ROUND 2 (BLOCKER 1) — shared M&A authz gate + real stored-profile
 * source. The legacy per-company endpoint below MUST apply the exact same
 * privacy tiers as /api/collective/ma-intel. */
import { getUserContext } from "./lib/userContext";
import { decideMaAccess } from "./lib/maAuthzGate";
import { deriveMaIntelFromProfile, readMaReadinessNarrative } from "./lib/maProfileSource";

/* ----------------- deterministic acquirer-fit math ----------------- */

/**
 * Compute acquirer-fit score from a 6-feature vector. Each feature in [0,1].
 * Weighted sum × 100; rounded to nearest integer; clamped.
 *
 *   weights = { pmf 0.20, tech 0.20, mgmt 0.15, growth 0.15, share 0.10, lowChurn 0.20 }
 */
export function computeAcquirerFitScore(features: {
  pmf: number; tech: number; mgmt: number; growth: number; share: number; lowChurn: number;
}): number {
  const w = { pmf: 0.20, tech: 0.20, mgmt: 0.15, growth: 0.15, share: 0.10, lowChurn: 0.20 };
  const raw =
    features.pmf * w.pmf +
    features.tech * w.tech +
    features.mgmt * w.mgmt +
    features.growth * w.growth +
    features.share * w.share +
    features.lowChurn * w.lowChurn;
  const score = Math.round(raw * 100);
  return Math.max(0, Math.min(100, score));
}

/** Filter comparable exits to last `windowMonths` and within sector tag. */
export function filterComparableExits<T extends { date: string; sector: string }>(
  comps: T[],
  asOfIso: string,
  sector: string,
  windowMonths = 24,
): T[] {
  const asOf = new Date(asOfIso).getTime();
  const cutoff = asOf - windowMonths * 30 * 24 * 60 * 60 * 1000;
  return comps.filter((c) => {
    const t = new Date(c.date).getTime();
    return Number.isFinite(t) && t >= cutoff && t <= asOf && c.sector === sector;
  });
}

/* ----------------- seeded data per company ----------------- */
// DEMO SEED — not production data. The maps below are retained ONLY as
// optional demo-mode seed content (gated by DEMO_SEED_ENABLED in
// getMaIntelligenceFor). v25.44 ROUND 2 removed them from BOTH the legacy
// per-company endpoint and the Collective aggregation; real M&A intelligence
// is now derived from stored Company Profile Step 4 fields
// (see server/lib/maProfileSource.ts). Do NOT reintroduce these into any
// authenticated production read path.

const COMPS_LIBRARY: Array<{ target: string; acquirer: string; date: string; valuationUsd: number; revenueMultiple: number; sector: string }> = [
  { target: "BridgeFX",     acquirer: "Visa",      date: "2025-11-04", valuationUsd:  680_000_000, revenueMultiple: 11.4, sector: "Fintech" },
  { target: "Quill Pay",    acquirer: "Stripe",    date: "2025-08-19", valuationUsd:  340_000_000, revenueMultiple:  9.2, sector: "Fintech" },
  { target: "Astra Settle", acquirer: "Adyen",     date: "2024-12-12", valuationUsd:  220_000_000, revenueMultiple:  8.0, sector: "Fintech" },
  { target: "Cordis Bio",   acquirer: "Roche",     date: "2025-09-30", valuationUsd: 1_100_000_000, revenueMultiple: 18.5, sector: "Biotech" },
  { target: "MimicLabs",    acquirer: "Illumina",  date: "2024-11-21", valuationUsd:  410_000_000, revenueMultiple:  9.4, sector: "Biotech" },
  { target: "Ardent Care",  acquirer: "Teladoc",   date: "2025-04-10", valuationUsd:  280_000_000, revenueMultiple:  6.8, sector: "Digital Health" },
  { target: "Vesta Robotics", acquirer: "Rockwell", date: "2025-07-01", valuationUsd:  520_000_000, revenueMultiple:  7.2, sector: "Industrial Automation" },
  { target: "OnyxAI",       acquirer: "ServiceNow", date: "2025-10-08", valuationUsd:  890_000_000, revenueMultiple: 14.0, sector: "AI Infrastructure" },
  { target: "Bristle Grid", acquirer: "Schneider", date: "2025-02-14", valuationUsd:  310_000_000, revenueMultiple:  6.0, sector: "Climate / Grid" },
];

// DEMO SEED — not production data. (see note above)
const COMPANY_FEATURES: Record<string, {
  sector: string;
  pmf: number; tech: number; mgmt: number; growth: number; share: number; lowChurn: number;
  buyers: Array<{ name: string; rationale: string; recentActivity: string }>;
}> = {
  co_novapay: {
    sector: "Fintech",
    pmf: 0.78, tech: 0.85, mgmt: 0.80, growth: 0.74, share: 0.18, lowChurn: 0.92,
    buyers: [
      { name: "Stripe",      rationale: "Cross-border B2B payments overlap; Stripe has acquired adjacent rails",       recentActivity: "Acquired Quill Pay 2025-08; rumored interest in agentic-AI routing" },
      { name: "Visa",        rationale: "Visa Direct expansion; agentic-AI orchestration is a strategic gap",          recentActivity: "Acquired BridgeFX 2025-11 for $680M" },
      { name: "Adyen",       rationale: "B2B settlement platform; AI-routing complements unified commerce",            recentActivity: "Acquired Astra Settle 2024-12; expanding APAC corridor" },
    ],
  },
  co_arboreal: {
    sector: "Digital Health",
    pmf: 0.62, tech: 0.70, mgmt: 0.68, growth: 0.85, share: 0.06, lowChurn: 0.81,
    buyers: [
      { name: "Teladoc",     rationale: "Closed-loop coaching slots into chronic-care offering",                      recentActivity: "Acquired Ardent Care 2025-04" },
      { name: "Oura",        rationale: "Wearable + at-home labs is a horizontal expansion play",                     recentActivity: "Series E 2025-10; biomarker partnerships" },
      { name: "UnitedHealth", rationale: "Optum behavioral health rollup; payer reimbursement aligned",                recentActivity: "Optum acquired Persona Health 2025-06" },
    ],
  },
  co_quanta: {
    sector: "Industrial Automation",
    pmf: 0.74, tech: 0.82, mgmt: 0.71, growth: 0.66, share: 0.11, lowChurn: 0.86,
    buyers: [
      { name: "Rockwell",    rationale: "Buying autonomy stack to round out factory-floor portfolio",                 recentActivity: "Acquired Vesta Robotics 2025-07 for $520M" },
      { name: "Siemens",     rationale: "Sinumerik strategy slots in CV-driven QC modules",                            recentActivity: "Strategic announcement on AI-perception stack" },
      { name: "ABB",         rationale: "Robotics & motion division is consolidating the long-tail",                  recentActivity: "Open M&A mandate Q1 2026" },
    ],
  },
  co_kelvin: {
    sector: "Climate / Grid",
    pmf: 0.55, tech: 0.69, mgmt: 0.62, growth: 0.71, share: 0.04, lowChurn: 0.78,
    buyers: [
      { name: "Schneider",   rationale: "Microgrid software shortfall; Bristle Grid roll-up template",                recentActivity: "Acquired Bristle Grid 2025-02" },
      { name: "GE Vernova",  rationale: "Distributed-grid software is a stated 2026 priority",                         recentActivity: "Spin-off Q3 2025; greenfield M&A budget" },
      { name: "Hitachi Energy", rationale: "Asia-Pacific grid orchestration build-out",                                recentActivity: "Acquired Lumio 2024-09" },
    ],
  },
  co_helia: {
    sector: "AI Infrastructure",
    pmf: 0.82, tech: 0.88, mgmt: 0.86, growth: 0.91, share: 0.09, lowChurn: 0.94,
    buyers: [
      { name: "ServiceNow",  rationale: "Agent platform expansion; OnyxAI integration playbook is the template",      recentActivity: "Acquired OnyxAI 2025-10 for $890M" },
      { name: "Snowflake",   rationale: "Data + agent runtime convergence; gap in compute orchestration",             recentActivity: "Open M&A budget; multiple rumored bids" },
      { name: "Databricks",  rationale: "Databricks Mosaic acquisition pattern; agent runtime is next",                recentActivity: "Series I 2025-09; aggressive M&A mode" },
    ],
  },
  co_lattice: {
    sector: "Biotech",
    pmf: 0.71, tech: 0.76, mgmt: 0.75, growth: 0.62, share: 0.07, lowChurn: 0.84,
    buyers: [
      { name: "Roche",       rationale: "Diagnostics platform expansion; molecular-foundry is gap",                    recentActivity: "Acquired Cordis Bio 2025-09 for $1.1B" },
      { name: "Illumina",    rationale: "Foundry-as-a-service plays into MimicLabs roll-up",                          recentActivity: "Acquired MimicLabs 2024-11" },
      { name: "Ginkgo Bioworks", rationale: "Vertical roll-up of biofoundries",                                        recentActivity: "Series F 2025-12" },
    ],
  },
};

export function getMaIntelligenceFor(companyId: string, asOfIso = new Date().toISOString()): MaIntelligence {
  // Patch v4: drop the NovaPay default fallback. When demo is off, return null-like
  // baseline so the function does not leak NovaPay buyers to fresh users.
  const f = COMPANY_FEATURES[companyId] ?? (DEMO_SEED_ENABLED ? COMPANY_FEATURES.co_novapay : { sector: "", pmf: 0, tech: 0, mgmt: 0, growth: 0, share: 0, lowChurn: 0, buyers: [] });
  const acquirerFitScore = computeAcquirerFitScore({ pmf: f.pmf, tech: f.tech, mgmt: f.mgmt, growth: f.growth, share: f.share, lowChurn: f.lowChurn });
  // M&A score weights deal-readiness signals (mgmt + lowChurn + tech)
  const maScore = Math.round((f.mgmt * 0.4 + f.lowChurn * 0.4 + f.tech * 0.2) * 100);
  const comps = filterComparableExits(COMPS_LIBRARY, asOfIso, f.sector, 24)
    .map(({ target, acquirer, date, valuationUsd, revenueMultiple }) => ({ target, acquirer, date, valuationUsd, revenueMultiple }));
  const mults = comps.map((c) => c.revenueMultiple).filter((n): n is number => Number.isFinite(n));
  const low  = mults.length ? Math.min(...mults) : 0;
  const high = mults.length ? Math.max(...mults) : 0;
  const intentSignal: MaIntelligence["intentSignal"] =
    acquirerFitScore >= 80 ? "active_negotiation" :
    acquirerFitScore >= 65 ? "inbound" :
    acquirerFitScore >= 45 ? "outbound" : "none";
  return {
    companyId,
    acquirerFitScore,
    maScore,
    intentSignal,
    topStrategicBuyers: f.buyers.slice(0, 3),
    comparableExits: comps,
    revenueMultipleRange: { low, high },
    productMarketFit: Math.round(f.pmf * 100),
    technologyDifferentiation: Math.round(f.tech * 100),
    customerConcentration: Math.round((1 - f.share) * 100),
    growthRate: Math.round(f.growth * 100),
    marketShare: Math.round(f.share * 100),
    managementTeamStrength: Math.round(f.mgmt * 100),
  };
}

/* ----------------- investor-led initiatives ----------------- */
type Initiative = MaInitiativePayload & {
  id: string;
  createdAt: string;
  threadId: string;
  investorUserId: string;
};
const initiatives: Initiative[] = [];

export function getInitiatives(): Initiative[] {
  return initiatives.slice();
}

export function clearInitiatives(): void {
  initiatives.length = 0;
}

/**
 * v25.10 fix C4 — hydrate the initiatives array from kv_maInitiativesStore
 * on boot so initiatives created in a previous process are still visible.
 * Called from HYDRATE_ORDER in lib/hydrateStores.ts.
 */
export function hydrateMaInitiativesStore(): number {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { hydrateEntries } = require("./lib/storePersistenceShim");
    const rows = hydrateEntries("maInitiativesStore") as Array<[string, Initiative]>;
    let n = 0;
    for (const [, init] of rows) {
      if (init && !initiatives.some((x) => x.id === init.id)) {
        initiatives.push(init);
        n++;
      }
    }
    return n;
  } catch {
    return 0;
  }
}

export function registerMaIntelligenceRoutes(app: Express): void {
  /**
   * v25.44 ROUND 2 (BLOCKER 1) — legacy per-company M&A intelligence endpoint,
   * now behind the SAME shared privacy gate as /api/collective/ma-intel.
   *
   * Tiers (see server/lib/maAuthzGate.ts):
   *   FULL      — founder/admin/member of the company OR DB admin → all fields
   *               + maReadinessNarrative.
   *   DETAIL    — same-chapter member when shareWithChapter → scores + buyers,
   *               narrative only when NOT redacted.
   *   AGGREGATE — cross-Collective member when shareWithCollective → scores +
   *               sector + buyer COUNT only (NO buyer names/rationale/narrative).
   *   NONE      → 403.
   *
   * The data itself is now derived from REAL stored Step 4 profile fields
   * (deriveMaIntelFromProfile), NOT the static COMPANY_FEATURES mocks.
   */
  app.get("/api/investor/ma/intelligence/:companyId", async (req: Request, res: Response) => {
    const companyId = String(req.params.companyId ?? "");
    const ctx = await getUserContext(req);
    const userId = ctx?.userId;
    if (!userId) {
      res.status(401).json({ ok: false, error: "missing_identity" });
      return;
    }

    const decision = decideMaAccess({
      companyId,
      userId,
      isAdminFromCtx: ctx?.isAdmin === true,
    });

    // (d) NONE — no access for this requester to this company.
    if (decision.level === "NONE") {
      res.status(403).json({ ok: false, error: "ma_intel_forbidden" });
      return;
    }

    const intel = deriveMaIntelFromProfile(companyId);
    if (!intel) {
      // Company exists in scope policy-wise but has no stored Step 4 data.
      res.status(404).json({ ok: false, error: "ma_intel_not_available" });
      return;
    }

    // (c) AGGREGATE — scores + sector + buyer COUNT only.
    if (decision.level === "AGGREGATE") {
      res.json({
        companyId,
        accessLevel: "AGGREGATE",
        maScore: intel.maScore,
        acquirerFitScore: intel.acquirerFitScore,
        intentSignal: intel.intentSignal,
        productMarketFit: intel.productMarketFit,
        technologyDifferentiation: intel.technologyDifferentiation,
        customerConcentration: intel.customerConcentration,
        growthRate: intel.growthRate,
        marketShare: intel.marketShare,
        managementTeamStrength: intel.managementTeamStrength,
        strategicBuyerCount: intel.topBuyer ? 1 : 0,
      });
      return;
    }

    // (a) FULL / (b) DETAIL — full detail; narrative only when authorized.
    const body: Record<string, unknown> = {
      companyId,
      accessLevel: decision.level,
      maScore: intel.maScore,
      acquirerFitScore: intel.acquirerFitScore,
      intentSignal: intel.intentSignal,
      productMarketFit: intel.productMarketFit,
      technologyDifferentiation: intel.technologyDifferentiation,
      customerConcentration: intel.customerConcentration,
      growthRate: intel.growthRate,
      marketShare: intel.marketShare,
      managementTeamStrength: intel.managementTeamStrength,
      strategicPriorities: intel.strategicPriorities,
      transactionInterests: intel.transactionInterests,
      topStrategicBuyers: decision.canSeeBuyers && intel.topBuyer ? [intel.topBuyer] : [],
    };
    if (decision.canSeeNarrative) {
      body.maReadinessNarrative = readMaReadinessNarrative(companyId) ?? "";
    }
    res.json(body);
  });

  app.post("/api/investor/ma/initiative", (req: Request, res: Response) => {
    const parsed = maInitiativeSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "validation_failed", issues: parsed.error.format() });
    }
    const id = `mai_${randomBytes(8).toString("hex")}`;
    const initiative: Initiative = {
      ...parsed.data,
      id,
      createdAt: new Date().toISOString(),
      threadId: `ch_ma_${parsed.data.companyId}_${id}`,
      // v23.8 D2/W-18 — attribute to the authenticated session user, not a
      // synthetic demo investor.
      investorUserId: req.userContext?.userId ?? "u_unknown",
    };
    initiatives.push(initiative);
    /* v25.10 fix C4 — write-through to DB so the initiative survives a
     * server restart. The legacy in-process array still gets the push so
     * reads in this process see it immediately. */
    try {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { persistEntry } = require("./lib/storePersistenceShim");
      persistEntry("maInitiativesStore", id, initiative);
    } catch {
      /* Non-fatal — the in-process push above still works in this session. */
    }
    const eventType = parsed.data.initiativeType === "lead_initiative"
      ? "ma_initiative_started"
      : "ma_discussion_started";
    const env = emitSync({
      eventType,
      aggregateId: parsed.data.companyId,
      aggregateKind: "company",
      payload: {
        initiativeId: id,
        threadId: initiative.threadId,
        topic: parsed.data.topic,
        buyerShortlist: parsed.data.buyerShortlist ?? [],
        investorUserId: initiative.investorUserId,
      },
      req,
    });
    res.json({ ok: true, initiative, telemetry: env });
  });

  // GET initiatives back for tests + dashboard
  app.get("/api/investor/ma/initiatives", (_req, res) => {
    res.json(initiatives);
  });
}
